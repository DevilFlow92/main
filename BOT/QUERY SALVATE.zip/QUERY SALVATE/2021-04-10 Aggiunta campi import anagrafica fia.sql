USE clc

GO
/*
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
ADD iport DECIMAL(18,3)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add codice_sconto varchar(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add costo_medio DECIMAL(18,5)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add num_quote DECIMAL(18,3)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_sottoscrizione DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_regolamento DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_caricamento DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_valuta_movim DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_stato_man DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add status_mandato SMALLINT
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add VCCRED1 VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add VCIN_CC VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add CABI VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add CAB VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add VCCRED VARCHAR(50)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add iban VARCHAR(50)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add tipo_tassazione SMALLINT
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add cod_ateco VARCHAR(50)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add fatca_status VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add status_crs VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add tipo_doc VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add num_doc VARCHAR(50)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_doc DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add luogo_rilasc_doc VARCHAR(100)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add prov_rilasc_doc VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add sogg_segn_aui VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add autocert_fatca VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add autocert_crs VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add dt_acq_cliente DATETIME
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add cod_sae VARCHAR(10)
ALTER TABLE scratch.L_CESAM_AZ_FIA_ImportAnagrafica
add desc_sae VARCHAR(200)

*/