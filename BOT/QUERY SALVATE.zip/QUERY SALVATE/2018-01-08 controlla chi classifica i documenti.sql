use ScanDB_EPH

SELECT * FROM QTask_R_Pacchetto_Dati where IdIncarico = 

select * FROM T_Pacchetto where IdPacchetto = 'bt06538256'

SELECT * from S_Operatore where IdOperatore = 8339

SELECT * FROM S_OperatoreAutosede join S_Operatore on IdOperatore = IdOperatoreInterno
--lista operatori fittizi