Clear-Host
$error.Clear()


$ErrorActionPreference = "stop"

$jsonPath = $($MyInvocation.MyCommand.path) -replace "ps1", "json"
$conf=gc $jsonPath | Out-String | ConvertFrom-Json



$itextsharpdllpath = "$(Split-Path $($MyInvocation.MyCommand.path))\itextsharp.dll"
$winscpdllpath = "$(Split-Path $($MyInvocation.MyCommand.path))\WinSCPnet.dll"
$blankpagepath = "$(Split-Path $($MyInvocation.MyCommand.path))\BlankPage.pdf"

$stampaPython =$($MyInvocation.MyCommand.path) -replace "ps1","py"
$printIdIncaricoPython = "$(Split-Path $($MyInvocation.MyCommand.path))\PrintIdIncarico.py"

Clear-Host
$error.Clear()

$test = 0 
$locale = 0

$flag_sql_download = 1 #
$flag_sql_select1 = 0
$flag_documents_download = 1 #
$flag_convertto_pdfa = 1 #
$flag_estraiSEPA = 1 #
$flag_estrai2switch = 1 #
$flag_documents_merge = 1 #
$flag_documents_stamp = 1 #
$flag_raggruppa_15 = 1 #
$flag_mergefoldersinpdf = 1 #
$flag_producicsv = 1 #
$flag_create_zip = 1 #
$flag_trasferisci_transferagent = 1 #

$flag_esegui_transizioni = 1 #
$flag_remove_work_folder = 1

if($test -eq 0){
$urlBase = $conf.WebAPI.url
$user = $conf.WebAPI.user
$Password = $conf.WebAPI.pwd
$conn = $conf.SQLConnection.istanzaProdDotNet
}else{
$urlBase = $conf.WebAPI.urlTest
$user = $conf.WebAPI.userTest
$Password = $conf.WebAPI.pwdTest
$conn = $conf.SQLConnection.istanzaTest
}

if($locale -eq 1){
$ghostscript = $conf.GhostScript.pathLocale
$destinazione = $conf.Destinazione.pathLocale

}else{
$ghostscript = $conf.GhostScript.pathServer
$destinazione = $conf.Destinazione.pathServer
}



function Pdf-toPdfa($OutputFile,$InputFile){
$errore = $null
$table = @()
$tablevalue = New-Object System.Object


try{
 & "$GhostScript"  -dBATCH -dNOPAUSE -sDEVICE=pdfwrite -sOutputFile="$OutputFile" "$InputFile"
 }catch{$errore = $error
 
 
 
 }finally{if($errore -eq $null){
        $tablevalue | Add-Member -MemberType NoteProperty -Name "IsOk" -Value 1
        $table += $tablevalue 
 }else{
        $tablevalue | Add-Member -MemberType NoteProperty -Name "IsOk" -Value 0
        $table += $tablevalue 
 }}
        $table      
 }
 


function Test-FileLock {
  param (
    [parameter(Mandatory=$true)][string]$Path
  )

  $oFile = New-Object System.IO.FileInfo $Path

  if ((Test-Path -Path $Path) -eq $false) {
    return $false
  }

  try {
    $oStream = $oFile.Open([System.IO.FileMode]::Open, [System.IO.FileAccess]::OpenWrite, [System.IO.FileShare]::None)

    if ($oStream) {
      $oStream.Close()
    }
    $false
  } catch {
    # file is locked by a process.
    return $true
  }
}


function Merge-pdf(){
    [CmdletBinding()]
    param(
        [string]$workingDirectory,
        [string]$fileOutPut
    )
    [void] [System.Reflection.Assembly]::LoadFrom($itextsharpdllpath);
    $pdfs = ls $workingDirectory -recurse | where {-not $_.PSIsContainer -and $_.Extension -imatch "^\.pdf$"} | sort{$_.Name};
    $output = $fileOutPut
    $op = [System.IO.FileMode]::OpenOrCreate
    $fileStream = New-Object System.IO.FileStream($output, $op);
    $document = New-Object iTextSharp.text.Document;
    $pdfCopy = New-Object iTextSharp.text.pdf.PdfCopy($document, $fileStream);
    $document.Open();

    foreach ($pdf in $pdfs) {
        $reader = New-Object -typeName iTextSharp.text.pdf.PdfReader -ArgumentList $($pdf.FullName);
        $pdfCopy.AddDocument($reader);
        $reader.Dispose(); 
    }
    

    $pdfCopy.Dispose();
    $document.Dispose();
    $fileStream.Dispose();
    
}



function Add-StampToPdf($localDestFile , $path_text)
{
	[void][System.Reflection.Assembly]::LoadFrom($itextsharpdllpath);

	#region fontsettings
	$baseFont = [iTextSharp.text.pdf.BaseFont]::CreateFont([iTextSharp.text.pdf.BaseFont]::HELVETICA,[System.Text.Encoding]::ASCII.EncodingName,"false")
	$fontSize = 10.0
	$fcolor = New-Object iTextSharp.text.BaseColor (0,0,0)
	#calculating the angel of the stamp with trigometrics the angel is around 45� in an A4 page
	$textAngle = ([System.Math]::Atan2($pageSize.Height, $pageSize.Width) + (0/[System.Math]::PI))*1.0
    
	#endregion



	try{

        $file = New-Object System.IO.FileInfo $localDestFile
	    $reader = New-Object iTextSharp.text.pdf.PdfReader $file.FullName

		$mStream = New-Object System.IO.MemoryStream
		$stamper = New-Object iTextSharp.text.pdf.PdfStamper ($reader, $mStream)
		$padding = 2.0
		$index = 1
		do{		

			$pdfSize = $reader.GetPageSizeWithRotation($index)
			$overContent = $stamper.GetOverContent($index)
			# creating the overLayer
			$overContent.SetRGBColorFill(0, 0, 0)
			$overContent.MoveTo(0 + $padding, 0 + $padding)
			$overContent.LineTo(0 + $padding, $pdfSize.Top - $padding)
			$overContent.LineTo($pdfSize.Right - $padding, $pdfSize.Top - $padding)
			$overContent.LineTo($pdfSize.Right - $padding, 0 + $padding)
			$overContent.ClosePath();

		
				# inserting text
				$overContent.SetRGBColorFill(0, 0, 0)
				$overContent.BeginText()
				$overContent.SetFontAndSize($baseFont,$fontSize)
				$overContent.setColorFill($fcolor);
				$overContent.ShowTextAligned([iTextSharp.text.pdf.PdfContentByte]::ALIGN_LEFT, $path_text, $pdfSize.Width / 12, $pdfSize.Height - 25, $textAngle)
                
				$overContent.EndText()

			$index ++
		}while($index -le $reader.NumberOfPages)
		$stamper.Close();
        $reader.Dispose();
      	$fileStream = [System.IO.File]::OpenWrite($file.FullName)

		$fileStream.Write($mStream.ToArray(), 0, $mStream.ToArray().Length)
        
	}catch{
		throw $_
}finally{
		$fileStream.Dispose()
		$mStream.Dispose()
      }
	
}

function exec-salvariconcilia(
$inseriscitr,
$idincarico,
$idmovimentocontobancario,
$flagriconciliato,
$flagconfermato,
$notaaggiuntiva,
$eliminadatr,
$sp_tiporiconciliazione
){

if(!$sp_tiporiconciliazione){$sp_tiporiconciliazione = "NULL"}

$notaaggiuntiva = $notaaggiuntiva -replace "'","''"
if(!$eliminadatr){
    $eliminadatr = 0
}

if($Comando){
 

$Comando = $ConnectionObject.CreateCommand()

$Exec =   @"

EXEC orga.Salva_Riconciliazione_MovimentoContoBancario	@InserisciTR = $inseriscitr,
                                                        @IdIncarico = $idincarico,
														@IdMovimentoContoBancario = $idmovimentocontobancario,
														@FlagRiconciliato = $flagriconciliato,
														@FlagConfermato = $flagconfermato,
														@NotaAggiuntiva = '$notaaggiuntiva',
                                                        @EliminaDaTR = $eliminadatr,
                                                        @TipoRiconciliazione = $sp_tiporiconciliazione

"@

#$Exec

$Comando.CommandTimeout = 20
$Comando.CommandText = $Exec
$Comando.ExecuteNonQuery()

}

}

Function Create-PDF([iTextSharp.text.Document]$Document
, [string]$File
, [int32]$TopMargin
, [int32]$BottomMargin
, [int32]$LeftMargin
, [int32]$RightMargin
, [string]$Author
)
{

    $Document.SetPageSize([iTextSharp.text.PageSize]::A4)
    $Document.SetMargins($LeftMargin, $RightMargin, $TopMargin, $BottomMargin)
    [void][iTextSharp.text.pdf.PdfWriter]::GetInstance($Document, [System.IO.File]::Create($File))
    $Document.AddAuthor($Author)
}

function Add-Image([iTextSharp.text.Document]$Document
, [string]$File,
 [int32]$Scale = 100
 , [int32]$ScalePercent
 )
{


    [iTextSharp.text.Image]$img = [iTextSharp.text.Image]::GetInstance($File)
   
   if($img.Height > $img.Width){
    [float]$percentage = 700 / $img.Height
    $img.ScalePercent($percentage*100)

   } else {
   [float]$percentage = 450 / $img.Width
    $img.ScalePercent($percentage*100)
    $img.scaleab
   }
   $Document.Add($img)
}

if($flag_sql_download -eq 1){
 # connessione a sql
 $StringaConnessione = "Server=$($conn);Database=$($conf.SQLConnection.database);Trusted_Connection=Yes"
 $ConnectionObject = New-Object System.Data.SqlClient.SqlConnection($StringaConnessione)
 $Comando = New-Object System.Data.SqlClient.SqlCommand 
 
 #tabella che viene popolata all'esecuzione della vista
 $Datatable = New-Object System.Data.DataTable 
 
$Query =   @"

SELECT --top 20
StampaRiconciliati.IdIncarico
	  ,StampaRiconciliati.Documento_id
      ,StampaRiconciliati.CodTipoDocumento
      ,StampaRiconciliati.TipoDocumento
	  ,StampaRiconciliati.Nome_file
      ,StampaRiconciliati.FlagPDF
	  ,StampaRiconciliati.NomeFileOutput
	  ,StampaRiconciliati.EstensioneFileOutput
	  ,StampaRiconciliati.IdMovimentoContoBancario
	  ,StampaRiconciliati.Importo
      ,StampaRiconciliati.ImportoIncarichi
	  ,StampaRiconciliati.DataValuta
	  ,StampaRiconciliati.DataContabile
	  ,StampaRiconciliati.IbanOrdinante
	  ,StampaRiconciliati.Abi
	  ,StampaRiconciliati.Cab
	  ,StampaRiconciliati.RiferimentoOrdinante
	  ,StampaRiconciliati.Causale
      ,StampaRiconciliati.NotaAggiuntiva
      ,StampaRiconciliati.Gruppo
      ,StampaRiconciliati.DettaglioProdotti
FROM rs.v_CESAM_AZ_TransferAgent_StampaRiconciliati StampaRiconciliati 
ORDER BY StampaRiconciliati.IdMovimentoContoBancario, StampaRiconciliati.IdIncarico

"@
    
 #apro la connessione a sql
 $ConnectionObject.Open()
 
 $Comando = $ConnectionObject.CreateCommand()
 $Comando.CommandTimeout = 10000
 $Comando.CommandText = $Query
 
 $DataSetDiRitorno = $null
 $DataSetDiRitorno = $Comando.ExecuteReader()
 

 $DataTable.Load($DataSetDiRitorno)
  #chiudo la connessione a sql

 $ConnectionObject.close()



if($flag_sql_select1 -eq 1){
 $Datatable = $Datatable | Select-Object #-First 30

 }

 $Datatable | Add-Member -MemberType NoteProperty -Name "IsOK" -Value $null
 
}

$TempStampa = @()
 $TempStampa = New-Object System.Data.DataTable 
 $column1 = New-Object System.Data.DataColumn "IdIncarico",([INT])
 $TempStampa.Columns.Add($column1)
 $column2 = New-Object System.Data.DataColumn "Importo",([DECIMAL])
 $TempStampa.Columns.add($column2)
 $column3 = New-Object System.Data.DataColumn "SommaOperazioniIncarichi", ([DECIMAL])
 $TempStampa.Columns.Add($column3)
 $column4 = New-Object System.Data.DataColumn "DataValuta",([STRING])
 $TempStampa.Columns.Add($column4)
 $column5 = New-Object System.Data.DataColumn "DataContabile",([STRING])
 $TempStampa.Columns.Add($column5)
 $column6 = New-Object System.Data.DataColumn "ABI",([STRING])
 $TempStampa.Columns.Add($column6)
 $column7 = New-Object System.Data.DataColumn "CAB",([STRING])
 $TempStampa.Columns.Add($column7)
 $column8 = New-Object System.Data.DataColumn "RiferimentoOrdinante",([STRING])
 $TempStampa.Columns.Add($column8)
 $column9 = New-Object System.Data.DataColumn "Causale",([STRING])
 $TempStampa.Columns.Add($column9) 
 $column10 = New-Object System.Data.DataColumn "NotaUfficioBonifici",([STRING])
 $TempStampa.Columns.Add($column10)
 $column11 = New-Object System.Data.DataColumn "IdMovimentoContoBancario",([INT])
 $TempStampa.Columns.Add($column11)
 $column12 = New-Object System.Data.DataColumn "Documento_id",([INT])
 $TempStampa.Columns.ADD($column12)
 $COLUMN13 = New-Object System.Data.DataColumn "TipoDocumento",([STRING])
 $TempStampa.Columns.ADD($column13)
 $column14 = New-Object System.Data.DataColumn "Gruppo",([STRING])
 $TempStampa.Columns.ADD($column14)
 $COLUMN15 = New-Object System.Data.DataColumn "IsOK",([STRING])
 $TempStampa.Columns.ADD($column15)


  

if($flag_documents_download -eq 1){


# scratch directory
$data = $null
$data = Get-Date -Format "dd-MM-yyyy"
$ora = $null
$ora = Get-Date -Format "HH-mm"
$scratchname=$($conf.ScratchName)
$scratchDir="$env:TEMP\$scratchname"
$scratchSubDir = "$scratchDir\work"

$log = @()
$logfile = "$(Split-Path $($MyInvocation.MyCommand.path))\LOG\$data-$ora.txt"

 
if(Test-Path $scratchDir){

Remove-Item $scratchDir -Recurse -Force
  
}
 mkdir $scratchDir | Out-Null
 mkdir $scratchSubDir | Out-Null


$servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
    $headerToken =Invoke-RestMethod �Uri "$urlBase/Autenticazione/NomeHeaderTokenSessione"
    $credenziali = @{ Username = $User; Password = $Password} | ConvertTo-Json
    $token = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Autenticazione/Autentica" -Body $credenziali
    $headers = @{"$headerToken" = $token }
    $sessione = Invoke-RestMethod -ContentType "application/json" -Method Get -Uri "$urlBase/Autenticazione/Sessione" -Headers $headers

$DataTableIncarichi = $Datatable | select IdIncarico, Documento_id, Nome_file, FlagPDF, IdMovimentoContoBancario, NomeFileOutput, EstensioneFileOutput, IsOK, Gruppo -Unique


$fileblankprecedente = $null

$DataTableIncarichi | ForEach-Object {

$idincarico = $null
$iddocumento = $null
$filePath = $null
$filepathblankpage = $null

$foldername = $null
$foldername = $_.Gruppo


$idincarico = $_.IdIncarico
$iddocumento = $_.Documento_id
$idmovimento = $_.IdMovimentoContoBancario

if(!(Test-Path "$scratchSubDir\$data-$ora-$foldername")){

                mkdir "$scratchSubDir\$data-$ora-$foldername" | Out-Null
              }

if(Test-Path "$scratchSubDir\$data-$ora-$foldername\$($_.IdMovimentoContoBancario)_$($_.IdIncarico).pdf" -PathType Leaf){

}else{
Copy-Item $blankpagepath -Destination "$scratchSubDir\$data-$ora-$foldername\$($_.IdMovimentoContoBancario)_$($_.IdIncarico).pdf"
}
$filepathblankpage = "$scratchSubDir\$data-$ora-$foldername\$($_.IdMovimentoContoBancario)_$($_.IdIncarico).pdf"
$filePath = "$scratchSubDir\$data-$ora-$foldername\$($_.NomeFileOutput)$($_.EstensioneFileOutput)"

Write-Host $iddocumento -ForegroundColor Yellow
                    $servicePoint.CloseConnectionGroup("")
                   $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
                   Invoke-RestMethod -ContentType "application/json" -Method GET -Uri "$urlBase/Incarico/$idincarico/Documento/$iddocumento/contenuto" -Headers $headers -OutFile $filePath
                           
                   $servicePoint.CloseConnectionGroup("")

if($_.FlagPDF -ne 1){

    Write-Host "Conversione file in pdf"
    $nomePDF = $null
    $nomePDF = "$($_.NomeFileOutput).pdf"

    $filepdf = $null
    $filepdf = "$(Split-Path $filePath)\$nomePDF"

    $pdf = New-Object iTextSharp.text.Document

    Create-PDF -Document $pdf -file $filepdf -TopMargin 20 -BottomMargin 20 -LeftMargin 20 -RightMargin 20 -Author "Fiori"
    $pdf.open()
    Add-Image -Document $pdf -file $filePath
    $pdf.close()

    $filePath = $filepdf

}

<#
$newfilepath = $null
$newfilepath = python $printIdIncaricoPython "$idincarico" "$filepath"

Remove-Item $filePath
Rename-Item -Path $newfilepath -NewName "$($_.NomeFileOutput)$($_.EstensioneFileOutput)"
#>



if($flag_convertto_pdfa -eq 1){


$filePathblankpage_c = $null
$filePathblankpage_c = $filepathblankpage -replace "\.pdf","_c.pdf"

$filePath_c = $null
$filePath_c = $filePath -replace "\.pdf","_c.pdf"

$PDFTOPDFA = $null

$PDFTOPDFA = Pdf-toPdfa -OutputFile $filePathblankpage_c -InputFile $filepathblankpage 


$PDFTOPDFA = Pdf-toPdfa -OutputFile $filePath_c -InputFile $filePath 


#write-host $PDFTOPDFA -ForegroundColor red
IF($($PDFTOPDFA.IsOk) -eq 1){
$_.IsOk = 1

$log += "convertito $filepathblankpage in $filePathblankpage_c"
$log += "convertito $filepath in $filePath_c"


Remove-Item $filepathblankpage -Recurse -Force | Out-Null
Rename-Item -Path $filePathblankpage_c -NewName $filepathblankpage

$fileblankprecedente = $filepathblankpage

Remove-Item $filePath -Recurse -Force | Out-Null
Rename-Item -Path $filePath_c -NewName $filePath



if($flag_documents_stamp -eq 1){

    $DatatableMovimenti = $Datatable | Where-Object{ $_.IdIncarico -Match $idincarico -and $_.IdMovimentoContoBancario -match $idmovimento}  | Select IdMovimentoContoBancario, Importo, ImportoIncarichi, DataValuta, DataContabile, Abi, Cab, RiferimentoOrdinante, Causale, NotaAggiuntiva, Gruppo, DettaglioProdotti -Unique 

    #foreach ($r in $DataTableMovimenti){
    $idmovimentocontobancario = $null
    $importo = $null
    $datavaluta = $null
    $datacontabile = $null
    $abi = $null
    $cab = $null
    $riferimentoordinante = $null
    $causale = $null
    $notaaggiuntiva = $null
    $gruppo = $null
    $importoincarichi = $null
    $dettaglioprodotti = $null
    
    <#
    $idmovimentocontobancario = $r.IdMovimentoContoBancario
    $importo = $r.Importo
    $datavaluta = $r.DataValuta
    $datacontabile = $r.DataContabile
    $abi = $r.Abi
    $cab = $r.Cab
    $riferimentoordinante = $r.RiferimentoOrdinante
    $causale = $r.Causale
    $notaaggiuntiva = $r.NotaAggiuntiva
    #>
    
    $idmovimentocontobancario = $DatatableMovimenti.IdMovimentoContoBancario -join "�"
    $importo = $DatatableMovimenti.Importo -join "�"
    $datavaluta = $DatatableMovimenti.DataValuta -join "�"
    $datacontabile = $DatatableMovimenti.DataContabile -join "�"
    $abi = $DatatableMovimenti.Abi -join "�"
    $cab = $DatatableMovimenti.Cab -join "�"
    $riferimentoordinante = $DatatableMovimenti.RiferimentoOrdinante -join "�"
    $causale = $DatatableMovimenti.Causale -join "�"
    $notaaggiuntiva = $DatatableMovimenti.NotaAggiuntiva -join "�"
    $gruppo = $DatatableMovimenti.Gruppo -join "�"
    $importoincarichi = $DatatableMovimenti.ImportoIncarichi -join "�"
    $dettaglioprodotti = $DatatableMovimenti.DettaglioProdotti -join "�"
    
    Write-Host  "$filepathblankpage  Incarico $idincarico" -ForegroundColor Cyan
   
    $stampa = $null
    $stampa = python $stampaPython "$idincarico" "$idmovimentocontobancario" "$importo" "$datavaluta" "$datacontabile" "$abi" "$cab" "$riferimentoordinante" "$causale" "$notaaggiuntiva" "$filepathblankpage" "$importoincarichi" "$dettaglioprodotti"
    
    write-host "stampa: $stampa" -ForegroundColor Magenta
    
    <#
    Add-StampToPdf -localDestFile $filepathblankpage -path_text "Incarico: $idincarico
    Importo: $importo
    DataValuta: $datavaluta
    DataContabile: $datacontabile
    Abi: $abi 
    Cab: $cab
    Riferimento Ordinante: $riferimentoordinante
    Causale: $causale"
    #>
    #}
    if($stampa -eq "OK"){

    $ConnectionObject.Open()

    $log+="Stampato $idincarico IdMovimenti $idmovimentocontobancario"
    foreach($movimento in $DatatableMovimenti){
    if($flag_esegui_transizioni -eq 1){
    exec-salvariconcilia -inseriscitr 0 -eliminadatr 0 -idincarico 0 -idmovimentocontobancario $movimento.IdMovimentoContoBancario -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva "Stampato"
    }
    }
    $ConnectionObject.close()
    
    $Datatable | Where-Object{$_.Documento_id -Match $iddocumento -and $_.IdMovimentoContoBancario -match $idmovimento} | ForEach-Object{
        $row = $null
        $row = $TempStampa.NewRow()
        $row."IdIncarico"                = $_.IdIncarico           
        $row."Importo"                   = $_.Importo             
        $row."DataValuta"                = $_.DataValuta           
        $row."DataContabile"             = $_.DataContabile         
        $row."ABI"                       = $_.ABI                  
        $row."CAB"                       = $_.CAB                   
        $row."RiferimentoOrdinante"      = $_.RiferimentoOrdinante   
        $row."Causale"                   = $_.Causale              
        $row."NotaUfficioBonifici"       = $_.NotaUfficioBonifici    
        $row."IdMovimentoContoBancario"  = $_.IdMovimentoContoBancario
        $row."Documento_id"              = $_.Documento_id           
        $row."TipoDocumento"             = $_.TipoDocumento
        $row."Gruppo"                    = $_.Gruppo
        $row."IsOK"                      = 1
        $TempStampa.rows.add($row) 

 
        }
    }else{ 
        Write-Host "$idincarico IdMovimenti $idmovimentocontobancario $error" -ForegroundColor Red
        $log += "$idincarico IdMovimenti $idmovimentocontobancario $error"
        $Datatable | Where-Object{ $_.Documento_id -Match $iddocumento -and $_.IdMovimentoContoBancario -match $idmovimento} | ForEach-Object{
            $row = $null
            $row = $TempStampa.NewRow()
            $row."IdIncarico"                = $_.IdIncarico           
            $row."Importo"                   = $_.Importo             
            $row."DataValuta"                = $_.DataValuta           
            $row."DataContabile"             = $_.DataContabile         
            $row."ABI"                       = $_.ABI                  
            $row."CAB"                       = $_.CAB                   
            $row."RiferimentoOrdinante"      = $_.RiferimentoOrdinante   
            $row."Causale"                   = $_.Causale              
            $row."NotaUfficioBonifici"       = $_.NotaUfficioBonifici    
            $row."IdMovimentoContoBancario"  = $_.IdMovimentoContoBancario
            $row."Documento_id"              = $_.Documento_id           
            $row."TipoDocumento"             = $_.TipoDocumento
            $row."Gruppo"                    = $_.Gruppo
            $row."IsOK"                      = 0
            $TempStampa.rows.add($row)           
          }

    }

} #end $flag_documents_stamp


}ELSE{

$_.IsOk = 0
Write-Host "errore pdfa IdIncarico $idincarico IdDocumento $iddocumento IdMovimenti $idmovimentocontobancario" -ForegroundColor Red
$log += "errore pdfa IdIncarico $idincarico IdDocumento $iddocumento IdMovimenti $idmovimentocontobancario"
$error
$Datatable | Where-Object{ $_.Documento_id -Match $iddocumento -and $_.IdMovimentoContoBancario -match $idmovimento} | ForEach-Object{
$row = $null
$row = $TempStampa.NewRow()
$row."IdIncarico"                = $_.IdIncarico           
$row."Importo"                   = $_.Importo             
$row."DataValuta"                = $_.DataValuta           
$row."DataContabile"             = $_.DataContabile         
$row."ABI"                       = $_.ABI                  
$row."CAB"                       = $_.CAB                   
$row."RiferimentoOrdinante"      = $_.RiferimentoOrdinante   
$row."Causale"                   = $_.Causale              
$row."NotaUfficioBonifici"       = $_.NotaUfficioBonifici    
$row."IdMovimentoContoBancario"  = $_.IdMovimentoContoBancario
$row."Documento_id"              = $_.Documento_id           
$row."TipoDocumento"             = $_.TipoDocumento
$row."Gruppo"                    = $_.Gruppo
$row."IsOK"                      = 0
$TempStampa.rows.add($row)           
}

if($fileblankprecedente -ne $filepathblankpage){
Remove-Item $filepathblankpage -Recurse -Force | Out-Null
}

Remove-Item $filePathblankpage_c -Recurse -Force | Out-Null

Remove-Item $filePath -Recurse -Force | Out-Null
Remove-Item $filePath_c -Recurse -Force | Out-Null

}

}


} #close foreach

if($flag_documents_merge -eq 1){ 

    $mergingdirs = $Datatable | Where-Object {$_.IsOk -eq 1} | where EstensioneFileOutput -Match ".pdf" | select NomeFileOutput, EstensioneFileOutput, Gruppo -Unique
    
    #$mergingdirs

    foreach($mergingdir in $mergingdirs){

    $foldername = $null 
    $foldername = $_.Gruppo

    $workdir = $null
    $workdir = "$scratchSubDir\$data-$ora-$foldername\$($mergingdir.NomeFileOutput)"

    mkdir $workdir

    #$workdir

    $attachments = $Datatable | Where-Object {$_.IsOk -eq 1} | where NomeFileOutput -Match $($mergingdir.NomeFileOutput)
    $incarico = $Datatable | Where-Object {$_.IsOk -eq 1} | where NomeFileOutput -Match $($mergingdir.NomeFileOutput) | select  IdIncarico, EstensioneFileOutput, Gruppo  -Unique

    "$scratchSubDir\$data-$ora-$foldername\$($incarico.IdIncarico)$($incarico.EstensioneFileOutput)"

    Copy-Item "$scratchSubDir\$data-$ora-$foldername\$($incarico.IdIncarico)$($incarico.EstensioneFileOutput)" $workdir
    Remove-Item  "$scratchSubDir\$data-$ora-$foldername\$($incarico.IdIncarico)$($incarico.EstensioneFileOutput)" -Recurse

    foreach($attachment in $attachments){

    Copy-Item "$scratchSubDir\$data-$ora-$foldername\$($attachment.Nome_file)" "$workdir\$($attachment.Nome_file)"
    Remove-Item  "$scratchSubDir\$data-$ora-$foldername\$($attachment.Nome_file)" -Recurse

    }

    $Files = $null
    $files = Get-ChildItem $workdir
    #$files
    $NFiles = $null
    $NFiles = ($Files | Measure-Object).count
    $OutputFile = $null
    $OutputFile = "$scratchSubDir\$data-$ora-$foldername\$($mergingdir.NomeFileOutput)$($mergingdir.EstensioneFileOutput)"

    if($NFiles -eq 1){
    
    Move-Item "$workdir\$($attachment.Nome_file)" $OutputFile
    Remove-Item $workdir               

    }
    
    if($NFiles -gt 1){

   pushd $workdir
   try{
        Write-Host $workdir -ForegroundColor Green

        Merge-pdf -workingDirectory $workdir -fileOutPut $OutputFile
        }catch{ throw $_}finally{
   popd }

    Remove-Item $workdir -Recurse

    }

     }

} #close if documents merge


if($flag_raggruppa_15 -eq 1){


#MoveTo-folder -filesperfolder 50 -sourcePath $scratchSubDir -destPath $scratchSubDir

}

if($flag_mergefoldersinpdf -eq 1){

$listfolders = $null
$listfolders = Get-ChildItem $scratchSubDir -Recurse | ?{$_.PSIsContainer} 
$folder = $null
foreach($folder in $listfolders){

    $Files = $null
    $files = Get-ChildItem $folder.FullName
    $NFiles = $null
    $NFiles = ($Files | Measure-Object).count

    $outputfolderfile = $null
    $outputfolderfile = "$scratchSubDir\$($folder.Name).pdf"
    
    if($NFiles -eq 1){

    $file = $null
    $file = Get-ChildItem $($folder.FullName) | ForEach-Object {Move-Item $_.FullName $outputfolderfile}

    Remove-Item $($folder.FullName)

    }
    
    if($NFiles -gt 1){

       pushd $($folder.FullName)
   try{
        Write-Host $($folder.FullName) -ForegroundColor DarkYellow
        #Get-ChildItem $folder.FullName
        Merge-pdf -workingDirectory $($folder.FullName) -fileOutPut $outputfolderfile
        }catch{ throw $_}finally{
   popd }

    Remove-Item $($folder.FullName) -Recurse


    }


    }


}

if($flag_producicsv -eq 1){

$TempStampa | export-csv -Delimiter ";" -NoTypeInformation -Path "$scratchSubDir\lista.csv"

}

$TempStampa.clear()


if($flag_create_zip -eq 1){

$zipfolder = $null
$zipfolder = "$scratchDir\$data-$ora.zip"
# zip folder
Add-Type -assembly "system.io.compression.filesystem"
[io.compression.zipfile]::CreateFromDirectory($scratchSubDir, $zipfolder)

}


} #close flag_documents_download

if($flag_remove_work_folder -eq 1){

Remove-Item $scratchSubDir -Recurse -force

}


if($flag_trasferisci_transferagent -eq 1){

$zipfolder_name = $null
$zipfolder_name = $zipfolder | Split-Path -Leaf

if(Test-Path "$($destinazione)\$zipfolder_name"){
    Remove-Item "$($destinazione)\$zipfolder_name" -Recurse -Force
}

Move-Item $zipfolder "$($destinazione)\$zipfolder_name"

} #close if trasferisci TA
 



if($flag_esegui_transizioni -eq 1){

$listatransizioni = $null
$attributodestinazione = $null
$attributodestinazione = 17473

$listatransizioni = $Datatable  | select IdIncarico -Unique
$listatransizioni | ForEach-Object {

$idincarico = $null
$idincarico = $_.IdIncarico

<#
if(-not ([string]::IsNullOrEmpty($_.WorkflowDestinazione))){
 
#transizione
$statoworkflow = $null
$statoworkflow = $_.WorkflowDestinazione
                    $servicePoint.CloseConnectionGroup("")
                   $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
                   Invoke-RestMethod -ContentType "application/json" -Method PUT -Uri "$urlBase/Incarico/$idincarico/statoWorkflow/$statoworkflow" -Headers $headers -Verbose
                   
                    $servicePoint.CloseConnectionGroup("")

#Write-Host $_.WorkflowDestinazione -ForegroundColor Yellow



}
#>
if(-not ([string]::IsNullOrEmpty($attributodestinazione))){

#attributo
$attributo = $null
$attributo = $attributodestinazione

 $servicePoint.CloseConnectionGroup("")
                   $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
                   Invoke-RestMethod -ContentType "application/json" -Method PUT -Uri "$urlBase/Incarico/$idincarico/attributo/$attributo" -Headers $headers -Verbose
                   
                    $servicePoint.CloseConnectionGroup("")

#Write-Host $_.AttributoDestinazione -ForegroundColor DarkYellow

}


} #close foreach



} #close if esegui transizione

$log | Out-File $logfile



#>