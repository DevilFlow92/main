﻿

$Error.Clear()
$ErrorActionPreference="continue"

Clear-Host




############### Author: Padric ######################################
Function Create-PDF([iTextSharp.text.Document]$Document, [string]$File, [int32]$TopMargin, [int32]$BottomMargin, [int32]$LeftMargin, [int32]$RightMargin, [string]$Author)
{

    $Document.SetPageSize([iTextSharp.text.PageSize]::A4)
    $Document.SetMargins($LeftMargin, $RightMargin, $TopMargin, $BottomMargin)
    [void][iTextSharp.text.pdf.PdfWriter]::GetInstance($Document, [System.IO.File]::Create($File))
    $Document.AddAuthor($Author)
}

function Add-Image([iTextSharp.text.Document]$Document, [string]$File, [int32]$Scale = 100, [int32]$ScalePercent)
{


    [iTextSharp.text.Image]$img = [iTextSharp.text.Image]::GetInstance($File)
   
   if($img.Height > $img.Width){
    [float]$percentage = 700 / $img.Height
    $img.ScalePercent($percentage*100)

   } else {
   [float]$percentage = 450 / $img.Width
    $img.ScalePercent($percentage*100)
    $img.scaleab
   }
   
   <#$percentage
   $img.Height

   $img.Width
   #>
  #$img.ScalePercent($ScalePercent)
  
    $Document.Add($img)
}

#######################################################################################



### RICHIAMO CONFIGURAZIONI GENERALI ##############

$jsonPath = $null
$jsonPath = $($MyInvocation.MyCommand.path) -replace "ps1", "json"

$convertImgToPdf = "$(split-path $($MyInvocation.MyCommand.path))\PythonScripts\ConvertIMGtoPDF.py"

$conf=gc $jsonPath | Out-String | ConvertFrom-Json -Verbose

###################################################


##### RICHIAMO FILE / VARIABILI APPOGGIO ##########

$data = Get-Date -Format "yyyyMMdd_HHmmss"

$DirectoryDownloadedFile = $($MyInvocation.MyCommand.path) -replace ".ps1","_$data"

$logfile = "$(Split-path $($MyInvocation.MyCommand.path))\LOG\$data-ConvertImgToPDF.txt"

Add-Type -AssemblyName Microsoft.VisualBasic

$itextsharp = $conf.itextsharp.dllpath

Add-Type -Path $itextsharp

##################################################


# api - autenticazione

    $urlBase = $conf.WebAPI.url

    $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
    
    $headerToken = Invoke-RestMethod -Uri "$urlBase/Autenticazione/NomeHeaderTokenSessione"  

    $credenziali = @{ Username = $conf.WebAPI.user; Password = $conf.WebAPI.pwd } | ConvertTo-Json 
    
    $servicePoint.CloseConnectionGroup("")
    $token = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Autenticazione/Autentica" -Body $credenziali 

    
    $headers = @{ "$headerToken" = $token } 
    
    $servicePoint.CloseConnectionGroup("")
    $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
    $sessione = Invoke-RestMethod -ContentType "application/json" -Method Get -Uri "$urlBase/Autenticazione/Sessione" -Headers $headers 

# fine api - autenticazione - 

<#
Get-ChildItem "C:\ScriptAdminRoot\DocumentiBancoPopolare" -Filter *.JPG | ForEach-Object {
#>



try { [IO.File]::OpenWrite($logfile).close();$check = $true }
catch {$check = $false}

if($check -eq $true){ 

    if(test-path $logfile){

    Remove-Item  $logfile -Force

    }

    
} else {

[Microsoft.VisualBasic.Interaction]::MsgBox("Chiudere file: $logfile", "OKOnly,SystemModal,Exclamation", "LOG")

}

# connessione a sql
 $StringaConnessione = "Server=$($conf.SQLConnection.istanzaProdDotNet);Database=$($conf.SQLConnection.database);Trusted_Connection=Yes"
 $ConnectionObject = New-Object System.Data.SqlClient.SqlConnection($StringaConnessione)
 $Comando = New-Object System.Data.SqlClient.SqlCommand 

 $DataTable = New-Object System.Data.DataTable

$query = @"
SELECT ti.IdIncarico
, tdoc.Documento_id IdDocumento
, tdoc.Nome_file NomeFile
, tdoc.Tipo_Documento 
FROM T_Incarico ti
JOIN T_Documento tdoc ON ti.IdIncarico = tdoc.IdIncarico
AND tdoc.FlagPresenzaInFileSystem = 1
AND tdoc.FlagScaduto = 0
AND tdoc.Nome_file NOT LIKE '%.pdf%'
JOIN export.Z_Cliente_TipoIncarico_TipoDocumento Z ON ti.CodCliente = Z.CodCliente
AND ti.CodTipoIncarico = Z.CodTipoIncarico
AND tdoc.Tipo_Documento = Z.CodTipoDocumento

WHERE ti.CodArea = 8
AND ti.CodCliente = 23
AND ti.CodTipoIncarico IN (
95	--Rimborso Fondi Pensione
				,173 --Disinvestimenti Previdenza
				,99,167	--Sottoscrizioni/Versamenti Fondi Pensione --> cambiare con azimut previdenza
				,102	--Switch Fondi Pensione
				,178	--Varie Fondo Pensione
				,57 --gestione SEPA 
				,572	--Sottoscrizioni Previdenza - Zenith
				,175
				,657		--Sottoscrizioni Previdenza - AZISF
					,661	--Sottoscrizioni Previdenza - Zenith - AZISF
					,658	--Disinvestimenti Previdenza - AZISF
					,656	--Switch Previdenza - AZISF
					,660	--Varie Previdenza - AZISF
					,655	--Gestione SEPA - AZISF	
					,659	--Successioni - Previdenza - AZISF
)

AND ti.DataUltimaTransizione >= DATEADD(DAY,-6,CONVERT(DATE,GETDATE()))

"@

#apro la connessione a sql
 $ConnectionObject.Open()
 
 $Comando = $ConnectionObject.CreateCommand()
 $Comando.CommandTimeout = 10000
 $Comando.CommandText = $Query

 $DataSetDiRitorno = $null
 $DataSetDiRitorno = $Comando.ExecuteReader()
 

 $DataTable.Load($DataSetDiRitorno)


  #chiudo la connessione a sql
 $ConnectionObject.close()

 $TempConversione = @()
 $TempConversione = New-Object System.Data.DataTable 
 $column1 = New-Object System.Data.DataColumn "IdIncarico",([INT])
 $TempConversione.Columns.Add($column1)
 $column2 = New-Object System.Data.DataColumn "IdDocumento",([INT])
 $TempConversione.Columns.ADD($column2)
 $Column3 = New-Object System.Data.DataColumn "NomeFIle",([STRING])
 $TempConversione.Columns.add($Column3)
 $column4 = New-Object System.Data.DataColumn "NomePDF", ([STRING])
 $TempConversione.Columns.add($column4)

 #$TempConversione

 if(!(Test-Path $DirectoryDownloadedFile)){

                mkdir $DirectoryDownloadedFile | Out-Null
              }
                          

              Add-Content -Path $logfile -Value "$data --> cartella creata $DirectoryDownloadedFile"

$DataTable | ForEach-Object {


  $IdIncarico = $null
  $IdIncarico = $_.IdIncarico
  $IdDocumento = $null
  $IdDocumento = $_.IdDocumento
  $NomeFile = $null
  $NomeFile = $_.NomeFile
  $nomePDF = $null
  $nomePDF = $_.NomeFile -replace ".png",".pdf" -replace ".jpg",".pdf" -replace ".jpeg",".pdf"
  
   $row = $null
        $row = $TempConversione.NewRow()
        $row."IdIncarico"                = $IdIncarico        
        $row."IdDocumento"                   = $IdDocumento           
        $row."NomeFile"                = $NomeFile           
        $row."NomePDF"             = $nomePDF       
   $TempConversione.rows.add($row)


  try{

   #download file jpg
     $servicePoint.CloseConnectionGroup("")
     $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)

     $datidocumento = $null
     $datidocumento = Invoke-RestMethod -ContentType "application/json" -Method GET -Uri "$urlBase/Incarico/$IdIncarico/Documento/$IdDocumento" -Headers $headers            
     
     $FilePath = $null
     $FilePath = "$DirectoryDownloadedFile\$NomeFile"

     ##add log if file already exists

     $servicePoint.CloseConnectionGroup("")
     $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
     Invoke-RestMethod -ContentType "application/json" -Method GET -Uri "$urlBase/Incarico/$IdIncarico/Documento/$IdDocumento/contenuto" -Headers $headers -OutFile $filePath

     $filepdf = $null
     $filepdf = "$DirectoryDownloadedFile\$nomePDF"

     
  <#
  ############### CREATE PDF #############################
  $pdf = New-Object iTextSharp.text.Document
  
  #CREATE PDF FROM JPG
  Create-PDF -Document $pdf -File $filepdf -TopMargin 20 -BottomMargin 20 -LeftMargin 20 -RightMargin 20 -Author "Fiori"
  $pdf.Open()
  Add-Image -Document $pdf -File $filepath
  $pdf.Close()
  
  #######################################################
  #>

  $conversione = python $convertImgToPdf "$filepath"
  Write-Host "Conversione: $conversione" -ForegroundColor Magenta

  #$datidocumento
  Write-Host "trasferimento Documento $nomePDF IdIncarico $IdIncarico" -ForegroundColor Cyan
  Add-Content -Path $logfile -Value "$data --> trasferimento Documento $nomePDF IdIncarico $IdIncarico"


  # imbarco pdf creato
  $ParametriDocumentoDaAssociare = $null
  $ParametriDocumentoDaAssociare = @{ IdIncarico = $IdIncarico
  ; CodTipoDocumento = $($datidocumento.Tipo_Documento)
  ; NomeFile = $nomePDF
  ; Contenuto = [Convert]::ToBase64String([IO.File]::ReadAllBytes($filepdf))
   
  } | ConvertTo-Json
      $servicePoint.CloseConnectionGroup("")
      $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
      $documentoid = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Documento" -Headers $headers -Body $ParametriDocumentoDaAssociare
  
  $parametriDocumentoEliminare = $null
  $parametriDocumentoEliminare = @{FlagScaduto = 1

  } | ConvertTo-Json

  Invoke-RestMethod -ContentType "application/json" -Method Put -Uri "$urlBase/Documento/$IdDocumento" -Headers $headers -Body $parametriDocumentoEliminare


  }catch{
  $Error 
   Add-Content -path $logfile -Value "$data ---> Errore sul file $Filename ---> $Error"

  }#try-catch esegui download jpg, creazione pdf e imbarco pdf, eliminazione jpg


} #foreach                           


$csvfile = "$(Split-Path $($MyInvocation.MyCommand.path))\LISTE\$data-$ora-lista.csv"
$TempConversione | Export-Csv -Delimiter ";" -NoTypeInformation -Path $csvfile
$TempConversione.clear()

Remove-Item $DirectoryDownloadedFile -Recurse
Add-Content -Path $logfile -Value "$data ---> Cartella di appoggio rimossa:"
Add-Content -Path $logfile -Value "$DirectoryDownloadedFile"

$mailBody=@"
$MessaggioErrore
Log in allegato.

Server: $env:COMPUTERNAME
ScriptPath: $($MyInvocation.MyCommand.Path)

"@
$mailSubject="Conversione Image to PDF"
$mailParams =@{}

$conf.mailing  | Get-Member -MemberType NoteProperty | %{
    $mailParams.Add($_.name,$conf.mailing."$($_.name)")
}

$mailParams.Add("Body",$mailbody)
$mailParams.Add("Subject",$mailSubject)

#$mailFrom=$($conf.mailing.from)
#$mailTo=$($conf.mailing.to)
#$mailCC=$($conf.mailing.cc)
#$mailSmtp=$($conf.mailing.smtp)

if($DataTable.Rows.Count -gt 0){
Send-MailMessage @mailParams -Encoding utf8 -Attachments $logfile, $csvfile
}