﻿

$Error.Clear()
$ErrorActionPreference="continue"

Clear-Host




############### Author: Padric ######################################
Function Create-PDF([iTextSharp.text.Document]$Document, [string]$File, [int32]$TopMargin, [int32]$BottomMargin, [int32]$LeftMargin, [int32]$RightMargin, [string]$Author)
{

    $Document.SetPageSize([iTextSharp.text.PageSize]::A4)
    $Document.SetMargins($LeftMargin, $RightMargin, $TopMargin, $BottomMargin)
    [void][iTextSharp.text.pdf.PdfWriter]::GetInstance($Document, [System.IO.File]::Create($File))
    $Document.AddAuthor($Author)
}

function Add-Image([iTextSharp.text.Document]$Document, [string]$File, [int32]$Scale = 100, [int32]$ScalePercent)
{


    [iTextSharp.text.Image]$img = [iTextSharp.text.Image]::GetInstance($File)
   
   if($img.Height > $img.Width){
    [float]$percentage = 700 / $img.Height
    $img.ScalePercent($percentage*100)

   } else {
   [float]$percentage = 450 / $img.Width
    $img.ScalePercent($percentage*100)
    $img.scaleab
   }
   
   <#$percentage
   $img.Height

   $img.Width
   #>
  #$img.ScalePercent($ScalePercent)
  
    $Document.Add($img)
}

#######################################################################################



### RICHIAMO CONFIGURAZIONI GENERALI ###

$jsonPath = $null
$jsonPath = $($MyInvocation.MyCommand.path) -replace "ps1", "json"

$convertImgToPdf = "$(split-path $($MyInvocation.MyCommand.path))\PythonScripts\ConvertIMGtoPDF.py"

$conf=gc $jsonPath | Out-String | ConvertFrom-Json -Verbose

###################################################


##### RICHIAMO FILE / VARIABILI APPOGGIO ##########

$data = Get-Date -Format "yyyyMMdd_HHmmss"

$DirectoryDownloadedFile = $($MyInvocation.MyCommand.path) -replace ".ps1","_$data"

$logfile = $($MyInvocation.MyCommand.path) -replace ".ps1" ,".txt"

Add-Type -AssemblyName Microsoft.VisualBasic

$itextsharp = $conf.itextsharp.dllpath

Add-Type -Path $itextsharp

##################################################


# api - autenticazione

    $urlBase = $conf.WebAPI.url

    $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
    
    $headerToken = Invoke-RestMethod -Uri "$urlBase/Autenticazione/NomeHeaderTokenSessione"  

    $credenziali = @{ Username = $conf.WebAPI.user; Password = $conf.WebAPI.pwd } | ConvertTo-Json 
    
    $servicePoint.CloseConnectionGroup("")
    $token = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Autenticazione/Autentica" -Body $credenziali 

    
    $headers = @{ "$headerToken" = $token } 
    
    $servicePoint.CloseConnectionGroup("")
    $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
    $sessione = Invoke-RestMethod -ContentType "application/json" -Method Get -Uri "$urlBase/Autenticazione/Sessione" -Headers $headers 

# fine api - autenticazione - 

<#
Get-ChildItem "C:\ScriptAdminRoot\DocumentiBancoPopolare" -Filter *.JPG | ForEach-Object {
#>



try { [IO.File]::OpenWrite($logfile).close();$check = $true }
catch {$check = $false}

if($check -eq $true){ 

    if(test-path $logfile){

    Remove-Item  $logfile -Force

    }

    
} else {

[Microsoft.VisualBasic.Interaction]::MsgBox("Chiudere file: $logfile", "OKOnly,SystemModal,Exclamation", "LOG")

}

try { [IO.File]::OpenWrite($logfile).close();$check = $true }
catch {$check = $false}

if($check -eq $true){

    [Microsoft.VisualBasic.Interaction]::MsgBox("Il file deve essere un csv e deve avere le colonne: IdIncarico,IdDocumento,NomeFile", "OKOnly,SystemModal,Information", "Select File")

 

        #search file to import

        Add-Type -AssemblyName System.Windows.Forms
        $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
            Multiselect = $false # Multiple files can be chosen
        	Filter = 'Csv (*.csv)|*.csv' # Specified file types
        }
     
        [void]$FileBrowser.ShowDialog()
        $File = $null
        $file = $FileBrowser.FileName;

        $log = @()
 
  if($File){
        Add-Content -Path $logfile -Value "$data --> file $File"

 
        $array = $null
        $array = Import-Csv -delimiter ";" $File

        #write-host $array.count  -ForegroundColor Green
        $numeroincarichi = $null
        $numeroincarichi = $array.idIncarico.Count
        
        if($numeroincarichi -gt 500){
            
            Add-Content -Path $logfile -Value "$data --> Numero documenti superiore a 500"

            #dialogue box
 
            [Microsoft.VisualBasic.Interaction]::MsgBox("Il file può contenere max 500 righe", "OKOnly,SystemModal,Critical", "Input file")

        }else{
              
              [int]$contatore = 0

              
              if(!(Test-Path $DirectoryDownloadedFile)){

                mkdir $DirectoryDownloadedFile | Out-Null
              }

              $data = Get-Date -Format "yyyyMMdd_HHmmss"

              Add-Content -Path $logfile -Value "$data --> cartella creata $DirectoryDownloadedFile"
              
              $array | ForEach-Object {
              
                $contatore = $contatore +1
             
              
                if($($contatore/$numeroincarichi) -eq 0.25){

                 write-host $($contatore/$numeroincarichi) -ForegroundColor Green
                 Add-Content -Path $logfile -Value "$data --> avanzamento 25%"

                }

                if($($contatore/$numeroincarichi) -eq 0.50){

                 write-host $($contatore/$numeroincarichi) -ForegroundColor Green
                 Add-Content -Path $logfile -Value "$data --> avanzamento 50%"
                }

                if($($contatore/$numeroincarichi) -eq 0.75){

                 write-host $($contatore/$numeroincarichi) -ForegroundColor Green
                 Add-Content -Path $logfile -Value "$data --> avanzamento 75%"
                }

                if($($contatore/$numeroincarichi) -eq 1){
                 write-host $($contatore/$numeroincarichi) -ForegroundColor Green
                 Add-Content -Path $logfile -Value "$data --> avanzamento 100%"
                }


                $IdIncarico = $null
                $IdIncarico = $_.IdIncarico.Trim() 
                $IdDocumento = $null
                $IdDocumento = $_.IdDocumento.trim()
                $NomeFile = $null
                $NomeFile = $_.NomeFile.trim() 
                $nomePDF = $null
                $nomePDF = $_.NomeFile.trim() -replace ".png",".pdf" -replace ".jpg",".pdf" -replace ".jpeg",".pdf"
                
                try{

                 #download file jpg
                   $servicePoint.CloseConnectionGroup("")
                   $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)

                   $datidocumento = $null
                   $datidocumento = Invoke-RestMethod -ContentType "application/json" -Method GET -Uri "$urlBase/Incarico/$IdIncarico/Documento/$IdDocumento" -Headers $headers            
                   
                   $FilePath = $null
                   $FilePath = "$DirectoryDownloadedFile\$NomeFile"

                   ##add log if file already exists

                   $servicePoint.CloseConnectionGroup("")
                   $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
                   Invoke-RestMethod -ContentType "application/json" -Method GET -Uri "$urlBase/Incarico/$IdIncarico/Documento/$IdDocumento/contenuto" -Headers $headers -OutFile $filePath

                   $filepdf = $null
                   $filepdf = "$DirectoryDownloadedFile\$nomePDF"

                   
                
                ############### CREATE PDF #############################
                $pdf = New-Object iTextSharp.text.Document
                
                #CREATE PDF FROM JPG
                Create-PDF -Document $pdf -File $filepdf -TopMargin 20 -BottomMargin 20 -LeftMargin 20 -RightMargin 20 -Author "Fiori"
                $pdf.Open()
                Add-Image -Document $pdf -File $filepath
                $pdf.Close()
                
                #######################################################

                #$datidocumento
                Write-Host "trasferimento Documento $nomePDF IdIncarico $IdIncarico" -ForegroundColor Cyan

                # imbarco pdf creato
                $ParametriDocumentoDaAssociare = $null
                $ParametriDocumentoDaAssociare = @{ IdIncarico = $IdIncarico
                ; CodTipoDocumento = $($datidocumento.Tipo_Documento)
                ; NomeFile = $nomePDF
                ; Contenuto = [Convert]::ToBase64String([IO.File]::ReadAllBytes($filepdf))
                 
                } | ConvertTo-Json
                    $servicePoint.CloseConnectionGroup("")
                    $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
                    $documentoid = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Documento" -Headers $headers -Body $ParametriDocumentoDaAssociare
                
                $parametriDocumentoEliminare = $null
                $parametriDocumentoEliminare = @{FlagScaduto = 1

                } | ConvertTo-Json

                Invoke-RestMethod -ContentType "application/json" -Method Put -Uri "$urlBase/Documento/$IdDocumento" -Headers $headers -Body $parametriDocumentoEliminare


                }catch{
                $Error 
                 Add-Content -path $logfile "$data ---> Errore sul file $Filename ---> $Error"

                }#try-catch esegui download jpg, creazione pdf e imbarco pdf, eliminazione jpg


            } #foreach

        } #else if 500 righe

    } #if file

} #if logfile chiuso
