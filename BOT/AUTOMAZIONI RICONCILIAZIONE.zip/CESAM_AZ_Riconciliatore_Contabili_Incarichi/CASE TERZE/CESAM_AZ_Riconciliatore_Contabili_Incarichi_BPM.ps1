﻿<#


4. storicizzare tutte le riconciliazioni, in modo da non riproporle - anche se l'operatore le disassocia


IMPORTANTE: 

-- aggiungere un ciclo che cicla su tutti gli incarichi associati ad una contabile e flag riconciliato = 0 and statusworkflow = 1 
        su questi deve essere fatto update soltanto nella contabile associata - quindi modificare anche la sp di salvataggio per NON inserire nella TRincaricomovimentocontobancario


#>


Clear-Host
$start = Get-Date

$MessaggioErrore = $null

$jsonPath = $($MyInvocation.MyCommand.path) -replace "ps1", "json"
$conf=gc $jsonPath | Out-String | ConvertFrom-Json

$Error.Clear()
$ErrorActionPreference = "stop"
$flag_connettisql = 1
$flag_estraimovimenti = 1
$flag_estraiincarichi = 1
$flag_eseguiriconciliazione = 1
$flaginserisciadb = 1 #
$livelliRiconciliazione = 5
$logicariconciliazionesingoloconto = 1
$flagvisualizzaparametririconciliazione = 0
$flageseguimodificacontabili = 1 #
$flagmodificariconciliato = 1 #
$flageliminaprecedentiriconciliazioniserictipo1 = 1
$flagabilitacontrolloordinantebeneficiario = 1



$nomescript = [System.IO.Path]::GetFileNameWithoutExtension($jsonPath) 


$log = @()

$scratchname = $nomescript
$scratchDir="$env:TEMP\$scratchname"
if(-not (Test-Path $scratchDir)){
    mkdir $scratchDir | Out-Null
}


$file_risultatiriconciliazione = "$scratchDir\r_$($nomescript)_$($dateformat).csv"
$file_log = "$scratchDir\l_$($nomescript)_$($dateformat).txt"

function exec-salvariconcilia(
$inseriscitr,
$idincarico,
$idmovimentocontobancario,
$flagriconciliato,
$flagconfermato,
$notaaggiuntiva,
$eliminadatr,
$sp_tiporiconciliazione
){

if(!$sp_tiporiconciliazione){$sp_tiporiconciliazione = "NULL"}

$notaaggiuntiva = $notaaggiuntiva -replace "'","''"
if(!$eliminadatr){
    $eliminadatr = 0
}

if($Comando){
 

$Comando = $ConnectionObject.CreateCommand()

$Exec =   @"

EXEC orga.Salva_Riconciliazione_MovimentoContoBancario	@InserisciTR = $inseriscitr,
                                                        @IdIncarico = $idincarico,
														@IdMovimentoContoBancario = $idmovimentocontobancario,
														@FlagRiconciliato = $flagriconciliato,
														@FlagConfermato = $flagconfermato,
														@NotaAggiuntiva = '$notaaggiuntiva',
                                                        @EliminaDaTR = $eliminadatr,
                                                        @TipoRiconciliazione = $sp_tiporiconciliazione

"@

#$Exec

$Comando.CommandTimeout = 20
$Comando.CommandText = $Exec
$Comando.ExecuteNonQuery()

}

}

function logica-riconciliazione (
$statusworkflow
,$idmovimentocontabile
,$tiporiconciliazione
,$idincarico
,$inseriscitr
,$notacontabile
,$eliminadatr
){


if($inseriscitr -eq 1){
    if($tiporiconciliazione-eq 1){
    
        if($statusworkflow -eq 0){

        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                         
        
        
        }else{

        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 1 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                 
        }
        
    
    }
    
    if($tiporiconciliazione -eq 2){
      if($statusworkflow -eq 0){
       
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                   
        
        
        }else{
       
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 1 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                    
        
        }
    
    
    }

    if($tiporiconciliazione -eq 3){
      if($statusworkflow -eq 0){
       
        exec-salvariconcilia -inseriscitr 0 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                    
        
        
        }else{
       
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 1 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                  
        
        }
    
    
    }

    if($tiporiconciliazione -eq 8){
      if($statusworkflow -eq 0){
       
        exec-salvariconcilia -inseriscitr 0 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva "altrocc-$idincarico"                                   
        
        
        }else{
       
        exec-salvariconcilia -inseriscitr 0 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva "altrocc-$idincarico"                                
        
        }
    
    
    }
    
    if($tiporiconciliazione -eq 5){
      if($statusworkflow -eq 0){
        
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                 
        
        
        }else{
        
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 1 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                 
        }
        
       
    }
    
    if($tiporiconciliazione -eq 6){
    
    if($statusworkflow -eq 0){
        
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                 
        
        
        }else{
        
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva $notacontabile -sp_tiporiconciliazione $tiporiconciliazione                                 
        }
    
    
    
    
    }

    if($tiporiconciliazione -eq 7){ #ordinante diverso da beneficiario
    
    if($statusworkflow -eq 0){
        
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva "Ord!=Ben" -sp_tiporiconciliazione $tiporiconciliazione                               
        
        
        }else{
        
        exec-salvariconcilia -inseriscitr 1 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva "Ord!=Ben"   -sp_tiporiconciliazione $tiporiconciliazione                             
        }
    
    
    
    
    }
}else{
    
    if($notacontabile){
    exec-salvariconcilia -inseriscitr 0 -idincarico 0 -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 1 -flagconfermato 1 -notaaggiuntiva "$notacontabile"
    
    }elseif($eliminadatr -eq 0){
  exec-salvariconcilia -inseriscitr 0 -idincarico 0 -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 1 -flagconfermato 0 -notaaggiuntiva "r"                               
        }

    if($eliminadatr -eq 1){
    
    exec-salvariconcilia -eliminadatr 1 -inseriscitr 0 -idincarico $idincarico -idmovimentocontobancario $idmovimentocontabile -flagriconciliato 0 -flagconfermato 0 -notaaggiuntiva ""                               
 

    }
    

}

}



try{

if($flag_connettisql -eq 1){

 # connessione a sql
 $StringaConnessione = "Server=$($conf.SQLConnection.istanza);Database=$($conf.SQLConnection.database);Trusted_Connection=Yes"
 $ConnectionObject = New-Object System.Data.SqlClient.SqlConnection($StringaConnessione)
 $Comando = New-Object System.Data.SqlClient.SqlCommand


if($flag_estraimovimenti -eq 1){
write-host "Estrai movimenti" -ForegroundColor Green
$log += "Estrai movimenti"
 #tabella che viene popolata all'esecuzione della vista
 $Datatable_movimenti = @()
 $Datatable_movimenti = New-Object System.Data.DataTable 
 
$Query_movimenti =   @"


SELECT 	ElencoMovimenti.ImportoIncarichiAssociati,
		ElencoMovimenti.NonRiconciliatoMaAssociatoCorrettamente,
		ElencoMovimenti.IdContoBancario,
		ElencoMovimenti.DataImport,
		ElencoMovimenti.DataValuta,
		ElencoMovimenti.IdContoBancarioPerAnno,
		ElencoMovimenti.NomeConto,
		ElencoMovimenti.ProdottoConto,
		ElencoMovimenti.NumeroConto,
		ElencoMovimenti.IdMovimentoContoBancario,
		ElencoMovimenti.SegnoImporto,
		ElencoMovimenti.Importo,
		ElencoMovimenti.NomeOperazione,
		ElencoMovimenti.IdOperazioneContoBancario,
		ElencoMovimenti.Testo,
		ElencoMovimenti.Gruppo,
		ElencoMovimenti.Gruppo_Automatismo,
		ElencoMovimenti.FlagEseguiControlloOrdinanteBeneficiario 
FROM rs.v_CESAM_Rendicontazione_BPM_ElencoMovimenti  ElencoMovimenti
		


"@
    
    #apro la connessione a sql
 $ConnectionObject.Open()
 
 $Comando = $ConnectionObject.CreateCommand()
 $Comando.CommandTimeout = 500
 $Comando.CommandText = $Query_movimenti
 
 $DataSetDiRitorno = $null
 $DataSetDiRitorno = $Comando.ExecuteReader()
 

 $DataTable_movimenti.Load($DataSetDiRitorno)
    #chiudo la connessione a sql

 $ConnectionObject.close()

    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "IsRiconciliato" -Value 0
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "TipoRiconciliazione" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "IdIncarico" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "Prodotto" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "Cognome" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "Nome" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "RagioneSociale" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "ImportoIncarico" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "NumeroMandato" -Value $null
    $Datatable_movimenti | Add-Member -MemberType NoteProperty -Name "SommaPerCognomeNome" -Value $null
    

    $Datatable_movimenti  = $Datatable_movimenti | 
        Select-Object IsRiconciliato,
        TipoRiconciliazione,
        IdIncarico,Prodotto,ProdottoConto,
        Cognome,
        Nome,
        RagioneSociale,
        ImportoIncarico,
        NumeroMandato,
        SommaPerCognomeNome,
        IdContoBancario,
        IdContoBancarioPerAnno,
        IdMovimentoContoBancario,NomeConto,NumeroConto,
        SegnoImporto,
        Importo,
        NomeOperazione,
        IdOperazioneContoBancario,
        Gruppo,
        Gruppo_Automatismo,
        FlagEseguiControlloOrdinanteBeneficiario,
        @{Name="Testo";Expression ={$_.Testo -replace "IT\d\d\w\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d",""}}, 
        @{Name="Iban";Expression ={$([regex]::Match($_.Testo,"IT\d\d\w\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d")).Value}}              


}

if($flag_estraiincarichi -eq 1){

write-host "Estrai incarichi" -ForegroundColor Green
 $log += "Estrai incarichi"
 #tabella che viene popolata all'esecuzione della vista
 $datatable_incarichi = @()
 $Datatable_incarichi = New-Object System.Data.DataTable 
 
$Query_incarichi =   @"

		

		SELECT 
     	elencoincarichi.IdIncarico,
		elencoincarichi.Prodotto,
		elencoincarichi.IdMovimentoContoBancario,
		elencoincarichi.importomovimentocontobancario,
		elencoincarichi.NonRiconciliatoMaAssociatoCorrettamente,
		elencoincarichi.CodTipoIncarico,
		elencoincarichi.DataUltimaTransizione,
		elencoincarichi.ProgressivoPersona,
		elencoincarichi.CodTipoPersona,
		elencoincarichi.cognome,
		elencoincarichi.ragionesociale,
		elencoincarichi.nome,
		elencoincarichi.Importo,
		elencoincarichi.NumeroMandato,
		elencoincarichi.StatusWF,
		elencoincarichi.CodStatoWorkflowIncarico,
		elencoincarichi.NmandatoNoZero,
		elencoincarichi.SommaPerCognomeNome 
FROM rs.v_CESAM_AZ_Incarichi_AnagraficheClienti_RIC_BPM elencoincarichi
ORDER BY elencoincarichi.IdIncarico ASC





"@
    
    #apro la connessione a sql
 $ConnectionObject.Open()
 
 $Comando = $ConnectionObject.CreateCommand()
 $Comando.CommandTimeout = 500
 $Comando.CommandText = $Query_incarichi
 
 $DataSetDiRitorno = $null
 $DataSetDiRitorno = $Comando.ExecuteReader()
 

 $Datatable_incarichi.Load($DataSetDiRitorno)
    #chiudo la connessione a sql


 $ConnectionObject.close()

 $Datatable_incarichi | Add-Member -MemberType NoteProperty -Name "IsRiconciliato" -Value 0
 $Datatable_incarichi | Add-Member -MemberType NoteProperty -Name "IdMovimentoContoBancaricoInRun" -Value $null
 $Datatable_incarichi | Add-Member -MemberType NoteProperty -Name "TipoRiconciliazioneInRun" -Value $null


}

}

#$Datatable_incarichi =  $Datatable_incarichi | Where-Object {$_.Cognome -match "PIROVANO"}
if($flag_eseguiriconciliazione -eq 1 ){
write-host "start riconciliazione standard $(Get-Date)" -ForegroundColor Green
$log += "start riconciliazione standard $(Get-Date)"



 # connessione a sql
 $StringaConnessione = "Server=$($conf.SQLConnection.istanza);Database=$($conf.SQLConnection.database);Trusted_Connection=Yes"
 $ConnectionObject = New-Object System.Data.SqlClient.SqlConnection($StringaConnessione)
 $Comando = New-Object System.Data.SqlClient.SqlCommand
 $ConnectionObject.Open()
  
 $Tempriconciliazione = @()
 $Tempriconciliazione = New-Object System.Data.DataTable 
 $column1 = New-Object System.Data.DataColumn "idincarico",([STRING])
 $Tempriconciliazione.Columns.Add($column1)
 $column2 = New-Object System.Data.DataColumn "idmovimentocontabile",([INT])
 $Tempriconciliazione.Columns.Add($column2)
 $column3 = New-Object System.Data.DataColumn "idmovimentoincarico",([INT])
 $Tempriconciliazione.Columns.Add($column3)
 $column4 = New-Object System.Data.DataColumn "tiporiconciliazione",([INT])
 $Tempriconciliazione.Columns.Add($column4)
 $column5 = New-Object System.Data.DataColumn "statuswf",([INT])
 $Tempriconciliazione.Columns.Add($column5)
  $column6 = New-Object System.Data.DataColumn "ImportoIncarico",([decimal])
 $Tempriconciliazione.Columns.Add($column6)
  $column7 = New-Object System.Data.DataColumn "ImportoIncaricoSomma",([decimal])
 $Tempriconciliazione.Columns.Add($column7)
  $column8 = New-Object System.Data.DataColumn "ImportoContabile",([decimal])
 $Tempriconciliazione.Columns.Add($column8)
  $column9 = New-Object System.Data.DataColumn "Prodotto",([STRING])
 $Tempriconciliazione.Columns.Add($column9)
  $column10 = New-Object System.Data.DataColumn "ProdottoConto",([STRING])
 $Tempriconciliazione.Columns.Add($column10)
   $column11 = New-Object System.Data.DataColumn "FlagRiconcilia",([INT])
 $Tempriconciliazione.Columns.Add($column11)
    $column12 = New-Object System.Data.DataColumn "OrdinanteBonifico",([STRING])
 $Tempriconciliazione.Columns.Add($column12)
     $column13 = New-Object System.Data.DataColumn "Cognome",([STRING])
 $Tempriconciliazione.Columns.Add($column13)
      $column14 = New-Object System.Data.DataColumn "Nome",([STRING])
 $Tempriconciliazione.Columns.Add($column14)
       $column15 = New-Object System.Data.DataColumn "RagioneSociale",([STRING])
 $Tempriconciliazione.Columns.Add($column15)
        $column16 = New-Object System.Data.DataColumn "FlagEseguiControlloOrdinanteBeneficiario",([INT])
 $Tempriconciliazione.Columns.Add($column16)


$uniqueincarichi = $null
$uniqueincarichi = $datatable_incarichi | Select-Object idincarico,IsRiconciliato -Unique #| Where-Object {$_.idincarico -eq 12397931}


foreach($uniqueincarico in $uniqueincarichi){


$listaincarico = $null
$listaincarico = $datatable_incarichi | Where-Object {$_.idincarico -eq $uniqueincarico.idincarico}
$uniquemovimentiincarico = $null
$uniquemovimentiincarico =$listaincarico | Select-Object IdMovimentoContoBancario -Unique


$incarico = $null
foreach($incarico in $listaincarico){

if ($flagvisualizzaparametririconciliazione -eq 1){Write-Host $incarico.IdIncarico -ForegroundColor DarkCyan}
    $ImportoIncaricoRangeSuperiore = $null
    $ImportoIncaricoRangeInferiore = $null

    if($incarico.Importo -le 500000){ #se supera cento mila non faccio nulla
            $ImportoIncaricoRangeSuperiore = $incarico.Importo * 1.02
            $ImportoIncaricoRangeInferiore = $incarico.Importo / 1.02
        }else{
            $ImportoIncaricoRangeSuperiore = $incarico.Importo 
            $ImportoIncaricoRangeInferiore = $incarico.Importo 
        }

    $ImportoIncarico_GruppoRangeSuperiore = $null
    $ImportoIncarico_GruppoRangeInferiore = $null

    if($incarico.Importo -le 1000000){   #se supera un milione non faccio nulla
            $ImportoIncarico_GruppoRangeSuperiore = $incarico.Importo * 1.02
            $ImportoIncarico_GruppoRangeInferiore = $incarico.Importo / 1.02
        }else{
            $ImportoIncarico_GruppoRangeSuperiore = $incarico.Importo 
            $ImportoIncarico_GruppoRangeInferiore = $incarico.Importo 
        }

#write-host "$($incarico.IdIncarico)         $($incarico.cognome) " -ForegroundColor Cyan

   
 $m1 = $null #match per cognome,nome,importo preciso,somma cognomenome
 $m2 = $null #match per mandato,importo preciso,somma cognomenome   
 $m3 = $null #match per cognome,nome,importo maggiorato del 2%,somma cognomenome maggiorata del 2%
 $m4 = $null #match per mandato,importo maggiorato del 2%,somma cognomenome maggiorata del 2%
 $m5 = $null #match per cognome nome / o mandato e cognome

 
 $m1 = $Datatable_movimenti  |
            
            Where-Object {
           $_.IsRiconciliato -eq 0 -and
           (@($uniquemovimentiincarico.IdMovimentoContoBancario) -notcontains $_.IdMovimentoContoBancario) -and 

            (
            ( #match per cognome e nome
            ($_.Testo -match "$($incarico.cognome)\W") -and 
            ($_.Testo -match "$($incarico.Nome)\W")
            ) -or
            ( #match per mandato
             (-not ([string]::IsNullOrEmpty($incarico.NumeroMandato))) -and
             ($_.Testo -match "$($incarico.NumeroMandato)\W" -or $_.Testo -match "$($incarico.NmandatoNoZero)\W")
            )
            )-and
            ( #match per importo
            (($_.Importo) -ge $ImportoIncaricoRangeInferiore -and ($_.Importo) -le $ImportoIncaricoRangeSuperiore) -or 
            (($_.Importo) -ge $ImportoIncarico_GruppoRangeInferiore -and ($_.Importo) -le $ImportoIncarico_GruppoRangeSuperiore)
            )
                        

            }

 <#logica tipo 1 blocca il resto#>
 $m1 | Where-Object {$_.Testo -match "$($incarico.cognome)\W" -and 
                            ((-not ([string]::IsNullOrEmpty($incarico.NumeroMandato))) -and 
                            ($_.Testo -match "$($incarico.NumeroMandato)\W" -or $_.Testo -match "$($incarico.NmandatoNoZero)\W"))} |
                            foreach {

                          $_.IsRiconciliato = 1

                          $_.TipoRiconciliazione = 1
                            
                          Write-Host "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" -ForegroundColor Green
                          $log += "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" 
                       

                          $row = $null
                          $row = $Tempriconciliazione.NewRow()
                          $row."idincarico" = $($incarico.IdIncarico)
                          $row."idmovimentocontabile" =  $($_.IdMovimentoContoBancario)
                          $row."idmovimentoincarico" = $($incarico.IdMovimentoContoBancario)
                          $row."tiporiconciliazione" = $($_.TipoRiconciliazione)
                          $row."statuswf" = $($incarico.StatusWF)
                          $row."ImportoIncarico" = $($incarico.Importo)
                          $row."ImportoIncaricoSomma" = $($incarico.SommaPerCognomeNome)
                          $row."ImportoContabile" = $($_.Importo)
                          $row."Prodotto" = $($incarico.Prodotto)
                          $row."ProdottoConto" = $($_.ProdottoConto)
                         $row."FlagRiconcilia" = 1
                         $row."OrdinanteBonifico" = $($_.Testo).Substring(0,50)
                         $row."Cognome" = $incarico.cognome
                         $row."Nome" = $incarico.nome
                         $row."RagioneSociale" = $incarico.ragionesociale
                         $row."FlagEseguiControlloOrdinanteBeneficiario" = $($_.FlagEseguiControlloOrdinanteBeneficiario)
                          $Tempriconciliazione.Rows.add($row)


                          $_.Idincarico = $incarico.IdIncarico
                          $_.Prodotto = $incarico.Prodotto
                          $_.Cognome = $incarico.cognome
                          $_.Nome = $incarico.Nome
                          $_.RagioneSociale = $incarico.RagioneSociale
                          $_.ImportoIncarico = $incarico.Importo
                          $_.NumeroMandato = $incarico.NumeroMandato
                          $_.SommaPerCognomeNome = $incarico.SommaPerCognomeNome

                            }

# se esiste almeno una riconciliazione di tipo uno allora non faccio nulla, altrimenti trovo le riconciliazioni di tipo 2
if($m1 | Where-Object {$_.Tiporiconciliazione -eq 1 }){



}else{

$m1 | foreach {          $_.IsRiconciliato = 0

                                 $_.TipoRiconciliazione = 2
                                 
                                 Write-Host "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" -ForegroundColor Green
                                 $log += "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF"  

                                 $row = $null
                                 $row = $Tempriconciliazione.NewRow()
                                 $row."idincarico" = $($incarico.IdIncarico)
                                 $row."idmovimentocontabile" =  $($_.IdMovimentoContoBancario)
                                 $row."idmovimentoincarico" = $($incarico.IdMovimentoContoBancario)
                                 $row."tiporiconciliazione" = $($_.TipoRiconciliazione)
                                 $row."statuswf" = $($incarico.StatusWF)
                                 $row."ImportoIncarico" = $($incarico.Importo)
                                 $row."ImportoIncaricoSomma" = $($incarico.SommaPerCognomeNome)
                                 $row."ImportoContabile" = $($_.Importo)
                                 $row."Prodotto" = $($incarico.Prodotto)
                                 $row."ProdottoConto" = $($_.ProdottoConto)
                                 $row."FlagRiconcilia" = 1
                                  $row."OrdinanteBonifico" = if($($_.Testo).length -lt 41){$($_.Testo)}else{ $($_.Testo).Substring(0,40)}
                         $row."Cognome" = $incarico.cognome
                         $row."Nome" = $incarico.nome
                         $row."RagioneSociale" = $incarico.ragionesociale
                         $row."FlagEseguiControlloOrdinanteBeneficiario" = $($_.FlagEseguiControlloOrdinanteBeneficiario)
                                 $Tempriconciliazione.Rows.add($row)

                                 $_.Idincarico = $incarico.IdIncarico
                                 $_.Prodotto = $incarico.Prodotto
                                 $_.Cognome = $incarico.cognome
                                 $_.Nome = $incarico.Nome
                                 $_.RagioneSociale = $incarico.RagioneSociale
                                 $_.ImportoIncarico = $incarico.Importo
                                 $_.NumeroMandato = $incarico.NumeroMandato
                                 $_.SommaPerCognomeNome = $incarico.SommaPerCognomeNome
            




}

}



if(!$m1 -and $livelliRiconciliazione -ge 5){

$m5 = $Datatable_movimenti   |
            
            Where-Object {
            $_.IsRiconciliato -eq 0 -and
            (@($uniquemovimentiincarico.IdMovimentoContoBancario) -notcontains $_.IdMovimentoContoBancario) -and 
            (
            (
            (-not ([string]::IsNullOrEmpty($incarico.NumeroMandato))) -and
            ($_.Testo -match "$($incarico.NumeroMandato)\W" -or $_.Testo -match "$($incarico.NmandatoNoZero)\W") -and
            ($_.Testo -match "$($incarico.cognome)\W")
            ) -or 

            ((-not ([string]::IsNullOrEmpty($incarico.cognome))) -and
            ($_.Testo -match "$($incarico.cognome)\W") -and 
            ($_.Testo -match "$($incarico.Nome)\W")

            )
            )

            } 

 $m5 | foreach {     # Write-Host "$($incarico.NumeroMandato) - $($_.Testo)" -ForegroundColor Cyan 
                        $_.IsRiconciliato = 0
                        if(
                             (-not ([string]::IsNullOrEmpty($incarico.NumeroMandato))) -and
                             ($_.Testo -match "$($incarico.NumeroMandato)\W" -or $_.Testo -match "$($incarico.NmandatoNoZero)\W")
                             )
                             {
                                $_.TipoRiconciliazione = 5
                        
                               Write-Host "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" -ForegroundColor Yellow
                              $log += "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" 

                                $row = $null
                                 $row = $Tempriconciliazione.NewRow()
                                 $row."idincarico" = $($incarico.IdIncarico)
                                 $row."idmovimentocontabile" =  $($_.IdMovimentoContoBancario)
                                 $row."idmovimentoincarico" = $($incarico.IdMovimentoContoBancario)
                                 $row."tiporiconciliazione" = $($_.TipoRiconciliazione)
                                 $row."statuswf" = $($incarico.StatusWF)
                                 $row."ImportoIncarico" = $($incarico.Importo)
                                 $row."ImportoIncaricoSomma" = $($incarico.SommaPerCognomeNome)
                                 $row."ImportoContabile" = $($_.Importo)
                                 $row."Prodotto" = $($incarico.Prodotto)
                                 $row."ProdottoConto" = $($_.ProdottoConto)
                                 $row."FlagRiconcilia" = 1
                                  $row."OrdinanteBonifico" = if($($_.Testo).Length -gt 50){$($_.Testo).Substring(0,50)}else{$($_.Testo)}
                         $row."Cognome" = $incarico.cognome
                         $row."Nome" = $incarico.nome
                         $row."RagioneSociale" = $incarico.ragionesociale
                         $row."FlagEseguiControlloOrdinanteBeneficiario" = $($_.FlagEseguiControlloOrdinanteBeneficiario)
                                 $Tempriconciliazione.Rows.add($row)
                        
                        }else{ 
                        
                                $_.TipoRiconciliazione = 6 
                        
                        
                                Write-Host "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" -ForegroundColor Yellow
                                $log += "$($_.NomeConto) $($_.NumeroConto) $($_.IdMovimentoContoBancario) IDMOVIMENTO $($incarico.IdIncarico) IDINCARICO $($_.TipoRiconciliazione) TIPORICONCILIAZIONE $($incarico.StatusWF) SWF" 
                                

                               $row = $null
                                 $row = $Tempriconciliazione.NewRow()
                                 $row."idincarico" = $($incarico.IdIncarico)
                                 $row."idmovimentocontabile" =  $($_.IdMovimentoContoBancario)
                                 $row."idmovimentoincarico" = $($incarico.IdMovimentoContoBancario)
                                 $row."tiporiconciliazione" = $($_.TipoRiconciliazione)
                                 $row."statuswf" = $($incarico.StatusWF)
                                 $row."ImportoIncarico" = $($incarico.Importo)
                                 $row."ImportoIncaricoSomma" = $($incarico.SommaPerCognomeNome)
                                 $row."ImportoContabile" = $($_.Importo)
                                 $row."Prodotto" = $($incarico.Prodotto)
                                 $row."ProdottoConto" = $($_.ProdottoConto)
                                 $row."FlagRiconcilia" = 1
                                  $row."OrdinanteBonifico" = if($($_.Testo).Length -gt 50){$($_.Testo).Substring(0,50)}else{$($_.Testo)}
                         $row."Cognome" = $incarico.cognome
                         $row."Nome" = $incarico.nome
                         $row."RagioneSociale" = $incarico.ragionesociale
                         $row."FlagEseguiControlloOrdinanteBeneficiario" = $($_.FlagEseguiControlloOrdinanteBeneficiario)
                                 $Tempriconciliazione.Rows.add($row)
                        
                        
                        }
                        $_.Idincarico = $incarico.IdIncarico
                        $_.Prodotto = $incarico.Prodotto
                        $_.Cognome = $incarico.cognome
                        $_.Nome = $incarico.Nome
                        $_.RagioneSociale = $incarico.RagioneSociale
                        $_.ImportoIncarico = $incarico.Importo
                        $_.NumeroMandato = $incarico.NumeroMandato
                        $_.SommaPerCognomeNome = $incarico.SommaPerCognomeNome

                          }
    

#Write-Host "5" -ForegroundColor Yellow    



}    

if($flagvisualizzaparametririconciliazione -eq 1  ){
if($m1){
Write-Host "---> m1" -ForegroundColor Yellow
$m1
}
if($m5){
Write-Host "---> m5" -ForegroundColor red
$m5
}
}





if($m1){ 
#Write-Host "esco dal ciclo" -ForegroundColor Cyan
break 
}




}


if($flagvisualizzaparametririconciliazione -eq 1){
    $Tempriconciliazione | Select-Object idincarico,idmovimentocontabile,tiporiconciliazione,statuswf,Prodotto,ProdottoConto,FlagRiconcilia
    }
if(@($Tempriconciliazione).count -ge 1){
    $Tempriconciliazionegrouped = $null
    $Tempriconciliazionegrouped = $Tempriconciliazione | Select-Object idincarico,idmovimentocontabile,tiporiconciliazione,statuswf,ImportoIncarico,ImportoIncaricoSomma,ImportoContabile -Unique
    

    $importoincarico = $null
    $importoincarico = $Tempriconciliazione.ImportoIncarico[0]
    $importoincaricoSomma = $null
    $importoincaricoSomma = $Tempriconciliazione.ImportoIncaricoSomma[0]
    $sommacontabli = $null
    $sommacontabli = $($Tempriconciliazionegrouped | Group-Object -Property Idincarico | Select-Object @{Name="Somma";Expression={($_.Group | Measure-Object ImportoContabile -Sum).Sum}}).Somma
    
    $IdMovimentoContoBancaricoInRun = $null
    $IdMovimentoContoBancaricoInRun = $Tempriconciliazione.idmovimentocontabile[0]
    
    #controllo se l'incarico è stato associato a più contabili uguali, se si lo disassocio
    [string]$rapportosommacontabileimportoincarico = $null
    if($importoincarico -eq 0){
        [string]$rapportosommacontabileimportoincarico = 0
        }else{
        [string]$rapportosommacontabileimportoincarico = $sommacontabli/$importoincarico
        }
    $movimentodatentere = $null
    if( $rapportosommacontabileimportoincarico -notmatch "\." -and  
    $rapportosommacontabileimportoincarico -gt 1 #-and $Tempriconciliazione.TipoRiconciliazione[0] -ne 1
    ){
    
    $movimentodatenere = $Tempriconciliazione.idmovimentocontabile[0]
    $log += "movimento da tenere $movimentodatenere"
    $Tempriconciliazione | Where-Object {$_.idmovimentocontabile -ne $movimentodatenere} | ForEach-Object {$_.FlagRiconcilia = 0}


    $Datatable_movimenti | Where-Object {$_.IdIncarico -eq $incarico.IdIncarico -and $_.IdMovimentoContoBancario -ne $movimentodatenere} | ForEach-Object{

    if($flagvisualizzaparametririconciliazione -eq 1){
    Write-Host "disassocio movimento $($_.IdMovimentoContoBancario)" -ForegroundColor Red
    }
    
    $_.IsRiconciliato = 0
    $_.TipoRiconciliazione = 0
    $_.IdIncarico = 0


    }

    }


    $listaanagraficaincarico = $null
    $listaanagraficaincarico = $datatable_incarichi | Where-Object {$_.IdIncarico -eq $incarico.idincarico} | Select-Object Nome, Cognome, RagioneSociale
    
    $Tempriconciliazione | Where-Object {$_.FlagRiconcilia -eq 1} | 
    Select-Object idincarico,idmovimentocontabile,tiporiconciliazione,statuswf,Prodotto,ProdottoConto,OrdinanteBonifico,FlagEseguiControlloOrdinanteBeneficiario -Unique | 
    ForEach-Object {
    
    $Tempriconciliazione_idmovimentocontabile = $null
    $Tempriconciliazione_idmovimentocontabile = $_.idmovimentocontabile   


    #logica che associa se la somma delle contabili trovate è uguale all'importo incarico/o alla somma per cognome
    if(($importoincarico -eq $sommacontabli -or $importoincaricoSomma -eq $sommacontabli) -and 
        -not($_.tiporiconciliazione -eq 1 -or $_.tiporiconciliazione -eq 2))
        {
    
    $_.tiporiconciliazione = 3
           $log += "tiporiconciliazione 3"

    }
    #>
    #logica che verifica se il nome del prodotto è presente, 
    #se è presente verifico di aver raggiunto l'importo totale dell'incarico
    #se non è presente - traccio nelle note di riconciliazione idincarico e prodotto

    
if($flagabilitacontrolloordinantebeneficiario -eq 1 -and $_.FlagEseguiControlloOrdinanteBeneficiario -eq 1){

$modificatiporiconciliazionecontrolloordinantebeneficiario = 1

foreach ($intestatario in $listaanagraficaincarico){

if(
    ((-not ([string]::IsNullOrEmpty($intestatario.RagioneSociale))) -and $($_.OrdinanteBonifico -replace " ","") -match $($intestatario.RagioneSociale -replace " ","")) -or
    ((-not ([string]::IsNullOrEmpty($intestatario.Nome))) -and $($_.OrdinanteBonifico -replace " ","") -match $($intestatario.Nome -replace " ","") -and $($_.OrdinanteBonifico -replace " ","") -match $($intestatario.cognome -replace " ",""))


 ){


$modificatiporiconciliazionecontrolloordinantebeneficiario = 0

}

if($modificatiporiconciliazionecontrolloordinantebeneficiario -eq 1){
    $log += "Controllo Ordinante Bonifico - Ordinante $($_.OrdinanteBonifico)- ragione sociale $($intestatario.RagioneSociale) - cognome $($intestatario.Cognome) - Nome $($intestatario.Nome)"
   

    }


} #foreach intestatario in anagrafica

if($modificatiporiconciliazionecontrolloordinantebeneficiario -eq 1){
     $_.tiporiconciliazione = 7
     $log += "Tiporiconciliazione 7 Ordinante diverso da tutti i beneficiari"
}


}

    <#IL CONTROLLO SUL CONTO/PRODOTTO DEVE ESSERE SEMPRE L'ULTIMO CONTROLLO EFFETTUATO#>
    if($logicariconciliazionesingoloconto -eq 1){

        IF(
        (-not ([string]::IsNullOrEmpty($_.Prodotto))) -and
        ($_.Prodotto -ne $_.ProdottoConto)
        ){

        $_.tiporiconciliazione = 8
        $log += "tiporiconciliazione 8"
        
    $Datatable_movimenti | Where-Object {$_.IdMovimentoContoBancario -eq $Tempriconciliazione_idmovimentocontabile} | ForEach-Object{

    if($flagvisualizzaparametririconciliazione -eq 1){
    Write-Host "disassocio movimento $($_.IdMovimentoContoBancario)" -ForegroundColor Red
    }
    
    $_.IsRiconciliato = 0
    $_.TipoRiconciliazione = 0
    $_.IdIncarico = 0


    }



        }


    }

   

if($flagvisualizzaparametririconciliazione -eq 1){
    Write-Host "tiporiconciliazione: $($_.tiporiconciliazione) idmovimento $($_.idmovimentocontabile) idincarico $($_.idincarico)" -ForegroundColor Yellow
    }

    
    #eseguo update sulla tabella datatable incarichi in modo da storicizzare anche il movimento associato in running all'incarico

    $TipoRiconciliazioneInRun = $null
    $TipoRiconciliazioneInRun = $($_.tiporiconciliazione) 
    $idincaricoinrun = $null
    $idincaricoinrun = $($_.idincarico)
    
    $datatable_incarichi | Where-Object {$_.idincarico -eq $idincaricoinrun  } | ForEach-Object {
        $_.IdMovimentoContoBancaricoInRun = $IdMovimentoContoBancaricoInRun
        $_.TipoRiconciliazioneInRun = $TipoRiconciliazioneInRun 
        $_.IsRiconciliato = 1
    }
    #>




        
    #gestione eliminazione incarichi riconciliati con tipo meno preciso (il tipo meno preciso ha un valore superiore)
    $listatipiriconciliazioni  = $null
    $listatipiriconciliazioni = $datatable_incarichi | Where-Object {$_.IdMovimentoContoBancaricoInRun -eq $IdMovimentoContoBancaricoInRun} | select TipoRiconciliazioneInRun
    $listatipiriconciliazioni = $listatipiriconciliazioni.TipoRiconciliazioneInRun
    $maxtiporiconciliazione = $null
    [int]$maxtiporiconciliazione = $($listatipiriconciliazioni | measure -Maximum  | select Maximum).Maximum
    $mintiporiconciliazione = $null
    [int]$mintiporiconciliazione = $($listatipiriconciliazioni | measure -Minimum | select Minimum).Minimum
    

    #lista degli incarichi associati al movimento che hanno tiporiconciliazione diversa da 1
    $listaincarichidaeliminare = @()
    if($maxtiporiconciliazione -ne $mintiporiconciliazione -and $flageliminaprecedentiriconciliazioniserictipo1 -eq 1){

        $listaincarichidaeliminare =  $datatable_incarichi |
            Where-Object {

            $_.IdMovimentoContoBancaricoInRun -eq $IdMovimentoContoBancaricoInRun -and
            $_.TipoRiconciliazioneInRun -gt $mintiporiconciliazione

            } |
            select IdIncarico -Unique


    }
    if($flagvisualizzaparametririconciliazione -eq 1){
    Write-Host "lista incarichi da eliminare" -ForegroundColor Red
    $listaincarichidaeliminare
    }
    
    if($flaginserisciadb -eq 1){  
        logica-riconciliazione -inseriscitr 1 -statusworkflow $($_.statuswf) -idmovimentocontabile $($_.idmovimentocontabile) -tiporiconciliazione $($_.tiporiconciliazione) -idincarico $($_.idincarico)
     #Write-Host "inserisco a db" -ForegroundColor Cyan
        
            ##############elimina relazione movimento incarico per riconciliazione inferiore a tipo 1##################
         if($listaincarichidaeliminare -and $flageliminaprecedentiriconciliazioniserictipo1 -eq 1){

         $listaincarichidaeliminare | ForEach-Object {

         Write-Host "elimino incarico $($_.IdIncarico) per riconciliazione inferiore con movimento $IdMovimentoContoBancaricoInRun" -ForegroundColor Red
         $log += "elimino incarico $($_.IdIncarico) per riconciliazione inferiore con movimento $IdMovimentoContoBancaricoInRun" 
       
         logica-riconciliazione -eliminadatr 1 -inseriscitr 0 -statusworkflow 0 -idincarico $($_.IdIncarico) -idmovimentocontabile $IdMovimentoContoBancaricoInRun -tiporiconciliazione 0


         }

         }
         
            ################################ 

                                      

    } #flaginserisciadb
} #foreachobject 

if(@($Tempriconciliazione).count -ge 1){$uniqueincarico.IsRiconciliato = 1}

$Tempriconciliazione.Clear()

}

}

 $ConnectionObject.close()
} #flag esegui riconciliazione

$dateformat = Get-Date -Format "yyyyMMdd_HHmm"
$end = Get-Date
$duration = $end - $start
write-host "minuti esecuzione $($duration.totalminutes)" -ForegroundColor Cyan
$log += "minuti esecuzione $($duration.totalminutes)"

$Datatable_movimenti | export-csv $file_risultatiriconciliazione -Delimiter ";" -NoTypeInformation
#$datatable_incarichi | export-csv "H:\incarichi_$($dateformat).csv" -Delimiter ";" -NoTypeInformation
$riconciliati = $null
$riconciliati = $Datatable_movimenti | Where-Object {-not ([string]::IsNullOrEmpty($_.IdIncarico))}
$numeroriconciliati = @($riconciliati).count
$numeroincarichi = $null
$numeroincarichi = @($uniqueincarichi).Count
$numeroincarichiriconciliati = $null
$numeroincarichiriconciliati = @($uniqueincarichi |Where-Object{$_.IsRiconciliato -eq 1}).Count
$numerocontabili = $null
$numerocontabili = @($Datatable_movimenti).Count

Write-Host "%ric su incarichi [$($numeroriconciliati/$numeroincarichi)] %ric su contabili [$($numeroriconciliati/$numerocontabili)]" -ForegroundColor Yellow
$log += "%ric su incarichi [$($numeroriconciliati/$numeroincarichi)] %ric su contabili [$($numeroriconciliati/$numerocontabili)]"

if($flageseguimodificacontabili -eq 1){

if($flag_connettisql -eq 1){

 # connessione a sql
 $StringaConnessione = "Server=$($conf.SQLConnection.istanza);Database=$($conf.SQLConnection.database);Trusted_Connection=Yes"
 $ConnectionObject = New-Object System.Data.SqlClient.SqlConnection($StringaConnessione)
 $Comando = New-Object System.Data.SqlClient.SqlCommand

 $ConnectionObject.Open()

    $Datatable_movimenti | 
        #Where-Object {-not [string]::IsNullOrEmpty($_.Gruppo) } | 
        #Select-Object -First 1 | 
        ForEach-Object {

    #Write-Host "ciao $($_.IdMovimentoContoBancario) - $($_.Gruppo) "
    
        if(-not [string]::IsNullOrEmpty($_.Gruppo)){
                if($flaginserisciadb -eq 1){  
                 logica-riconciliazione -inseriscitr 0 -statusworkflow 0 -idmovimentocontabile $($_.IdMovimentoContoBancario) -tiporiconciliazione 0 -idincarico 0 -notacontabile "AUTO_$($_.Gruppo)"
        
                } #flaginserisciadb
        
        }

         if(-not [string]::IsNullOrEmpty($_.Gruppo_Automatismo)){
                if($flaginserisciadb -eq 1){  
                 logica-riconciliazione -inseriscitr 0 -statusworkflow 0 -idmovimentocontabile $($_.IdMovimentoContoBancario) -tiporiconciliazione 0 -idincarico 0 -notacontabile "AUTO_$($_.Gruppo_Automatismo)"
        
                } #flaginserisciadb
        
        
        }
    
    
    } #foreach datatablemovimenti

 $ConnectionObject.Close()
 } #flagconnetti sql
} #flageseguimodificacontabili

<# IMPLEMENTARE LOGICA FLAG STATO WORKFLOW, SE TROVO UNA CONTABILE ASSOCIATA A PIU' INCARICHI
   E ALMENO UNO DI QUESTI HA STATUS WORKFLOW = 1
     ALLORA RIMUOVO DALL'ASSOCIAZIONE TRINCARICOMOVIMENTO TUTTI GLI INCARICHI CON STATUS 0
     ED INSERISCO IL FLAGRICONCILIATO = 1
   

#>
if($flagmodificariconciliato -eq 1){
 $ConnectionObject.Open()

$movimentidavariareinriconciliato = $null
$movimentidavariareinriconciliato = $datatable_incarichi | 
Where-Object {-not ([string]::IsNullOrEmpty($_.IdMovimentocontobancario)) -and $_.IsRiconciliato -eq 0 -and $_.StatusWF -eq 1} | 
Select IdMovimentocontobancario -Unique 

if($movimentidavariareinriconciliato){Write-Host "Modifica flagriconciliato" -ForegroundColor green
$log += "Modifica flagriconciliato"

}

$movimentidavariareinriconciliato |
ForEach-Object {
    Write-Host $($_.IdMovimentocontobancario)  -ForegroundColor Green
    $log +=  $($_.IdMovimentocontobancario)
    logica-riconciliazione -inseriscitr 0 -statusworkflow 1 -idmovimentocontabile $($_.IdMovimentocontobancario) -tiporiconciliazione 7 -idincarico 0 -eliminadatr 0
    
}


$datatable_incarichi | 

Where-Object {(@($movimentidavariareinriconciliato.IdMovimentoContoBancario) -contains $_.IdMovimentocontobancario)  -and $_.StatusWF -eq 0} |
ForEach-Object {
  Write-Host "elimino $($_.IdIncarico) incarico - $($_.IdMovimentocontobancario) movimento da TR" -ForegroundColor red
  $log += "elimino $($_.IdIncarico) incarico - $($_.IdMovimentocontobancario) movimento da TR"
  logica-riconciliazione -eliminadatr 1 -inseriscitr 0 -statusworkflow 0 -idincarico $($_.IdIncarico) -idmovimentocontabile $($_.IdMovimentocontobancario) -tiporiconciliazione 0

}


 $ConnectionObject.Close()
}

$log | Out-File $file_log

}catch{

$MessaggioErrore = $null
$error
$MessaggioErrore = $error




}finally{



 
    $mailParams=@{}
    $mailBody=@"
"@;

$mailBody=@"
$nomescript

minuti esecuzione $($duration.totalminutes)
%ric su incarichi [$($numeroriconciliati/$numeroincarichi)] %ric su contabili [$($numeroriconciliati/$numerocontabili)]

$MessaggioErrore

Server: $env:COMPUTERNAME
ScriptPath: $($MyInvocation.MyCommand.Path)



"@

    if($MessaggioErrore -eq $null){
        $mailSubject="[success] $($nomescript)"
    } 
    else{
        $mailSubject="[error] $($nomescript)"
    }
    
    $conf.mailing  | Get-Member -MemberType NoteProperty | %{
        $mailParams.Add($_.name,$conf.mailing."$($_.name)")
    }

    $mailParams.Add("Body",$mailbody)
    $mailParams.Add("Subject",$mailSubject)
    Send-MailMessage @mailParams -Attachments $file_risultatiriconciliazione, $file_log

    # print dei parametri subject, body
    $mailSubject
    $mailBody 
   

   # $MessaggioErrore

Remove-Item $scratchDir -Force -Recurse
}
