﻿Clear-Host
$Error.Clear()
$ErrorActionPreference="Continue"
$MessaggioErrore = $null

$jsonPath = $($MyInvocation.MyCommand.path) -replace "ps1", "json"

$conf=gc $jsonPath | Out-String | ConvertFrom-Json -Verbose

$urlbase = $conf.WebAPI.url
$User = $conf.WebAPI.user
$Password = $conf.WebAPI.pwd

#per far funzionare il merge, ti serve il file itextsharp.dll!! in questa macchina l'ho messo su scriptadminroot
function Merge-pdf(){
    [CmdletBinding()]
    param(
        [string]$workingDirectory,
        [string]$fileOutPut
    )
    <#
    [void] [System.Reflection.Assembly]::LoadFrom(
        [System.IO.Path]::Combine($workingDirectory, 'itextsharp.dll')
    );#>
    [void] [System.Reflection.Assembly]::LoadFrom('C:\ScriptAdminRoot\Modify\itextsharp.dll')
    $pdfs = ls $workingDirectory -recurse | where {-not $_.PSIsContainer -and $_.Extension -imatch "^\.pdf$"};
    $output = $fileOutPut
    $fileStream = New-Object System.IO.FileStream($output, [System.IO.FileMode]::OpenOrCreate);
    $document = New-Object iTextSharp.text.Document;
    $pdfCopy = New-Object iTextSharp.text.pdf.PdfCopy($document, $fileStream);
    $document.Open();
    [iTextSharp.text.pdf.PdfReader]::unethicalreading=$true
    foreach ($pdf in $pdfs) {
        Write-Verbose "Adding pdf $($pdf.name) into $fileOutPut"
        $reader = New-Object iTextSharp.text.pdf.PdfReader($pdf.FullName);
        
        $pdfCopy.AddDocument($reader);
        $reader.Dispose();  
    }

    $pdfCopy.Dispose();
    $document.Dispose();
    $fileStream.Dispose();
}

Import-Module PSSqlQuery


$VerbosePreference="continue"
$query=@"

SELECT Documento_id, IdIncarico
, Nome_file nomefile_input
, CAST(IdIncarico as VARCHAR(20)) AS nomedocumentopdf 

FROM T_Documento
WHERE IdIncarico = 14542718
AND FlagPresenzaInFileSystem = 1
AND Tipo_Documento = 1539

"@

#per far funzionare l'applicativo, occorre che i singoli pdf abbiano il campo nomedocumentopdf in comune!!

$s=([guid]::NewGuid()).Guid

$scratchDir="$env:temp\merge_pdf\$s"
if (Test-Path "$env:temp\merge_pdf"){
    Remove-Item "$env:temp\merge_pdf" -Recurse -Force
}
if (-not (Test-Path $scratchDir)){
    mkdir $scratchDir | Out-Null
}

   $sqlConn=Connect-SQLServer -Istance BTSQLCL05 -Database clc
    $records=Invoke-SQLQuery -query $query -Connection $sqlConn

           # autenticazione api
    $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
    $headerToken =Invoke-RestMethod –Uri "$urlBase/Autenticazione/NomeHeaderTokenSessione"
    $credenziali = @{ Username = $User; Password = $Password} | ConvertTo-Json
    $token = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Autenticazione/Autentica" -Body $credenziali
    $headers = @{"$headerToken" = $token }
    $sessione = Invoke-RestMethod -ContentType "application/json" -Method Get -Uri "$urlBase/Autenticazione/Sessione" -Headers $headers


foreach ($r in $records){
        $workdir = $null
        $workdir="$scratchDir\ZipFolder\$($r.nomedocumentopdf)"
        #$workdir= "$tmpdir\$($r.nomedocumentopdf)"
        if (-not (Test-Path $workdir)){
            mkdir $workdir |Out-Null
        }

$filePath = "$workdir/$($r.nomefile_input)"
           
            # download file from qtask
            $servicePoint.CloseConnectionGroup("")
            $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)

            Invoke-RestMethod -ContentType "application/json" -Method GET -Uri "$urlBase/Incarico/$($r.idincarico)/Documento/$($r.documento_id)/contenuto" -Headers $headers -OutFile $filePath


}

dir $scratchDir -Directory | % {
        pushd $($_.FullName)
        $pdfs=dir -Directory
        foreach ($d in $pdfs){
           $outputPdf="$($d.FullName).pdf"
           Write-Verbose $outputPdf
           Merge-pdf -workingDirectory $d.FullName -fileOutPut $outputPdf
           Remove-Item $d.FullName -Recurse
        }
        popd 
    }



$scratchDir

#$outputPdf

<#
# imbarco pdf creato
 $ParametriDocumentoDaAssociare = $null
 $ParametriDocumentoDaAssociare = @{ IdIncarico = $IdIncarico
 ; CodTipoDocumento = $($datidocumento.Tipo_Documento)
 ; NomeFile = $nomePDF
 ; Contenuto = [Convert]::ToBase64String([IO.File]::ReadAllBytes($filepdf))
  
 } | ConvertTo-Json
     $servicePoint.CloseConnectionGroup("")
     $servicePoint = [System.Net.ServicePointManager]::FindServicePoint($urlBase)
     $documentoid = Invoke-RestMethod -ContentType "application/json" -Method Post -Uri "$urlBase/Documento" -Headers $headers -Body $ParametriDocumentoDaAssociare
 
 $parametriDocumentoEliminare = $null
 $parametriDocumentoEliminare = @{FlagScaduto = 1

 } | ConvertTo-Json

 Invoke-RestMethod -ContentType "application/json" -Method Put -Uri "$urlBase/Documento/$IdDocumento" -Headers $headers -Body $parametriDocumentoEliminare


if (Test-Path $scratchDir){
       Remove-Item $scratchDir -Recurse -Force
}

#>