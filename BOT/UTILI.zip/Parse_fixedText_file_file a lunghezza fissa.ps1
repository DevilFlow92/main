﻿
Clear-Host



[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') 
 
$Parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser( 
    'K:\BPO\Orga CLP\Andrea\azimut\case terze\SALDI00047\SALDI00047.txt') 
     
$Parser.TextFieldType = 'FixedWidth' 
$Parser.TrimWhiteSpace = $true 
$Parser.FieldWidths = @(10, 2,30,10,16,24,7,12,12,20,16,40,15,1,8,20,26,2,16,16,116) 

        $item = $null
        $item = New-Object PSObject
        $item | Add-Member -type NoteProperty -Name 'ANIMADataArray'  -value             $null
        $item | Add-Member -type NoteProperty -Name 'ANIMAFundCode'  -value              $null
        $item | Add-Member -type NoteProperty -Name 'ANIMAFundName'  -value              $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACode'  -value                  $null
        $item | Add-Member -type NoteProperty -Name 'ANIMAContract'  -value              $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACode2'  -value                 $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACode3'  -value                 $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACode4'  -value                 $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACode5'  -value                 $null
        $item | Add-Member -type NoteProperty -Name 'ANIMANQuotes'  -value               $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACodiceFiscalePIva'  -value         $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACognome'  -value               $null
        $item | Add-Member -type NoteProperty -Name 'ANIMANome'  -value                  $null
        $item | Add-Member -type NoteProperty -Name 'ANIMASesso'  -value                 $null
        $item | Add-Member -type NoteProperty -Name 'ANIMADataNascita'  -value           $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACittaNascita'  -value          $null
        $item | Add-Member -type NoteProperty -Name 'ANIMAProvinciaNascita'  -value      $null
        $item | Add-Member -type NoteProperty -Name 'ANIMATipoDocumento'  -value         $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACodiceFiscale1'  -value        $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACodiceFiscale2'  -value        $null
        $item | Add-Member -type NoteProperty -Name 'ANIMACode6'  -value                 $null
       
$ANIMAParsedArray = @()

while(!$Parser.EndOfData) 
{ 
    try 
    { 
        $line = $Parser.ReadFields()   
        $info = @{                                                             
        ANIMADataArray         =        $line[0]             
        ANIMAFundCode          =          $line[1]           
        ANIMAFundName          =           $line[2]          
        ANIMACode              =           $line[3]          
        ANIMAContract          =           $line[4]          
        ANIMACode2             =           $line[5]          
        ANIMACode3             =           $line[6]          
        ANIMACode4             =           $line[7]          
        ANIMACode5             =           $line[8]          
        ANIMANQuotes           =             $line[9]        
        ANIMACodiceFiscalePIva     =                $line[10]    
        ANIMACognome           =          $line[11]          
        ANIMANome              =           $line[12]         
        ANIMASesso             =           $line[13]         
        ANIMADataNascita       =              $line[14]      
        ANIMACittaNascita      =               $line[15]     
        ANIMAProvinciaNascita  =                   $line[16] 
        ANIMATipoDocumento     =                $line[17]    
        ANIMACodiceFiscale1    =                 $line[18]   
        ANIMACodiceFiscale2    =                 $line[19]   
        ANIMACode6             =         $line[20]    
        
        }
        
        $item = New-Object -TypeName psobject -Property $info
        $ANIMAParsedArray += $item          

  
        
    } 
    catch [Microsoft.VisualBasic.FileIO.MalformedLineException] 
    { 
        Write-Host "Error, line $($_.Exception.LineNumber): $($Parser.ErrorLine)" 
    } 
} 

$ANIMAParsedArrayGrouped = $ANIMAParsedArray | Group-Object -Property ANIMACodiceFiscalePIva

$ANIMAParsedArrayFinal = @()
$item = $null

$ANIMAParsedArrayFinal += foreach($item in $ANIMAParsedArrayGrouped){

    $item.group | Select -Unique ANIMACodiceFiscalePIva, @{Name = 'SommaQuote'; Expression = {(($item.group) | measure -Property ANIMANQuotes -Sum).Sum}}, @{Name= 'Dettagli';Expression = {($item.Group)}}


}

$ANIMAParsedArrayFinal
