$path = "\\mifil03\root\CESAM\Previdenza\2021 Certificazioni Fiscali CF\AZIPR\1 invio\zip"

$filename = "ListaFilesAZIPR_Lotto1.csv"

$csvfile = "C:\ProgrammiSicuri\ScriptAdminRoot\Execute\AZIMUT\PREVIDENZA\InvioCertificazioniFiscaliPrevidenza\FileImport\Folder 2021\Creazione Incarichi\$filename"

$array = get-childitem $path -filter *.zip | Select-Object FullName

$array | Export-Csv -Path $csvfile -NoTypeInformation -Delimiter ";"