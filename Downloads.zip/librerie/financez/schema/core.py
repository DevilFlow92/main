import json
from collections import namedtuple
from dataclasses import asdict, make_dataclass
from datetime import date, datetime
from decimal import Decimal as D
from enum import Enum
from typing import Any, Mapping, TypedDict

from pymol.types.mappings.gsa import CodTipoTitoloFinanziario, IdOperazioneContoBancario

SelfFields = tuple[tuple[str, type], ...]  # values from the message
MappedFields = tuple[tuple[str, type], ...]  # values inferred from external searched on SelfFields
SchemaMappings = Mapping[
    str, tuple[SelfFields, MappedFields]
]  # maps the message class name to the fields of the message


class Meta(TypedDict):
    provider: str
    feed: str
    routing_state: dict[str, str]
    id: str
    row: dict[str, Any]
    errors: dict[str, list[str]] | None
    ver: int
    sender: str
    call_global_id: str | None
    call_single_id: str | None


SCHEMA_MAPPINGS: SchemaMappings = {
    "Cancellazione": ((("id_msg", str),), ()),
    "MovimentoCash": (
        (
            ("data_valuta", date),
            ("data_operazione", date),
            # codice operazione così come specificato dalla banca, senza traduzione
            ("cod_operazione_banca", str),
            ("segno", int),  # 1,-1
            ("importo_in_valuta_del_conto", D),
            ("valuta_del_conto", str),
            ("importo", D),
            ("valuta_di_riferimento", str),
            ("cambio", D),  # importo_conto / cambio = importo in valuta di riferimento
            ("descrizione", str),
        ),
        (
            ("cod_operazione", IdOperazioneContoBancario),
            ("descrizione_cod_operazione", str),
            ("source_importo_in_valuta_del_conto", str),  # feed, calcolato
            ("source_importo", str),  # feed, calcolato
            ("source_cambio", str),  # feed, BancaItalia, calcolato
        ),
    ),
    "SaldoCash": (
        (
            ("data", date),
            # a seconda del flusso la data si può riferire alla valuta o all'operazione
            ("valuta_o_operazione", str),
            ("importo_in_valuta_del_conto", D),
            ("valuta_del_conto", str),
            ("importo", D),
            ("valuta_di_riferimento", str),
            ("cambio", D),  # importo_conto / cambio = importo in valuta di riferimento
        ),
        (
            ("source_importo_in_valuta_del_conto", str),  # feed, calcolato
            ("source_importo", str),  # feed, calcolato
            ("source_cambio", str),  # feed, BancaItalia, calcolato
        ),
    ),
    "MovimentoTitolo": (
        (
            ("data_valuta", date),
            ("data_operazione", date),
            ("identificatore_banca", str),  # identificativo del titolo lato banca (può essere isin o altro)
            # codice operazione così come specificato dalla banca, senza traduzione
            ("cod_operazione_banca", str),
            ("quantita", D),  # così come specificata nel messaggio, eventualmente da dividere
            ("prezzo_in_valuta_del_conto", D),
            # gli importi vengono già eventualmente divisi
            ("importo_in_valuta_del_conto", D),
            ("valuta_del_conto", str),
            # da qui in valuta di riferimento
            ("importo", D),
            ("valuta_di_riferimento", str),
            ("cambio", D),  # importo_titolo / cambio = importo in valuta riferimento
            ("valuta_di_trattazione", str),
            ("cambio_di_trattazione", D),
            ("importo_lordo", D),
            ("commissioni", D),
            ("euroritenute", D),
            ("ratei", D),
            ("ritenute", D),
            ("spese", D),
            ("descrizione", str),
        ),
        (
            ("cod_operazione", IdOperazioneContoBancario),
            ("descrizione_cod_operazione", str),
            ("identificativi_titolo", dict[str, str]),
            # dict di tutti gli identificativi estraibili per il titolo, es
            # {"isin": "IT0001", "cusip": "001"}
            ("codice_borsa", str),  # todo enum
            ("tipo_titolo", CodTipoTitoloFinanziario),
            ("divisore_qty", int),  # quantità per cui va divisa la quantità
            ("source_prezzo_in_valuta_del_conto", str),  # feed, calcolato
            ("source_importo_in_valuta_del_conto", str),  # feed, calcolato
            ("source_importo", str),  # feed, calcolato
            ("source_cambio", str),  # feed, BancaItalia, calcolato
        ),
    ),
    "SaldoTitolo": (
        (
            ("data", date),
            # a seconda del flusso la data si può riferire alla valuta o all'operazione
            ("valuta_o_operazione", str),
            ("identificatore_banca", str),  # identificativo del titolo lato banca (può essere isin o altro)
            ("quantita", D),  # così come specificata nel messaggio, eventualmente da dividere
            ("prezzo_in_valuta_del_conto", D),
            # gli importi vengono già eventualmente divisi
            ("importo_in_valuta_del_conto", D),
            ("valuta_del_conto", str),
            ("importo", D),
            ("valuta_di_riferimento", str),
            ("ratei", D),  # in valore assoluto
            ("cambio", D),  # importo_titolo / cambio = importo in valuta riferimento
        ),
        (
            ("identificativi_titolo", dict[str, str]),
            # dict di tutti gli identificativi estraibili per il titolo, es
            # {"isin": "IT0001", "cusip": "001"}
            ("codice_borsa", str),  # todo enum
            ("tipo_titolo", CodTipoTitoloFinanziario),
            ("divisore_qty", int),  # quantità per cui va divisa la quantità
            ("source_prezzo_in_valuta_del_conto", str),  # feed, calcolato
            ("source_importo_in_valuta_del_conto", str),  # feed, calcolato
            ("source_importo", str),  # feed, calcolato
            ("source_cambio", str),  # feed, BancaItalia, calcolato
        ),
    ),
    "CorporateAction": ((("data", date),), ()),
    # msg di test ( non reali )
    "TestCash": (
        (
            ("data_valuta", date),
            ("importo", D),
        ),
        (),
    ),
    "TestTitolo": (
        (("data_valuta", date), ("importo", D), ("importo_lordo", D), ("isin", str)),
        (("tipo_titolo", int),),
    ),
}


def serialize(obj):  # type: ignore
    if isinstance(obj, (date,)):
        return obj.isoformat()[0:10]
    if isinstance(obj, (datetime,)):
        return obj.date().isoformat()[0:10]
    if isinstance(obj, (D,)):
        return float(obj)


def _dataclass_fields(fields: tuple[SelfFields, MappedFields]) -> list[tuple[str, type]]:
    """Campi comuni a qualsiasi classe di messaggio."""
    output = list(fields[0])
    Mappings = TypedDict("Mappings", {k: v for k, v in fields[1]})  # type: ignore
    output.extend(
        [
            ("provider_account", str),  # aka codice mandato / rapporto
            ("account_number", str),  # numero conto
            ("provider_msgid", str),
            ("rettifica", str),  # se presente id di un messaggio precedente
            # i cui valori vanno sostituiti con quelli attuali
            ("feed_msgs_accorpati", list[str]),
            ("mappings_", Mappings),
            ("meta_", Meta),
        ]
    )
    return output


def _dataclass_namespace(invalid: bool = False) -> dict[str, Any]:
    ns = {
        "as_dict": lambda self: asdict(self),
        "as_json": lambda self: json.dumps(asdict(self), default=serialize),
        "is_valid": property(lambda self: not invalid),
    }
    if invalid:
        ns["is_complete"] = property(lambda self: False)
    else:
        ns["is_complete"] = property(lambda self: all(self.mappings_.values()))
    return ns


def _make_schemas(schema_mappings: SchemaMappings, msg_class: str) -> tuple[type, type]:
    ValidSchema = make_dataclass(
        cls_name=msg_class, fields=_dataclass_fields(schema_mappings[msg_class]), namespace=_dataclass_namespace()
    )
    InvalidSchema = make_dataclass(
        cls_name="Invalid" + msg_class,
        fields=_dataclass_fields(schema_mappings[msg_class]),
        namespace=_dataclass_namespace(True),
    )
    return ValidSchema, InvalidSchema


ValidCancellazione, InvalidCancellazione = _make_schemas(SCHEMA_MAPPINGS, "Cancellazione")
ValidMovimentoCash, InvalidMovimentoCash = _make_schemas(SCHEMA_MAPPINGS, "MovimentoCash")
ValidSaldoCash, InvalidSaldoCash = _make_schemas(SCHEMA_MAPPINGS, "SaldoCash")
ValidMovimentoTitolo, InvalidMovimentoTitolo = _make_schemas(SCHEMA_MAPPINGS, "MovimentoTitolo")
ValidSaldoTitolo, InvalidSaldoTitolo = _make_schemas(SCHEMA_MAPPINGS, "SaldoTitolo")
ValidCorporateAction, InvalidCorporateAction = _make_schemas(SCHEMA_MAPPINGS, "CorporateAction")
# solo test
ValidTestCash, InvalidTestCash = _make_schemas(SCHEMA_MAPPINGS, "TestCash")
ValidTestTitolo, InvalidTestTitolo = _make_schemas(SCHEMA_MAPPINGS, "TestTitolo")


# classi composte per ora devono essere fatte in un secondo step
COMPLEX_SCHEMA_MAPPINGS = {
    "Giroconto": ((("movimento_in", ValidMovimentoCash), ("movimento_out", ValidMovimentoCash)), ()),
    "CambioValuta": (
        (("movimento_in", ValidMovimentoCash), ("movimento_out", ValidMovimentoCash), ("data_contratto", date)),
        (),
    ),
    # msg di test ( non reali )
    "TestGiroconto": ((("movimento_in", ValidTestCash), ("movimento_out", ValidTestCash)), ()),
}
ValidGiroconto, InvalidGiroconto = _make_schemas(COMPLEX_SCHEMA_MAPPINGS, "Giroconto")
ValidCambioValuta, InvalidCambioValuta = _make_schemas(COMPLEX_SCHEMA_MAPPINGS, "CambioValuta")
# solo test
ValidTestGiroconto, InvalidTestGiroconto = _make_schemas(COMPLEX_SCHEMA_MAPPINGS, "TestGiroconto")


VIF = namedtuple("VIF", "valid invalid fields")


class Schemas(Enum):
    Cancellazione = VIF(ValidCancellazione, InvalidCancellazione, _dataclass_fields(SCHEMA_MAPPINGS["Cancellazione"]))
    MovimentoCash = VIF(ValidMovimentoCash, InvalidMovimentoCash, _dataclass_fields(SCHEMA_MAPPINGS["MovimentoCash"]))
    SaldoCash = VIF(ValidSaldoCash, InvalidSaldoCash, _dataclass_fields(SCHEMA_MAPPINGS["SaldoCash"]))
    MovimentoTitolo = VIF(
        ValidMovimentoTitolo, InvalidMovimentoTitolo, _dataclass_fields(SCHEMA_MAPPINGS["MovimentoTitolo"])
    )
    SaldoTitolo = VIF(ValidSaldoTitolo, InvalidSaldoTitolo, _dataclass_fields(SCHEMA_MAPPINGS["SaldoTitolo"]))
    CorporateAction = VIF(
        ValidCorporateAction, InvalidCorporateAction, _dataclass_fields(SCHEMA_MAPPINGS["CorporateAction"])
    )
    Giroconto = VIF(ValidGiroconto, InvalidGiroconto, _dataclass_fields(COMPLEX_SCHEMA_MAPPINGS["Giroconto"]))
    CambioValuta = VIF(
        ValidCambioValuta, InvalidCambioValuta, _dataclass_fields(COMPLEX_SCHEMA_MAPPINGS["CambioValuta"])
    )
    # msg di test ( non reali )
    TestCash = VIF(ValidTestCash, InvalidTestCash, _dataclass_fields(SCHEMA_MAPPINGS["TestCash"]))
    TestTitolo = VIF(ValidTestTitolo, InvalidTestTitolo, _dataclass_fields(SCHEMA_MAPPINGS["TestTitolo"]))
    TestGiroconto = VIF(
        ValidTestGiroconto, InvalidTestGiroconto, _dataclass_fields(COMPLEX_SCHEMA_MAPPINGS["TestGiroconto"])
    )
