import json
from typing import Any

from pyodbc import Cursor, Row


class AbstractMsgFactory:
    """Factory per la traduzione dei messaggi dei provider."""

    def __init__(self, cursor: Cursor) -> None:
        self.msgs_to_complete: dict[str, list[dict[str, Any]]] = {}
        self.completion_functions: dict[str, Any] = {}  # todo correct callable
        self.cursor = cursor

    def translate(self, feed_msg: Row) -> Any:
        """Traduce uno o più messaggi dal feed_msg, accumulando nel proprio stato una lista di msg incompleti."""
        msgs = []
        for translator in self.get_translator(feed_msg):
            trs = translator(self.cursor)
            msg = trs.translate(feed_msg)
            msgs.append(msg)

            if msg.is_valid:
                if hasattr(trs, "msg_completion_function"):
                    trs_class = trs.__class__.__name__
                    if trs_class not in self.msgs_to_complete:
                        self.msgs_to_complete[trs_class] = []
                        self.completion_functions[trs_class] = trs.msg_completion_function
                    self.msgs_to_complete[trs_class].append(msg)

        return msgs

    def get_translator(self, feed_msg: Row) -> Any:
        """Capisce il tipo di messaggio in ingresso e restituisce la classe Translator opportuna."""
        raise NotImplementedError()

    def complete(self) -> dict[str, list[dict[str, Any]]]:
        """Tenta il completamento dei msg incompleti accumulati."""
        for trs_class, msgs in self.msgs_to_complete.items():
            self.completion_functions[trs_class](msgs)
        return self.msgs_to_complete


def _to_dict_row(feed_msg: Row) -> dict[str, Any]:
    return dict(zip([t[0] for t in feed_msg.cursor_description], feed_msg))


class AbstractTranslator:
    """Base per le classi di traduzione dei messaggi dai provider.

    La classe concreta, oltre a implementare i metodi per la valorizzazione dei campi comuni e specifici
    di classe del messaggio, dovrà definire i seguenti attributi:

    ```
    def __init__(self, cursor: Cursor) -> None:
        self.cursor = cursor
        self.valid_class, self.invalid_class, self.fields = Schemas.[ClasseMessaggio].value
        self.msg_completion_function = completion_function_classe_messaggio
    ```

    self.msg_completion_function, se implementata, riceve i messaggi tradotti, mappati sulla source di ogni messaggio.
    Dovrà restituire un mapping equivalente ma con a valore il dizionario di completezza.

    ```
    def complete_cash(data: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:

        # data == {"pycc.TableName:id": {"msg_field": "value", ...}, ...}
        ...
        # return {"pycc.TableName:id": {"new_field": "new_value", ...}, ...}
    ```

    """

    def get_provider_msgid(self, feed_msg: Row) -> str | None:
        """Torna l'eventuale identificativo del messaggio del provider."""
        return None

    def get_rettifica(self, feed_msg: Row) -> int | str | None:
        """Torna il source id del messaggio che rettifica."""
        return None

    def get_feed_msgs_accorpati(self, feed_msg: Row) -> list[str]:
        return []

    def post_check(self, feed_msg: Row, msg: dict[str, Any], errors: dict[str, Any]) -> None:
        """Controlla condizioni di invalidità dipendenti da più campi del messaggio."""
        pass

    def translate(self, feed_msg: Row) -> dict[str, Any]:
        msg: dict[str, Any] = {
            "meta_": {
                "provider": feed_msg.provider,
                "feed": feed_msg.feed,
                "routing_state": json.loads(feed_msg.routing_state),
                "id": feed_msg.source,
                "row": _to_dict_row(feed_msg),
                "ver": 1,
                "sender": None,
                "call_global_id": None,
                "call_single_id": None,
            },
            "mappings_": {},
        }
        errors = {}

        for k in [field[0] for field in self.fields if field[0] not in ("meta_", "mappings_")]:  # type: ignore
            try:
                fun = getattr(self, f"get_{k}")
                msg[k] = fun(feed_msg)
                # se il campo è a sua volta un InvalidMsg, aggiungo i suoi errori ai miei
                if hasattr(msg[k], "meta_") and "errors" in msg[k].meta_ and len(msg[k].meta_["errors"]) > 0:
                    errors[k] = msg[k].meta_["errors"]
            except NotImplementedError as e:
                raise e
            except Exception as e:
                msg[k] = None
                desc = f"{e.__class__.__name__} : {str(e)})"
                errors[k] = (
                    [
                        desc,
                    ]
                    if k not in errors
                    else errors[k]
                    + [
                        desc,
                    ]
                )

        self.post_check(feed_msg, msg, errors)

        for f in [field for field in self.fields if field[0] in ("mappings_")]:  # type: ignore
            for k in frozenset.union(*[f[1].__required_keys__, f[1].__optional_keys__]):
                msg["mappings_"][k] = None

        if len(errors) == 0:
            return self.valid_class(**msg)  # type: ignore
        else:
            msg["meta_"]["errors"] = errors
            return self.invalid_class(**msg)  # type: ignore
