"""Utility per la gestione portafoglio titoli su QTask."""
from datetime import date, datetime
from decimal import Decimal as D
from typing import Any, Dict, List, Optional, Tuple, Union

import pyodbc

from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import DBAction, DBObject
from pymol.validation import Schema, SchemaError, is_isin

from .conti import cached_conto_titoli
from .schema import SaldoQTask
from .utils import get_date_fatturazione

four = D("0.0000")


class Titoli:
    @classmethod
    def saldo_conto_titoli(
        cls,
        cursor: pyodbc.Cursor,
        saldo: SaldoQTask,
        ts: datetime,
        crea: bool = True,
        account_number: bool = False,
    ) -> Tuple[List[DBObject], Dict[str, List[Dict[str, str]]]]:
        """Todo."""
        dbobjects: List[DBObject] = []
        consolidate_list = []

        if saldo.common_params.cod_consolidanti:
            consolidate_list = list(saldo.common_params.cod_consolidanti)
            consolidate_list.sort()

        dati_incarico, created_objects = cached_conto_titoli(
            cursor=cursor,
            chiave_cliente=saldo.chiave_cliente,
            nome_relazione_bancaria=saldo.nome_relazione_bancaria,
            anno=saldo.anno,
            nome_conto=saldo.nome_conto,
            numero_conto=saldo.numero_conto,
            cod_valuta=saldo.cod_valuta,
            id_banca=saldo.common_params.cod_banca,
            cod_tipo_incarico_master=saldo.common_params.cod_tipo_incarico_master,
            cod_area=saldo.common_params.cod_area,
            cod_cliente=saldo.common_params.cod_cliente,
            cod_tipo_workflow=saldo.common_params.cod_tipo_workflow,
            cod_tipo_incarico_slave=saldo.common_params.cod_tipo_incarico_slave,
            ts=ts,
            cod_consolidanti=tuple(consolidate_list),
            create=crea,
            account_number_filter=account_number,
        )

        # recupero le informazioni sul subincarico e sull'incarico master
        info_incarico: dict[str, Any] = cls.check_info_subincarico(cursor, saldo, dati_incarico, created_objects)

        # controllo per il subincarico se la data valuta cade nel periodo di fatturazione valido
        # ritorno le date di inizio e fine del periodo di fatturazione valido
        date_valide: dict[str, date] = cls.check_fatturazione(cursor, saldo, dati_incarico, info_incarico)

        # recupero le informazioni del subincarico dell'annualità precedente (utile per pratiche cross-anno)
        info_incarico = cls.get_info_subincarico_anno_prec(cursor, saldo, dati_incarico, info_incarico, date_valide)

        # cancellazione saldi vecchi dall'idcontotitoli e dall'eventuale idcontotitoli dell'anno precedente
        cls.clean_old_saldi(cursor, saldo, dati_incarico, info_incarico, date_valide)

        dbobjects.extend(list(set(created_objects) - set(dbobjects)))
        importo = merge_amount(
            cursor=cursor,
            amounts=saldo.importi,
            desired_currency=dati_incarico["cod_valuta"],
            fx_date=saldo.data_valuta,
        )
        if importo is None:
            raise BusinessValueError("Ricavo un importo nullo dal messaggio")
        saldo_objs = cls.insert_or_update_saldo_titoli(
            cursor=cursor,
            idcontotitoliperanno=dati_incarico["idcontotitoliperanno"],
            idtitolo=saldo.idtitolo,  # type: ignore
            data_valuta=saldo.data_valuta,
            qty=saldo.qty,
            importo=importo,
            date_valide=date_valide,
            rateo=saldo.rateo,
            prezzo=saldo.prezzo,
            flagIncompleto=saldo.flagIncompleto,
        )
        saldo_objs_storico = cls.insert_saldo_titoli_storico(
            cursor=cursor,
            idcontotitoliperanno=dati_incarico["idcontotitoliperanno"],
            idtitolo=saldo.idtitolo,  # type: ignore
            data_valuta=saldo.data_valuta,
            qty=saldo.qty,
            importo=importo,
            is_metallo=saldo.is_metallo,
            prezzo=saldo.prezzo,
        )

        dbobjects.extend(saldo_objs)
        dbobjects.extend(saldo_objs_storico)

        return dbobjects, {"info": []}

    @classmethod
    def insert_or_update_saldo_titoli(
        cls,
        cursor: pyodbc.Cursor,
        idcontotitoliperanno: int,
        idtitolo: int,
        data_valuta: date,
        qty: D,
        importo: D,
        date_valide: dict[str, Any],
        rateo: D | None = None,
        prezzo: D | None = None,
        flagIncompleto: int = 0,
    ) -> List[DBObject]:
        dbobjects = []
        cursor.execute(
            """
            SELECT COUNT(*) FROM dbo.T_SaldoContoTitoli WHERE IdContoTitoliPerAnno = ?
            AND IdTitoloFinanziario = ? AND DataSaldo>= ? AND DataSaldo <= ?
            """,
            idcontotitoliperanno,
            idtitolo,
            date_valide["data_inizio"],
            date_valide["data_fine"],
        )
        if cursor.fetchone()[0] == 0:
            if qty != 0:
                cursor.execute(
                    """
                INSERT INTO dbo.T_SaldoContoTitoli
                (IdContoTitoliPerAnno, DataSaldo, IdTitoloFinanziario, Quantita, PrezzoUnitario,
                ImportoLordo, Rateo, FlagIncompleto)
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    idcontotitoliperanno,
                    data_valuta,
                    idtitolo,
                    D(str(qty)).quantize(four),
                    D(str(prezzo)).quantize(four)
                    if prezzo
                    else ((D(str(importo)) / D(str(qty))).quantize(four) if qty else None),
                    D(str(importo)).quantize(four),
                    D(str(rateo)).quantize(four) if rateo else None,
                    flagIncompleto,
                )
                cursor.execute("""SELECT @@IDENTITY""")
                id_saldo_conto_titoli = cursor.fetchone()[0]
                dbobjects.append(
                    DBObject(table="dbo.T_SaldoContoTitoli", idcol="IdSaldoContoTitoli", id=id_saldo_conto_titoli)
                )
        else:
            cursor.execute(
                """
                SELECT MAX(DataSaldo) as dataSaldo FROM dbo.T_SaldoContoTitoli WHERE IdContoTitoliPerAnno = ?
                AND IdTitoloFinanziario = ? AND DataSaldo>= ? AND DataSaldo <= ?
                """,
                idcontotitoliperanno,
                idtitolo,
                date_valide["data_inizio"],
                date_valide["data_fine"],
            )

            res = cursor.fetchone()
            if res.dataSaldo.date() <= data_valuta:
                if qty == 0:
                    cursor.execute(
                        """
                        DELETE FROM dbo.T_SaldoContoTitoli WHERE IdContoTitoliPerAnno = ? AND IdTitoloFinanziario = ?
                        AND DataSaldo>= ? AND DataSaldo <= ?
                        """,
                        idcontotitoliperanno,
                        idtitolo,
                        date_valide["data_inizio"],
                        date_valide["data_fine"],
                    )
                else:
                    cursor.execute(
                        """
                        SELECT IdSaldoContoTitoli as id FROM dbo.T_SaldoContoTitoli WHERE IdContoTitoliPerAnno = ?
                        AND IdTitoloFinanziario = ? AND DataSaldo>= ? AND DataSaldo <= ?
                        """,
                        idcontotitoliperanno,
                        idtitolo,
                        date_valide["data_inizio"],
                        date_valide["data_fine"],
                    )

                    res = cursor.fetchone()

                    cursor.execute(
                        """
                        DECLARE @id INT
                        UPDATE dbo.T_SaldoContoTitoli SET DataSaldo = ?, Quantita = ?, PrezzoUnitario = ?,
                        ImportoLordo = ?, @id = dbo.T_SaldoContoTitoli.IdSaldoContoTitoli, Rateo = ?,
                        FlagIncompleto = ?, IdDocumento = NULL
                        WHERE IdContoTitoliPerAnno = ? AND IdTitoloFinanziario = ?
                        AND IdSaldoContoTitoli = ?
                        SELECT @id
                        """,
                        data_valuta,
                        D(str(qty)).quantize(four),
                        D(str(prezzo)).quantize(four)
                        if prezzo
                        else ((D(str(importo)) / D(str(qty))).quantize(four) if qty else None),
                        D(str(importo)).quantize(four),
                        D(str(rateo)).quantize(four) if rateo else None,
                        flagIncompleto,
                        idcontotitoliperanno,
                        idtitolo,
                        res.id,
                    )
                    id_saldo_conto_titoli = cursor.fetchone()[0]
                    dbobjects.append(
                        DBObject(
                            table="dbo.T_SaldoContoTitoli",
                            idcol="IdSaldoContoTitoli",
                            id=id_saldo_conto_titoli,
                            action=DBAction.Update,
                        )
                    )

            else:
                dbobjects.append(
                    DBObject(
                        table="",
                        idcol="",
                        id=None,
                        action=DBAction.Skip,
                    )
                )

        return dbobjects

    @classmethod
    def insert_saldo_titoli_storico(
        cls,
        cursor: pyodbc.Cursor,
        idcontotitoliperanno: int,
        idtitolo: int,
        data_valuta: date,
        qty: D,
        importo: D,
        is_metallo: bool,
        prezzo: D | None = None,
        borsa: Optional[str] = None,
    ) -> List[DBObject]:
        dbobjects = []
        if qty != 0:
            cursor.execute(
                """
            INSERT INTO scratch.T_HST_SaldoContoTitoli
            (IdContoTitoliPerAnno, DataSaldo, IdTitoloFinanziario, Quantita, PrezzoUnitario, ImportoLordo,
            IsMetallo, QuotazioneSaldoSwift)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                idcontotitoliperanno,
                data_valuta,
                idtitolo,
                D(str(qty)).quantize(four),
                prezzo.quantize(four) if prezzo else (D(str(importo)) / D(str(qty))).quantize(four),
                D(str(importo)).quantize(four),
                is_metallo,
                borsa,
            )
            cursor.execute("""SELECT @@IDENTITY""")
            id_saldo_conto_titoli = cursor.fetchone()[0]
            dbobjects.append(
                DBObject(table="scratch.T_HST_SaldoContoTitoli", idcol="IdSaldoContoTitoli", id=id_saldo_conto_titoli)
            )

        return dbobjects

    @staticmethod
    def check_info_subincarico(
        cursor: pyodbc.Cursor,
        saldo: SaldoQTask,
        dati_incarico: dict[str, Any],
        created_objects: list[DBObject],
    ) -> dict[str, Any]:

        info: dict[str, Any] = {}
        if "idincarico" in dati_incarico.keys():
            # recupero l'ultima gestione dell'incarico e la data di fine periodo fiscale
            cursor.execute(
                """SELECT trisi.IdIncarico, ti.ChiaveCliente, trisi.IdSubIncarico, ti1.ChiaveCliente,
                dtda.Descrizione, dtda.Codice, tda.Testo FROM T_R_Incarico_SubIncarico trisi
                JOIN T_DatoAggiuntivo tda ON trisi.IdSubIncarico  = tda.IdIncarico
                JOIN T_Incarico ti ON trisi.IdIncarico = ti.IdIncarico
                JOIN T_Incarico ti1 ON trisi.IdSubIncarico  = ti1.IdIncarico
                JOIN D_TipoDatoAggiuntivo dtda ON dtda.Codice = tda.CodTipoDatoAggiuntivo
                WHERE trisi.IdIncarico = ? AND ti.CodCliente = 149 AND ti.CodTipoIncarico =238
                AND tda.FlagAttivo = 1 AND tda.CodTipoDatoAggiuntivo IN (1289, 1290, 1291, 1292)
                ORDER BY IdSubIncarico DESC""",
                dati_incarico["idincarico"],
            )
            res = cursor.fetchone()
            if res:
                # subincarico già presente, recupero il suo dato aggiuntivo
                info["annualità"] = res.ChiaveCliente[0:4]
                parts = res.Descrizione.split()
                info["tipo_gestione"] = parts[len(parts) - 1].lower()  # annuale, semestrale, trimestrale, mensile
                info["dato_aggiuntivo"] = res.Testo
                info["creato"] = False
            else:
                # subincarico appena creato, recupero le info dell'ultimo dato aggiuntivo dell'annualità precedente
                cursor.execute(
                    """SELECT trisi.IdIncarico, ti.ChiaveCliente, trisi.IdSubIncarico, ti1.ChiaveCliente,
                    dtda.Descrizione, dtda.Codice, tda.Testo FROM T_R_Incarico_SubIncarico trisi
                    JOIN T_DatoAggiuntivo tda ON trisi.IdSubIncarico  = tda.IdIncarico
                    JOIN T_Incarico ti ON trisi.IdIncarico = ti.IdIncarico
                    JOIN T_Incarico ti1 ON trisi.IdSubIncarico  = ti1.IdIncarico
                    JOIN D_TipoDatoAggiuntivo dtda ON dtda.Codice = tda.CodTipoDatoAggiuntivo
                    WHERE trisi.IdIncarico = ? AND ti.CodCliente = 149 AND ti.CodTipoIncarico =238
                    AND tda.FlagAttivo = 1 AND tda.CodTipoDatoAggiuntivo IN (1289, 1290, 1291, 1292)
                    ORDER BY IdSubIncarico DESC""",
                    dati_incarico["idincarico"],
                )
                res = cursor.fetchone()
                if not res:
                    raise BusinessValueError("Impossibile recupera il tipo di gestione dall'incarico master.")

                info["annualità"] = res.ChiaveCliente[0:4]
                parts = res.Descrizione.split()
                info["tipo_gestione"] = parts[len(parts) - 1].lower()  # annuale, semestrale, trimestrale, mensile
                info["dato_aggiuntivo"] = res.Testo
                info["creato"] = True

            # recupero la data di fine periodo fiscale
            cursor.execute(
                """SELECT ti2.IdIncarico, ChiaveCliente, tda.CodTipoDatoAggiuntivo, dtda.Descrizione, tda.Testo
                FROM T_Incarico ti2 JOIN T_DatoAggiuntivo tda ON ti2.IdIncarico = tda.IdIncarico
                JOIN D_TipoDatoAggiuntivo dtda ON dtda.Codice = tda.CodTipoDatoAggiuntivo
                WHERE ti2.IdIncarico = ? AND ti2.CodCliente = 149 AND ti2.CodTipoIncarico = 238
                AND tda.FlagAttivo = 1 AND tda.CodTipoDatoAggiuntivo = 1287""",
                dati_incarico["idincarico"],
            )
            res = cursor.fetchone()
            if not res:
                raise BusinessValueError(
                    f"""Impossibile recuperare la data di fine periodo fiscale
                (incarico: {dati_incarico['idincarico']})."""
                )

            info["fine_periodo_fiscale"] = res.Testo

        else:
            raise BusinessValueError("Impossibile recuperare le informazioni sull'incarico.")

        return info

    @staticmethod
    def get_info_subincarico_anno_prec(
        cursor: pyodbc.Cursor,
        saldo: SaldoQTask,
        dati_incarico: dict[str, Any],
        info_incarico: dict[str, Any],
        date_fatturazione: dict[str, date],
    ) -> dict[str, Any]:
        # recupero l'ultimo conto titoli per anno, escluso quello appena creato, in caso di nuovo anno
        if date_fatturazione["data_inizio"].year != date_fatturazione["data_fine"].year:
            cursor.execute(
                """SELECT IdContoTitoliPerAnno FROM dbo.T_ContoTitoliPerAnno ctpa
                INNER JOIN dbo.T_ContoTitoli tct on ctpa.IdContoTitoli = tct.IdContoTitoli
                WHERE tct.IdContoTitoli = ? AND IdIncarico <> ? AND Anno = ? ORDER BY tct.IdContoTitoli DESC""",
                dati_incarico["idcontotitoli"],
                dati_incarico["idsubincarico"],
                saldo.anno - 1,
            )
            res = cursor.fetchone()
            info_incarico["idcontotitoliperanno_anno_prec"] = res.IdContoTitoliPerAnno if res else None
        else:
            info_incarico["idcontotitoliperanno_anno_prec"] = None
        return info_incarico

    @staticmethod
    def check_fatturazione(
        cursor: pyodbc.Cursor, saldo: SaldoQTask, dati_incarico: dict[str, Any], info_incarico: dict[str, Any]
    ) -> dict[str, date]:
        info: dict[str, Any] = {}

        data_inizio, data_fine = get_date_fatturazione(info_incarico)

        if saldo.data_valuta < data_inizio or saldo.data_valuta > data_fine:
            raise BusinessValueError("Data valuta non inclusa nel periodo di fatturazione selezionato")

        info["data_inizio"] = data_inizio
        info["data_fine"] = data_fine

        return info

    @staticmethod
    def clean_old_saldi(
        cursor: pyodbc.Cursor,
        saldo: SaldoQTask,
        dati_incarico: dict[str, Any],
        info_incarico: dict[str, Any],
        date_valide: dict[str, date],
    ) -> None:
        idcontotitoliperanno_anno_prec = info_incarico["idcontotitoliperanno_anno_prec"]
        idcontotitoliperanno = dati_incarico["idcontotitoliperanno"]
        # cancellazione eventuali saldi rimasti in subincarichi di annualità precedenti
        # ma riferiti allo stesso periodo di fatturazione
        if idcontotitoliperanno_anno_prec:
            cursor.execute(
                """
                DELETE FROM dbo.T_SaldoContoTitoli WHERE IdContoTitoliPerAnno = ?
                AND DataSaldo>= ? AND DataSaldo <= ?
                """,
                idcontotitoliperanno_anno_prec,
                date_valide["data_inizio"],
                date_valide["data_fine"],
            )

        # cancellazione dei saldi del conto titoli con date contenute nel range di fatturazione
        # ma con datasaldo inferiore a quella che sto processando (saldi vecchi)
        cursor.execute(
            """
                DELETE FROM dbo.T_SaldoContoTitoli WHERE IdContoTitoliPerAnno = ?
                AND DataSaldo>= ? AND DataSaldo <= ? AND DataSaldo < ?
                """,
            idcontotitoliperanno,
            date_valide["data_inizio"],
            date_valide["data_fine"],
            saldo.data_valuta,
        )


def merge_amount(
    cursor: pyodbc.Cursor,
    amounts: list[tuple[D, int]] = [],
    desired_currency: Optional[int] = None,
    fx_date: date = date.today(),
) -> D | None:
    output = None
    if len(amounts) == 0:
        return None
    if desired_currency is None:
        raise BusinessValueError("Non è possibile convertire somma senza il cambio desiderato")

    for partial_amount, amount_currency in amounts:
        if partial_amount is not None and amount_currency is not None:
            if not output:
                output = convert_fx(cursor, amount_currency, desired_currency, partial_amount, fx_date)
            else:
                output += convert_fx(cursor, amount_currency, desired_currency, partial_amount, fx_date)

    return output


def next_progressivo_conto(cursor: pyodbc.Cursor, id_conto_bancario_annuo: int) -> int:
    cursor.execute(
        """
    SELECT  MAX(T_MovimentoContoBancario.Progressivo)
    FROM T_MovimentoContoBancario
    WHERE T_MovimentoContoBancario.IdContoBancarioPerAnno = ?""",
        id_conto_bancario_annuo,
    )
    res = cursor.fetchone()
    if res[0]:
        return int(res[0]) + 1
    return 1


def convert_fx(
    cursor: pyodbc.Cursor, src_cod_currency: int, dst_cod_currency: int, amount: D, fx_date: date = date.today()
) -> D:
    """Converti l'amount dalla currency src alla currency dst."""
    if int(src_cod_currency) == (dst_cod_currency):
        return amount

    cursor.execute(
        """SELECT Cambio FROM S_CambioValuta WHERE Data = ? and CodTipoCambioValuta = 1 AND CodValuta = ?""",
        fx_date,
        dst_cod_currency,
    )
    row = cursor.fetchone()
    if not row:
        cursor.execute("""SELECT Descrizione FROM D_Valuta WHERE Codice = ?""", dst_cod_currency)
        line = cursor.fetchone()
        raise BusinessValueError(f"Can't find {str(fx_date)} EUR to {line.Descrizione} FX")
    euro_to_dst = D(row[0])
    if src_cod_currency == 1:
        return D(round(float(amount * euro_to_dst), 6))

    cursor.execute(
        """SELECT Cambio FROM S_CambioValuta WHERE Data = ? and CodTipoCambioValuta = 1 AND CodValuta = ?""",
        fx_date,
        src_cod_currency,
    )
    row = cursor.fetchone()
    if not row:
        cursor.execute("""SELECT Descrizione FROM D_Valuta WHERE Codice = ?""", src_cod_currency)
        line = cursor.fetchone()
        raise BusinessValueError(f"Can't find {str(fx_date)} EUR to {src_cod_currency} FX")
    euro_to_src = D(str(row[0]))
    amount_in_euro = D(str(amount)) * D(1 / euro_to_src)

    return D(round(float(amount_in_euro * euro_to_dst), 6))


def get_op_segno(
    cursor: pyodbc.Cursor,
    id_operazione: int,
) -> int:

    cursor.execute(
        """SELECT SegnoImporto
            FROM S_OperazioneContoBancario WHERE IdOperazioneContoBancario = ?""",
        id_operazione,
    )
    msg = cursor.fetchone()

    if not msg:
        raise BusinessValueError(f"""Segno importo non trovato per l'id operazione {id_operazione}.""")

    return int(msg.SegnoImporto)


def get_relazione_from_mandato(
    cursor: pyodbc.Cursor,
    account: str,
    ext_params: Dict[str, Any],
) -> Tuple[str, Optional[str]]:

    cursor.execute(
        """SELECT ChiaveClienteMaster, CodMandatodaFlussoAggiuntivo
            FROM pycc.AssociazioneIncarichiAiFlussi
            WHERE CodMandatoDaFlusso = ? AND CodCliente = ? AND CodBancaVD = ?""",
        account,
        ext_params["cod_cliente"],
        ext_params["cod_banca"],
    )
    msg = cursor.fetchone()

    if not msg:
        raise BusinessValueError(
            f"Chiave cliente non trovata per il mandato {account}" f" e codice cliente {ext_params['cod_cliente']}"
        )

    return (str(msg.ChiaveClienteMaster), msg.CodMandatodaFlussoAggiuntivo)


def get_destination_from_mandato(
    cursor: pyodbc.Cursor,
    account: str,
    ext_params: Dict[str, Any],
) -> bool:

    cursor.execute(
        """SELECT isQtask
            FROM pycc.AssociazioneIncarichiAiFlussi
            WHERE CodMandatoDaFlusso = ? AND CodCliente = ? AND CodBancaVD = ?""",
        account,
        ext_params["cod_cliente"],
        ext_params["cod_banca"],
    )
    msg = cursor.fetchone()

    if not msg:
        raise BusinessValueError(
            f"Chiave cliente non trovata per il mandato {account}" f" e codice cliente {ext_params['cod_cliente']}"
        )

    return bool(msg.isQtask)


def insert_titoli_non_censiti(
    cursor: pyodbc.Cursor,
    msg_table: str,
    codCliente: Union[str, None, int],
    nome_titolo: Optional[str],
    msg_id: Optional[int] = None,
    ISIN: Optional[str] = None,
) -> None:
    """Inserisce un titolo nella tabella dei titoli non censiti."""
    if ISIN:
        cursor.execute(
            """
        SELECT COUNT(*) as cnt FROM scratch.ElementiNonCensiti WHERE ISIN = ?
        """,
            ISIN,
        )
    else:
        cursor.execute(
            """
        SELECT COUNT(*) as cnt FROM scratch.ElementiNonCensiti WHERE NomeTitolo = ?
        """,
            nome_titolo,
        )

    res = cursor.fetchone()

    if not res.cnt:
        cursor.execute(
            """
            INSERT INTO scratch.ElementiNonCensiti (NomeTitolo, ISIN, msg_id, CodCliente, msg_table)
            VALUES (?, ?, ?, ?, ?)
            """,
            nome_titolo,
            ISIN,
            msg_id,
            codCliente,
            msg_table,
        )

        cursor.commit()

    return


def get_id_titolo(
    cursor: pyodbc.Cursor,
    msg_id: int,
    codCliente: int,
    msg_table: str,
    nome_titolo: Optional[str] = None,
    ISIN: Optional[str] = None,
) -> Tuple[int, int, bool, int]:
    """Todo."""
    _is_isin = False

    if not ISIN:

        cursor.execute(
            """SELECT COUNT(*) as cnt

        FROM T_TitoloFinanziario WHERE NomeTitolo = ? GROUP BY NomeTitolo""",
            nome_titolo,
        )

        msg = cursor.fetchone()

        if msg and msg.cnt > 1:

            raise BusinessValueError(f"Titolo {nome_titolo} censito più di una volta")

        cursor.execute(
            """SELECT idtitolofinanziario, CodTipoTitoloFinanziario, CodStatoEmissione

        FROM T_TitoloFinanziario WHERE NomeTitolo = ?""",
            nome_titolo,
        )

        msg = cursor.fetchone()

        if not msg:

            insert_titoli_non_censiti(
                cursor, msg_table=msg_table, msg_id=msg_id, nome_titolo=str(nome_titolo), codCliente=codCliente
            )

            raise BusinessValueError(f"Titolo {nome_titolo} non censito")

    else:
        try:
            schema = Schema({"isin": is_isin})
            schema.validate({"isin": ISIN})
            cursor.execute(
                """SELECT idtitolofinanziario, CodTipoTitoloFinanziario, CodStatoEmissione
                FROM T_TitoloFinanziario WHERE ISIN = ?""",
                ISIN,
            )
            msg = cursor.fetchone()
            if not msg:
                insert_titoli_non_censiti(
                    cursor,
                    nome_titolo=nome_titolo,
                    ISIN=ISIN,
                    msg_id=msg_id,
                    msg_table=msg_table,
                    codCliente=codCliente,
                )
                raise BusinessValueError(f"ISIN {ISIN} non censito")
            _is_isin = True
        except SchemaError:
            cursor.execute(
                """SELECT idtitolofinanziario, CodTipoTitoloFinanziario, CodStatoEmissione
                FROM T_TitoloFinanziario WHERE NumeroValore = ?""",
                ISIN,
            )
            msg = cursor.fetchone()
            if not msg:
                insert_titoli_non_censiti(
                    cursor,
                    nome_titolo=nome_titolo,
                    ISIN=str(ISIN),
                    msg_id=msg_id,
                    msg_table=msg_table,
                    codCliente=codCliente,
                )
                raise BusinessValueError(f"ISIN {ISIN} non è valido e non è censito come NumeroValore")

    return (msg.idtitolofinanziario, msg.CodTipoTitoloFinanziario, _is_isin, msg.CodStatoEmissione)
