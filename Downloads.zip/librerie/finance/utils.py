"""Libreria Utils."""
import calendar
from datetime import date, datetime, timedelta
from typing import Any, Optional, Tuple

import pyodbc

from pymol.types.exceptions import BusinessValueError


def split_consolidanti(params: str) -> set[int]:
    if params:
        return set([int(c) for c in str(params).split(",") if len(c)])
    else:
        return set()


def get_msg_state(cursor: pyodbc.Cursor, id: int, table: str, table_column: str) -> str:
    cursor.execute(f"""SELECT msg_state FROM {table} WHERE {table_column} = ?""", str(id))
    res = cursor.fetchone()

    return str(res.msg_state)


def set_msg_state(cursor: pyodbc.Cursor, id: int, table: str, msg_state: str, table_column: str) -> None:
    cursor.execute(f"""UPDATE {table} SET msg_state = '{msg_state}' WHERE {table_column} = ?""", id)
    return


def get_date_fatturazione(info_incarico: dict[str, Any]) -> Tuple[date, date]:  # noqa
    giorno_fine_fiscale = int(info_incarico["fine_periodo_fiscale"].split("/")[0])
    mese_fine_fiscale = int(info_incarico["fine_periodo_fiscale"].split("/")[1])
    if info_incarico["creato"]:
        # assenza di dato aggiuntivo e annualità diversa da quelle presenti
        ultimo_giorno_fiscale = datetime.strptime(
            f"""{info_incarico['annualità']}-{mese_fine_fiscale}-{giorno_fine_fiscale}""", "%Y-%m-%d"
        )

        fattore_incrementale = None
        match info_incarico["tipo_gestione"]:
            case "trimestrale":
                fattore_incrementale = 3
            case "semestrale":
                fattore_incrementale = 6
            case "annuale":
                fattore_incrementale = 12
            case _:
                # mensile
                fattore_incrementale = 1

        data_inizio_periodo = datetime.strptime(str((ultimo_giorno_fiscale + timedelta(days=1)).date()), "%Y-%m-%d")
        data_fine_periodo = add_months(ultimo_giorno_fiscale, fattore_incrementale, giorno_fine_fiscale)
        while int(data_fine_periodo.strftime("%Y")) != int(info_incarico["annualità"]) + 1:
            data_inizio_periodo = datetime.strptime(str((data_fine_periodo + timedelta(days=1))), "%Y-%m-%d")
            data_fine_periodo = add_months(data_fine_periodo, fattore_incrementale, giorno_fine_fiscale)

        data_inizio = data_inizio_periodo.date()
        data_fine = datetime.strptime(str((data_fine_periodo)), "%Y-%m-%d").date()

    else:
        # dato aggiuntivo già presente
        parts = info_incarico["dato_aggiuntivo"].split(" [")[0].split(" (")[0].split(" ")
        ultimo_giorno_fiscale = datetime.strptime(
            f"""{info_incarico['annualità']}-{mese_fine_fiscale}-{giorno_fine_fiscale}""", "%Y-%m-%d"
        )

        start = None
        end = None
        i = len(parts) - 1
        periodo = ""
        while i >= 0:
            periodo = parts[i].upper() if i == len(parts) - 1 else parts[i].upper() + " " + periodo
            if periodo in FATTURAZIONE_TO_DATE.keys():
                start, end = FATTURAZIONE_TO_DATE[periodo]
                break
            i = i - 1

        if periodo in FATTURAZIONE_TO_DATE.keys():
            start, end = FATTURAZIONE_TO_DATE[periodo]

        if not start:
            raise BusinessValueError("Impossibile ricavare informazioni sul periodo di fatturazione")

        if not end:
            # gestione mensile
            last_day_of_month = calendar.monthrange(int(info_incarico["annualità"]), start)[1]
            data_inizio = datetime.strptime(f"{info_incarico['annualità']}-{start}-01", "%Y-%m-%d")
            data_fine = datetime.strptime(
                f"{info_incarico['annualità']}-{start}-{last_day_of_month}", "%Y-%m-%d"
            ).date()
        else:
            # gestione trimestrale, semestrale, annuale
            fattore_incrementale = None
            if "trimestre" in periodo.lower():
                fattore_incrementale = 3
                counter = (
                    3
                    if "III TRIMESTRE" in periodo
                    else (2 if "II TRIMESTRE" in periodo else (4 if "IV TRIMESTRE" in periodo else 1))
                )
            elif "semestre" in periodo.lower():
                fattore_incrementale = 6
                counter = 2 if "II SEMESTRE" in periodo else 1
            else:
                fattore_incrementale = 12
                counter = 1

            data_inizio_periodo = datetime.strptime(str((ultimo_giorno_fiscale + timedelta(days=1)).date()), "%Y-%m-%d")
            if data_inizio_periodo.year > int(info_incarico["annualità"]):
                # pratica con data fine fiscale 31/12
                data_inizio_periodo = datetime.strptime(f"{int(info_incarico['annualità'])}-01-01", "%Y-%m-%d")
                data_fine_temp = datetime.strptime(f"{int(info_incarico['annualità'])-1}-12-31", "%Y-%m-%d")
                data_fine_periodo = add_months(data_fine_temp, fattore_incrementale, giorno_fine_fiscale)
            else:
                data_fine_periodo = add_months(ultimo_giorno_fiscale, fattore_incrementale, giorno_fine_fiscale)

            if counter:
                counter -= 1
                while counter > 0:
                    data_inizio_periodo = datetime.strptime(str((data_fine_periodo + timedelta(days=1))), "%Y-%m-%d")
                    data_fine_periodo = add_months(data_fine_periodo, fattore_incrementale, giorno_fine_fiscale)
                    counter -= 1

            data_inizio = data_inizio_periodo.date()
            data_fine = datetime.strptime(str((data_fine_periodo)), "%Y-%m-%d").date()
    return data_inizio, data_fine


FATTURAZIONE_TO_DATE: dict[str, tuple[int, Optional[int]]] = {
    ("GENNAIO"): (1, None),
    ("FEBBRAIO"): (2, None),
    ("MARZO"): (3, None),
    ("APRILE"): (4, None),
    ("MAGGIO"): (5, None),
    ("GIUGNO"): (6, None),
    ("LUGLIO"): (7, None),
    ("AGOSTO"): (8, None),
    ("SETTEMBRE"): (9, None),
    ("OTTOBRE"): (10, None),
    ("NOVEMBRE"): (11, None),
    ("DICEMBRE"): (12, None),
    ("I TRIMESTRE"): (1, 3),
    ("II TRIMESTRE"): (4, 6),
    ("III TRIMESTRE"): (7, 9),
    ("IV TRIMESTRE"): (10, 12),
    ("I SEMESTRE"): (1, 6),
    ("II SEMESTRE"): (7, 12),
    ("ANNUALE"): (1, 12),
}


def add_months(data: date, months: int, last_day_fiscale: int) -> date:
    months_count = data.month + months

    # Calculate the year
    year = data.year + (int(months_count / 12) if months_count % 12 != 0 else 0)

    # Calculate the month
    month = months_count % 12
    if month == 0:
        month = 12

    # Calculate the day
    day = data.day
    last_day_of_month = calendar.monthrange(year, month)[1]
    if day > last_day_of_month or (day < last_day_fiscale and last_day_of_month >= last_day_fiscale):
        day = last_day_of_month

    new_date = datetime(year, month, day).date()
    return new_date
