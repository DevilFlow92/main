from datetime import datetime
from decimal import Decimal as D
from enum import Enum
from typing import Any, Dict, List, Tuple

import pyodbc

from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import DBAction, DBObject

from .conti import conto_bancario, nota_incarichi
from .schema import Movimento
from .titoli import merge_amount, next_progressivo_conto
from .utils import get_date_fatturazione


class DbVal(Enum):
    NULL = 1
    DEFAULT = 2


class Movimenti:
    @classmethod
    def movimento_conto_bancario(
        cls,
        cursor: pyodbc.Cursor,
        mov: Movimento,
        ts: datetime,
        crea: bool = True,
        check_crea_subincarico: bool = False,
        check_fatturazione: bool = False,
    ) -> Tuple[List[DBObject], Dict[str, List[Dict[str, str]]]]:
        """Todo."""
        id_movimento, dbobjects, infos = cls.movimento(
            cursor, mov, ts, crea, check_crea_subincarico, check_fatturazione
        )
        id_nota, obj_nota = nota_incarichi(cursor, ts, mov.testo_nota)

        dbobjects.append(obj_nota)
        cursor.execute(
            """
        UPDATE dbo.T_MovimentoContoBancario set IdNotaIncarichi = ?
        WHERE IdMovimentoContoBancario = ?
        """,
            id_nota,
            id_movimento,
        )

        return dbobjects, {"info": [{"info": info} for info in infos]}

    @classmethod
    def consolida_giroconto(
        cls,
        cursor: pyodbc.Cursor,
        mov: Movimento,
        ts: datetime,
        crea: bool = True,
        check_crea_subincarico: bool = False,
        check_fatturazione: bool = False,
    ) -> Tuple[List[DBObject], Dict[str, List[Dict[str, str]]]]:
        """Consolida due movimenti separati in un giroconto."""
        values = mov.__dict__
        id_movimento_esistente = values.pop("linked_mov")
        id_movimento, dbobjs, _ = cls.movimento(cursor, mov, ts, crea, check_crea_subincarico, check_fatturazione)
        cursor.execute(
            """SELECT IdNotaIncarichi, Importo FROM dbo.T_MovimentoContoBancario WHERE IdMovimentoContoBancario = ?""",
            id_movimento_esistente,
        )

        nota = ""
        dati_mov_esistente = cursor.fetchone()

        if dati_mov_esistente:
            cursor.execute(
                """SELECT Testo FROM T_NotaIncarichi WHERE IdNotaIncarichi = ?""",
                dati_mov_esistente.IdNotaIncarichi,
            )
            testo_nota = cursor.fetchone()
            nota = testo_nota.Testo

            cursor.execute(
                """DELETE FROM T_NotaIncarichi WHERE IdNotaIncarichi = ?""",
                dati_mov_esistente.IdNotaIncarichi,
            )
            dbobj_delete = DBObject(
                table="dbo.T_NotaIncarichi",
                idcol="IdNotaIncarichi",
                id=dati_mov_esistente.IdNotaIncarichi,
                action=DBAction.Delete,
            )
            dbobjs.append(dbobj_delete)
        else:
            raise ValueError(f"Nota incarichi non creata per il msg {id_movimento_esistente}")

        nota = nota + " -- " + str(values["testo_nota"])
        id_nota, dbobj = nota_incarichi(cursor, ts, nota)
        dbobjs.append(dbobj)

        cursor.execute(
            "UPDATE dbo.T_MovimentoContoBancario SET CodTipoMovimentoContoBancario = 2,"
            "IdMovimentoContoBancarioCollegato = ?, IdNotaIncarichi = ?, IdOperazioneContoBancario = NULL,"
            "IdTitoloFinanziario = NULL ,Quantita = NULL, QuantitaOriginale = NULL, PrezzoUnitario = NULL,"
            "ImportoLordo = NULL, Commissioni = NULL, Rateo = NULL, Ritenute = NULL, Euroritenute = NULL "
            "WHERE IdMovimentoContoBancario = ?",
            id_movimento_esistente,
            id_nota,
            id_movimento,
        )
        cursor.execute(
            "UPDATE dbo.T_MovimentoContoBancario SET CodTipoMovimentoContoBancario = 2,"
            "IdMovimentoContoBancarioCollegato = ?, IdNotaIncarichi = ?, IdOperazioneContoBancario = NULL,"
            "IdTitoloFinanziario = NULL ,Quantita = NULL, QuantitaOriginale = NULL, PrezzoUnitario = NULL,"
            "ImportoLordo = NULL, Commissioni = NULL, Rateo = NULL, Ritenute = NULL, Euroritenute = NULL "
            "WHERE IdMovimentoContoBancario = ?",
            id_movimento,
            id_nota,
            id_movimento_esistente,
        )

        return dbobjs, {"info": [{"info": f"Consolidato giroconto fra {id_movimento_esistente} e {id_movimento}"}]}

    @classmethod
    def movimento(
        cls,
        cursor: pyodbc.Cursor,
        movimento: Movimento,
        ts: datetime,
        crea: bool = False,
        check_crea_subincarico: bool = False,
        check_fatturazione: bool = False,
        add_relazione: bool = False,
    ) -> Tuple[int, List[DBObject], List[str]]:
        dbobjects: List[DBObject] = []
        dati_incarico, created_objects = conto_bancario(
            cursor=cursor,
            chiave_cliente=movimento.chiave_cliente,
            nome_relazione_bancaria=movimento.nome_relazione_bancaria,
            anno=movimento.anno if movimento.anno else movimento.data_valuta.year,
            nome_conto=movimento.nome_conto,
            numero_conto=movimento.numero_conto,
            cod_valuta=movimento.cod_valuta,
            id_banca=movimento.common_params.cod_banca,
            cod_tipo_incarico_master=movimento.common_params.cod_tipo_incarico_master,
            cod_area=movimento.common_params.cod_area,
            cod_cliente=movimento.common_params.cod_cliente,
            cod_tipo_workflow=movimento.common_params.cod_tipo_workflow,
            cod_tipo_incarico_slave=movimento.common_params.cod_tipo_incarico_slave,
            ts=datetime.now(),
            cod_consolidanti=set(movimento.common_params.cod_consolidanti)
            if movimento.common_params.cod_consolidanti is not None
            else set(),
            create=crea,
            add_relazione=add_relazione,
        )
        dbobjects.extend(created_objects)

        # recupero le informazioni sul subincarico e sull'incarico master
        info_incarico: dict[str, Any] = cls.check_info_subincarico(cursor, movimento, dati_incarico, created_objects)

        # controllo per il subincarico se la data valuta cade nel periodo di fatturazione valido
        # ritorno le date di inizio e fine del periodo di fatturazione valido
        cls.check_fatturazione(cursor, movimento, dati_incarico, info_incarico)

        progressivo = next_progressivo_conto(cursor, dati_incarico["id_conto_bancario_per_anno"])
        importo, importoLordo, commissioni, ritenute, ratei, euroritenute = (
            merge_amount(
                cursor=cursor,
                amounts=movimento.importi,
                desired_currency=dati_incarico["cod_valuta"],
                fx_date=movimento.data_valuta,
            ),
            merge_amount(
                cursor=cursor,
                amounts=movimento.importiLordi,
                desired_currency=dati_incarico["cod_valuta"],
                fx_date=movimento.data_valuta,
            ),
            merge_amount(
                cursor=cursor,
                amounts=movimento.commissioni,
                desired_currency=dati_incarico["cod_valuta"],
                fx_date=movimento.data_valuta,
            ),
            merge_amount(
                cursor=cursor,
                amounts=movimento.ritenute,
                desired_currency=dati_incarico["cod_valuta"],
                fx_date=movimento.data_valuta,
            ),
            merge_amount(
                cursor=cursor,
                amounts=movimento.ratei,
                desired_currency=dati_incarico["cod_valuta"],
                fx_date=movimento.data_valuta,
            ),
            merge_amount(
                cursor=cursor,
                amounts=movimento.euroritenute,
                desired_currency=dati_incarico["cod_valuta"],
                fx_date=movimento.data_valuta,
            ),
        )
        if movimento.multivaluta:
            (
                importo_multival,
                importoLordo_multival,
                commissioni_multival,
                ritenute_multival,
                ratei_multival,
                euroritenute_multival,
            ) = (
                merge_amount(
                    cursor=cursor,
                    amounts=movimento.multivaluta.importi if movimento.multivaluta.importi else [],
                    desired_currency=movimento.multivaluta.cod_valuta,
                    fx_date=movimento.data_valuta,
                ),
                merge_amount(
                    cursor=cursor,
                    amounts=movimento.multivaluta.importiLordi if movimento.multivaluta.importiLordi else [],
                    desired_currency=movimento.multivaluta.cod_valuta,
                    fx_date=movimento.data_valuta,
                ),
                merge_amount(
                    cursor=cursor,
                    amounts=movimento.multivaluta.commissioni if movimento.multivaluta.commissioni else [],
                    desired_currency=movimento.multivaluta.cod_valuta,
                    fx_date=movimento.data_valuta,
                ),
                merge_amount(
                    cursor=cursor,
                    amounts=movimento.multivaluta.ritenute if movimento.multivaluta.ritenute else [],
                    desired_currency=movimento.multivaluta.cod_valuta,
                    fx_date=movimento.data_valuta,
                ),
                merge_amount(
                    cursor=cursor,
                    amounts=movimento.multivaluta.ratei if movimento.multivaluta.ratei else [],
                    desired_currency=movimento.multivaluta.cod_valuta,
                    fx_date=movimento.data_valuta,
                ),
                merge_amount(
                    cursor=cursor,
                    amounts=movimento.multivaluta.euroritenute if movimento.multivaluta.euroritenute else [],
                    desired_currency=movimento.multivaluta.cod_valuta,
                    fx_date=movimento.data_valuta,
                ),
            )

        values = movimento.__dict__
        valori_movimento = values["valori_movimento"].__dict__

        query = f"""INSERT INTO dbo.T_MovimentoContoBancario (
        Progressivo,
        IdContoBancarioPerAnno,
        DataValuta,
        Importo,
        ImportoLordo,
        Commissioni,
        Rateo,
        Ritenute,
        Euroritenute,
        CodValutaMovimento,
        TassoCambioValutaMovimento,
        PrezzoUnitarioValutaMovimento,
        ImportoLordoValutaMovimento,
        ImportoValutaMovimento,
        CommissioniValutaMovimento,
        RateoValutaMovimento,
        RitenuteValutaMovimento,
        EuroritenuteValutaMovimento,
        {",".join([k for k in valori_movimento.keys()])}
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        {",".join(["DEFAULT" if v == DbVal.DEFAULT else "?" for _, v in valori_movimento.items()])})"""

        _values = (
            v.quantize(D("0.0000"))
            if isinstance(v, D)
            else (D(str(v)).quantize(D("0.0000")) if isinstance(v, float) else v)
            for k, v in valori_movimento.items()
            if v != DbVal.DEFAULT
        )
        cursor.execute(
            query,
            progressivo,
            dati_incarico["id_conto_bancario_per_anno"],
            values["data_valuta"],
            D(str(importo)).quantize(D("0.0000")) if importo is not None else None,
            D(str(importoLordo)).quantize(D("0.0000")) if importoLordo is not None else None,
            D(str(commissioni)).quantize(D("0.0000")) if commissioni is not None else None,
            ratei,
            ritenute,
            euroritenute,
            movimento.multivaluta.cod_valuta if movimento.multivaluta else None,
            movimento.multivaluta.cambio if movimento.multivaluta else None,
            movimento.multivaluta.prezzoUnitario if movimento.multivaluta else None,
            (D(str(importoLordo_multival)).quantize(D("0.0000")) if importoLordo_multival is not None else None)
            if movimento.multivaluta
            else None,
            (D(str(importo_multival)).quantize(D("0.0000")) if importo_multival is not None else None)
            if movimento.multivaluta
            else None,
            (D(str(commissioni_multival)).quantize(D("0.0000")) if commissioni_multival is not None else None)
            if movimento.multivaluta
            else None,
            ratei_multival if movimento.multivaluta else None,
            ritenute_multival if movimento.multivaluta else None,
            euroritenute_multival if movimento.multivaluta else None,
            *_values,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        id_movimento = cursor.fetchone()[0]
        dbobjects.append(
            DBObject(table="dbo.T_MovimentoContoBancario", idcol="IdMovimentoContoBancario", id=id_movimento)
        )
        return int(id_movimento), dbobjects, []

    @staticmethod
    def check_info_subincarico(
        cursor: pyodbc.Cursor,
        movimento: Movimento,
        dati_incarico: dict[str, Any],
        created_objects: list[DBObject],
    ) -> dict[str, Any]:

        info: dict[str, Any] = {}
        if "idincarico" in dati_incarico.keys():
            # recupero l'ultima gestione dell'incarico e la data di fine periodo fiscale
            cursor.execute(
                """SELECT trisi.IdIncarico, ti.ChiaveCliente, trisi.IdSubIncarico, ti1.ChiaveCliente,
                dtda.Descrizione, dtda.Codice, tda.Testo FROM T_R_Incarico_SubIncarico trisi
                JOIN T_DatoAggiuntivo tda ON trisi.IdSubIncarico  = tda.IdIncarico
                JOIN T_Incarico ti ON trisi.IdIncarico = ti.IdIncarico
                JOIN T_Incarico ti1 ON trisi.IdSubIncarico  = ti1.IdIncarico
                JOIN D_TipoDatoAggiuntivo dtda ON dtda.Codice = tda.CodTipoDatoAggiuntivo
                WHERE trisi.IdIncarico = ? AND ti.CodCliente = 149 AND ti.CodTipoIncarico =238
                AND tda.FlagAttivo = 1 AND tda.CodTipoDatoAggiuntivo IN (1289, 1290, 1291, 1292)
                ORDER BY IdSubIncarico DESC""",
                dati_incarico["idincarico"],
            )
            res = cursor.fetchone()
            if res:
                # subincarico già presente, recupero il suo dato aggiuntivo
                info["annualità"] = res.ChiaveCliente[0:4]
                parts = res.Descrizione.split()
                info["tipo_gestione"] = parts[len(parts) - 1].lower()  # annuale, semestrale, trimestrale, mensile
                info["dato_aggiuntivo"] = res.Testo
                info["creato"] = False
            else:
                # subincarico appena creato, recupero le info dell'ultimo dato aggiuntivo dell'annualità precedente
                cursor.execute(
                    """SELECT trisi.IdIncarico, ti.ChiaveCliente, trisi.IdSubIncarico, ti1.ChiaveCliente,
                    dtda.Descrizione, dtda.Codice, tda.Testo FROM T_R_Incarico_SubIncarico trisi
                    JOIN T_DatoAggiuntivo tda ON trisi.IdSubIncarico  = tda.IdIncarico
                    JOIN T_Incarico ti ON trisi.IdIncarico = ti.IdIncarico
                    JOIN T_Incarico ti1 ON trisi.IdSubIncarico  = ti1.IdIncarico
                    JOIN D_TipoDatoAggiuntivo dtda ON dtda.Codice = tda.CodTipoDatoAggiuntivo
                    WHERE trisi.IdIncarico = ? AND ti.CodCliente = 149 AND ti.CodTipoIncarico =238
                    AND tda.FlagAttivo = 1 AND tda.CodTipoDatoAggiuntivo IN (1289, 1290, 1291, 1292)
                    ORDER BY IdSubIncarico DESC""",
                    dati_incarico["idincarico"],
                )
                res = cursor.fetchone()
                if not res:
                    raise BusinessValueError("Impossibile recupera il tipo di gestione dall'incarico master.")

                info["annualità"] = res.ChiaveCliente[0:4]
                parts = res.Descrizione.split()
                info["tipo_gestione"] = parts[len(parts) - 1].lower()  # annuale, semestrale, trimestrale, mensile
                info["dato_aggiuntivo"] = res.Testo
                info["creato"] = True

            # recupero la data di fine periodo fiscale
            cursor.execute(
                """SELECT ti2.IdIncarico, ChiaveCliente, tda.CodTipoDatoAggiuntivo, dtda.Descrizione, tda.Testo
                FROM T_Incarico ti2 JOIN T_DatoAggiuntivo tda ON ti2.IdIncarico = tda.IdIncarico
                JOIN D_TipoDatoAggiuntivo dtda ON dtda.Codice = tda.CodTipoDatoAggiuntivo
                WHERE ti2.IdIncarico = ? AND ti2.CodCliente = 149 AND ti2.CodTipoIncarico = 238
                AND tda.FlagAttivo = 1 AND tda.CodTipoDatoAggiuntivo = 1287""",
                dati_incarico["idincarico"],
            )
            res = cursor.fetchone()
            if not res:
                raise BusinessValueError(
                    f"""Impossibile recuperare la data di fine periodo fiscale
                (incarico: {dati_incarico['idincarico']})."""
                )

            info["fine_periodo_fiscale"] = res.Testo

        else:
            raise BusinessValueError("Impossibile recuperare le informazioni sull'incarico.")

        return info

    @staticmethod
    def check_fatturazione(
        cursor: pyodbc.Cursor, movimento: Movimento, dati_incarico: dict[str, Any], info_incarico: dict[str, Any]
    ) -> None:
        data_inizio, data_fine = get_date_fatturazione(info_incarico)

        if movimento.data_valuta < data_inizio:
            raise BusinessValueError("Data valuta non inclusa nel periodo di fatturazione selezionato")
