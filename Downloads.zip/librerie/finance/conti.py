"""Utility per la gestione conti su QTask."""
from datetime import datetime
from functools import cache
from typing import Any, Optional, Set, Union

import pyodbc

from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import DBAction, DBObject

from .schema import COD_STATO_WORKFLOW


def _existing_id(rows: pyodbc.Row, label: str, msg_info: str = "") -> int:
    if len(rows) == 1:
        return int(getattr(rows[0], label))

    raise BusinessValueError(f"Più di un {label} ({msg_info})")  # pragma: no cover


def nota_incarichi(cursor: pyodbc.Cursor, ts: datetime, testo_nota: str) -> tuple[int, DBObject]:
    cursor.execute(
        """
    INSERT INTO T_NotaIncarichi (CodTipoNotaIncarichi, DataInserimento, IdOperatore, Testo)
    VALUES (92, ?, 0, ?);
    """,
        ts,
        testo_nota,
    )
    cursor.execute("""SELECT @@IDENTITY""")
    id_nota = cursor.fetchone()[0]
    return int(id_nota), DBObject(
        table="dbo.T_NotaIncarichi", idcol="IdNotaIncarichi", id=id_nota, action=DBAction.Insert
    )


def incarichi_e_relazione(
    cursor: pyodbc.Cursor,
    chiave_cliente: str,
    nome_relazione_bancaria: str,
    anno: int,
    cod_tipo_incarico_master: int,
    cod_area: int,
    cod_cliente: int,
    cod_tipo_workflow: int,
    cod_tipo_incarico_slave: int,
    ts: datetime,
    create: bool = True,
    consolidante: Optional[dict[str, Union[int, str]]] = None,
) -> tuple[dict[str, Any], list[DBObject]]:
    db_objects: list[DBObject] = []

    if consolidante:
        id_relazione_bancaria = consolidante["id_relazione_bancaria"]
        id_incarico = consolidante["id_incarico"]

        id_subincarico, created = get_or_create_subincarico(
            cursor,
            int(id_incarico),
            anno,
            str(consolidante["chiave_consolidante"]),
            int(consolidante["cod_tipo_incarico_slave"]),
            int(consolidante["cod_tipo_workflow"]),
            int(consolidante["cod_area"]),
            int(consolidante["cod_cliente"]),
            ts,
            create,
        )
        if created:
            db_objects.extend(created)

    else:
        id_incarico, created = get_or_create_incarico(
            cursor,
            chiave_cliente,
            cod_tipo_incarico_master,
            cod_area,
            cod_cliente,
            cod_tipo_workflow,
            ts,
            create,
        )
        if created:
            db_objects.extend(created)

        id_subincarico, created = get_or_create_subincarico(
            cursor,
            id_incarico,
            anno,
            chiave_cliente,
            cod_tipo_incarico_slave,
            cod_tipo_workflow,
            cod_area,
            cod_cliente,
            ts,
            create,
        )
        if created:
            db_objects.extend(created)

        id_relazione_bancaria, created = get_or_create_relazione_bancaria(
            cursor, nome_relazione_bancaria, id_incarico, id_subincarico, create
        )
        if created:
            db_objects.extend(created)

    return {
        "idincarico": id_incarico,
        "idsubincarico": id_subincarico,
        "idrelazionebancaria": id_relazione_bancaria,
    }, db_objects


def conto_bancario(
    cursor: pyodbc.Cursor,
    chiave_cliente: str,
    nome_relazione_bancaria: str,
    anno: int,
    nome_conto: str,
    numero_conto: str,
    cod_valuta: int,
    id_banca: int,
    cod_tipo_incarico_master: int,
    cod_area: int,
    cod_cliente: int,
    cod_tipo_workflow: int,
    cod_tipo_incarico_slave: int,
    ts: datetime,
    cod_consolidanti: Set[int] = set(),
    create: bool = True,
    add_relazione: bool = False,
) -> tuple[dict[str, Any], list[DBObject]]:
    db_objects: list[DBObject] = []

    relazione_consolidante = None
    if cod_consolidanti is not None:
        cod_consolidanti.add(cod_cliente)
        relazione_consolidante = get_consolidante(cursor, chiave_cliente, cod_consolidanti)

    res, created = incarichi_e_relazione(
        cursor,
        chiave_cliente,
        nome_relazione_bancaria,
        anno,
        cod_tipo_incarico_master,
        cod_area,
        cod_cliente,
        cod_tipo_workflow,
        cod_tipo_incarico_slave,
        ts,
        create,
        relazione_consolidante,
    )
    if created:
        db_objects.extend(created)

    id_conto_bancario, relazioni_bancarie = get_or_create_conto_bancario(
        cursor,
        nome_conto,
        numero_conto,
        cod_valuta,
        id_banca,
        cod_consolidanti,
        res["idrelazionebancaria"],
        create,
        add_relazione,
    )
    if relazioni_bancarie:
        db_objects.extend(relazioni_bancarie)

    id_conto_bancario_annuo, conto_bancario = get_or_create_conto_bancario_annuo(
        cursor, anno, res["idsubincarico"], id_conto_bancario, create
    )
    if conto_bancario:
        db_objects.extend(conto_bancario)

    res["idcontobancario"] = id_conto_bancario
    res["id_conto_bancario_per_anno"] = id_conto_bancario_annuo
    res["cod_valuta"] = cod_valuta

    return res, db_objects


def conto_titoli(
    cursor: pyodbc.Cursor,
    chiave_cliente: str,
    nome_relazione_bancaria: str,
    anno: int,
    nome_conto: str,
    numero_conto: str,
    cod_valuta: int,
    id_banca: int,
    cod_tipo_incarico_master: int,
    cod_area: int,
    cod_cliente: int,
    cod_tipo_workflow: int,
    cod_tipo_incarico_slave: int,
    ts: datetime,
    cod_consolidanti: Set[int] = set(),
    create: bool = True,
    account_number_filter: bool = True,
) -> tuple[dict[str, Any], list[DBObject]]:
    db_objects: list[DBObject] = []

    cod_consolidanti.add(cod_cliente)
    relazione_consolidante = get_consolidante(cursor, chiave_cliente, cod_consolidanti)

    res, created = incarichi_e_relazione(
        cursor,
        chiave_cliente,
        nome_relazione_bancaria,
        anno,
        cod_tipo_incarico_master,
        cod_area,
        cod_cliente,
        cod_tipo_workflow,
        cod_tipo_incarico_slave,
        ts,
        create,
        relazione_consolidante,
    )
    if created:
        db_objects.extend(created)

    id_conto_titoli, created_conto = get_or_create_conto_titoli(
        cursor,
        nome_conto,
        numero_conto,
        anno,
        cod_valuta,
        id_banca,
        res["idincarico"],
        res["idrelazionebancaria"],
        create,
        account_number_filter,
    )
    if created_conto:
        db_objects.extend(created_conto)

    id_conto_titoli_annuo, created_conto_annuo = get_or_create_conto_titoli_annuo(
        cursor, anno, res["idsubincarico"], id_conto_titoli, create
    )
    if created_conto_annuo:
        db_objects.extend(created_conto_annuo)

    output = {
        "idincarico": res["idincarico"],
        "idsubincarico": res["idsubincarico"],
        "idrelazionebancaria": res["idrelazionebancaria"],
        "idcontotitoli": id_conto_titoli,
        "idcontotitoliperanno": id_conto_titoli_annuo,
        "cod_valuta": cod_valuta,
    }

    return output, db_objects


@cache
def cached_conto_titoli(
    cursor: pyodbc.Cursor,
    chiave_cliente: str,
    nome_relazione_bancaria: str,
    anno: int,
    nome_conto: str,
    numero_conto: str,
    cod_valuta: int,
    id_banca: int,
    cod_tipo_incarico_master: int,
    cod_area: int,
    cod_cliente: int,
    cod_tipo_workflow: int,
    cod_tipo_incarico_slave: int,
    ts: datetime,
    cod_consolidanti: tuple[int, ...] = (),
    create: bool = True,
    account_number_filter: bool = True,
) -> tuple[dict[str, Any], list[DBObject]]:

    return conto_titoli(
        cursor,
        chiave_cliente,
        nome_relazione_bancaria,
        anno,
        nome_conto,
        numero_conto,
        cod_valuta,
        id_banca,
        cod_tipo_incarico_master,
        cod_area,
        cod_cliente,
        cod_tipo_workflow,
        cod_tipo_incarico_slave,
        ts,
        set(cod_consolidanti),
        create,
        account_number_filter,
    )


def get_or_create_incarico(
    cursor: pyodbc.Cursor,
    chiave_cliente: str,
    cod_tipo_incarico_master: int,
    cod_area: int,
    cod_cliente: int,
    cod_tipo_workflow: int,
    ts: datetime,
    create: bool = True,
) -> tuple[int, list[DBObject]]:
    cursor.execute(
        """SELECT T_Incarico.IdIncarico
        FROM T_Incarico
        WHERE CodCliente = ? AND ChiaveCliente = ? AND CodTipoIncarico = ? AND T_Incarico.FlagArchiviato = 0""",
        cod_cliente,
        chiave_cliente,
        cod_tipo_incarico_master,
    )
    rows = cursor.fetchall()
    msg_info = f"{cod_cliente} / {chiave_cliente}"

    if len(rows) == 0:
        if not create:
            raise BusinessValueError(f"Incarico inesistente ({msg_info})")
        cursor.execute(
            """INSERT INTO T_Incarico
            (codarea, codcliente, chiavecliente, codtipoincarico, codtipoworkflow, codstatoworkflowincarico,
            flagurgente, flagattesa, codattributoincarico, datacreazione, dataultimamodifica,
            dataultimatransizione, flagarchiviato)
            VALUES
            (?, ?, ?, ?, ?, ?, DEFAULT, DEFAULT, 0, ?, ?, ?, DEFAULT)""",
            cod_area,
            cod_cliente,
            chiave_cliente,
            cod_tipo_incarico_master,
            cod_tipo_workflow,
            COD_STATO_WORKFLOW,
            ts,
            ts,
            ts,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idincarico = cursor.fetchone()[0]
        cursor.execute(
            """INSERT INTO dbo.L_WorkflowIncarico
            ([idincarico], [idoperatore], [datatransizione], [codtipoworkflow], [codstatoworkflowincaricopartenza],
            [flagurgentepartenza], [codstatoworkflowincaricodestinazione], [flagurgentedestinazione], [flagmanuale],
            [codattributoincaricopartenza], [codattributoincaricodestinazione], [flagattesapartenza],
            [flagattesadestinazione], [codareapartenza], [codareadestinazione])
            VALUES
            (?, 8615, ?, ?, NULL, 0, 10500, 0, 0, NULL, NULL, NULL, 0, NULL, ?)""",
            idincarico,
            ts,
            cod_tipo_workflow,
            cod_area,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idworkflow = cursor.fetchone()[0]
        return idincarico, [
            DBObject(table="dbo.T_Incarico", idcol="IdIncarico", id=idincarico, action=DBAction.Insert),
            DBObject(table="dbo.L_WorkflowIncarico", idcol="IdTransizione", id=idworkflow, action=DBAction.Insert),
        ]

    return _existing_id(rows, "IdIncarico", msg_info), []


def get_or_create_subincarico(
    cursor: pyodbc.Cursor,
    id_incarico: int,
    anno: int,
    chiave_cliente: str,
    cod_tipo_incarico_slave: int,
    cod_tipo_workflow: int,
    cod_area: int,
    cod_cliente: int,
    ts: datetime,
    create: bool = True,
) -> tuple[int, list[DBObject]]:
    cursor.execute(
        """SELECT T_Incarico.IdIncarico, T_Incarico.CodStatoWorkflowIncarico
        FROM T_Incarico
        WHERE CodCliente = ?
        AND ChiaveCliente = ?
        AND CodTipoIncarico = ?
        AND T_Incarico.FlagArchiviato = 0""",
        cod_cliente,
        f"{anno}_{chiave_cliente}",
        cod_tipo_incarico_slave,
    )
    rows = cursor.fetchall()
    msg_info = f"{cod_cliente} / {chiave_cliente}"

    if len(rows) == 0:
        if not create:
            raise BusinessValueError(f"SubIncarico inesistente ({msg_info})")
        cursor.execute(
            """
            INSERT INTO T_Incarico
            (CodArea, CodCliente, ChiaveCliente, CodTipoIncarico, CodTipoWorkflow, CodStatoWorkflowIncarico,
            FlagUrgente, FlagAttesa, CodAttributoIncarico, DataCreazione, DataUltimaModifica,
            DataUltimaTransizione, FlagArchiviato)
            VALUES (?, ?, ?, ?, ?, ?,
            DEFAULT, DEFAULT, 0, DEFAULT, ?, ?, DEFAULT)""",
            cod_area,
            cod_cliente,
            f"{anno}_{chiave_cliente}",
            cod_tipo_incarico_slave,
            cod_tipo_workflow,
            COD_STATO_WORKFLOW,
            ts,
            ts,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idsubincarico = cursor.fetchone()[0]
        cursor.execute(
            """INSERT INTO T_R_Incarico_SubIncarico (IdIncarico, IdSubIncarico, FlagArchiviato)
            VALUES (?, ?, DEFAULT)""",
            id_incarico,
            idsubincarico,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idrelazione = cursor.fetchone()[0]
        cursor.execute(
            """INSERT INTO dbo.L_WorkflowIncarico
            ([idincarico], [idoperatore], [datatransizione], [codtipoworkflow], [codstatoworkflowincaricopartenza],
            [flagurgentepartenza], [codstatoworkflowincaricodestinazione], [flagurgentedestinazione], [flagmanuale],
            [codattributoincaricopartenza], [codattributoincaricodestinazione], [flagattesapartenza],
            [flagattesadestinazione], [codareapartenza], [codareadestinazione])
            VALUES
            (?, 8615, ?, ?, NULL, 0, 10500, 0, 0, NULL, NULL, NULL, 0, NULL, ?)""",
            idsubincarico,
            ts,
            cod_tipo_workflow,
            cod_area,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idworkflow = cursor.fetchone()[0]
        return idsubincarico, [
            DBObject(table="dbo.T_Incarico", idcol="IdIncarico", id=idsubincarico, action=DBAction.Insert),
            DBObject(table="dbo.T_R_Incarico_SubIncarico", idcol="IdRelazione", id=idrelazione, action=DBAction.Insert),
            DBObject(table="dbo.L_WorkflowIncarico", idcol="IdTransizione", id=idworkflow, action=DBAction.Insert),
        ]

    id_ = _existing_id(rows, "IdIncarico", msg_info)
    cod_stato_wf = rows[0].CodStatoWorkflowIncarico
    if cod_stato_wf in (10515, 10520, 10530, 10535, 10540):
        raise BusinessValueError("SubIncarico in elaborazione o fatturazione")
    return id_, []


def get_or_create_conto_bancario(
    cursor: pyodbc.Cursor,
    nome_conto: str,
    numero_conto: str,
    cod_valuta: int,
    id_banca: int,
    cod_cliente: Set[int],
    id_relazione_bancaria: str,
    create: bool = True,
    add_relazione: bool = False,
) -> tuple[int, list[DBObject]]:
    dbobjs = []
    in_str = ",".join(["?" for c in cod_cliente])
    cursor.execute(
        f"""SELECT DISTINCT(T_ContoBancario.IdContoBancario)
        FROM T_ContoBancario
        INNER JOIN T_ContoBancarioPerAnno ON T_ContoBancario.IdContoBancario = T_ContoBancarioPerAnno.IdContoBancario
        INNER JOIN T_Incarico ON T_ContoBancarioPerAnno.IdIncarico = T_Incarico.IdIncarico
        WHERE T_ContoBancario.NomeConto = ? AND T_ContoBancario.CodBancaVD = ? AND T_ContoBancario.CodValuta = ?
        AND T_ContoBancario.FlagCancellato = 0 AND T_Incarico.FlagArchiviato = 0
        AND T_Incarico.CodCliente IN ({in_str})
        """,
        nome_conto,
        id_banca,
        cod_valuta,
        *cod_cliente,
    )
    rows = cursor.fetchall()
    msg_info = f"{nome_conto} / {numero_conto}"

    conto_creato = False

    if len(rows) == 0:
        if not create:
            raise BusinessValueError(f"ContoBancario inesistente {msg_info})")
        cursor.execute(
            """INSERT INTO T_ContoBancario
            (NomeConto, NumeroConto, CodBancaVD, CodValuta, CodTipoContoBancario, FlagFittizio)
            VALUES (?, ?, ?, ?, 2, ?)""",
            nome_conto,
            numero_conto,
            id_banca,
            cod_valuta,
            True if "XX" in nome_conto else False,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idcontobancario = cursor.fetchone()[0]
        dbobjs.append(
            DBObject(table="dbo.T_ContoBancario", idcol="IdContoBancario", id=idcontobancario, action=DBAction.Insert)
        )
        conto_creato = True
    else:
        idcontobancario = _existing_id(rows, "IdContoBancario", msg_info)

    if add_relazione is False and not conto_creato:
        return idcontobancario, dbobjs

    cursor.execute(
        """
    SELECT T_R_ContoBancario_RelazioneBancaria.IdRelazioneBancaria FROM T_R_ContoBancario_RelazioneBancaria
    WHERE IdRelazioneBancaria = ? AND IdContoBancario = ?
    """,
        id_relazione_bancaria,
        idcontobancario,
    )
    rows = cursor.fetchall()

    if len(rows) == 0:
        cursor.execute(
            """INSERT INTO T_R_ContoBancario_RelazioneBancaria (IdRelazioneBancaria, IdContoBancario)
            VALUES (?, ?)""",
            id_relazione_bancaria,
            idcontobancario,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        idrelazione = cursor.fetchone()[0]
        dbobjs.append(
            DBObject(
                table="dbo.T_R_ContoBancario_RelazioneBancaria",
                idcol="IdRelazione",
                id=idrelazione,
                action=DBAction.Insert,
            )
        )
    if len(rows) > 1:
        raise BusinessValueError(f"Più di una T_R_ContoBancario_RelazioneBancaria ({msg_info})")

    return idcontobancario, dbobjs


def get_or_create_conto_bancario_annuo(
    cursor: pyodbc.Cursor, anno: int, id_subincarico: int, id_conto_bancario: int, create: bool = True
) -> tuple[int, list[DBObject]]:
    cursor.execute(
        """SELECT T_ContoBancarioPerAnno.IdContoBancarioPerAnno FROM T_ContoBancarioPerAnno
        WHERE IdContoBancario = ? AND Anno = ? AND IdIncarico = ? AND FlagCancellato = 0""",
        id_conto_bancario,
        anno,
        id_subincarico,
    )
    rows = cursor.fetchall()
    msg_info = str(id_conto_bancario)

    if len(rows) == 0:
        if not create:
            raise BusinessValueError(f"ContoBancarioPerAnno inesistente ({msg_info})")
        cursor.execute(
            """
        INSERT INTO T_ContoBancarioPerAnno (IdIncarico, IdContoBancario, Anno)
        VALUES (?, ? , ?)
        """,
            id_subincarico,
            id_conto_bancario,
            anno,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        id_ = cursor.fetchone()[0]
        return id_, [
            DBObject(
                table="dbo.T_ContoBancarioPerAnno", idcol="IdContoBancarioPerAnno", id=id_, action=DBAction.Insert
            ),
        ]

    return _existing_id(rows, "IdContoBancarioPerAnno", msg_info), []


def get_or_create_conto_titoli(
    cursor: pyodbc.Cursor,
    nome_conto: str,
    numero_conto: str,
    anno: int,
    cod_valuta: int,
    id_banca: int,
    id_incarico: str,
    id_relazione_bancaria: str,
    create: bool = True,
    account_number_filter: bool = True,
) -> tuple[int, list[DBObject]]:
    dbobjs: list[DBObject] = []

    filter_by_numero = "AND NumeroConto = ?" if account_number_filter else ""
    query = f"""SELECT DISTINCT(tct.IdContoTitoli)
            FROM T_ContoTitoli tct
            INNER JOIN T_ContoTitoliPerAnno tctpa ON tct.IdContoTitoli  = tctpa.IdContoTitoli
            WHERE NomeConto = ? AND CodBancaVD = ? AND Anno >= ? {filter_by_numero}
            AND tct.IdContoTitoli in (
                SELECT IdContoTitoli FROM T_ContoTitoliPerAnno
                INNER JOIN T_Incarico ON T_ContoTitoliPerAnno.IdIncarico = T_Incarico.IdIncarico
                AND FlagArchiviato = 0
                INNER JOIN T_R_Incarico_SubIncarico ON
                T_ContoTitoliPerAnno.IdIncarico = T_R_Incarico_SubIncarico.IdSubIncarico
                WHERE T_R_Incarico_SubIncarico.IdIncarico = ?)"""

    if account_number_filter:
        cursor.execute(
            query,
            nome_conto,
            id_banca,
            anno - 1,
            numero_conto,
            id_incarico,
        )
    else:
        cursor.execute(
            query,
            nome_conto,
            id_banca,
            anno - 1,
            id_incarico,
        )
    rows = cursor.fetchall()
    msg_info = f"{nome_conto} / {numero_conto}"

    if len(rows) == 0:
        if not create:
            raise BusinessValueError(f"ContoTitoli inesistente {nome_conto} (incarico {id_incarico})")
        cursor.execute(
            """INSERT INTO T_ContoTitoli
            (NomeConto, NumeroConto, CodBancaVD, CodValuta)
            VALUES (?, ?, ?, ?)""",
            nome_conto,
            numero_conto,
            id_banca,
            cod_valuta,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        id_conto_titoli = cursor.fetchone()[0]
        dbobjs.append(
            DBObject(table="dbo.T_ContoTitoli", idcol="IdContoTitoli", id=id_conto_titoli, action=DBAction.Insert)
        )

        cursor.execute(
            """
        SELECT IdRelazione FROM T_R_ContoTitoli_RelazioneBancaria
        WHERE IdRelazioneBancaria = ? AND IdContoTitoli = ?
        """,
            id_relazione_bancaria,
            id_conto_titoli,
        )
        if cursor.fetchone() is None:
            cursor.execute(
                """
            INSERT INTO T_R_ContoTitoli_RelazioneBancaria (IdRelazioneBancaria, IdContoTitoli)
            VALUES (?, ?)""",
                id_relazione_bancaria,
                id_conto_titoli,
            )
            cursor.execute("""SELECT @@IDENTITY""")
            id_relazione = cursor.fetchone()[0]
            dbobjs.append(
                DBObject(
                    table="dbo.T_R_ContoTitoli_RelazioneBancaria",
                    idcol="IdRelazione",
                    id=id_relazione,
                    action=DBAction.Insert,
                )
            )

        return id_conto_titoli, dbobjs

    return _existing_id(rows, "IdContoTitoli", msg_info), dbobjs


def get_or_create_conto_titoli_annuo(
    cursor: pyodbc.Cursor, anno: int, id_subincarico: int, id_conto_titoli: int, create: bool = True
) -> tuple[int, list[DBObject]]:
    cursor.execute(
        """SELECT T_ContoTitoliPerAnno.IdContoTitoliPerAnno FROM T_ContoTitoliPerAnno
        WHERE IdContoTitoli = ? AND Anno = ? AND IdIncarico = ?""",
        id_conto_titoli,
        anno,
        id_subincarico,
    )
    rows = cursor.fetchall()
    msg_info = f"conto {id_conto_titoli} / subincarico {id_subincarico}"

    if len(rows) == 0:
        if not create:
            raise BusinessValueError(f"ContoTitoliPerAnno inesistente ({msg_info})")
        cursor.execute(
            """
        INSERT INTO T_ContoTitoliPerAnno (IdIncarico, IdContoTitoli, Anno)
        VALUES (?, ? , ?)
        """,
            id_subincarico,
            id_conto_titoli,
            anno,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        id_ = cursor.fetchone()[0]
        return id_, [
            DBObject(table="dbo.T_ContoTitoliPerAnno", idcol="IdContoTitoliPerAnno", id=id_, action=DBAction.Insert),
        ]

    return _existing_id(rows, "IdContoTitoliPerAnno", msg_info), []


def get_consolidante(
    cursor: pyodbc.Cursor, chiave_cliente: str, cod_cliente: Set[int]
) -> Optional[dict[str, Union[int, str]]]:
    # Does a relation with my name exists ?
    # ( complex query due to rules for relations being different before 2017,
    # not isnumeric on first 4 chars implies before 2017 as well )
    try:
        in_str = ",".join(["?" for c in cod_cliente])
        cursor.execute(
            f"""SELECT subincarico.IdIncarico, T_RelazioneBancaria.IdRelazioneBancaria, subincarico.CodTipoIncarico
            FROM T_RelazioneBancaria
            INNER JOIN T_Incarico subincarico ON T_RelazioneBancaria.IdIncarico = subincarico.IdIncarico
            INNER JOIN T_R_Incarico_SubIncarico trpadri ON trpadri.IdSubIncarico = subincarico.IdIncarico
            INNER JOIN T_R_Incarico_SubIncarico trfigli ON trfigli.IdIncarico = trpadri.IdIncarico
            INNER JOIN T_Incarico as incaricofiglio ON trfigli.IdSubIncarico = incaricofiglio.IdIncarico
            WHERE T_RelazioneBancaria.NomeRelazione = ?
            AND subincarico.CodCliente IN ({in_str})
            AND incaricofiglio.CodTipoIncarico NOT IN (141, 237)
            AND subincarico.FlagArchiviato = 0
            AND ISNUMERIC(SUBSTRING(incaricofiglio.ChiaveCliente, 0, 5)) = 1
            AND CAST(SUBSTRING(incaricofiglio.ChiaveCliente, 0, 5) AS int) > 2016
            GROUP BY subincarico.IdIncarico, T_RelazioneBancaria.IdRelazioneBancaria, subincarico.CodTipoIncarico
            """,
            chiave_cliente,
            *cod_cliente,
        )
    except Exception as ex:
        if ex.args[0] == "22018":  # Invalid value char for cast
            raise BusinessValueError(f"La chiave cliente {chiave_cliente} non rispetta il formato atteso")
        raise ex
    rows_relazioni = cursor.fetchall()

    if len(rows_relazioni) > 1:
        raise BusinessValueError(f"Più di una RelazioneBancaria ({chiave_cliente})")  # pragma: no cover
    if len(rows_relazioni) == 0:
        return None

    res = rows_relazioni[0]
    id_subincarico = res.IdIncarico
    id_relazione_bancaria = res.IdRelazioneBancaria
    cod_tipo_incarico_slave = res.CodTipoIncarico

    cursor.execute(  # il mio incarico master si chiama come me ?
        """SELECT T_Incarico.IdIncarico, T_Incarico.ChiaveCliente,
        T_Incarico.CodArea, T_Incarico.CodCliente,
        T_Incarico.CodTipoWorkflow, T_Incarico.CodTipoIncarico
        FROM T_Incarico INNER JOIN T_R_Incarico_SubIncarico
        ON T_Incarico.IdIncarico = T_R_Incarico_SubIncarico.IdIncarico
        WHERE T_R_Incarico_SubIncarico.IdSubIncarico = ?
        """,
        id_subincarico,
    )
    rows_incarichi = cursor.fetchall()

    if len(rows_incarichi) > 1 or len(rows_incarichi) == 0:
        raise BusinessValueError(f"Nessuno o più di un IncaricoMaster ({chiave_cliente})")  # pragma: no cover

    res = rows_incarichi[0]
    if chiave_cliente == res.ChiaveCliente:
        return None

    output = {
        "chiave_consolidante": res.ChiaveCliente,
        "id_incarico": res.IdIncarico,
        # "id_relazione_bancaria_consolidata": id_relazione_bancaria,
        "id_relazione_bancaria": id_relazione_bancaria,
        "cod_area": res.CodArea,
        "cod_cliente": res.CodCliente,
        "cod_tipo_workflow": res.CodTipoWorkflow,
        "cod_tipo_incarico_master": res.CodTipoIncarico,
        "cod_tipo_incarico_slave": cod_tipo_incarico_slave,
    }

    return output


def get_or_create_relazione_bancaria(
    cursor: pyodbc.Cursor, nome_relazione: str, id_incarico: int, idsubincarico: int, create: bool = True
) -> tuple[int, list[DBObject]]:
    cursor.execute(
        """SELECT T_RelazioneBancaria.IdRelazioneBancaria
        FROM T_RelazioneBancaria WHERE NomeRelazione = ? AND IdIncarico IN (
        SELECT T_R_Incarico_SubIncarico.IdSubIncarico AS IdIncarico
        FROM T_R_Incarico_SubIncarico WHERE T_R_Incarico_SubIncarico.IdIncarico = ?)""",
        nome_relazione,
        id_incarico,
    )
    rows = cursor.fetchall()
    msg_info = nome_relazione

    if len(rows) == 0:
        # Does another relation with my name exists ?
        # ( complex query due to rules for relations being different before 2017 )
        cursor.execute(
            """SELECT
            T_RelazioneBancaria.IdRelazioneBancaria
            FROM T_RelazioneBancaria INNER JOIN T_Incarico subincarico
            ON T_RelazioneBancaria.IdIncarico = subincarico.IdIncarico
            INNER JOIN T_R_Incarico_SubIncarico trpadri ON trpadri.IdSubIncarico = subincarico.IdIncarico
            INNER JOIN T_R_Incarico_SubIncarico trfigli ON trfigli.IdIncarico = trpadri.IdIncarico
            INNER JOIN T_Incarico as incaricofiglio ON trfigli.IdSubIncarico = incaricofiglio.IdIncarico
            WHERE T_RelazioneBancaria.NomeRelazione = ?
            AND incaricofiglio.CodTipoIncarico NOT IN (141, 237)
            AND subincarico.FlagArchiviato = 0
            AND CAST(SUBSTRING(incaricofiglio.ChiaveCliente, 0, 5) AS int) > 2016
            GROUP BY subincarico.IdIncarico, T_RelazioneBancaria.IdRelazioneBancaria, subincarico.CodTipoIncarico""",
            nome_relazione,
        )
        mismateched_relations = cursor.fetchall()
        if len(mismateched_relations):
            raise BusinessValueError(f"RelazioneBancaria '{nome_relazione}' esistente in altro Incarico")
        if not create:
            raise BusinessValueError(f"RelazioneBancaria '{nome_relazione}' inesistente (incarico {id_incarico})")
        cursor.execute(
            """INSERT INTO T_RelazioneBancaria (IdIncarico, NomeRelazione)
            VALUES (?,?)""",
            idsubincarico,
            nome_relazione,
        )
        cursor.execute("SELECT @@IDENTITY")
        id_ = cursor.fetchone()[0]

        return id_, [
            DBObject(table="dbo.T_RelazioneBancaria", idcol="IdRelazioneBancaria", id=id_, action=DBAction.Insert),
        ]

    return _existing_id(rows, "IdRelazioneBancaria", msg_info), []
