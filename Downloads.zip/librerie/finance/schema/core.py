"""Definizioni dei messaggi verso le librerie e i servizi."""
import dataclasses
import json
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal as D
from typing import Any, Optional, Union

from pymol.types.mappings.gsa import CodTipoMovimentoContoBancario, IdOperazioneContoBancario

COD_STATO_WORKFLOW = 10480


def serialize(obj):  # type: ignore
    if isinstance(obj, (date,)):
        return obj.isoformat()[0:10]
    if isinstance(obj, (datetime,)):
        return obj.date().isoformat()[0:10]
    if isinstance(obj, (D,)):
        return float(obj)


@dataclass
class CommonParams:
    cod_banca: int
    cod_cliente: int
    cod_tipo_incarico_master: int
    cod_tipo_incarico_slave: int
    cod_area: int
    cod_tipo_workflow: int
    cod_numero_conto: str | None = None
    cod_stato_workflow_incarico: int | None = None
    cod_consolidanti: set[int] | None = None
    cod_sistema: str | None = None
    suffix_name_clienti: str | None = None
    gate: str | None = None


@dataclass
class InvalidCommonParams:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    cod_banca: Optional[int] = None
    cod_cliente: Optional[int] = None
    cod_tipo_incarico_master: Optional[int] = None
    cod_tipo_incarico_slave: Optional[int] = None
    cod_area: Optional[int] = None
    cod_tipo_workflow: Optional[int] = None
    cod_numero_conto: Optional[str] = None
    cod_stato_workflow_incarico: Optional[int] = None
    cod_consolidanti: Optional[list[int]] = None
    cod_sistema: Optional[str] = None
    suffix_name_clienti: Optional[str] = None
    gate: Optional[str] = None
    row: dict[str, Any] = field(default_factory=lambda: {})


@dataclass
class SaldoQTask:
    chiave_cliente: str
    nome_relazione_bancaria: str
    nome_conto: str
    numero_conto: str
    cod_valuta: int
    qty: D
    importi: list[tuple[D, int]]
    data_valuta: date
    anno: int
    is_metallo: bool
    product_name: str | None
    common_params: CommonParams
    idtitolo: int | None = None
    prezzo: D | None = None
    isin: str | None = None
    borsa: str | None = None
    rateo: D | None = None
    flagIncompleto: int = 0


@dataclass
class InvalidSaldoQTask:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    chiave_cliente: Optional[str] = None
    nome_relazione_bancaria: Optional[str] = None
    nome_conto: Optional[str] = None
    numero_conto: Optional[str] = None
    cod_valuta: Optional[int] = None
    qty: Optional[float] = None
    importi: Optional[list[tuple[float, int]]] = None
    data_valuta: Optional[date] = None
    anno: Optional[int] = None
    is_metallo: Optional[bool] = None
    product_name: Optional[str] = None
    common_params: Optional[Union[CommonParams, InvalidCommonParams]] = None
    idtitolo: Optional[int] = None
    prezzo: Optional[float] = None
    isin: Optional[str] = None
    borsa: Optional[str] = None
    rateo: Optional[float] = None
    flagIncompleto: Optional[int] = 0


@dataclass
class ValoriMovimento:
    codTipoMovimentoContoBancario: CodTipoMovimentoContoBancario
    dataOperazione: date
    idOperazioneContoBancario: IdOperazioneContoBancario | None = None
    flagIncompleto: int = 0
    flagPresenzaContabile: int = 0
    flagImportIncompleto: int = 0
    idTitoloFinanziario: int | None = None
    prezzoUnitario: float | None = None
    quantita: float | None = None
    quantitaOriginale: float | None = None
    dataATermine: date | None = None
    dataInizioTrade: date | None = None
    dataFineTrade: date | None = None


@dataclass
class InvalidValoriMovimento:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    codTipoMovimentoContoBancario: CodTipoMovimentoContoBancario | None = None
    dataOperazione: date | None = None
    idOperazioneContoBancario: IdOperazioneContoBancario | None = None
    flagIncompleto: int | None = None
    flagPresenzaContabile: int | None = None
    flagImportIncompleto: int | None = None
    idTitoloFinanziario: int | None = None
    prezzoUnitario: float | None = None
    quantita: float | None = None
    quantitaOriginale: float | None = None
    dataATermine: date | None = None
    dataInizioTrade: date | None = None
    dataFineTrade: date | None = None


@dataclass
class TrattazioneMultiValuta:
    cod_valuta: int | None = None
    cambio: D | None = None
    prezzoUnitario: D | None = None
    importi: list[tuple[D, int]] | None = None
    importiLordi: list[tuple[D, int]] | None = None
    commissioni: list[tuple[D, int]] | None = None
    ratei: list[tuple[D, int]] | None = None
    ritenute: list[tuple[D, int]] | None = None
    euroritenute: list[tuple[D, int]] | None = None


@dataclass
class Movimento:
    nome_relazione_bancaria: str
    chiave_cliente: str
    nome_conto: str
    numero_conto: str
    cod_valuta: int
    data_valuta: date
    importi: list[tuple[D, int]]
    importiLordi: list[tuple[D, int]]
    commissioni: list[tuple[D, int]]
    testo_nota: str
    valori_movimento: ValoriMovimento
    ritenute: list[tuple[D, int]]
    ratei: list[tuple[D, int]]
    euroritenute: list[tuple[D, int]]
    common_params: CommonParams
    saldo_iniziale: dict[str, Any] | None = None
    linked_mov: int | None = None
    chiaveEsterna: str | None = None
    anno: int | None = None
    divisa: str | None = None
    isin: str | None = None
    multivaluta: TrattazioneMultiValuta | None = None


@dataclass
class InvalidMovimento:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})

    nome_relazione_bancaria: Optional[str] = None
    chiave_cliente: Optional[str] = None
    nome_conto: Optional[str] = None
    numero_conto: Optional[str] = None
    cod_valuta: Optional[int] = None
    data_valuta: Optional[date] = None
    importi: Optional[list[tuple[float, int]]] = None
    importiLordi: Optional[list[tuple[float, int]]] = None
    commissioni: Optional[list[tuple[float, int]]] = None
    testo_nota: Optional[str] = None
    valori_movimento: Optional[Union[ValoriMovimento, InvalidValoriMovimento]] = None
    ritenute: Optional[list[tuple[float, int]]] = None
    ratei: Optional[list[tuple[float, int]]] = None
    euroritenute: Optional[list[tuple[float, int]]] = None
    common_params: Optional[Union[CommonParams, InvalidCommonParams]] = None
    saldo_iniziale: Optional[dict[str, Any]] = None
    linked_mov: Optional[int] = None
    chiaveEsterna: Optional[str] = None
    anno: Optional[int] = None

    divisa: Optional[str] = None
    isin: Optional[str] = None
    multivaluta: Optional[TrattazioneMultiValuta] = None


@dataclass
class Movimento940:
    data_valuta: date
    data_operazione: date
    precedente_saldo: float
    attuale_saldo: float
    operazioni_intercorse: str
    importo_operazione: float
    common_params: CommonParams
    id_messaggio: Optional[int] = None


@dataclass
class InvalidMovimento940:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    data_valuta: Optional[date] = None
    data_operazione: Optional[date] = None
    precedente_saldo: Optional[float] = None
    attuale_saldo: Optional[float] = None
    operazioni_intercorse: Optional[str] = None
    importo_operazione: Optional[float] = None
    common_params: Optional[Union[CommonParams, InvalidCommonParams]] = None
    id_messaggio: Optional[int] = None


@dataclass
class SaldoCorner:
    chiave_cliente: str
    nome_relazione_bancaria: str
    nome_conto: str
    numero_conto: str
    cod_valuta: int
    common_params: CommonParams


@dataclass
class InvalidSaldoCorner:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    chiave_cliente: Optional[str] = None
    nome_relazione_bancaria: Optional[str] = None
    nome_conto: Optional[str] = None
    numero_conto: Optional[str] = None
    cod_valuta: Optional[int] = None
    common_params: Optional[Union[CommonParams, InvalidCommonParams]] = None


@dataclass
class SaldoSingolo940(SaldoCorner):
    movimenti: list[Movimento940]
    anno: Optional[int] = None
    testo_nota: Optional[str] = None
    dataValuta: Optional[date] = None
    saldo_iniziale: Optional[dict[str, Any]] = None
    saldo_finale: Optional[dict[str, Any]] = None
    chiaveEsterna: Optional[str] = None


@dataclass
class InvalidSaldoSingolo940(SaldoCorner):
    movimenti: Optional[list[Movimento940]] = None
    anno: Optional[int] = None
    testo_nota: Optional[str] = None
    dataValuta: Optional[date] = None
    saldo_iniziale: Optional[dict[str, Any]] = None
    saldo_finale: Optional[dict[str, Any]] = None
    chiaveEsterna: Optional[str] = None


@dataclass
class SaldoMulti940(SaldoCorner):
    movimenti: list[Movimento940]
    meta_id: int
    msg_id: int


@dataclass
class InvalidSaldoMulti940(SaldoCorner):
    movimenti: Optional[list[Movimento940]] = None
    meta_id: Optional[int] = None
    msg_id: Optional[int] = None


@dataclass
class SaldoSingolo941(SaldoCorner):
    is_metallo: bool
    data_valuta: date
    importo: float
    cod_bene: int
    data_operazione: date
    anno: int
    note: str
    testo_nota: str
    qty: Optional[float] = None


@dataclass
class InvalidSaldoSingolo941(SaldoCorner):
    is_metallo: Optional[bool] = None
    data_valuta: Optional[date] = None
    importo: Optional[float] = None
    cod_bene: Optional[int] = None
    data_operazione: Optional[date] = None
    anno: Optional[int] = None
    note: Optional[str] = None
    testo_nota: Optional[str] = None
    qty: Optional[float] = None


# da qui in poi refactoring da implementare


@dataclass
class PosizioneQtask:
    """L'insieme di valori che identifica un conto in QTask.

    A volte è necessario identificare il conto in QTask a cui apparterrà un messaggio
    durante l'invio ad altre applicazioni. Per ragioni storiche la valorizzazione
    degli attributi ha logiche specifiche da flusso a flusso; ce ne occupiamo a monte
    anche se sono dati specifici di applicativo per evitare dispersione di business logic
    in applicazioni diverse.

    Attributi
    ----------
    nome_relazione_bancaria:

    chiave_cliente:

    nome_conto

    numero_conto:

    cod_valuta

    anno:

    common_params: vedi CommonParams

    testo_nota:

    idTitolo:

    iban:
    """

    nome_relazione_bancaria: str
    chiave_cliente: str
    nome_conto: str
    numero_conto: str
    cod_valuta: str
    anno: int
    common_params: CommonParams
    testo_nota: str
    idTitolo: Optional[int] = None
    iban: Optional[str] = None


@dataclass
class InvalidPosizioneQtask:
    # attributo e lista degli errori per quell'attributo
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    nome_relazione_bancaria: Optional[str] = None
    chiave_cliente: Optional[str] = None
    nome_conto: Optional[str] = None
    numero_conto: Optional[str] = None
    cod_valuta: Optional[str] = None
    anno: Optional[int] = None
    common_params: Optional[Union[CommonParams, InvalidCommonParams]] = None
    testo_nota: Optional[str] = None
    idTitolo: Optional[int] = None
    iban: Optional[str] = None
    row: dict[str, Any] = field(default_factory=lambda: {})


@dataclass
class ABSMsg:
    @property
    def is_valid(self) -> bool:
        return True

    def as_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)

    def as_json(self) -> str:
        return json.dumps(dataclasses.asdict(self), default=serialize)


@dataclass
class ABSMsgCash(ABSMsg):
    id: int  # id di ingestion
    posizione_qtask: PosizioneQtask


@dataclass
class InvalidABSMsg(ABSMsg):
    @property
    def is_valid(self) -> bool:
        return False


@dataclass
class InvalidABSMsgCash(InvalidABSMsg):
    id: int  # id di ingestion
    posizione_qtask: Union[PosizioneQtask, InvalidPosizioneQtask]
    row: dict[str, Any] = field(default_factory=lambda: {})
    errors: dict[str, list[str]] = field(default_factory=lambda: {})


@dataclass
class MovimentoCanc(ABSMsg):
    id: int
    id_cancel: int


@dataclass
class InvalidMovimentoCanc(InvalidABSMsg):
    id: int
    id_cancel: Optional[int] = None


@dataclass
class MovimentoCash(ABSMsgCash):
    data_valuta: date
    data_operazione: date
    id_operazione_conto_bancario: IdOperazioneContoBancario

    importo_lordo: D
    importo: D
    commissioni: D
    euroritenute: D
    ratei: D
    ritenute: D
    spese: D

    cambio: Optional[D]  # valore mov * cambio = valore conto
    chiave_esterna: Optional[str]
    is_rettifica: Optional[int]


@dataclass
class InvalidMovimentoCash(InvalidABSMsgCash):
    data_valuta: Optional[date] = None
    data_operazione: Optional[date] = None
    id_operazione_conto_bancario: Optional[IdOperazioneContoBancario] = None

    importo_lordo: Optional[D] = None
    importo: Optional[D] = None
    commissioni: Optional[D] = None
    euroritenute: Optional[D] = None
    ratei: Optional[D] = None
    ritenute: Optional[D] = None
    spese: Optional[D] = None

    cambio: Optional[D] = None
    chiave_esterna: Optional[str] = None
    is_rettifica: Optional[int] = None


@dataclass
class Giroconto(ABSMsg):
    movimento_in: MovimentoCash
    movimento_out: MovimentoCash


@dataclass
class InvalidGiroconto(InvalidABSMsg):
    movimento_in: Union[MovimentoCash, InvalidMovimentoCash, None]
    movimento_out: Union[MovimentoCash, InvalidMovimentoCash, None]
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    row: dict[str, Any] = field(default_factory=lambda: {})


@dataclass
class CambioATermine(ABSMsg):
    movimento_in: MovimentoCash
    movimento_out: MovimentoCash
    data_contratto: date


@dataclass
class InvalidCambioATermine(InvalidABSMsg):
    movimento_in: Union[MovimentoCash, InvalidMovimentoCash, None]
    movimento_out: Union[MovimentoCash, InvalidMovimentoCash, None]
    data_contratto: Optional[date] = None
    errors: dict[str, list[str]] = field(default_factory=lambda: {})
    row: dict[str, Any] = field(default_factory=lambda: {})


@dataclass
class MovimentoTitolo(MovimentoCash):
    codice_strumento: str
    divisa: str
    quantita: D
    prezzo: D
    is_censito: bool
    cusip: Optional[str]


@dataclass
class InvalidMovimentoTitolo(InvalidMovimentoCash):
    codice_strumento: Optional[str] = None
    divisa: Optional[str] = None
    quantita: Optional[D] = None
    prezzo: Optional[D] = None
    is_censito: Optional[bool] = None
    cusip: Optional[str] = None


@dataclass
class MovimentoRitenute(MovimentoCash):
    isin: str
    is_censito: bool


@dataclass
class InvalidMovimentoRitenute(InvalidMovimentoCash):
    isin: Optional[str] = None
    is_censito: Optional[bool] = None


@dataclass
class SaldoCash(ABSMsgCash):
    data: date
    importo_valuta: D
    importo: D
    cambio: D


@dataclass
class InvalidSaldoCash(InvalidABSMsgCash):
    data: Optional[date] = None
    importo_valuta: Optional[D] = None
    importo: Optional[D] = None
    cambio: Optional[D] = None


@dataclass
class SaldoTitolo(ABSMsgCash):
    data: date
    quantita: D
    prezzo: D
    ratei: D
    importo: D
    cambio: D
    codice_strumento: str
    is_censito: bool
    cusip: Optional[str]


@dataclass
class InvalidSaldoTitolo(InvalidABSMsgCash):
    data: Optional[date] = None
    quantita: Optional[D] = None
    prezzo: Optional[D] = None
    ratei: Optional[D] = None
    importo: Optional[D] = None
    cambio: Optional[D] = None
    codice_strumento: Optional[str] = None
    is_censito: Optional[bool] = None
    cusip: Optional[str] = None
