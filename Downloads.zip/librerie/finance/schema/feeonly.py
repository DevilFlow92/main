from dataclasses import dataclass, field
from typing import Any, Optional, Union, cast

from .core import CambioATermine as BaseCambioATermine
from .core import Giroconto as BaseGiroconto
from .core import InvalidCambioATermine as BaseInvalidCambioATermine
from .core import InvalidGiroconto as BaseInvalidGiroconto
from .core import InvalidMovimentoCanc as BaseInvalidMovimentoCanc
from .core import InvalidMovimentoCash as BaseInvalidMovimentoCash
from .core import InvalidMovimentoRitenute as BaseInvalidMovimentoRitenute
from .core import InvalidMovimentoTitolo as BaseInvalidMovimentoTitolo
from .core import InvalidSaldoCash as BaseInvalidSaldoCash
from .core import InvalidSaldoTitolo as BaseInvalidSaldoTitolo
from .core import MovimentoCanc as BaseMovimentoCanc
from .core import MovimentoCash as BaseMovimentoCash
from .core import MovimentoRitenute as BaseMovimentoRitenute
from .core import MovimentoTitolo as BaseMovimentoTitolo
from .core import SaldoCash as BaseSaldoCash
from .core import SaldoTitolo as BaseSaldoTitolo


@dataclass
class ValoriDepositaria:
    codice_causale: Optional[str]
    descrizione: Optional[str]
    segno: Optional[int]

    codice_rapporto: Optional[str]  # arriva dal flusso e giriam pari pari
    codice_causale_dep: Optional[dict[str, Any]] = None


@dataclass
class MovimentoCanc(BaseMovimentoCanc):
    valori_depositaria: ValoriDepositaria


@dataclass
class MovimentoCash(BaseMovimentoCash):
    valori_depositaria: ValoriDepositaria


@dataclass
class Giroconto(BaseGiroconto):
    pass


@dataclass
class CambioATermine(BaseCambioATermine):
    valori_depositaria: ValoriDepositaria


@dataclass
class MovimentoTitolo(BaseMovimentoTitolo):
    # data_contratto: date = None
    valori_depositaria: ValoriDepositaria


@dataclass
class MovimentoRitenute(BaseMovimentoRitenute):
    valori_depositaria: ValoriDepositaria


@dataclass
class SaldoTitolo(BaseSaldoTitolo):
    valori_depositaria: ValoriDepositaria


@dataclass
class SaldoCash(BaseSaldoCash):
    valori_depositaria: ValoriDepositaria


@dataclass
class InvalidGiroconto(BaseInvalidGiroconto):
    pass


@dataclass
class InvalidMovimentoCanc(BaseInvalidMovimentoCanc):
    valori_depositaria: Optional[ValoriDepositaria] = None


@dataclass
class InvalidMovimentoCash(BaseInvalidMovimentoCash):
    valori_depositaria: Optional[ValoriDepositaria] = None


@dataclass
class InvalidMovimentoTitolo(BaseInvalidMovimentoTitolo):
    valori_depositaria: Optional[ValoriDepositaria] = None


@dataclass
class InvalidMovimentoRitenute(BaseInvalidMovimentoRitenute):
    valori_depositaria: Optional[ValoriDepositaria] = None


@dataclass
class InvalidCambioATermine(BaseInvalidCambioATermine):
    valori_depositaria: Optional[ValoriDepositaria] = None


@dataclass
class InvalidSaldoCash(BaseInvalidSaldoCash):
    valori_depositaria: Optional[ValoriDepositaria] = None


@dataclass
class InvalidSaldoTitolo(BaseInvalidSaldoTitolo):
    valori_depositaria: Optional[ValoriDepositaria] = None


def translate(  # noqa
    m: Union[
        BaseMovimentoCanc,
        BaseMovimentoCash,
        BaseGiroconto,
        BaseCambioATermine,
        BaseMovimentoTitolo,
        BaseMovimentoRitenute,
        BaseSaldoTitolo,
        BaseSaldoCash,
        BaseInvalidMovimentoCanc,
        BaseInvalidMovimentoCash,
        BaseInvalidMovimentoTitolo,
        BaseInvalidMovimentoRitenute,
        BaseInvalidCambioATermine,
        BaseInvalidGiroconto,
        BaseInvalidSaldoCash,
        BaseInvalidSaldoTitolo,
    ],
    vd: ValoriDepositaria,
    errors: dict[str, list[str]] = field(default_factory=lambda: {}),
) -> Union[
    MovimentoCash,
    MovimentoCanc,
    Giroconto,
    CambioATermine,
    MovimentoTitolo,
    MovimentoRitenute,
    SaldoTitolo,
    SaldoCash,
    InvalidMovimentoCanc,
    InvalidMovimentoCash,
    InvalidMovimentoTitolo,
    InvalidMovimentoRitenute,
    InvalidGiroconto,
    InvalidCambioATermine,
    InvalidSaldoCash,
    InvalidSaldoTitolo,
]:
    if m.__class__.__name__ == "MovimentoCanc":
        m = cast(BaseMovimentoCanc, m)
        return MovimentoCanc(
            valori_depositaria=vd,
            id=m.id,
            id_cancel=m.id_cancel,
        )

    if m.__class__.__name__ == "MovimentoCash":
        m = cast(BaseMovimentoCash, m)
        return MovimentoCash(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data_valuta=m.data_valuta,
            data_operazione=m.data_operazione,
            id_operazione_conto_bancario=m.id_operazione_conto_bancario,
            cambio=m.cambio,
            importo_lordo=m.importo_lordo,
            importo=m.importo,
            commissioni=m.commissioni,
            euroritenute=m.euroritenute,
            ratei=m.ratei,
            ritenute=m.ritenute,
            spese=m.spese,
            chiave_esterna=m.chiave_esterna,
            is_rettifica=m.is_rettifica,
        )

    if m.__class__.__name__ == "MovimentoRitenute":
        m = cast(BaseMovimentoRitenute, m)
        return MovimentoRitenute(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data_valuta=m.data_valuta,
            data_operazione=m.data_operazione,
            id_operazione_conto_bancario=m.id_operazione_conto_bancario,
            cambio=m.cambio,
            importo_lordo=m.importo_lordo,
            importo=m.importo,
            commissioni=m.commissioni,
            euroritenute=m.euroritenute,
            ratei=m.ratei,
            ritenute=m.ritenute,
            spese=m.spese,
            chiave_esterna=m.chiave_esterna,
            isin=m.isin,
            is_rettifica=m.is_rettifica,
            is_censito=m.is_censito,
        )

    if m.__class__.__name__ == "Giroconto":
        m = cast(BaseGiroconto, m)
        return Giroconto(movimento_in=m.movimento_in, movimento_out=m.movimento_out)

    if m.__class__.__name__ == "CambioATermine":
        m = cast(BaseCambioATermine, m)
        return CambioATermine(
            valori_depositaria=vd,
            movimento_in=m.movimento_in,
            movimento_out=m.movimento_out,
            data_contratto=m.data_contratto,
        )

    if m.__class__.__name__ == "MovimentoTitolo":
        m = cast(BaseMovimentoTitolo, m)
        return MovimentoTitolo(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data_valuta=m.data_valuta,
            data_operazione=m.data_operazione,
            quantita=m.quantita,
            prezzo=m.prezzo,
            id_operazione_conto_bancario=m.id_operazione_conto_bancario,
            cambio=m.cambio,
            importo_lordo=m.importo_lordo,
            importo=m.importo,
            commissioni=m.commissioni,
            euroritenute=m.euroritenute,
            ratei=m.ratei,
            ritenute=m.ritenute,
            spese=m.spese,
            chiave_esterna=m.chiave_esterna,
            divisa=m.divisa,
            codice_strumento=m.codice_strumento,
            is_rettifica=m.is_rettifica,
            is_censito=m.is_censito,
            cusip=m.cusip,
        )

    if m.__class__.__name__ == "SaldoTitolo":
        m = cast(BaseSaldoTitolo, m)
        return SaldoTitolo(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            codice_strumento=m.codice_strumento,
            is_censito=m.is_censito,
            data=m.data,
            quantita=m.quantita,
            prezzo=m.prezzo,
            cambio=m.cambio,
            ratei=m.ratei,
            importo=m.importo,
            cusip=m.cusip,
        )

    if m.__class__.__name__ == "SaldoCash":
        m = cast(BaseSaldoCash, m)
        return SaldoCash(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data=m.data,
            cambio=m.cambio,
            importo=m.importo,
            importo_valuta=m.importo_valuta,
        )

    if m.__class__.__name__ == "InvalidMovimentoCanc":
        m = cast(BaseInvalidMovimentoCanc, m)
        return InvalidMovimentoCanc(
            valori_depositaria=vd,
            id=m.id,
            id_cancel=m.id_cancel if m.id_cancel else None,
        )

    if m.__class__.__name__ == "InvalidMovimentoCash":
        m = cast(BaseInvalidMovimentoCash, m)
        return InvalidMovimentoCash(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,  # noqa
            data_valuta=m.data_valuta if m.data_valuta else None,
            data_operazione=m.data_operazione if m.data_operazione else None,
            id_operazione_conto_bancario=m.id_operazione_conto_bancario if m.id_operazione_conto_bancario else None,
            cambio=m.cambio if m.cambio else None,
            importo_lordo=m.importo_lordo if m.importo_lordo else None,
            importo=m.importo if m.importo else None,
            commissioni=m.commissioni if m.commissioni else None,
            euroritenute=m.euroritenute if m.euroritenute else None,
            ratei=m.ratei if m.ratei else None,
            ritenute=m.ritenute if m.ritenute else None,
            spese=m.spese if m.spese else None,
            chiave_esterna=m.chiave_esterna if m.chiave_esterna else None,
            is_rettifica=m.is_rettifica,
            errors=m.errors,
            row=m.row,
        )

    if m.__class__.__name__ == "InvalidGiroconto":
        m = cast(BaseInvalidGiroconto, m)
        return InvalidGiroconto(
            movimento_in=m.movimento_in if m.movimento_in else None,
            movimento_out=m.movimento_out if m.movimento_out else None,
            errors=m.errors,
            row=m.row,
        )

    if m.__class__.__name__ == "InvalidMovimentoRitenute":
        m = cast(BaseInvalidMovimentoRitenute, m)
        return InvalidMovimentoRitenute(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data_valuta=m.data_valuta if m.data_valuta else None,
            data_operazione=m.data_operazione if m.data_operazione else None,
            id_operazione_conto_bancario=m.id_operazione_conto_bancario if m.id_operazione_conto_bancario else None,
            cambio=m.cambio if m.cambio else None,
            importo_lordo=m.importo_lordo if m.importo_lordo else None,
            importo=m.importo if m.importo else None,
            commissioni=m.commissioni if m.commissioni else None,
            euroritenute=m.euroritenute if m.euroritenute else None,
            ratei=m.ratei if m.ratei else None,
            ritenute=m.ritenute if m.ritenute else None,
            spese=m.spese if m.spese else None,
            chiave_esterna=m.chiave_esterna if m.chiave_esterna else None,
            isin=m.isin if m.isin else None,
            is_censito=m.is_censito,
            is_rettifica=m.is_rettifica,
            errors=m.errors,
            row=m.row,
        )

    if m.__class__.__name__ == "InvalidCambioATermine":
        m = cast(BaseInvalidCambioATermine, m)
        return InvalidCambioATermine(
            valori_depositaria=vd,
            movimento_in=m.movimento_in if m.movimento_in else None,
            movimento_out=m.movimento_out if m.movimento_out else None,
            data_contratto=m.data_contratto if m.data_contratto else None,
            errors=m.errors,
            row=m.row,
        )

    if m.__class__.__name__ == "InvalidMovimentoTitolo":
        m = cast(BaseInvalidMovimentoTitolo, m)
        return InvalidMovimentoTitolo(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data_valuta=m.data_valuta if m.data_valuta else None,
            data_operazione=m.data_operazione if m.data_operazione else None,
            quantita=m.quantita if m.quantita else None,
            prezzo=m.prezzo if m.prezzo else None,
            id_operazione_conto_bancario=m.id_operazione_conto_bancario if m.id_operazione_conto_bancario else None,
            cambio=m.cambio if m.cambio else None,
            importo_lordo=m.importo_lordo if m.importo_lordo else None,
            importo=m.importo if m.importo else None,
            commissioni=m.commissioni if m.commissioni else None,
            euroritenute=m.euroritenute if m.euroritenute else None,
            ratei=m.ratei if m.ratei else None,
            ritenute=m.ritenute if m.ritenute else None,
            spese=m.spese if m.spese else None,
            chiave_esterna=m.chiave_esterna if m.chiave_esterna else None,
            divisa=m.divisa if m.divisa else None,
            codice_strumento=m.codice_strumento if m.codice_strumento else None,
            is_censito=m.is_censito,
            is_rettifica=m.is_rettifica,
            cusip=m.cusip if m.cusip else None,
            errors=m.errors,
            row=m.row,
        )

    if m.__class__.__name__ == "InvalidSaldoTitolo":
        m = cast(BaseInvalidSaldoTitolo, m)
        return InvalidSaldoTitolo(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            codice_strumento=m.codice_strumento if m.codice_strumento else None,
            is_censito=m.is_censito if m.is_censito else None,
            data=m.data if m.data else None,
            quantita=m.quantita if m.quantita else None,
            prezzo=m.prezzo if m.prezzo else None,
            cambio=m.cambio if m.cambio else None,
            ratei=m.ratei if m.ratei else None,
            importo=m.importo if m.importo else None,
            cusip=m.cusip if m.cusip else None,
            errors=m.errors,
            row=m.row,
        )

    if m.__class__.__name__ == "InvalidSaldoCash":
        m = cast(BaseInvalidSaldoCash, m)
        return InvalidSaldoCash(
            valori_depositaria=vd,
            id=m.id,
            posizione_qtask=m.posizione_qtask,
            data=m.data if m.data else None,
            cambio=m.cambio if m.cambio else None,
            importo=m.importo if m.importo else None,
            importo_valuta=m.importo_valuta if m.importo_valuta else None,
            errors=m.errors,
            row=m.row,
        )

    raise ValueError(f"Unknown movimento type: {m.__class__.__name__}")
