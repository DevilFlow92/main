import os
from datetime import datetime
from typing import Dict, Optional, Tuple, Union, cast

import ldap
import requests
from hvac import Client, exceptions

from pymol import logger
from pymol.logger import log
from pymol.types.core import JsonRes


def _get_client(vault_addr: str, token: str) -> Client:
    client = Client(url=vault_addr)
    client.token = token
    return client


def local_token() -> str:
    token = os.getenv("VAULT_TOKEN")
    if token:
        return token
    raise Exception("missing vault config : VAULT_TOKEN")


def is_authenticated(token: str) -> bool:
    vault_addr = os.getenv("VAULT_ADDR")
    if not vault_addr:
        raise Exception("missing vault config : VAULT_ADDR")

    client = _get_client(vault_addr, token)
    output = client.is_authenticated()

    if not output:
        log.message(message=f"Failed Authentication for Token {token[0:6]}...", level=logger.LogLevel.WARNING)

    return cast(bool, output)


def _client_token_env_tenancy(
    token: Optional[str], deploy_env: Optional[str], tenancy: Optional[str]
) -> Tuple[Client, str, str, Optional[str]]:
    vault_addr = os.getenv("VAULT_ADDR")
    token = token or os.getenv("VAULT_TOKEN")
    deploy_env = deploy_env or os.getenv("DEPLOY_ENV")
    tenancy = tenancy or os.getenv("TENANCY")

    if not (token and vault_addr and deploy_env):
        raise Exception(
            f"missing vault / environment config : VAULT_ADDR={vault_addr} "
            f"VAULT_TOKEN={'missing' if not token else '****'} DEPLOY_ENV={deploy_env})"
        )

    client = _get_client(vault_addr, token)
    if not client.is_authenticated():
        log.message(message=f"Failed Authentication for Token {token[0:6]}...", level=logger.LogLevel.WARNING)

    return client, token, deploy_env, tenancy


def _read_vault(  # noqa
    client: Client, label: str, token: str, deploy_env: str, tenancy: Union[None, str], backend: str
) -> JsonRes:

    local_mount = _local_mount(client, backend)
    if local_mount:
        try:
            result = client.secrets.kv.v1.read_secret(path=label, mount_point=local_mount)
            if "_shutoff" in result["data"] and result["data"]["_shutoff"] in ("y", "yes", "1", "true"):
                pass
            else:
                print(f"! READING '{label}' FROM LOCAL OVERRIDE")  # noqa: T001
                return cast(JsonRes, result["data"])
        except (exceptions.Forbidden, exceptions.InvalidPath):
            pass

    if tenancy:
        try:
            result = client.secrets.kv.v1.read_secret(path=label, mount_point=f"{backend}/{tenancy}/{deploy_env}")
            return cast(JsonRes, result["data"])
        except (exceptions.Forbidden, exceptions.InvalidPath):
            pass

    try:
        result = client.secrets.kv.v1.read_secret(path=label, mount_point=f"{backend}/common/{deploy_env}")
        return cast(JsonRes, result["data"])
    except (exceptions.Forbidden, exceptions.InvalidPath):
        try:
            result = client.secrets.kv.v1.read_secret(path=label, mount_point=f"{backend}/{deploy_env}")
            log.message(
                message=f"Label senza un namespace sono deprecate, sposta '{label}' sotto una tenancy o in 'common'",
                level=logger.LogLevel.WARNING,
            )
        except (exceptions.Forbidden, exceptions.InvalidPath) as exc:
            log.message(message=f"Failed Authorization for Token {token[0:6]}...", level=logger.LogLevel.WARNING)
            raise exc

    return cast(JsonRes, result["data"])


def _update_vault(
    client: Client,
    payload: JsonRes,
    label: str,
    token: str,
    deploy_env: str,
    tenancy: Union[None, str],
    backend: str,
) -> None:
    if deploy_env.lower() in [
        "loc",
    ]:
        local_mount = _local_mount(client, backend)
        if local_mount:
            result = client.secrets.kv.v1.read_secret(path=label, mount_point=local_mount)
            if "_shutoff" in result["data"] and result["data"]["_shutoff"] == "y":
                raise exceptions.InvalidPath
            else:
                print(f"! WRITING '{label}' TO LOCAL OVERRIDE")  # noqa: T001
                vals = cast(JsonRes, result["data"])
                vals.update(payload)
                client.secrets.kv.v1.create_or_update_secret(label, secret=vals, mount_point=local_mount)
                return
        else:
            raise exceptions.InvalidPath

    mp = f"{backend}/{deploy_env}"

    try:
        result = client.secrets.kv.v1.read_secret(path=label, mount_point=mp)
        vals = cast(JsonRes, result["data"])
        vals.update(payload)
        client.secrets.kv.v1.create_or_update_secret(label, secret=vals, mount_point=mp)
    except (exceptions.Forbidden, exceptions.InvalidPath) as exc:
        log.message(message=f"Failed Authorization for Token {token[0:6]}...", level=logger.LogLevel.WARNING)
        raise exc


def from_vault(  # noqa
    label: str,
    token: Optional[str] = None,
    deploy_env: Optional[str] = None,
    tenancy: Optional[str] = None,
    backend: str = "kv",
) -> JsonRes:
    """Retrieve config jsons from the vault.

    Keyword arguments:
    label -- key for the config to retrieve
    token -- vault authentication tocken to use (defaults to VAULT_TOKEN env value)
    deploy_env -- referred deploy environment  (defaults to DEPLOY_ENV env value)
    backend -- backend to search (defaults to 'kv', only key-value v1 backends supported)

    Examples:
    to read the configuration for the dpegate in use by current environment :

        from_vault("gate_dn")

    to read the configuration for the depgate in test environment, passing a specific vault token

        from_vault("gate_dn", "s.xxx", "tst")
    """
    client, token, deploy_env, tenancy = _client_token_env_tenancy(token, deploy_env, tenancy)
    return _read_vault(client, label, token, deploy_env, tenancy, backend)


def update_vault(
    label: str,
    payload: JsonRes,
    token: Optional[str] = None,
    deploy_env: Optional[str] = None,
    tenancy: Optional[str] = None,
    backend: str = "kv",
) -> None:
    """Update configs in the vault for an existing key.

    Path is searched with the same rules for reading, unexisting path gives auth error in the same way.
    Only keys in the payload are updated, existing keys not in the payload are left untouched, extra keys
    in the payload are added.

    Keyword arguments:
    label -- key for the config to retrieve
    payload -- json with the values to add / update
    token -- vault authentication tocken to use (defaults to VAULT_TOKEN env value)
    deploy_env -- referred deploy environment  (defaults to DEPLOY_ENV env value)
    backend -- backend to search (defaults to 'kv', only key-value v1 backends supported)
    """
    client, token, deploy_env, tenancy = _client_token_env_tenancy(token, deploy_env, tenancy)
    _update_vault(client, payload, label, token, deploy_env, tenancy, backend)


def _local_mount(client: Client, backend: str) -> Optional[str]:
    token_lookup = client.lookup_token()["data"]
    entity_id = token_lookup["entity_id"]
    try:
        sub_prefix = client.secrets.identity.read_entity(entity_id)["data"]["name"]
    except (exceptions.UnexpectedError, exceptions.Forbidden):
        return None
    sub_mount_point = f"{backend}/loc/{sub_prefix}"
    return sub_mount_point


def qtask_token(auth_qtask: JsonRes) -> Tuple[Dict[str, str], datetime]:
    credentials = {"Username": auth_qtask["username"], "Password": auth_qtask["password"]}

    res = requests.get(f"{auth_qtask['host']}Autenticazione/NomeHeaderTokenSessione")
    token_key = res.json()
    res = requests.post(f"{auth_qtask['host']}Autenticazione/Autentica", json=credentials)

    if res.status_code != 200:
        log.message(
            message=f"Failed Authorization for QTask user {auth_qtask['username']}", level=logger.LogLevel.WARNING
        )
        raise ConnectionError(res.status_code)

    token_val = res.json()
    token_header = {token_key: token_val}
    res = requests.get(f"{auth_qtask['host']}Autenticazione/Sessione", headers=token_header)

    expires = res.json()["DataScadenza"][:19]
    return {token_key: token_val}, datetime.strptime(expires, "%Y-%m-%dT%H:%M:%S")


def autenticate(username: str, password: str) -> Dict[str, str]:
    conn = ldap.initialize("ldap://btdc01.gruppomol.lcl")
    conn.protocol_version = 3
    conn.set_option(ldap.OPT_REFERRALS, 0)
    conn.simple_bind_s(f"{username}@gruppomol.lcl", password)
    basedn = "OU=root,DC=GRUPPOMOL,DC=LCL"
    results = conn.search_s(basedn, ldap.SCOPE_SUBTREE, f"userPrincipalName={username}@gruppomol.it")
    if len(results) > 1:
        raise ValueError("Più di un utente trovato per queste credenziali")
    return cast(Dict[str, str], results[0][1])


def list_resources(deploy_env: Optional[str], tenancy: Optional[str]) -> dict[str, dict[str, str] | str]:
    client, _, deploy_env, tenancy = _client_token_env_tenancy(token=None, deploy_env=deploy_env, tenancy=tenancy)
    output: dict[str, dict[str, str] | str] = dict()

    try:
        secret_keys = client.secrets.kv.v1.list_secrets(path=".", mount_point=f"kv/{tenancy}/{deploy_env}")["data"][
            "keys"
        ]
    except exceptions.Forbidden:
        return {f"{deploy_env}:{tenancy}": "FORBIDDEN"}

    for secret_key in secret_keys:
        try:
            secret = client.secrets.kv.v1.read_secret(path=secret_key, mount_point=f"kv/{tenancy}/{deploy_env}")["data"]
            output[secret_key] = {
                "service_type": secret["service_type"] if "service_type" in secret.keys() else "MISSING",
                "protocol": secret["protocol"] if "protocol" in secret.keys() else "MISSING",
                "host": secret["host"] if "host" in secret.keys() else "MISSING",
                "username": secret["username"] if "username" in secret.keys() else "MISSING",
            }
        except exceptions.Forbidden:
            output[secret_key] = "FORBIDDEN"

    return output


def keycloack_bearer(label: str) -> dict[str, str]:
    conf = from_vault(label)
    host = from_vault("internal_endpoints")["keycloack"]
    res = requests.post(
        f"{host}/realms/gmolapps/protocol/openid-connect/token",
        data={"client_id": conf["clientid"], "client_secret": conf["secret"], "grant_type": "client_credentials"},
    )
    token = res.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}
