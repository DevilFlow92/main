from datetime import date
from typing import Literal, TypedDict

from pydantic import BaseModel

from .core import DateInterval, TimeInterval


class JobRestrictions(BaseModel):
    date: list[date] | None
    date_interval: list[DateInterval] | None
    time_interval: list[TimeInterval] | None
    week_day: list[Literal["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"]] | None


class JobSetup(TypedDict):
    capabilities: set[str]
    resources: dict[str, dict[str, str]]
    specific_resources: dict[str, set[str]]
    seconds_per_human_execution: int
    max_requests: int
    requests_delay: int
    restrictions: JobRestrictions | None
    cost_center: str | None
    notes: str | None
