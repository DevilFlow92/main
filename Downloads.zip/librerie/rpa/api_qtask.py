import base64
import json
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Any, Optional, cast

import requests
from requests.models import Response


class api_session_qtask:
    def __init__(self, username: str, password: str) -> None:
        self.credenziali = {"Username": username, "Password": password}
        self.url_base = r"https://backendservizi.gruppomol.lcl/api/v2"
        self.url_header_token = self.url_base + "/Autenticazione/NomeHeaderTokenSessione"
        self.url_sessione = self.url_base + "/Autenticazione/Sessione"
        self.header_sessione = {"Content-Type": "application/json"}
        self.header_token_sessione = self._get_header_token_sessione()

    def _get_header_token_sessione(self) -> str:
        # Qui qtask torna una stringa buttata lì ... per questo poi possiamo usarla come chiave
        return cast(str, requests.get(self.url_header_token).json())

    def post_autenticazione(self) -> Any:
        url_autenticazione = self.url_base + "/Autenticazione/Autentica"
        autenticazione = requests.post(
            url_autenticazione, headers=self.header_sessione, data=json.dumps(self.credenziali)
        )
        if autenticazione.status_code != 200:
            return autenticazione
        self.token_sessione = autenticazione.json()
        self.header_sessione[self.header_token_sessione] = self.token_sessione
        return autenticazione

    def sessione_is_valida(self) -> bool:
        sessione = requests.get(self.url_sessione, headers=self.header_sessione)
        if sessione.status_code != 200:
            return False
        return cast(bool, sessione.json()["IsValida"])

    def apri_sessione(func):  # type: ignore
        @wraps(func)  # type: ignore
        def wrapper(*args, **kwargs):
            if args[0].sessione_is_valida():
                return func(*args, **kwargs)  # type: ignore
            autenticazione = args[0].post_autenticazione()
            if not autenticazione:
                return autenticazione
            return func(*args, **kwargs)  # type: ignore

        return wrapper

    @apri_sessione  # type: ignore
    def post_incarico(
        self,
        cod_area: int,
        cod_cliente: int,
        cod_tipo_incarico: int,
        chiave_cliente: str,
        cod_attributo: Optional[int] = None,
        flag_urgente: Optional[bool] = None,
    ) -> Response:

        data = {
            "CodArea": cod_area,
            "CodCliente": cod_cliente,
            "CodTipoIncarico": cod_tipo_incarico,
            "ChiaveCliente": chiave_cliente,
            "CodAttributo": cod_attributo,
            "FlagUrgente": flag_urgente,
        }
        resp = requests.post(f"{self.url_base}/Incarico", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def get_incarico(self, id_incarico: int) -> Response:
        resp = requests.get(
            f"{self.url_base}/Incarico/{id_incarico}",
            headers=self.header_sessione,
        )
        return resp

    @apri_sessione  # type: ignore
    def get_incarico_collezione_documenti(self, id_incarico: int) -> Response:
        resp = requests.get(f"{self.url_base}/Incarico/{id_incarico}/collezioneDocumenti", headers=self.header_sessione)
        return resp

    @apri_sessione  # type: ignore
    def post_documento(
        self,
        id_incarico: int,
        cod_tipo_documento: int,
        path: Path,
        note: Optional[str] = None,
        flag_originale: Optional[bool] = None,
    ) -> Response:
        with open(path, "rb") as cont:
            doc = cont.read()
        documento = base64.b64encode(doc)
        data = {
            "Contenuto": documento.decode("utf-8"),
            "CodTipoDocumento": cod_tipo_documento,
            "NomeFile": path.name,
            "Note": note,
            "IdIncarico": id_incarico,
            "FlagOriginale": flag_originale,
        }
        resp = requests.post(f"{self.url_base}/Documento", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def put_documento(
        self,
        id_documento: int,
        flag_originale: Optional[bool] = None,
        flag_incompleto: Optional[bool] = None,
        note: Optional[str] = None,
    ) -> Response:
        data = {
            "idDocumento": id_documento,
            "FlagOriginale": flag_originale,
            "FlagIncompleto": flag_incompleto,
            "note": note,
        }
        resp = requests.post(f"{self.url_base}/Documento/{id_documento}", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def put_stato_workflow(self, id_incarico: int, cod_stato_workflow: int) -> Response:

        resp = requests.put(
            f"{self.url_base}/Incarico/{id_incarico}/statoWorkflow/{cod_stato_workflow}", headers=self.header_sessione
        )
        return resp

    @apri_sessione  # type: ignore
    def put_flag_attesa(self, id_incarico: int, flag_attesa: bool) -> Response:
        resp = requests.put(
            f"{self.url_base}/Incarico/{id_incarico}/flagAttesa/{flag_attesa}", headers=self.header_sessione
        )
        return resp

    @apri_sessione  # type: ignore
    def post_attivita_pianificata(
        self,
        id_incarico: int,
        cod_tipo_attivita_pianificata: int,
        cod_ufficio_attivita_pianificata: Optional[int] = None,
        id_operatore_responsabile: Optional[int] = None,
        data_scadenza: Optional[datetime] = None,
        flag_urgente: Optional[bool] = None,
        note: Optional[str] = None,
    ) -> Response:

        data = {
            "CodTipoAttivitaPianificataIncarico": cod_tipo_attivita_pianificata,
            "CodUfficioAttivitaPianificata": cod_ufficio_attivita_pianificata,
            "IdOperatoreResponsabile": id_operatore_responsabile,
            "DataScadenza": data_scadenza,
            "FlagUrgente": flag_urgente,
            "Note": note,
        }
        resp = requests.post(
            f"{self.url_base}/Incarico/{id_incarico}/attivitaPianificata", headers=self.header_sessione, json=data
        )
        return resp

    @apri_sessione  # type: ignore
    def put_attivita_pianificata(
        self,
        id_incarico: int,
        id_attivita: int,
        cod_stato_attivita: int,
        cod_tipo_attivita_pianificata: Optional[int] = None,
        cod_ufficio_attivita_pianificata: Optional[int] = None,
        id_operatore_responsabile: Optional[int] = None,
        data_scadenza: Optional[datetime] = None,
        flag_urgente: Optional[bool] = None,
        note: Optional[str] = None,
    ) -> Response:

        data = {
            "CodTipoAttivitaPianificataIncarico": cod_tipo_attivita_pianificata,
            "CodStatoAttivita": cod_stato_attivita,
            "CodUfficioAttivitaPianificata": cod_ufficio_attivita_pianificata,
            "IdOperatoreResponsabile": id_operatore_responsabile,
            "DataScadenza": data_scadenza,
            "FlagUrgente": flag_urgente,
            "Note": note,
        }
        resp = requests.put(
            f"{self.url_base}/Incarico/{id_incarico}/attivitaPianificata/{id_attivita}",
            headers=self.header_sessione,
            json=data,
        )

        return resp

    @apri_sessione  # type: ignore
    def put_flag_eccezione(self, id_pratica: int, flag_eccezione: bool) -> Response:

        resp = requests.put(
            f"{self.url_base}/Pratica/{id_pratica}/flagEccezione/{flag_eccezione}", headers=self.header_sessione
        )
        return resp

    @apri_sessione  # type: ignore
    def post_dato_aggiuntivo(
        self, id_incarico: int, cod_tipo_dato_aggiuntivo: int, testo_dato_aggiuntivo: str
    ) -> Response:

        data = {"CodTipoDatoAggiuntivo": cod_tipo_dato_aggiuntivo, "Testo": testo_dato_aggiuntivo}

        resp = requests.post(
            f"{self.url_base}/Incarico/{id_incarico}/datoAggiuntivo", headers=self.header_sessione, json=data
        )
        return resp

    @apri_sessione  # type: ignore
    def post_nota(self, id_incarico: int, cod_tipo_nota_incarichi: int, testo: str) -> Response:

        data = {"CodTipoNotaIncarichi": cod_tipo_nota_incarichi, "Testo": testo}
        resp = requests.post(f"{self.url_base}/Incarico/{id_incarico}/nota", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def post_ipoteca(
        self,
        id_incarico: int,
        cod_conservatoria: int,
        registro_generale: Optional[str] = None,
        registro_particolare: Optional[str] = None,
        registro_particolare_2: Optional[str] = None,
        data_iscrizione: Optional[datetime] = None,
        data_estinzione: Optional[datetime] = None,
        data_richiesta_cancellazione: Optional[datetime] = None,
        codice_invio: Optional[int] = None,
        data_rinnovo: Optional[datetime] = None,
        registro_generale_ipoteca_rinnovata: Optional[str] = None,
        registro_particolare_ipoteca_rinnovata: Optional[str] = None,
        data_scadenza_post_rinnovo: Optional[datetime] = None,
        data_titolo: Optional[datetime] = None,
        numero_repertorio_titolo: Optional[str] = None,
        notaio_titolo: Optional[str] = None,
        localita_titolo: Optional[str] = None,
        sigla_provincia_titolo: Optional[str] = None,
    ) -> Response:

        data = {
            "CodConservatoria": cod_conservatoria,
            "RegistroGenerale": registro_generale,
            "RegistroParticolare": registro_particolare,
            "RegistroParticolare2": registro_particolare_2,
            "DataIscrizione": data_iscrizione,
            "DataEstinzione": data_estinzione,
            "DataRichiestaCancellazione": data_richiesta_cancellazione,
            "CodiceInvio": codice_invio,
            "DataRinnovo": data_rinnovo,
            "RegistroGeneraleIpotecaRinnovata": registro_generale_ipoteca_rinnovata,
            "RegistroParticolareIpotecaRinnovata": registro_particolare_ipoteca_rinnovata,
            "DataScadenzaPostRinnovo": data_scadenza_post_rinnovo,
            "DataTitolo": data_titolo,
            "NumeroRepertorioTitolo": numero_repertorio_titolo,
            "NotaioTitolo": notaio_titolo,
            "LocalitaTitolo": localita_titolo,
            "SiglaProvinciaTitolo": sigla_provincia_titolo,
        }

        for key, value in data.items():
            if type(value) is datetime:
                data[key] = value.isoformat()

        data = {k: v for k, v in data.items() if v}

        resp = requests.post(f"{self.url_base}/Incarico/{id_incarico}/ipoteca", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def put_ipoteca(
        self,
        id_incarico: int,
        cod_conservatoria: int,
        registro_generale: Optional[str] = None,
        registro_particolare: Optional[str] = None,
        registro_particolare_2: Optional[str] = None,
        data_iscrizione: Optional[datetime] = None,
        data_estinzione: Optional[datetime] = None,
        data_richiesta_cancellazione: Optional[datetime] = None,
        codice_invio: Optional[int] = None,
        data_rinnovo: Optional[datetime] = None,
        registro_generale_ipoteca_rinnovata: Optional[str] = None,
        registro_particolare_ipoteca_rinnovata: Optional[str] = None,
        data_scadenza_post_rinnovo: Optional[datetime] = None,
        data_titolo: Optional[datetime] = None,
        numero_repertorio_titolo: Optional[str] = None,
        notaio_titolo: Optional[str] = None,
        localita_titolo: Optional[str] = None,
        sigla_provincia_titolo: Optional[str] = None,
    ) -> Response:

        data = {
            "CodConservatoria": cod_conservatoria,
            "RegistroGenerale": registro_generale,
            "RegistroParticolare": registro_particolare,
            "RegistroParticolare2": registro_particolare_2,
            "DataIscrizione": data_iscrizione,
            "DataEstinzione": data_estinzione,
            "DataRichiestaCancellazione": data_richiesta_cancellazione,
            "CodiceInvio": codice_invio,
            "DataRinnovo": data_rinnovo,
            "RegistroGeneraleIpotecaRinnovata": registro_generale_ipoteca_rinnovata,
            "RegistroParticolareIpotecaRinnovata": registro_particolare_ipoteca_rinnovata,
            "DataScadenzaPostRinnovo": data_scadenza_post_rinnovo,
            "DataTitolo": data_titolo,
            "NumeroRepertorioTitolo": numero_repertorio_titolo,
            "NotaioTitolo": notaio_titolo,
            "LocalitaTitolo": localita_titolo,
            "SiglaProvinciaTitolo": sigla_provincia_titolo,
        }

        for key, value in data.items():
            if type(value) is datetime:
                data[key] = value.isoformat()

        data = {k: v for k, v in data.items() if v}

        resp = requests.put(f"{self.url_base}/Incarico/{id_incarico}/ipoteca", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def post_relazione_persona(
        self,
        id_incarico: int,
        id_persona: int,
        cod_ruolo_richiedente: int,
        data_inizio_rapporto: Optional[datetime] = None,
    ) -> Response:

        data = {
            "IdPersona": id_persona,
            "CodRuoloRichiedente": cod_ruolo_richiedente,
            "DataInizioRapporto": data_inizio_rapporto,
        }
        resp = requests.post(
            f"{self.url_base}/Incarico/{id_incarico}/relazionePersona", headers=self.header_sessione, json=data
        )
        return resp

    @apri_sessione  # type: ignore
    def post_persona(
        self,
        cod_cliente: int,
        cod_tipo_persona: int,
        chiave_cliente: Optional[str] = None,
        chiave_cliente_secondaria: Optional[str] = None,
        cod_tipologia_cedente: Optional[int] = None,
        cod_parentela: Optional[int] = None,
        flag_fatca: Optional[bool] = None,
        flag_crs: Optional[bool] = None,
        cognome: Optional[str] = None,
        nome: Optional[str] = None,
        cod_sesso: Optional[int] = None,
        data_nascita: Optional[datetime] = None,
        cod_comune_nascita: Optional[str] = None,
        comune_nascita_estero: Optional[str] = None,
        sigla_provincia_nascita: Optional[str] = None,
        cod_stato_nascita: Optional[int] = None,
        codice_fiscale: Optional[str] = None,
        cod_nazionalita: Optional[int] = None,
        data_inizio_residenza_italiana: Optional[datetime] = None,
        data_decesso: Optional[datetime] = None,
        data_costituzione: Optional[datetime] = None,
        ragione_sociale: Optional[str] = None,
        cod_natura_giuridica: Optional[int] = None,
        codice_fiscale_estero: Optional[str] = None,
        partita_iva: Optional[str] = None,
        numero_cciaa: Optional[str] = None,
        data_costituzione_cciaa: Optional[datetime] = None,
        cod_costituzione_cciaa: Optional[str] = None,
        comune_costituzione_cciaa_estero: Optional[str] = None,
        sigla_provincia_costituzione_cciaa: Optional[str] = None,
        cod_stato_costituzione_cciaa: Optional[int] = None,
        codice_rea: Optional[str] = None,
    ) -> Response:

        data = {
            "CodCliente": cod_cliente,
            "ChiaveCliente": chiave_cliente,
            "ChiaveClienteSecondaria": chiave_cliente_secondaria,
            "CodTipologiaCedente": cod_tipologia_cedente,
            "CodTipoPersona": cod_tipo_persona,
            "CodParentela": cod_parentela,
            "FlagFatca": flag_fatca,
            "FlagCrs": flag_crs,
            "Cognome": cognome,
            "Nome": nome,
            "CodSesso": cod_sesso,
            "DataNascita": data_nascita,
            "CodComuneNascita": cod_comune_nascita,
            "ComuneNascitaEstero": comune_nascita_estero,
            "SiglaProvinciaNascita": sigla_provincia_nascita,
            "CodStatoNascita": cod_stato_nascita,
            "CodiceFiscale": codice_fiscale,
            "CodNazionalita": cod_nazionalita,
            "DataInizioResidenzaItaliana": data_inizio_residenza_italiana,
            "DataDecesso": data_decesso,
            "DataCostituzione": data_costituzione,
            "RagioneSociale": ragione_sociale,
            "CodNaturaGiuridica": cod_natura_giuridica,
            "CodiceFiscaleEstero": codice_fiscale_estero,
            "PartitaIva": partita_iva,
            "NumeroCciaa": numero_cciaa,
            "DataCostituzioneCciaa": data_costituzione_cciaa,
            "CodCostituzioneCciaa": cod_costituzione_cciaa,
            "ComuneCostituzioneCciaaEstero": comune_costituzione_cciaa_estero,
            "SiglaProvinciaCostituzioneCciaa": sigla_provincia_costituzione_cciaa,
            "CodStatoCostituzioneCciaa": cod_stato_costituzione_cciaa,
            "CodiceRea": codice_rea,
        }
        resp = requests.post(f"{self.url_base}/Persona", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def post_persona_contatto(
        self,
        id_persona: int,
        cod_ruolo_contatto: Optional[int] = None,
        referente: Optional[str] = None,
        telefono: Optional[str] = None,
        cellulare: Optional[str] = None,
        fax: Optional[str] = None,
        email: Optional[str] = None,
        email_alternativa: Optional[str] = None,
        email_pec: Optional[str] = None,
        descrizione: Optional[str] = None,
        cod_tipo_contatto: Optional[int] = None,
        flag_attivo: Optional[bool] = None,
    ) -> Response:

        data = {
            "CodRuoloContatto": cod_ruolo_contatto,
            "Referente": referente,
            "Telefono": telefono,
            "Cellulare": cellulare,
            "Fax": fax,
            "Email": email,
            "EmailAlternativa": email_alternativa,
            "EmailPec": email_pec,
            "Descrizione": descrizione,
            "CodTipoContatto": cod_tipo_contatto,
            "FlagAttivo": flag_attivo,
        }
        resp = requests.post(f"{self.url_base}/Persona/{id_persona}/contatto", headers=self.header_sessione, json=data)
        return resp
