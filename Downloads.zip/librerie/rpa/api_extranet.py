import base64
import json
from functools import wraps
from pathlib import Path
from typing import Any, Optional, cast

import requests
from requests.models import Response


class api_session_clc:
    def __init__(self, username: str, password: str) -> None:
        self.credenziali = {"Username": username, "Password": password}
        self.url_base = r"https://backendservizi.gruppomol.lcl/api/v2"
        self.url_header_token = self.url_base + "/Autenticazione/NomeHeaderTokenSessione"
        self.url_sessione = self.url_base + "/Autenticazione/Sessione"
        self.header_sessione = {"Content-Type": "application/json"}
        self.header_token_sessione = self._get_header_token_sessione()

    def _get_header_token_sessione(self) -> str:
        # Qui qtask torna una stringa buttata lì ... per questo poi possiamo usarla come chiave
        return cast(str, requests.get(self.url_header_token).json())

    def post_autenticazione(self) -> Any:
        url_autenticazione = self.url_base + "/Autenticazione/Autentica"
        autenticazione = requests.post(
            url_autenticazione, headers=self.header_sessione, data=json.dumps(self.credenziali)
        )
        if autenticazione.status_code != 200:
            return autenticazione
        self.token_sessione = autenticazione.json()
        self.header_sessione[self.header_token_sessione] = self.token_sessione
        return autenticazione

    def sessione_is_valida(self) -> bool:
        sessione = requests.get(self.url_sessione, headers=self.header_sessione)
        if sessione.status_code != 200:
            return False
        return cast(bool, sessione.json()["IsValida"])

    def apri_sessione(func):  # type: ignore
        @wraps(func)  # type: ignore
        def wrapper(*args, **kwargs):
            if args[0].sessione_is_valida():
                return func(*args, **kwargs)  # type: ignore
            autenticazione = args[0].post_autenticazione()
            if not autenticazione:
                return autenticazione
            return func(*args, **kwargs)  # type: ignore

        return wrapper

    @apri_sessione  # type: ignore
    def post_documento_clc(
        self,
        id_pratica: int,
        cod_tipo_documento: int,
        path: Path,
        note: Optional[str] = None,
        flag_originale: Optional[bool] = None,
    ) -> Response:
        with open(path, "rb") as cont:
            doc = cont.read()
        documento = base64.b64encode(doc)
        data = {
            "IdPratica": id_pratica,
            "Contenuto": documento.decode("utf-8"),
            "CodTipoDocumento": cod_tipo_documento,
            "NomeFile": path.name,
            "Note": note,
            "FlagOriginale": flag_originale,
        }
        resp = requests.post(f"{self.url_base}/Documento", headers=self.header_sessione, json=data)
        return resp

    @apri_sessione  # type: ignore
    def put_documento_clc(
        self,
        id_documento: int,
        flag_originale: Optional[bool] = None,
        flag_incompleto: Optional[bool] = None,
        note: Optional[str] = None,
    ) -> Response:
        data = {
            "idDocumento": id_documento,
            "FlagOriginale": flag_originale,
            "FlagIncompleto": flag_incompleto,
            "note": note,
        }
        resp = requests.post(f"{self.url_base}/Documento/{id_documento}", headers=self.header_sessione, json=data)
        return resp
