from pymol.types.rpa import JobRestrictions

__all__ = ["JobRestrictions"]
