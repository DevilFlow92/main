from typing import Any

import pyodbc

from pymol.auth import from_vault, qtask_token


def create_connection(label: str) -> pyodbc.Cursor:
    auth_params = from_vault(label)
    db_params = (
        f"DRIVER={auth_params['driver']};SERVER={auth_params['server']};"
        f"DATABASE={auth_params['database']};{auth_params['options']}"
    )
    dbconn = pyodbc.connect(db_params, autocommit=False)
    return dbconn


def service(vault_label: str) -> Any:
    auth = from_vault(vault_label)
    if "service_type" not in auth:
        raise ValueError(f"La configurazione {vault_label} non è un servizio.")

    if auth["service_type"] == "db":
        dbconn = create_connection(vault_label)
        cursor = dbconn.cursor()
        return {"conn": dbconn, "cursor": cursor}
    if auth["service_type"] == "api":
        api_auth = from_vault(vault_label)
        headers, expires = qtask_token(api_auth)
        headers["Content-Type"] = "application/json"
        return {"headers": headers, "expires": expires, "host": api_auth["host"]}


def close_service(vault_label: str, service_handler: Any) -> None:
    auth = from_vault(vault_label)
    if "service_type" not in auth:
        raise ValueError(f"La configurazione {vault_label} non è un servizio.")

    if auth["service_type"] == "db":
        service_handler["conn"].close()
