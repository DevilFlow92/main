import os
import shutil
from abc import ABC, abstractmethod
from collections.abc import Iterator
from datetime import datetime, time, timedelta
from getpass import getuser
from inspect import getdoc
from pathlib import Path
from socket import gethostname
from typing import Any, Optional, TypedDict, Union
from zoneinfo import ZoneInfo

import hvac
from requests.exceptions import HTTPError

from pymol import logger
from pymol.auth import from_vault
from pymol.logger import log
from pymol.types.core import JsonRes, WeekDay
from pymol.types.rpa import JobRestrictions, JobSetup

from .api_rpa import api_session_rpa


class RobotResponse(TypedDict):
    status: str
    details: Optional[dict[str, Any]]


class MOLRobot(ABC):
    def __init__(self, business_area: str) -> None:
        self.business_area = business_area
        self.name = type(self).__name__
        self.conf = self._conf()
        self.docboarding_path = Path(r"C:\DocBoarding", self.name)
        self.downloads_path = Path(r"C:\Users\srvc_rpa\Downloads")
        self.robotics_mail = "dugtiprpa@gruppomol.it"

    def start_(self, work_item: Any) -> RobotResponse:
        output = self.start(work_item)
        return RobotResponse(**output)  # type: ignore

    @abstractmethod
    def start(self, work_item: Any) -> RobotResponse:
        pass

    @abstractmethod
    def job_setup(self) -> JobSetup:
        pass

    def _conf(self) -> Any:
        try:
            return from_vault(f"confs/{self.business_area}/{self.name}", backend="rpa")
        except (hvac.exceptions.Forbidden, hvac.exceptions.InvalidPath):
            return {}

    def _create_job(self, rpa_session: api_session_rpa) -> None:
        setup = self.job_setup()
        job_payload = {
            "job_type": "ROBOT",
            "name": self.name,
            "description": getdoc(self),
            "priority": 0,
            "businessarea": self.business_area,
            "seconds_per_human_execution": setup["seconds_per_human_execution"],
            "max_requests": setup["max_requests"],
            "requests_delay": setup["requests_delay"],
            "cost_center": setup.get("cost_center"),
            "restrictions": setup.get("restrictions"),
            "notes": setup.get("notes"),
        }
        try:
            rpa_session.create_job(job_payload)
        except HTTPError as e:
            if e.response.response.status_code != 409:
                raise

    def _associate_capability(self, rpa_session: api_session_rpa) -> None:
        setup = self.job_setup()
        for cap_name in setup["capabilities"]:
            rpa_session.associate_capability(self.name, cap_name)

    def _assign_resources(self, rpa_session: api_session_rpa) -> None:
        setup = self.job_setup()
        for resource, fields in setup["resources"].items():
            res_payload = {"fields": fields}

            try:
                rpa_session.create_resource(resource, res_payload)
            except HTTPError as e:
                if e.response.response.status_code != 409:
                    raise
            rpa_session.assign_resource(self.name, resource)

    def _assign_specific_serources(self, rpa_session: api_session_rpa) -> None:
        setup = self.job_setup()
        for resource, specific_resources in setup["specific_resources"].items():
            for specific_resource in specific_resources:
                try:
                    rpa_session.create_resource_item(resource, specific_resource)
                except HTTPError as e:
                    if e.response.response.status_code != 409:
                        raise
                rpa_session.assign_specific_resource(self.name, resource, specific_resource)

    def register(self) -> None:

        s_rpa = api_session_rpa(f"{self.name}.{getuser()}@{gethostname()}", os.environ["VAULT_TOKEN"])

        self._create_job(s_rpa)
        self._associate_capability(s_rpa)
        self._assign_resources(s_rpa)
        self._assign_specific_serources(s_rpa)

        log.message(message="Registered robot", level=logger.LogLevel.INFO)

    def unregister(self) -> None:
        log.message(message="Unregister robot", level=logger.LogLevel.INFO)

    def resources(self, resources: dict[str, str]) -> dict[str, dict[str, JsonRes]]:
        return {
            resource: {label: from_vault(f"resources/{resource}/{label}", backend="rpa")}
            for resource, label in resources.items()
        }

    def add_to_share(
        self, file: Path, directory: str = "", rename: Optional[str] = None, overwrite: bool = False
    ) -> Path:
        rb_share = from_vault("commons/rb_share", backend="rpa")
        shared = Path(str(rb_share["base_path"]), str(rb_share["shared"]), self.business_area, self.name, directory)
        if shared.is_dir() and Path(shared, file.name) in list(shared.iterdir()) and overwrite is False:
            raise FileExistsError("File already in share")
        elif not shared.is_dir():
            shared.mkdir(parents=True)
        return Path(shutil.copy(file, Path(shared, (rename if rename else file.name))))

    def get_from_share(self, file_pattern: str, directory: str = "") -> list[Path]:
        rb_share = from_vault("commons/rb_share", backend="rpa")
        shared = Path(str(rb_share["base_path"]), str(rb_share["shared"]), self.business_area, self.name, directory)
        if shared.is_dir():
            return list(shared.glob(file_pattern))
        return []


def _merge_intervals(intervals: list[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    intervals = intervals.copy()
    while True:
        for i, date_1 in enumerate(intervals[:-1]):

            date_2 = intervals[i + 1]
            if date_1[1] >= date_2[0]:
                intervals[i] = (date_1[0], max(date_1[1], date_2[1]))
                intervals.pop(i + 1)
                break

        else:
            return intervals


class TimespanPartition(object):
    def __init__(
        self,
        starting_datetime: datetime,
        minutes_per_partition: int,
        restrictions: Optional[JobRestrictions] = None,
        due_datetime: Optional[datetime] = None,
        max_partitions: Optional[int] = None,
        timezone: ZoneInfo = ZoneInfo("Europe/Rome"),
    ):
        """
        Initialize a TimespanPartition object.

        Parameters
        ----------
        starting_datetime : datetime
            Starting datetime of the schedule. Ex. transiction datetime.
        minutes_per_partition : int
            Length, in minutes, of the partitions.
        stop_times : Optional[list[tuple[time, time]]]
            List of the times where the robot does not work, if any.
            [(time(hour=9), time(hour=18)),
             (time(hour=21), time(hour=8))]
        due_datetime : Optional[datetime]
            Due datetime to complete the Job, if any.
        max_partitions : Optional[int]
            Max number of partitions.
            If the combination of due_datetime and minutes_per_partition
            allows a different number of partitions, the selected partition
            will be the smallest of the two.

        Returns
        -------
        None.

        """
        self.starting_datetime = starting_datetime.replace(tzinfo=timezone)
        self.minutes_per_partition = minutes_per_partition
        self.timezone = timezone
        self.restrictions = restrictions
        self.due_datetime = (
            due_datetime.replace(tzinfo=timezone) if due_datetime else datetime.now(timezone) + timedelta(days=1)
        )
        self.update_due_datetime = due_datetime is None
        self.max_partitions = max_partitions

    def _now(self) -> datetime:
        """
        Return aware datetime.now.

        Needed to mock in test.
        """
        return datetime.now(self.timezone)

    def get_stop_intervals(self) -> list[tuple[datetime, datetime]]:
        """Create a list of stop intervals that spans datetimes from starting_datetime to due_datetime."""
        intervals = []

        stop_times = self.restrictions.time_interval if self.restrictions and self.restrictions.time_interval else []
        stop_dates = self.restrictions.date if self.restrictions and self.restrictions.date else []
        date_intervals = (
            self.restrictions.date_interval if self.restrictions and self.restrictions.date_interval else []
        )
        stop_days = self.restrictions.week_day if self.restrictions and self.restrictions.week_day else []
        for date_interval in date_intervals:
            date = date_interval.start_date
            while date <= date_interval.end_date:
                stop_dates.append(date)
                date += timedelta(days=1)

        days = 1

        while True:
            current_datetime = self.starting_datetime
            boundary_date = self._now() + timedelta(days=days)

            while current_datetime.date() <= boundary_date.date():
                for stop in stop_times:
                    start_datetime = datetime.combine(current_datetime.date(), stop.start_time)
                    end_datetime = datetime.combine(current_datetime.date(), stop.end_time)
                    if stop.start_time > stop.end_time:
                        start_datetime -= timedelta(days=1)

                    intervals.append(
                        (start_datetime.replace(tzinfo=self.timezone), end_datetime.replace(tzinfo=self.timezone))
                    )
                if current_datetime.date() in stop_dates or WeekDay(current_datetime.weekday()).name in stop_days:
                    intervals.append(
                        (
                            datetime.combine(current_datetime.date(), time(hour=0)).replace(tzinfo=self.timezone),
                            datetime.combine(current_datetime.date() + timedelta(days=1), time(hour=0)).replace(
                                tzinfo=self.timezone
                            ),
                        )
                    )

                current_datetime += timedelta(days=1)
            intervals = sorted(intervals, key=lambda x: x[0])
            if not intervals:
                return intervals

            intervals = _merge_intervals(intervals)

            if (
                boundary_date > intervals[-1][1]
                or len(intervals) > 1
                and intervals[-2][0] < self._now() < intervals[-1][0]
            ):
                return intervals
            days += 1

    def _init_int(self) -> tuple[Iterator[tuple[datetime, datetime]], datetime, datetime]:
        stop_intervals = (interval for interval in self.get_stop_intervals())

        try:
            stop_start, stop_end = next(stop_intervals)
        except StopIteration:
            stop_start = stop_end = self.starting_datetime
        while self.starting_datetime > stop_end:
            try:
                stop_start, stop_end = next(stop_intervals)
            except StopIteration:
                break
        return stop_intervals, stop_start, stop_end

    def get_working_intervals(self) -> dict[int, dict[str, datetime]]:
        """Create a segmentation of the timespan.

        Start end end datetimes are calculated counting the stop times so that
        each partition length has equal number of minutes
        """
        next_stop = True
        stop_intervals, stop_start, stop_end = self._init_int()
        current_date = self.starting_datetime
        if current_date > self._now():
            return {1: {"start": self._now(), "end": current_date}}
        partitions = {}
        i = 1
        while current_date < self._now():
            if stop_start and stop_start < current_date <= stop_end:
                try:
                    current_date = stop_end
                    stop_start, stop_end = next(stop_intervals)
                except StopIteration:
                    next_stop = False
            partitions[i] = {"start": current_date}

            elapsed = 0
            while (
                next_stop
                and current_date + timedelta(minutes=self.minutes_per_partition) - timedelta(seconds=elapsed)
                >= stop_start
            ):
                last_end = stop_start
                new_start = stop_end
                try:
                    elapsed += int((last_end - current_date).total_seconds())
                    current_date = new_start
                    stop_start, stop_end = next(stop_intervals)
                except StopIteration:
                    break
            current_date += timedelta(minutes=self.minutes_per_partition) - timedelta(seconds=elapsed)
            partitions[i]["end"] = current_date
            i += 1

        return partitions

    def get_partition(self) -> dict[str, Union[int, datetime]]:
        """Return the partition associated with the current time (datetime.now(timezone)).

        Associated partition depends on due_datetime end max_partition variables.
        """
        partitions = self.get_working_intervals()
        for partition_id, time_span in partitions.items():
            if self._now() < time_span["end"] or self.max_partitions and self.max_partitions == partition_id:
                break
        return {"id": partition_id} | partitions[int(partition_id)]
