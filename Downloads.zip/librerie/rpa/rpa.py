import contextlib
import random
import smtplib
import string
import tempfile
import time
from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from types import TracebackType
from typing import Literal, Optional, Type, cast

import pyautogui
import PyPDF2
from PIL import Image, ImageDraw, ImageFont
from pyodbc import Cursor

from pymol.auth import from_vault, update_vault
from pymol.types.core import JsonRes

from .services import close_service, service

pyautogui.FailSafeException = False

SERVER_MAIL = str(from_vault("mail_server")["server"]) + ".gruppomol.lcl"


class ImageNotFoundError(Exception):
    pass


class UpdatePasswordError(Exception):
    pass


def get_all_files(path: Path) -> list[Path]:
    files = []
    if path.is_file():
        return [path]
    for p in path.iterdir():
        if p.is_dir():
            files += get_all_files(p)
        elif p.is_file():
            files.append(Path(path, p))
    return files


class DownloadManager(object):
    def __init__(self, downloads_path: Path):
        self.downloads_path = downloads_path
        self.file_list = []
        for file in downloads_path.iterdir():
            if file.is_file():
                self.file_list.append(file)

    def __enter__(self) -> "DownloadManager":
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        pass

    def wait(self, file_extension: list[str] = [], exclude_extension: bool = False, elapse: int = 60) -> Optional[Path]:
        while elapse > 0:
            for file in self.downloads_path.iterdir():
                if (
                    file.is_file()
                    and (file.suffix in file_extension) is not exclude_extension
                    and file not in self.file_list
                ):
                    return Path(self.downloads_path, file)
            time.sleep(1)
            elapse -= 1
        return None


def get_random_password(
    lunghezza_minima: int, lunghezza_massima: int, caratteri_speciali_ammessi: str = "!#$%-_=+<>"
) -> str:
    """Genera una password casuale.

    Composta da almeno una lettera maiuscola, una lettera minuscola, un numero e un carattere speciale opzionale.
    """
    if lunghezza_minima < (3 if not caratteri_speciali_ammessi else 4):
        raise Exception(
            f"Impossibile generare una password di {lunghezza_minima}"
            + " caratteri contenente almeno una lettera maiuscola,"
            + " una lettera minuscola"
            + (", un numero e un carattere speciale" if caratteri_speciali_ammessi else " e un numero.")
        )
    char_list_1 = (
        random.choices(string.ascii_uppercase, k=1)
        + random.choices(string.digits, k=1)
        + random.choices(string.ascii_lowercase, k=1)
        + (random.choices(caratteri_speciali_ammessi, k=1) if caratteri_speciali_ammessi else [])
    )
    char_list_2 = random.choices(  # nosec: B311
        string.ascii_lowercase
        + string.ascii_uppercase
        + string.digits
        + (caratteri_speciali_ammessi if caratteri_speciali_ammessi else ""),
        k=random.randint(lunghezza_minima, lunghezza_massima) - len(char_list_1),
    )
    char_list = char_list_1 + char_list_2

    random.shuffle(char_list)
    return "".join(char_list)


def send_mail(
    from_: str,
    to: list[str],
    subject: str,
    body: str,
    form: str = "plain",  # [plain, html]
    cc: list[str] = [],
    ccn: list[str] = [],
    attachments: list[Path] = [],
) -> None:

    msg = MIMEMultipart()

    for attachment in attachments:
        att = MIMEApplication(attachment.read_bytes())
        att.add_header("Content-Disposition", "attachment", filename=attachment.name)
        msg.attach(att)

    msg["From"] = from_
    msg["To"] = ";".join(to)
    msg["Subject"] = subject
    msg["Cc"] = ";".join(cc)
    msg["Ccn"] = ";".join(ccn)

    body_ = MIMEText(body, form, "utf-8")

    msg.attach(body_)

    # Send the email
    try:
        server = smtplib.SMTP(SERVER_MAIL)
        server.sendmail(from_, to + cc + ccn, msg.as_string())
        return None
    finally:
        server.quit()


@contextlib.contextmanager
def db_connect(label: str) -> Cursor:
    handler = service(label)
    cursor = handler["cursor"]
    conn = handler["conn"]
    try:
        yield cursor
    except Exception:
        conn.rollback()
        raise
    else:
        conn.commit()
    finally:
        close_service(label, handler)


def wait_image(images: Path, name: str, seconds: int = 10, conf: float = 0.999) -> bool:
    while seconds >= 0:
        if pyautogui.locateOnScreen(str(Path(images, name)), confidence=conf):
            return True
        time.sleep(1)
        seconds -= 1
    return False


def wait_first_image(images: Path, names: list[str], seconds: int = 10, conf: float = 0.999) -> Optional[str]:
    while seconds >= 0:
        for name in names:
            if pyautogui.locateOnScreen(str(Path(images, name)), confidence=conf):
                return name
        time.sleep(1)
        seconds -= 1
    return None


def wait_image_and_click(
    images: Path, name: str, seconds: int = 0, clicks: Literal[1, 2, 3] = 1, conf: float = 0.999
) -> None:
    click_func = {1: pyautogui.click, 2: pyautogui.doubleClick, 3: pyautogui.tripleClick}
    while seconds >= 0:
        try:
            click_func[clicks](pyautogui.center(pyautogui.locateOnScreen(str(Path(images, name)), confidence=conf)))
            return None
        except TypeError:
            time.sleep(1)
        seconds -= 1
    raise ImageNotFoundError("Immagine non trovata: " + name)


def init_empty_folder(folder_path: Path) -> Path:
    folder_path.mkdir(parents=True, exist_ok=True)
    for file in folder_path.iterdir():
        file.unlink()
    return folder_path


class DictToProtectedPdf(object):
    def __init__(self, data: dict[str, str], password: str, font_size: int = 32) -> None:
        """
        Initialize the temporary file where data will be stored.

        Parameters:
        data dict[str, str]: key-values to protect.
        user_password str(): password to open the file.
        font_size(int): size of the font used in the pdf file.
        """
        self.data = data
        self.password = password
        self.font_size = font_size
        with tempfile.NamedTemporaryFile(suffix=".pdf") as temp_pdf:
            self.out_pdf = Path(temp_pdf.name)
        with tempfile.NamedTemporaryFile(suffix=".jpg") as temp_jpg:
            self.jpg_path = Path(temp_jpg.name)
        with tempfile.NamedTemporaryFile(suffix=".pdf") as temp_pdf:
            self.pdf_path = Path(temp_pdf.name)

    def __enter__(self) -> "DictToProtectedPdf":
        return self

    def get_pdf(self) -> Path:
        """
        Create a pdf with password.

        Returns: path to protected PDF.
        """
        text = "\n\n".join([f"{key}: {value}" for key, value in self.data.items()])
        font = ImageFont.truetype("calibriz.ttf", self.font_size)
        x1, y1 = font.getsize_multiline(text=text)
        width = x1 + 50
        length = y1 + 50

        img = Image.new("RGB", (width, length), "white")
        pixels = img.load()
        for i in [10, 11, 12, length - 12, length - 11, length - 10]:
            for j in range(img.size[0] - 10)[10:]:
                pixels[j, i] = (0, 51, 102)

        for i in [10, 11, 12, width - 12, width - 11, width - 10]:
            for j in range(img.size[1] - 10)[10:]:
                pixels[i, j] = (0, 51, 102)

        draw = ImageDraw.Draw(img)

        draw.text((25, 25), text, (0, 0, 0), font=font)
        img.save(self.jpg_path)
        with Image.open(self.jpg_path).convert("RGB") as im:
            im.save(self.pdf_path, "PDF", Quality=200)
        self.jpg_path.unlink()

        output = PyPDF2.PdfFileWriter()
        with open(self.pdf_path, "rb") as file, open(self.out_pdf, "wb") as output_file:
            input_stream = PyPDF2.PdfFileReader(file)
            output.addPage(input_stream.getPage(0))
            output.encrypt(self.password, use_128bit=True)
            output.write(output_file)
        self.pdf_path.unlink()
        return self.out_pdf

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        for file in {self.jpg_path, self.pdf_path, self.out_pdf}:
            try:
                file.unlink()
            except FileNotFoundError:
                pass


class UpdateResourcePassword(object):
    def __init__(self, resource: str, label: str, password: str, new_password: str, resource_uri: str | None = None):
        self.resource = resource
        self.label = label
        self.password = password
        self.new_password = new_password
        self.resource_uri = resource_uri or f"resources/{self.resource}/{self.label}"
        self.datetime_now = datetime.utcnow().isoformat()

    def __enter__(self) -> "UpdateResourcePassword":

        self.item_json = from_vault(self.resource_uri, backend="rpa")
        if self.password == self.new_password:
            raise UpdatePasswordError("New Password must be different from actual Password.")
        if self.password != self.item_json["password"]:
            raise UpdatePasswordError("Provided Password is different from Vault Password.")
        if self.item_json.get("updating_password_attempt"):
            raise UpdatePasswordError("Updating password attempt already in progress.")

        update_vault(self.resource_uri, payload={"updating_password_attempt": self.new_password}, backend="rpa")

        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        if not exc_type:
            old_passwords_to_keep = cast(int, self.item_json.get("expired_passwords_to_keep")) or 5

            expired_passwords = cast(JsonRes, self.item_json.get("expired_passwords") or dict())
            expired_passwords.update({datetime.utcnow().isoformat(): self.password})

            expired_passwords_to_keep = {
                k: expired_passwords[k]
                for k in sorted([key for key in expired_passwords.keys()], reverse=True)[
                    0 : min(len(expired_passwords), old_passwords_to_keep)
                ]
            }

            update_vault(
                self.resource_uri,
                payload={
                    "updating_password_attempt": None,
                    "password": self.new_password,
                    "expired_passwords": expired_passwords_to_keep,
                },
                backend="rpa",
            )
