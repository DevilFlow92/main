import socket
from typing import Any, Optional, Union, cast

import requests
from requests import Response
from requests.exceptions import HTTPError

from pymol.auth import from_vault
from pymol.types.core import Json


def get_json_or_raise_if_error(resp: Response) -> Union[None, dict[str, Json]]:
    try:
        resp.raise_for_status()
    except HTTPError as e:
        if e.response.headers["content-type"].strip().startswith("application/json"):
            raise HTTPError(
                e.args[0], e.response.json().get("detail"), response=e.response, request=e.request
            ) from None
        raise HTTPError(e.args[0], e.response.text, response=e.response, request=e.request) from None
    if resp.status_code != 204:
        return cast(dict[str, Json], resp.json())
    return None


class api_session_rpa:
    def __init__(self, username: str, password: str) -> None:
        self.user = username
        self.credenziali = {"grant_type": "password", "username": username, "password": password}
        self.url_base = str(from_vault("api_rpa")["host"])
        self.header_sessione = {"Content-Type": "application/x-www-form-urlencoded"}
        self.post_autenticazione()

    def post_autenticazione(self) -> None:
        url_autenticazione = self.url_base + "auth/token"
        resp = requests.post(url_autenticazione, headers=self.header_sessione, data=self.credenziali)
        try:
            resp.raise_for_status()
        except HTTPError as e:
            raise HTTPError({str(e)}, e.response.json().get("detail"), response=e) from None

        self.token_sessione = resp.json()["access_token"]
        self.token_type = resp.json()["token_type"]
        self.header_sessione["authorization"] = f"{self.token_type} {self.token_sessione}"

    def create_job(self, json_data: dict[str, Any]) -> Any:
        return get_json_or_raise_if_error(
            requests.post(f"{self.url_base}setup/jobs", headers=self.header_sessione, json=json_data)
        )

    def get_jobs(self) -> Any:
        return get_json_or_raise_if_error(requests.get(f"{self.url_base}setup/jobs", headers=self.header_sessione))

    def get_job(self, job_name: str) -> Any:
        return get_json_or_raise_if_error(
            requests.get(f"{self.url_base}setup/jobs/{job_name}", headers=self.header_sessione)
        )

    def associate_capability(self, job_name: str, cap_name: str) -> Any:
        return get_json_or_raise_if_error(
            requests.put(f"{self.url_base}setup/jobs/{job_name}/capabilities/{cap_name}", headers=self.header_sessione)
        )

    def create_resource(self, resource: str, json_data: dict[str, Any]) -> Any:
        return get_json_or_raise_if_error(
            requests.post(f"{self.url_base}setup/resources/{resource}", headers=self.header_sessione, json=json_data)
        )

    def assign_resource(self, job_name: str, resource_name: str) -> Any:
        return get_json_or_raise_if_error(
            requests.put(
                f"{self.url_base}setup/jobs/{job_name}/resources/{resource_name}", headers=self.header_sessione
            )
        )

    def create_resource_item(self, resource_name: str, item_label: str) -> Any:
        return get_json_or_raise_if_error(
            requests.post(
                f"{self.url_base}setup/resources/{resource_name}/items/{item_label}", headers=self.header_sessione
            )
        )

    def assign_specific_resource(self, job_name: str, resource_name: str, item_name: str) -> Any:
        return get_json_or_raise_if_error(
            requests.post(
                f"{self.url_base}setup/jobs/{job_name}/resources/{resource_name}/items/{item_name}",
                headers=self.header_sessione,
            )
        )

    def submit_work_request(self, job: str, business_identifiers: dict[str, str], data: dict[str, Any]) -> Any:
        return get_json_or_raise_if_error(
            requests.post(
                f"{self.url_base}queue/work",
                headers=self.header_sessione,
                json={
                    "job": job,
                    "requested_by": self.user,
                    "business_identifiers": business_identifiers,
                    "data": data,
                },
            )
        )

    def get_work_details(self, work_item_id: str) -> Any:
        return get_json_or_raise_if_error(
            requests.get(f"{self.url_base}queue/view/works/{work_item_id}", headers=self.header_sessione)
        )

    def get_works_in_state(self, state: str) -> Any:
        params = {"state": state}
        return get_json_or_raise_if_error(
            requests.get(f"{self.url_base}queue/view/works", params=params, headers=self.header_sessione)
        )

    def ask_for_work(self, capabilities: list[str]) -> Any:
        body = {"capabilities": list(capabilities), "worker": socket.gethostname()}
        return get_json_or_raise_if_error(
            requests.get(f"{self.url_base}queue/work", headers=self.header_sessione, params=body)
        )

    def update_work_state(self, work_id: str, state: str, details: Optional[dict[str, Any]] = None) -> Any:
        return get_json_or_raise_if_error(
            requests.put(
                f"{self.url_base}queue/works/{work_id}/state",
                headers=self.header_sessione,
                json={"changed_by": socket.gethostname(), "state": state, "details": details},
            )
        )

    def update_businessitem_state(
        self, businessitem_id: str, state: str, work_id: Optional[str], details: Optional[dict[str, Any]] = None
    ) -> Any:
        return get_json_or_raise_if_error(
            requests.put(
                f"{self.url_base}queue/business-items/{businessitem_id}/state",
                headers=self.header_sessione,
                json={"changed_by": socket.gethostname(), "state": state, "details": details, "work_id": work_id},
            )
        )
