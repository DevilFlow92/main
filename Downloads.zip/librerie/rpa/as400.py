import socket
import subprocess  # nosec
import time
from configparser import ConfigParser
from pathlib import Path
from typing import Optional, TypedDict, cast

import psutil
import pyautogui
import pyperclip

from pymol.auth import from_vault

from .rpa import ImageNotFoundError, wait_first_image, wait_image, wait_image_and_click

pyautogui.FailSafeException = False


class LoginError(Exception):
    pass


class Credentials(TypedDict):
    login_name: str
    password: str


class AS400_Compass:
    def __init__(self, exe: Path, session_conf_file: Path, credentials: Credentials):
        self.images = Path(__file__).absolute().parent.joinpath("as400", "images")
        self.exe = exe
        self.session_conf_file = session_conf_file
        self.credentials = credentials
        self._rename_session()

    def copy_page_data(self) -> str:
        """Copy the text from AS400 page."""
        time.sleep(0.5)
        wait_image_and_click(self.images, "Copia.PNG", seconds=3, conf=0.8)
        contenuto_page = pyperclip.paste()
        time.sleep(0.5)
        return cast(str, contenuto_page)

    def paste_data_to_page(self, text: str, x: Optional[int] = None, y: Optional[int] = None) -> None:
        """Past text, if x e y are given, move the cursor before pasting."""
        if x and y:
            pyautogui.click(x, y)
        pyperclip.copy(text)
        pyautogui.moveTo(100, 200)
        time.sleep(0.1)
        wait_image_and_click(self.images, "Incolla.PNG", 3, conf=0.8)

    def wait_for_text_in_page(self, text: str, seconds: int = 10) -> bool:
        """Wait untill text is found in page."""
        while seconds >= 0:
            if text in self.copy_page_data():
                return True
            seconds -= 1
        return False

    def save_screen_to_file(self, folder: Path, name: str) -> None:
        """Save screenshot to folder with name."""
        wait_image_and_click(self.images, "Savescreen.PNG", 6, conf=0.9)
        time.sleep(2)
        folder.mkdir(parents=True, exist_ok=True)
        time.sleep(2)
        pyperclip.copy(str(folder.joinpath(name)))
        time.sleep(0.5)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.5)
        pyautogui.hotkey("enter")
        time.sleep(3)

    def _rename_session(self) -> None:
        """Update the name of the session.

        Hostname must be in Vault /RPA/[env]/as400['Compass'].

        Json as follow: {"Compass: {"session_name": {"BTRB": "EXTMOL02"
                         , "CARB": "EXTMOL03", "DRRB": "EXTMOL04"}}}
        whith BTRB, CARB, DRRB the first four characters of the hostname.
        """
        config_file = ConfigParser()
        config_file.read(self.session_conf_file)
        as400_conf = from_vault("as400")["Compass"]

        session_name = socket.gethostname().replace(
            socket.gethostname()[0:4], as400_conf["session_name"][socket.gethostname()[0:4]]  # type: ignore
        )
        if config_file.get("5250", "WorkStationID") != session_name:
            config_file.set("5250", "WorkStationID", session_name)
        with open(self.session_conf_file, "w") as configfile:
            config_file.write(configfile)

    def open_emulator(self) -> None:
        """Open AS400 emulator (pcsws.exe)."""
        STARTF_USESHOWWINDOW = 1
        SW_MAXIMIZE = 3
        startupinfo = subprocess.STARTUPINFO()  # type: ignore
        startupinfo.dwFlags = STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = SW_MAXIMIZE
        subprocess.Popen([self.exe, self.session_conf_file], startupinfo=startupinfo)  # nosec
        if not wait_image(self.images, "FinestraMax.PNG", 10, conf=0.999):
            wait_image_and_click(self.images, "DaMassimizzare.PNG", seconds=7, clicks=1, conf=0.9)

    def login(self) -> None:
        check = wait_first_image(self.images, ["RichiediSempre.PNG", "PopUpLogin.PNG", "PopUpLogin1.PNG"], 15)
        if check == "RichiediSempre.PNG":
            wait_image_and_click(self.images, "RichiediSempre.PNG", seconds=5, clicks=1, conf=0.9)
            wait_image_and_click(self.images, "OkAlert.PNG", seconds=5, clicks=1, conf=0.9)
        else:
            if not wait_first_image(self.images, ["PopUpLogin.PNG", "PopUpLogin1.PNG"], 10, conf=0.999):
                raise LoginError("Errore Login - Errore apertura AS400")
        pyperclip.copy(self.credentials["login_name"])
        time.sleep(0.5)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.5)
        pyautogui.hotkey("tab")
        time.sleep(0.5)
        pyperclip.copy(self.credentials["password"])
        time.sleep(0.5)
        pyautogui.hotkey("ctrl", "v")
        wait_image_and_click(self.images, "OkParolaOrdine.PNG", seconds=5, clicks=1, conf=0.9)

        check = wait_first_image(
            self.images,
            ["SiDesideraFornireUnaDiversaParola.PNG", "PopupFornireIdDiverso.PNG", "RichiestaCambioPass.PNG"],
            10,
            conf=0.999,
        )
        if check == "SiDesideraFornireUnaDiversaParola.PNG":
            raise LoginError("Errore Login - Password Errata")
        elif check == "PopupFornireIdDiverso.PNG":
            check_2 = wait_first_image(self.images, ["Disabilitato.PNG", "NonEsiste.PNG"], 10, conf=0.999)
            if check_2 == "Disabilitato.PNG":
                raise LoginError("Errore Login - Utenza Disabilitata")
            elif check_2 == "NonEsiste.PNG":
                pyautogui.hotkey("enter")
                time.sleep(0.5)
                pyperclip.copy(self.credentials["login_name"])
                time.sleep(0.5)
                pyautogui.hotkey("ctrl", "v")
                time.sleep(0.5)
                pyautogui.hotkey("tab")
                pyperclip.copy(self.credentials["password"])
                time.sleep(0.5)
                pyautogui.hotkey("ctrl", "v")
                time.sleep(0.5)
                wait_image_and_click(self.images, "OkParolaOrdine.PNG", seconds=5, clicks=1, conf=0.9)
        elif check == "RichiestaCambioPass.PNG":
            raise LoginError("Errore Login - Richiesta Cambio Password")
        time.sleep(0.5)
        if "Utente" not in self.copy_page_data():
            raise LoginError("Errore Login - ricerca schermate AS400")
        self.paste_data_to_page(self.credentials["login_name"])
        pyautogui.hotkey("tab")
        time.sleep(0.5)
        self.paste_data_to_page(self.credentials["password"])
        time.sleep(0.5)
        pyautogui.hotkey("enter")

    def update_password(self, new_password: str) -> None:
        wait_image_and_click(self.images, "Si.PNG", seconds=5, clicks=1, conf=0.9)
        wait_image(self.images, "SchermataCambioPass.PNG", 5, conf=0.999)
        wait_image_and_click(self.images, "BoxInsertOldPass.PNG", seconds=5, clicks=1, conf=0.9)
        time.sleep(0.5)
        pyperclip.copy(self.credentials["password"])
        time.sleep(0.5)
        pyautogui.hotkey("ctrl", "v")
        wait_image_and_click(self.images, "BoxInsertNewPass.PNG", seconds=5, clicks=1, conf=0.9)
        time.sleep(0.5)
        pyperclip.copy(new_password)
        time.sleep(0.5)
        pyautogui.hotkey("ctrl", "v")
        wait_image_and_click(self.images, "BoxInsertConfermaPass.PNG", seconds=5, clicks=1, conf=0.9)
        time.sleep(0.5)
        pyperclip.copy(new_password)
        time.sleep(0.5)
        pyautogui.hotkey("ctrl", "v")
        wait_image_and_click(self.images, "OkConfermaNewPass.PNG", seconds=5, clicks=1, conf=0.9)
        if not wait_image(self.images, "ModificaPassOK.PNG", 5, conf=0.999):
            raise Exception("Password non cambiata correttamente")
        self.credentials = Credentials(login_name=self.credentials["login_name"], password=new_password)

    def go_to_gestione_prestiti(self) -> None:
        self.wait_for_text_in_page("Scelta", 5)
        self.paste_data_to_page("90")
        time.sleep(0.5)
        pyautogui.hotkey("enter")
        time.sleep(0.5)
        if "premere Invio" in self.copy_page_data():
            pyautogui.hotkey("enter")
        if self.wait_for_text_in_page("Utente", 5):
            self.paste_data_to_page(self.credentials["login_name"])
            pyautogui.hotkey("tab")
            time.sleep(0.5)
            self.paste_data_to_page(self.credentials["password"])
            time.sleep(0.5)
            pyautogui.hotkey("enter")
        if "Premere Invio per continuare" in self.copy_page_data():
            pyautogui.hotkey("enter")
            time.sleep(0.5)
        if "Codici EER/AAI abbinati a username400" in self.copy_page_data():
            pyautogui.hotkey("enter")
            time.sleep(0.5)
        if "Premere Invio per continuare" in self.copy_page_data():
            pyautogui.hotkey("enter")
            time.sleep(0.5)
        if "Gestione prestiti" not in self.copy_page_data():
            raise LoginError("Errore Login - Non sono nel menù Gestione prestiti")

    def logout_and_exit(self) -> None:
        time.sleep(2)
        for _ in range(3):
            pyautogui.hotkey("F7")
            time.sleep(0.5)
        try:
            wait_image_and_click(self.images, "Comunicazioni.PNG", 3, conf=0.9)
            wait_image_and_click(self.images, "Disconnetti.PNG", 3, conf=0.9)
            wait_image_and_click(self.images, "X_CloseWindow.PNG", 3, conf=0.9)
        except ImageNotFoundError:
            pass
        time.sleep(2)
        processes = [
            "pcsws.exe",
            "pcscm.exe",
            "Receiver.exe",
            "Concentr.exe",
            "wfcrun32.exe",
            "wfica32.exe",
            "acslaunch_win-64.exe",
            "concentr.exe",
            "msedge.exe",
        ]
        for pid in psutil.pids():
            try:
                p = psutil.Process(pid)
                if p.name() in processes:
                    p.terminate()
            except psutil.NoSuchProcess:
                pass
