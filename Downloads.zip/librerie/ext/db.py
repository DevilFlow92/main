"""Metodi di connessione al DB."""

from collections.abc import Iterable
from typing import Any

import pyodbc

from pymol.ext.auth import from_vault


def create_connection(label: str) -> pyodbc.Cursor:
    auth_params = from_vault(label)
    db_params = (
        f"DRIVER={auth_params['driver']};SERVER={auth_params['server']};"
        f"DATABASE={auth_params['database']};{auth_params['options']}"
    )
    dbconn = pyodbc.connect(db_params, autocommit=False)
    return dbconn


def insert(insert_command: str, values: Iterable[Any], crs: pyodbc.Cursor) -> Any:
    """Esegue :insert_command: e ritorna l'identity value."""
    if insert_command.lower().startswith("insert"):
        raise ValueError("Il comando passato deve essere una INSERT.")
    if ";" in insert_command:
        raise ValueError("Il comando passato deve contenere una sola istruzione.")

    crs.execute(insert_command.rstrip(";") + "; SELECT scope_identity()", *values)
    crs.nextset()
    id = crs.fetchone()[0]

    return id
