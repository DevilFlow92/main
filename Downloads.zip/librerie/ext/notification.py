import os
import smtplib
import ssl
from email.message import EmailMessage
from typing import Optional, TypedDict

from pymol import logger
from pymol.logger import log

ConfDict = TypedDict("ConfDict", {"username": Optional[str], "password": Optional[str], "server": str})
MessageDict = TypedDict(
    "MessageDict", {"subject": str, "msg": str, "from_addr": str, "to_addrs": str, "cc": str | None, "bcc": str | None}
)


def send_mail(
    conf: ConfDict,
    message: MessageDict,
) -> None:
    tenancy_ = os.getenv("TENANCY")
    subject_prefix = f"[{tenancy_}] " if tenancy_ else ""

    email = EmailMessage()
    email["Subject"] = f"{subject_prefix} {message['subject']}"
    email["From"] = message["from_addr"]
    email["To"] = message["to_addrs"]
    if cc := message.get("cc"):
        email["Cc"] = cc

    if bcc := message.get("bcc"):
        email["Bcc"] = bcc

    email.add_alternative(message["msg"], subtype="html")

    with smtplib.SMTP(conf["server"]) as server:
        try:
            if "username" in conf:
                server.ehlo()
                server.starttls(context=ssl.create_default_context())
                server.login(conf["username"], conf["password"])  # type: ignore
            server.send_message(email)
        except Exception as ex:
            log.message(f"Impossibile inviare mail: {ex}", logger.LogLevel.ERROR)
        finally:
            server.quit()
