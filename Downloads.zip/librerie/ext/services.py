import datetime
from typing import Any, Union

import pyodbc

from pymol.ext.auth import from_vault, qtask_token
from pymol.ext.db import create_connection
from pymol.ext.ftp import ABCFtp, ftp_conn


def service(
    vault_label: str,
) -> Union[
    dict[str, Union[pyodbc.Connection, pyodbc.Cursor]], dict[str, Union[dict[str, str], datetime.datetime, str]], ABCFtp
]:
    auth = from_vault(vault_label)
    if "service_type" not in auth:
        raise ValueError(f"La configurazione {vault_label} non è un servizio.")

    if auth["service_type"] == "db":
        dbconn = create_connection(vault_label)
        cursor = dbconn.cursor()
        return {"conn": dbconn, "cursor": cursor}
    if auth["service_type"] == "api":
        api_auth = from_vault(vault_label)
        headers, expires = qtask_token(api_auth)
        headers["Content-Type"] = "application/json"
        return {"headers": headers, "expires": expires, "host": api_auth["host"]}
    if auth["service_type"] == "share":
        return ftp_conn(from_vault(vault_label))

    raise ValueError(f"Service type {auth['service_type']} non è supportato.")


def close_service(vault_label: str, service_handler: Any) -> None:
    auth = from_vault(vault_label)
    if "service_type" not in auth:
        raise ValueError(f"La configurazione {vault_label} non è un servizio.")

    if auth["service_type"] == "db":
        service_handler["conn"].close()
    if auth["service_type"] == "share":
        service_handler.close_connection()
