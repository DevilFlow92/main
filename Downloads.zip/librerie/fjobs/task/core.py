from datetime import date
from decimal import Decimal as D
from typing import Any, Optional, Union

import pyodbc

from pymol.finance.schema.core import (
    CambioATermine,
    CommonParams,
    Giroconto,
    InvalidCambioATermine,
    InvalidCommonParams,
    InvalidGiroconto,
    InvalidMovimento,
    InvalidMovimento940,
    InvalidMovimentoCanc,
    InvalidMovimentoCash,
    InvalidMovimentoRitenute,
    InvalidMovimentoTitolo,
    InvalidPosizioneQtask,
    InvalidSaldoCash,
    InvalidSaldoCorner,
    InvalidSaldoMulti940,
    InvalidSaldoQTask,
    InvalidSaldoSingolo940,
    InvalidSaldoSingolo941,
    InvalidSaldoTitolo,
    InvalidValoriMovimento,
    Movimento,
    Movimento940,
    MovimentoCanc,
    MovimentoCash,
    MovimentoRitenute,
    MovimentoTitolo,
    PosizioneQtask,
    SaldoCash,
    SaldoCorner,
    SaldoMulti940,
    SaldoQTask,
    SaldoSingolo940,
    SaldoSingolo941,
    SaldoTitolo,
    ValoriMovimento,
)
from pymol.types.exceptions import BusinessValueError
from pymol.types.mappings.gsa import CodTipoMovimentoContoBancario, IdOperazioneContoBancario

FinanceMsgs = Union[
    CambioATermine,
    InvalidCambioATermine,
    Giroconto,
    InvalidGiroconto,
    Movimento,
    InvalidMovimento,
    MovimentoCanc,
    InvalidMovimentoCanc,
    MovimentoCash,
    InvalidMovimentoCash,
    MovimentoRitenute,
    InvalidMovimentoRitenute,
    MovimentoTitolo,
    InvalidMovimentoTitolo,
    SaldoCash,
    InvalidSaldoCash,
    SaldoQTask,
    InvalidSaldoQTask,
    SaldoTitolo,
    InvalidSaldoTitolo,
    CommonParams,
    InvalidCommonParams,
    PosizioneQtask,
    InvalidPosizioneQtask,
    SaldoCorner,
    InvalidSaldoCorner,
    SaldoSingolo940,
    InvalidSaldoSingolo940,
    SaldoMulti940,
    InvalidSaldoMulti940,
    SaldoSingolo941,
    InvalidSaldoSingolo941,
    Movimento940,
    InvalidMovimento940,
]


class AbstractTranslator:
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor

    def translate(self) -> FinanceMsgs:
        data, errors = {}, {}
        valid = True
        for k, fun in self.MX.items():  # type: ignore
            try:
                data[k] = fun()
                if hasattr(data[k], "errors"):
                    valid = False
                    errors[k] = data[k].errors
            except NotImplementedError as e:
                raise e
            except Exception as e:
                valid = False
                data[k] = None
                if isinstance(e, BusinessValueError):
                    desc = str(e)
                else:
                    desc = f"Impossibile valorizzare il campo, ({e.__class__.__name__} : {str(e)})"

                errors[k] = (
                    [
                        desc,
                    ]
                    if k not in errors
                    else errors[k]
                    + [
                        desc,
                    ]
                )

        if valid:
            return self.valid_class(**data)  # type: ignore
        else:
            data["errors"] = errors
            data["row"] = self.raw_msg
            return self.invalid_class(**data)  # type: ignore


class AbstractMsgFactory:
    """Factory per l'individuazione del tipo di messaggio."""

    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor

    def translate(self, oldmov: bool = True) -> FinanceMsgs:
        trs = self.get_translator(oldmov)(self.raw_msg, self.ext_params, self.cursor)
        return trs.translate()

    def get_translator(self, oldmov: bool) -> type[AbstractTranslator]:
        """Capisce il tipo di messaggio in ingresso e restituisce la classe Translator opportuna."""
        raise NotImplementedError()


class TranslatorValoriMovimento(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = ValoriMovimento
        self.invalid_class = InvalidValoriMovimento
        self.MX = {
            "codTipoMovimentoContoBancario": self.get_codTipoMovimentoContoBancario,
            "dataOperazione": self.get_dataOperazione,
            "idOperazioneContoBancario": self.get_idOperazioneContoBancario,
            "flagIncompleto": self.get_flagIncompleto,
            "flagPresenzaContabile": self.get_flagPresenzaContabile,
            "flagImportIncompleto": self.get_flagImportIncompleto,
            "idTitoloFinanziario": self.get_idTitoloFinanziario,
            "prezzoUnitario": self.get_prezzoUnitario,
            "quantita": self.get_quantita,
            "quantitaOriginale": self.get_quantitaOriginale,
            "dataATermine": self.get_dataATermine,
            "dataInizioTrade": self.get_dataInizioTrade,
            "dataFineTrade": self.get_dataFineTrade,
        }

    def get_codTipoMovimentoContoBancario(self) -> CodTipoMovimentoContoBancario:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_dataOperazione(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_idOperazioneContoBancario(self) -> Optional[IdOperazioneContoBancario]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_flagIncompleto(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_flagPresenzaContabile(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_flagImportIncompleto(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_idTitoloFinanziario(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_prezzoUnitario(self) -> Optional[float]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_quantita(self) -> Optional[float]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_quantitaOriginale(self) -> Optional[float]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_dataATermine(self) -> Optional[date]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_dataInizioTrade(self) -> Optional[date]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_dataFineTrade(self) -> Optional[date]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorCommonParams(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = CommonParams
        self.invalid_class = InvalidCommonParams
        self.MX = {
            "cod_banca": self.get_cod_banca,
            "cod_cliente": self.get_cod_cliente,
            "cod_tipo_incarico_master": self.get_cod_tipo_incarico_master,
            "cod_tipo_incarico_slave": self.get_cod_tipo_incarico_slave,
            "cod_area": self.get_cod_area,
            "cod_tipo_workflow": self.get_cod_tipo_workflow,
            "cod_numero_conto": self.get_cod_numero_conto,
            "cod_stato_workflow_incarico": self.get_cod_stato_workflow_incarico,
            "cod_consolidanti": self.get_cod_consolidanti,
            "cod_sistema": self.get_cod_sistema,
            "suffix_name_clienti": self.get_suffix_name_clienti,
            "gate": self.get_gate,
        }

    def get_cod_banca(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_cliente(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_tipo_incarico_master(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_tipo_incarico_slave(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_area(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_tipo_workflow(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_numero_conto(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_stato_workflow_incarico(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_consolidanti(self) -> Optional[list[int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_sistema(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_suffix_name_clienti(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_gate(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorMovimento(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = Movimento
        self.invalid_class = InvalidMovimento
        self.MX = {
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "chiave_cliente": self.get_chiave_cliente,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "data_valuta": self.get_data_valuta,
            "importi": self.get_importi,
            "importiLordi": self.get_importiLordi,
            "commissioni": self.get_commissioni,
            "testo_nota": self.get_testo_nota,
            "valori_movimento": self.get_valori_movimento,
            "ritenute": self.get_ritenute,
            "ratei": self.get_ratei,
            "euroritenute": self.get_euroritenute,
            "common_params": self.get_common_params,
            "saldo_iniziale": self.get_saldo_iniziale,
            "linked_mov": self.get_linked_mov,
            "chiaveEsterna": self.get_chiaveEsterna,
            "anno": self.get_anno,
            "divisa": self.get_divisa,
            "isin": self.get_isin,
        }

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importi(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importiLordi(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_commissioni(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_testo_nota(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_valori_movimento(self) -> Union[ValoriMovimento, InvalidValoriMovimento]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ritenute(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ratei(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_euroritenute(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_saldo_iniziale(self) -> Optional[dict[str, Any]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_linked_mov(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiaveEsterna(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_anno(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_divisa(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_isin(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorPosizioneQtask(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = PosizioneQtask
        self.invalid_class = InvalidPosizioneQtask
        self.MX = {
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "chiave_cliente": self.get_chiave_cliente,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "anno": self.get_anno,
            "common_params": self.get_common_params,
            "testo_nota": self.get_testo_nota,
            "idTitolo": self.get_idTitolo,
            "iban": self.get_iban,
        }

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_anno(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_testo_nota(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_idTitolo(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_iban(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorMovimentoCanc(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = MovimentoCanc
        self.invalid_class = InvalidMovimentoCanc
        self.MX = {
            "id": self.get_id,
            "id_cancel": self.get_id_cancel,
        }

    def get_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id_cancel(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorMovimentoCash(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = MovimentoCash
        self.invalid_class = InvalidMovimentoCash
        self.MX = {
            "id": self.get_id,
            "posizione_qtask": self.get_posizione_qtask,
            "data_valuta": self.get_data_valuta,
            "data_operazione": self.get_data_operazione,
            "id_operazione_conto_bancario": self.get_id_operazione_conto_bancario,
            "importo_lordo": self.get_importo_lordo,
            "importo": self.get_importo,
            "commissioni": self.get_commissioni,
            "euroritenute": self.get_euroritenute,
            "ratei": self.get_ratei,
            "ritenute": self.get_ritenute,
            "spese": self.get_spese,
            "cambio": self.get_cambio,
            "chiave_esterna": self.get_chiave_esterna,
            "is_rettifica": self.get_rettifica,
        }

    def get_rettifica(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_posizione_qtask(self) -> Union[PosizioneQtask, InvalidPosizioneQtask]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_operazione(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id_operazione_conto_bancario(self) -> IdOperazioneContoBancario:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo_lordo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_commissioni(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_euroritenute(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ratei(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ritenute(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_spese(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cambio(self) -> Optional[D]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiave_esterna(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorMovimentoTitolo(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = MovimentoTitolo
        self.invalid_class = InvalidMovimentoTitolo
        self.MX = {
            "id": self.get_id,
            "posizione_qtask": self.get_posizione_qtask,
            "data_valuta": self.get_data_valuta,
            "data_operazione": self.get_data_operazione,
            "id_operazione_conto_bancario": self.get_id_operazione_conto_bancario,
            "importo_lordo": self.get_importo_lordo,
            "importo": self.get_importo,
            "commissioni": self.get_commissioni,
            "euroritenute": self.get_euroritenute,
            "ratei": self.get_ratei,
            "ritenute": self.get_ritenute,
            "spese": self.get_spese,
            "cambio": self.get_cambio,
            "chiave_esterna": self.get_chiave_esterna,
            "codice_strumento": self.get_codice_strumento,
            "divisa": self.get_divisa,
            "quantita": self.get_quantita,
            "prezzo": self.get_prezzo,
            "is_rettifica": self.get_rettifica,
            "is_censito": self.get_censito,
            "cusip": self.get_cusip,
        }

    def get_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_posizione_qtask(self) -> Union[PosizioneQtask, InvalidPosizioneQtask]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_operazione(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id_operazione_conto_bancario(self) -> IdOperazioneContoBancario:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo_lordo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_commissioni(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_euroritenute(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ratei(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ritenute(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_spese(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cambio(self) -> Optional[D]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiave_esterna(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_codice_strumento(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_divisa(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_quantita(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_prezzo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_rettifica(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_censito(self) -> Optional[bool]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cusip(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorMovimentoRitenute(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = MovimentoRitenute
        self.invalid_class = InvalidMovimentoRitenute
        self.MX = {
            "id": self.get_id,
            "posizione_qtask": self.get_posizione_qtask,
            "data_valuta": self.get_data_valuta,
            "data_operazione": self.get_data_operazione,
            "id_operazione_conto_bancario": self.get_id_operazione_conto_bancario,
            "importo_lordo": self.get_importo_lordo,
            "importo": self.get_importo,
            "commissioni": self.get_commissioni,
            "euroritenute": self.get_euroritenute,
            "ratei": self.get_ratei,
            "ritenute": self.get_ritenute,
            "spese": self.get_spese,
            "cambio": self.get_cambio,
            "chiave_esterna": self.get_chiave_esterna,
            "isin": self.get_isin,
            "is_censito": self.get_censito,
            "is_rettifica": self.get_rettifica,
        }

    def get_rettifica(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_posizione_qtask(self) -> Union[PosizioneQtask, InvalidPosizioneQtask]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_operazione(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id_operazione_conto_bancario(self) -> IdOperazioneContoBancario:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo_lordo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_commissioni(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_euroritenute(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ratei(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ritenute(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_spese(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cambio(self) -> Optional[D]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiave_esterna(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_isin(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_censito(self) -> Optional[bool]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoQTask(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoQTask
        self.invalid_class = InvalidSaldoQTask
        self.MX = {
            "chiave_cliente": self.get_chiave_cliente,
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "qty": self.get_qty,
            "importi": self.get_importi,
            "data_valuta": self.get_data_valuta,
            "anno": self.get_anno,
            "is_metallo": self.get_is_metallo,
            "product_name": self.get_product_name,
            "common_params": self.get_common_params,
            "idtitolo": self.get_idtitolo,
            "prezzo": self.get_prezzo,
            "isin": self.get_isin,
            "borsa": self.get_borsa,
            "rateo": self.get_rateo,
        }

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_qty(self) -> float:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importi(self) -> list[tuple[float, int]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_anno(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_is_metallo(self) -> bool:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_product_name(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_idtitolo(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_prezzo(self) -> Optional[float]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_isin(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_borsa(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_rateo(self) -> Optional[float]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoCash(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoCash
        self.invalid_class = InvalidSaldoCash
        self.MX = {
            "id": self.get_id,
            "posizione_qtask": self.get_posizione_qtask,
            "data": self.get_date,
            "importo": self.get_importo,
            "importo_valuta": self.get_importo_valuta,
            "cambio": self.get_cambio,
        }

    def get_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_posizione_qtask(self) -> Union[PosizioneQtask, InvalidPosizioneQtask]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_date(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo_valuta(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cambio(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoTitolo(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoTitolo
        self.invalid_class = InvalidSaldoTitolo
        self.MX = {
            "id": self.get_id,
            "posizione_qtask": self.get_posizione_qtask,
            "data": self.get_date,
            "quantita": self.get_quantita,
            "prezzo": self.get_prezzo,
            "ratei": self.get_ratei,
            "importo": self.get_importo,
            "cambio": self.get_cambio,
            "codice_strumento": self.get_codice_strumento,
            "is_censito": self.get_censito,
            "cusip": self.get_cusip,
        }

    def get_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_posizione_qtask(self) -> Union[PosizioneQtask, InvalidPosizioneQtask]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_date(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_quantita(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_prezzo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_ratei(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cambio(self) -> D:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_codice_strumento(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_censito(self) -> bool:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cusip(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorGiroconto(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = Giroconto
        self.invalid_class = InvalidGiroconto
        self.MX = {"movimento_in": self.get_movimento_in, "movimento_out": self.get_movimento_out}

    def get_movimento_in(self) -> Union[MovimentoCash, InvalidMovimentoCash, None]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_movimento_out(self) -> Union[MovimentoCash, InvalidMovimentoCash, None]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorCambioATermine(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = CambioATermine
        self.invalid_class = InvalidCambioATermine
        self.MX = {
            "movimento_in": self.get_movimento_in,
            "movimento_out": self.get_movimento_out,
            "data_contratto": self.get_data_contratto,
        }

    def get_movimento_in(self) -> Union[MovimentoCash, InvalidMovimentoCash, None]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_movimento_out(self) -> Union[MovimentoCash, InvalidMovimentoCash, None]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_contratto(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")


# messaggi specifici di Corner


class TranslatorMovimento940(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = Movimento940
        self.invalid_class = InvalidMovimento940
        self.MX = {
            "data_valuta": self.get_data_valuta,
            "data_operazione": self.get_data_operazione,
            "precedente_saldo": self.get_precedente_saldo,
            "attuale_saldo": self.get_attuale_saldo,
            "operazioni_intercorse": self.get_operazioni_intercorse,
            "importo_operazione": self.get_importo_operazione,
            "common_params": self.get_common_params,
            "id_messaggio": self.get_id_messaggio,
        }

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_operazione(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_precedente_saldo(self) -> float:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_attuale_saldo(self) -> float:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_operazioni_intercorse(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo_operazione(self) -> float:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_id_messaggio(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoCorner(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoCorner
        self.invalid_class = InvalidSaldoCorner
        self.MX = {
            "chiave_cliente": self.get_chiave_cliente,
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "common_params": self.get_common_params,
        }

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoSingolo940(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoSingolo940
        self.invalid_class = InvalidSaldoSingolo940
        self.MX = {
            "chiave_cliente": self.get_chiave_cliente,
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "common_params": self.get_common_params,
            "movimenti": self.get_movimenti,
            "anno": self.get_anno,
            "testo_nota": self.get_testo_nota,
            "dataValuta": self.get_dataValuta,
            "saldo_iniziale": self.get_saldo_iniziale,
            "saldo_finale": self.get_saldo_finale,
            "chiaveEsterna": self.get_chiaveEsterna,
        }

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_movimenti(self) -> list[Union[Movimento940, InvalidMovimento940]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_anno(self) -> Optional[int]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_testo_nota(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_dataValuta(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_saldo_iniziale(self) -> Optional[dict[str, Any]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_saldo_finale(self) -> Optional[dict[str, Any]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_chiaveEsterna(self) -> Optional[str]:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoMulti940(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoMulti940
        self.invalid_class = InvalidSaldoMulti940
        self.MX = {
            "chiave_cliente": self.get_chiave_cliente,
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "common_params": self.get_common_params,
            "movimenti": self.get_movimenti,
            "meta_id": self.get_meta_id,
            "msg_id": self.get_msg_id,
        }

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_movimenti(self) -> list[Union[Movimento940, InvalidMovimento940]]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_meta_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_msg_id(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")


class TranslatorSaldoSingolo941(AbstractTranslator):
    def __init__(self, raw_msg: dict[str, Any], ext_params: dict[str, Any], cursor: pyodbc.Cursor) -> None:
        self.raw_msg = raw_msg
        self.ext_params = ext_params
        self.cursor = cursor
        self.valid_class = SaldoSingolo941
        self.invalid_class = InvalidSaldoSingolo941
        self.MX = {
            "chiave_cliente": self.get_chiave_cliente,
            "nome_relazione_bancaria": self.get_nome_relazione_bancaria,
            "nome_conto": self.get_nome_conto,
            "numero_conto": self.get_numero_conto,
            "cod_valuta": self.get_cod_valuta,
            "common_params": self.get_common_params,
            "is_metallo": self.get_is_metallo,
            "data_valuta": self.get_data_valuta,
            "importo": self.get_importo,
            "cod_bene": self.get_cod_bene,
            "data_operazione": self.get_data_operazione,
            "anno": self.get_anno,
            "note": self.get_note,
            "testo_nota": self.get_testo_nota,
            "qty": self.get_qty,
        }

    def get_chiave_cliente(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_relazione_bancaria(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_nome_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_numero_conto(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_valuta(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_common_params(self) -> Union[CommonParams, InvalidCommonParams]:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_is_metallo(self) -> bool:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_valuta(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_importo(self) -> float:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_cod_bene(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_data_operazione(self) -> date:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_anno(self) -> int:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_note(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_testo_nota(self) -> str:
        raise NotImplementedError(f"{self.__class__.__name__}")

    def get_qty(self) -> Optional[float]:
        raise NotImplementedError(f"{self.__class__.__name__}")
