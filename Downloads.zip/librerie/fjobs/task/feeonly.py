import abc
import json
import sys
import tempfile
import uuid
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import PosixPath
from typing import Any, Optional

import requests
from prefect import context
from pyodbc import Cursor, Row, connect

from pymol.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.finance.schema.core import ABSMsg, InvalidABSMsg, serialize
from pymol.finance.utils import get_msg_state
from pymol.jobs.core import Task
from pymol.jobs.evtl.load.feeds.tasks import ProcessDelivery
from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import AdditionalParams, DataRow, ExtParams, MessageState, TaskData

MAX_RETRIES = 2
RETRY_DELAY = timedelta(seconds=5)


@dataclass
class MsgState:
    id: int
    table: str


def _classify(
    d: dict[
        str,
        list[ABSMsg | InvalidABSMsg],
    ],
    ids: dict[str, list[MsgState]],
    msg: ABSMsg | InvalidABSMsg,
    msg_state: MsgState,
) -> None:
    k = msg.__class__.__name__
    if k in d:
        d[k].append(msg)
        ids[k].append(msg_state)
    else:
        d[k] = [
            msg,
        ]
        ids[k] = [
            msg_state,
        ]


def _send_fee(
    k: str,
    source_id: int,
    feed: str,
    msgs: list[DataRow],
    invalid_msgs: list[DataRow],
    on_date: date,
    logger: Any,
    cursor: Cursor,
    send_mock: Optional[str],
) -> int:
    status_code = 0
    base_url = from_vault(label="api_feeonly")["base_url"]

    if "Giroconto" in k or "CambioValuta" in k:
        global_id = (
            msgs[0]["movimento_in"]["meta_"]["call_global_id"]
            if msgs
            else invalid_msgs[0]["movimento_in"]["meta_"]["call_global_id"]
        )
    else:
        global_id = msgs[0]["meta_"]["call_global_id"] if msgs else invalid_msgs[0]["meta_"]["call_global_id"]

    MX = {
        "MovimentoCash": f"{base_url}/movimenti_cash",
        "MovimentoCanc": f"{base_url}/movimenti_canc",
        "MovimentoTitolo": f"{base_url}/movimenti_titoli",
        "CambioValuta": f"{base_url}/cambi_a_termine",
        "Giroconto": f"{base_url}/giroconti",
        "SaldoTitolo": f"{base_url}/saldi",
        "SaldoCash": f"{base_url}/saldi_cash",
    }

    headers = {"servizio": "gsa", "cliente": "444"}
    payload = {
        "id": global_id,
        "depositaria": feed,
        "source_id": source_id,
        "valid_rows": msgs,
        "invalid_rows": invalid_msgs,
    }

    # save info into table "send_to_external": valid msgs
    for msg in msgs:
        if "Giroconto" in k or "CambioValuta" in k:
            cursor.execute(
                """INSERT INTO pycc.send_to_external (provider, feed, call_global_id, call_single_id,
                msg, msg_type, source_table, source_id, source_table_2, source_id_2, ts, destination)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                feed,
                msg["movimento_in"]["meta_"]["row"]["feed"],
                global_id,
                msg["movimento_in"]["meta_"]["call_single_id"],
                json.dumps(msg, default=serialize).replace("'", ""),
                k,
                msg["movimento_in"]["meta_"]["row"]["source"].split(":")[0],
                msg["movimento_in"]["meta_"]["row"]["source"].split(":")[1],
                msg["movimento_out"]["meta_"]["row"]["source"].split(":")[0],
                msg["movimento_out"]["meta_"]["row"]["source"].split(":")[1],
                datetime.now(),
                "feeonly" if not send_mock else "mock",
            )
        else:
            cursor.execute(
                """INSERT INTO pycc.send_to_external (provider, feed, call_global_id, call_single_id,
                msg, msg_type, source_table, source_id, source_table_2, source_id_2, ts, destination)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                feed,
                msg["meta_"]["row"]["feed"],
                global_id,
                msg["meta_"]["call_single_id"],
                json.dumps(msg, default=serialize).replace("'", ""),
                k,
                msg["meta_"]["row"]["source"].split(":")[0],
                msg["meta_"]["row"]["source"].split(":")[1],
                None,
                None,
                datetime.now(),
                "feeonly" if not send_mock else "mock",
            )

    # save info into table "send_to_external": invalid msgs
    for msg in invalid_msgs:
        if "Giroconto" in k or "CambioValuta" in k:
            cursor.execute(
                """INSERT INTO pycc.send_to_external (provider, feed, call_global_id, call_single_id,
                msg, msg_type, source_table, source_id, source_table_2, source_id_2, ts, destination, motivo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                feed,
                msg["movimento_in"]["meta_"]["row"]["feed"],
                global_id,
                msg["movimento_in"]["meta_"]["call_single_id"],
                json.dumps(msg, default=serialize).replace("'", ""),
                f"Invalid{k}",
                msg["movimento_in"]["meta_"]["row"]["source"].split(":")[0],
                msg["movimento_in"]["meta_"]["row"]["source"].split(":")[1],
                msg["movimento_out"]["meta_"]["row"]["source"].split(":")[0] if msg["movimento_out"] else None,
                msg["movimento_out"]["meta_"]["row"]["source"].split(":")[1] if msg["movimento_out"] else None,
                datetime.now(),
                "feeonly" if not send_mock else "mock",
                json.dumps(msg["meta_"]["errors"], default=serialize).replace("'", ""),
            )
        else:
            cursor.execute(
                """INSERT INTO pycc.send_to_external (provider, feed, call_global_id, call_single_id,
                msg, msg_type, source_table, source_id, source_table_2, source_id_2, ts, destination, motivo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                feed,
                msg["meta_"]["row"]["feed"],
                global_id,
                msg["meta_"]["call_single_id"],
                json.dumps(msg, default=serialize).replace("'", ""),
                f"Invalid{k}",
                msg["meta_"]["row"]["source"].split(":")[0],
                msg["meta_"]["row"]["source"].split(":")[1],
                None,
                None,
                datetime.now(),
                "feeonly" if not send_mock else "mock",
                json.dumps(msg["meta_"]["errors"], default=serialize).replace("'", ""),
            )

        cursor.commit()
    if send_mock:
        with tempfile.NamedTemporaryFile() as fp:
            fp.write(str(json.dumps(payload, default=serialize)).encode("utf-8"))
            fp.flush()
            with ftp_conn(from_vault(send_mock)) as conn:
                endpoint = MX[k].split("/")[-1]
                conn.store(PosixPath(fp.name), PosixPath(feed, on_date.isoformat(), str(source_id), f"{endpoint}.json"))
    else:
        msg = {"id": uuid.uuid4().int, "depositaria": feed, "source_id": source_id, "tipologia": k}
        try:
            logger.info(f"Chiamata A Feeonly: {str(msg)}")
            resp = requests.post(MX[k], headers=headers, data=json.dumps(payload, default=serialize))
            logger.info(f"Callback Feeonly: {str(resp.content)}")
            status_code = resp.status_code
        except requests.exceptions.HTTPError:
            status_code = resp.status_code

    return status_code


def _send(
    k: str,
    source_id: int,
    feed: str,
    msgs: list[ABSMsg],
    invalid_msgs: list[InvalidABSMsg],
    on_date: date,
    logger: Any,
    cursor: Cursor,
    table: str,
    send_mock: Optional[str],
) -> int:
    status_code = 0

    base_url = from_vault(label="api_feeonly")["base_url"]
    MX = {
        "MovimentoCash": f"{base_url}/movimenti_cash",
        "MovimentoCanc": f"{base_url}/movimenti_canc",
        "MovimentoTitolo": f"{base_url}/movimenti_titoli",
        "CambioValuta": f"{base_url}/cambi_a_termine",
        "Giroconto": f"{base_url}/giroconti",
        "SaldoTitolo": f"{base_url}/saldi",
        "SaldoCash": f"{base_url}/saldi_cash",
    }

    headers = {"servizio": "gsa", "cliente": "444"}
    payload = {
        "id": uuid.uuid4().int,
        "depositaria": feed,
        "source_id": source_id,
        "valid_rows": [o.as_dict() for o in msgs],
        "invalid_rows": [o.as_dict() for o in invalid_msgs],
    }

    if send_mock:
        with tempfile.NamedTemporaryFile() as fp:
            fp.write(str(json.dumps(payload, default=serialize)).encode("utf-8"))
            fp.flush()
            with ftp_conn(from_vault(send_mock)) as conn:
                endpoint = MX[k].split("/")[-1]
                conn.store(PosixPath(fp.name), PosixPath(feed, on_date.isoformat(), str(source_id), f"{endpoint}.json"))
    else:
        msg = {"id": uuid.uuid4().int, "depositaria": feed, "source_id": source_id, "tipologia": k}
        try:
            logger.info(f"Chiamata A Feeonly: {str(msg)}")
            resp = requests.post(MX[k], headers=headers, data=json.dumps(payload, default=serialize))
            logger.info(f"Callback Feeonly: {str(resp.content)}")
            status_code = resp.status_code
        except requests.exceptions.HTTPError as err:
            ids = [a["id"] for a in msgs["valid_rows"]]  # type: ignore
            ids.extend([a["id"] for a in msgs["invalid_rows"]])  # type: ignore
            cursor.execute(f"UPDATE {table} SET msg_state='ERR' WHERE id in ({','.join(ids)})")
            raise BusinessValueError(err)

    return status_code


def _send_discarded_msgs(
    k: str,
    source_id: int,
    feed: str,
    msgs: list[dict[str, Any]],
    on_date: date,
    logger: Any,
    cursor: Cursor,
    send_mock: Optional[str],
) -> int:
    status_code = 0
    base_url = from_vault(label="api_feeonly")["base_url"]
    global_id = msgs[0]["meta_"]["call_global_id"]
    endpoint = f"{base_url}/elementi_scartati"
    headers = {"servizio": "gsa", "cliente": "444"}
    payload = {
        "id": global_id,
        "depositaria": feed,
        "source_id": source_id,
        "rows": [
            {
                "tipo": "saldo"
                if "saldi" in o["meta_"]["id"].lower()
                or (
                    o["meta_"]["provider"] == "ubs"
                    and (o["meta_"]["row"]["msg_type_ebics"] == "ZAH" or o["meta_"]["row"]["msg_type_ebics"] == "ZAQ")
                )
                else "movimento",
                "msg": o,
            }
            for o in msgs
        ],
    }

    # save info into table "send_to_external": discarded msgs
    for msg in msgs:
        cursor.execute(
            """INSERT INTO pycc.send_to_external (provider, feed, call_global_id, call_single_id,
            msg, msg_type, source_table, source_id, source_table_2, source_id_2, ts, destination, motivo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            feed,
            msg["meta_"]["row"]["feed"],
            global_id,
            msg["meta_"]["call_single_id"],
            json.dumps(msg, default=serialize).replace("'", ""),
            k,
            msg["meta_"]["row"]["source"].split(":")[0],
            msg["meta_"]["row"]["source"].split(":")[1],
            None,
            None,
            datetime.now(),
            "feeonly" if not send_mock else "mock",
            json.dumps(msg["meta_"]["errors"], default=serialize).replace("'", ""),
        )

    if send_mock:
        with tempfile.NamedTemporaryFile() as fp:
            fp.write(str(json.dumps(payload, default=serialize)).encode("utf-8"))
            fp.flush()
            with ftp_conn(from_vault(send_mock)) as conn:
                endpoint = endpoint.split("/")[-1]
                conn.store(PosixPath(fp.name), PosixPath(feed, on_date.isoformat(), str(source_id), f"{endpoint}.json"))
    else:
        msg = {
            "id": uuid.uuid4().int,
            "depositaria": feed,
            "source_id": source_id,
        }
        try:
            logger.info(f"Chiamata A Feeonly: {str(msg)}")
            resp = requests.post(endpoint, headers=headers, data=json.dumps(payload, default=serialize))
            logger.info(f"Callback Feeonly: {str(resp.content)}")
            status_code = resp.status_code
        except requests.exceptions.HTTPError:
            status_code = resp.status_code

    return status_code


def classify_by_meta(data: dict[str, list[DataRow]]) -> dict[str, dict[str, list[DataRow]]]:
    classified_msg_by_meta_id: dict[str, dict[str, list[DataRow]]] = {}

    for msg_type in data:
        for msg in data[msg_type]:
            meta_id = msg["meta_"]["row"]["meta_id"]

            if msg_type not in classified_msg_by_meta_id:
                classified_msg_by_meta_id[msg_type] = {}

            if meta_id not in classified_msg_by_meta_id[msg_type]:
                classified_msg_by_meta_id[msg_type][meta_id] = []

            classified_msg_by_meta_id[msg_type][meta_id].append(msg)

    return classified_msg_by_meta_id


class ProcessDeliveryTypesFeeonly(ProcessDelivery):
    def process(
        self,
        data: list[DataRow],
        invalid_data: list[DataRow],
        msg_type: str,
        meta_id: str,
        provider: str,
        logger: Any,
        on_date: str,
        send_mock: Optional[str] = None,
    ) -> dict[str, str]:
        return_status: dict[str, str] = {}
        _on_date = context.scheduled_start_time if on_date == "" else datetime.strptime(on_date, "%Y-%m-%d")
        if msg_type != "Scarti":
            status_code = _send_fee(
                k=msg_type,
                source_id=int(meta_id),
                feed=provider,
                msgs=data,
                invalid_msgs=invalid_data,
                on_date=_on_date,
                logger=logger,
                cursor=self.cursor,
                send_mock=send_mock,
            )
        else:
            status_code = _send_discarded_msgs(
                k=msg_type,
                source_id=int(meta_id),
                feed=provider,
                msgs=data,
                on_date=_on_date,
                logger=logger,
                cursor=self.cursor,
                send_mock=send_mock,
            )

        for msg in data:
            return_status[msg["meta_"]["id"]] = "PRC" if status_code == 200 else "ERR"

        for msg in invalid_data:
            return_status[msg["meta_"]["id"]] = "PRC" if status_code == 200 else "ERR"

        return return_status

    def run(  # type:ignore
        self,
        data: dict[str, list[DataRow]],
        additional_parameters: AdditionalParams,
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            bulk_results: TaskData = {"data": [], "errors": [], "meta": {}}
            self.open()
            classified_data = classify_by_meta(data)
            try:
                for msg_type in (
                    "MovimentoCanc",
                    "MovimentoCash",
                    "MovimentoTitolo",
                    "MovimentoRitenute",
                    "Giroconto",
                    "CambioValuta",
                    "SaldoCash",
                    "SaldoTitolo",
                    "Scarti",
                ):
                    if msg_type in classified_data.keys() or "Invalid" + msg_type in classified_data.keys():
                        meta_ids = (
                            set(classified_data[msg_type].keys()) if msg_type in classified_data.keys() else set()
                        ).union(
                            set(classified_data["Invalid" + msg_type].keys())
                            if "Invalid" + msg_type in classified_data.keys()
                            else set()
                        )
                        for meta_id in meta_ids:
                            output = self.process(
                                classified_data[msg_type][meta_id]
                                if msg_type in classified_data.keys() and meta_id in classified_data[msg_type].keys()
                                else [],
                                classified_data["Invalid" + msg_type][meta_id]
                                if "Invalid" + msg_type in classified_data.keys()
                                and meta_id in classified_data["Invalid" + msg_type].keys()
                                else [],
                                msg_type,
                                meta_id,
                                additional_parameters["provider"],  # type: ignore
                                self.log,
                                additional_parameters["on_date"],  # type: ignore
                                additional_parameters["send_mock"],  # type: ignore
                            )
                            for source_, state in output.items():
                                source, id_ = source_.split(":")
                                route = self.route
                                rs = self.dbconn.execute(
                                    f"""
                                SELECT routing_state FROM {source} WHERE id = ?
                                """,
                                    id_,
                                )
                                routing_state = json.loads(rs.fetchone()[0])
                                routing_state[route] = state
                                self.dbconn.execute(
                                    f"""
                                UPDATE {source} SET routing_state = ? WHERE id = ?
                                """,
                                    json.dumps(routing_state),
                                    id_,
                                )
                                self.dbconn.commit()

                                if any([v == "ERR" for v in routing_state.values()]):
                                    self.dbconn.execute(
                                        f"""
                                    UPDATE {source} SET msg_state = 'ERR' WHERE id = ?
                                    """,
                                        id_,
                                    )
                                    self.dbconn.commit()

                                if all([v == "PRC" or v == "SLN" for v in routing_state.values()]) and any(
                                    [v == "PRC" for v in routing_state.values()]
                                ):
                                    self.dbconn.execute(
                                        f"""
                                    UPDATE {source} SET msg_state = 'PRC' WHERE id = ?
                                    """,
                                        id_,
                                    )
                                    self.dbconn.commit()
                            bulk_results["data"].append(output)
                return bulk_results
            finally:
                self.close()


class ProcessFeeonly(Task):
    def __init__(
        self,
        db: str,
        provider: str,
        feed: str,
        tables: list[tuple[str, str]],
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.provider = provider
        self.feed = feed
        self.tables = tables
        self.db = db
        self.reports: dict[str, TaskData] = {}
        self.msgs: dict[str, list[ABSMsg]] = {}
        self.msgs_ids: dict[str, list[MsgState]] = {}
        self.discarded_msgs: dict[str, list[dict[str, Any]]] = {}
        self.discarded_msgs_ids: dict[str, list[MsgState]] = {}
        self.invalid_msgs: dict[str, list[InvalidABSMsg]] = {}
        self.invalid_msgs_ids: dict[str, list[MsgState]] = {}
        self.unreadable_msgs: list[tuple[dict[str, Any], str]] = []
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()
        self.cursor.execute("""SET NOCOUNT ON""")
        sys.path.append("/app/deployed_flows/")

    def close(self) -> None:
        self.cursor.execute("""SET NOCOUNT OFF""")
        self.dbconn.close()
        sys.path.remove("/app/deployed_flows/")

    def _wrapclassify(self, table: str, idcol: str, vals: Row, for_msg: str) -> None:
        try:
            if (
                get_msg_state(
                    cursor=self.cursor,
                    table=table,
                    table_column=idcol,
                    id=eval(f"vals.{idcol}"),
                ).strip()
                != "PRC"
            ):
                msg = self.translate(vals)
                if msg:
                    self.classify(msg, MsgState(table=table, id=getattr(vals, idcol)))
        except BusinessValueError as exc:
            mov_collegato = str(exc).split("messaggio collegato:")[1] if "messaggio collegato" in str(exc) else None
            self.handle_run_log(
                table=table,
                description=f"Errore messaggio {vals.msg_type}: {exc}",
                idcol=idcol,
                msg=vals,
                type_="warning",
            )
            if for_msg not in self.discarded_msgs:
                self.discarded_msgs[for_msg] = []
                self.discarded_msgs_ids[for_msg] = []
            columns = [column[0] for column in vals.cursor_description]
            self.discarded_msgs[for_msg].append(
                {
                    "msg": dict(zip(columns, vals)),
                    "error": {
                        "tipo": "saldo" if "saldo" in str(exc).lower() else "movimento",
                        "dettagli": str(exc),
                        "previous_msg": mov_collegato,
                    },
                }
            )
            self.discarded_msgs_ids[for_msg].append(MsgState(id=getattr(vals, idcol), table=table))
        except Exception as exc:
            self.handle_run_log(
                table=table,
                description=f"{exc.__class__} : {exc}",
                idcol=idcol,
                msg=vals,
                type_="error",
            )
            self.set_state(table, getattr(vals, idcol), MessageState.GaveError)
        else:
            self.dbconn.commit()

    def _call_feeonly(
        self,
        meta_id: int,
        _on_date: date,
        table: str,
        send_mock: str | None,
    ) -> int:
        prc_msgs = 0
        for k in (
            "MovimentoCanc",
            "MovimentoCash",
            "MovimentoTitolo",
            "MovimentoRitenute",
            "Giroconto",
            "CambioValuta",
            "SaldoCash",
            "SaldoTitolo",
        ):
            if k in self.msgs or "Invalid" + k in self.invalid_msgs:
                status_code = _send(
                    k,
                    meta_id,
                    f"{self.provider}:{self.feed}",
                    self.msgs[k] if k in self.msgs else [],
                    self.invalid_msgs["Invalid" + k] if "Invalid" + k in self.invalid_msgs else [],
                    _on_date,
                    self.logger,
                    self.cursor,
                    table,
                    send_mock,
                )
                if k in self.msgs_ids.keys():
                    for msg_state in self.msgs_ids[k]:
                        self.set_state(
                            msg_state.table,
                            msg_state.id,
                            MessageState.Processed if status_code == 200 else MessageState.GaveError,
                        )
                        prc_msgs += 1

                if "Invalid" + k in self.invalid_msgs_ids.keys():
                    for msg_state in self.invalid_msgs_ids["Invalid" + k]:
                        self.set_state(
                            msg_state.table,
                            msg_state.id,
                            MessageState.Processed if status_code == 200 else MessageState.GaveError,
                        )
                        prc_msgs += 1

        return prc_msgs

    def handle_run_log(
        self, table: str, description: str, idcol: Optional[str] = None, msg: Optional[Any] = None, type_: str = "info"
    ) -> None:
        if msg and idcol:
            source_id = getattr(msg, idcol)
            getattr(self.logger, type_)(f"{description}. Processando il messaggio : {table},{idcol},{source_id}")
        else:
            source_id = None
            getattr(self.logger, type_)(f"{description}. Processando la tabella : {table}")

        self.run_logs["data"].append(
            {
                "type": type_,
                "message": description,
                "source": table + (f".{idcol}.{source_id}" if source_id else ""),
            }
        )

    def run(  # type: ignore
        self,
        on_date: str,
        msg_types: str,
        ext_params: ExtParams,
        wait_for: TaskData | list[DataRow] | DataRow | None = None,
        send_mock: str | None = None,
    ) -> dict[str, TaskData]:
        self.ext_params = ext_params
        self.msgs = {}
        self.msgs_ids = {}
        self.invalid_msgs = {}
        self.invalid_msgs_ids = {}
        self.discarded_msgs = {}
        self.discarded_msgs_ids = {}
        self.run_logs: TaskData = {
            "data": [],
            "errors": [],
            "meta": {"on_date": on_date if on_date else "all", "msg_type": msg_types if msg_types else "all"},
        }
        with self.log.start_action(self.name), self.log.timed(self.name):
            _on_date = context.scheduled_start_time if on_date == "" else datetime.strptime(on_date, "%Y-%m-%d")
            for_msgs = (
                [
                    "",
                ]
                if msg_types == ""
                else [m.strip() for m in msg_types.split(",")]
            )

            try:
                self.open()
                total_processed_msgs, total_count = 0, 0
                for table, idcol in self.tables:
                    for for_msg in for_msgs:
                        processed_msgs, count = 0, 0
                        rows = self.get_messages(table, _on_date, for_msg)
                        for meta_id in rows.keys():
                            self.msgs = {}
                            self.msgs_ids = {}
                            self.invalid_msgs = {}
                            self.invalid_msgs_ids = {}
                            self.discarded_msgs = {}
                            for count, vals in enumerate(rows[meta_id], 1):
                                self._wrapclassify(table, idcol, vals, for_msg)
                            self.add_error_messages(_on_date, for_msg)
                            total_processed = self._call_feeonly(meta_id, _on_date, table, send_mock)

                            total_processed_msgs += total_processed
                            processed_msgs += total_processed

                            for k in self.discarded_msgs.keys():
                                status_code = _send_discarded_msgs(
                                    k,
                                    meta_id,
                                    f"{self.provider}:{self.feed}",
                                    self.discarded_msgs[k],
                                    _on_date,
                                    self.logger,
                                    self.cursor,
                                    send_mock,
                                )
                                prc_msgs = 0
                                for msg_state in self.discarded_msgs_ids[k]:
                                    self.set_state(
                                        msg_state.table,
                                        msg_state.id,
                                        MessageState.Processed if status_code == 200 else MessageState.GaveError,
                                    )
                                    prc_msgs += 1
                                processed_msgs += prc_msgs
                                total_processed_msgs += prc_msgs

                        self.logger.info(f"Processati {processed_msgs} messaggi di tipo {for_msg} su {count}")
                        total_count += count

                self.logger.info(f"Processati {total_processed_msgs} messaggi in totale su {total_count}")
            finally:
                self.close()

        self.reports.update({"run_logs": self.run_logs})
        return self.reports

    def get_messages(self, table: str, on_date: date, msg_type: Optional[str]) -> dict[int, list[Any]]:
        if msg_type:
            msg_filter = f"AND msg_type = '{msg_type}'"
        else:
            msg_filter = ""

        msg_destination_filter = f'AND (routing_state LIKE \'%"fee": "{MessageState.Unprocessed.value}"%\' or routing_state LIKE \'%"fee": "{MessageState.GaveError.value}"%\')'  # noqa

        self.cursor.execute(
            f"""SELECT {table}.* FROM
            {table} JOIN pycc.E_Meta ON meta_id = pycc.E_Meta.id
            WHERE {table}.msg_state IN
            ('{MessageState.Unprocessed.value}', '{MessageState.GaveError.value}') AND
            pycc.E_Meta.file_date = ? {msg_filter} {msg_destination_filter}
            ORDER BY pycc.E_Meta.file_time, pycc.E_Meta.ingest_ts ASC""",
            on_date,
        )
        rows = self.cursor.fetchall()

        output_rows: dict[int, list[Any]] = {}
        for row in rows:
            if row.meta_id not in output_rows:
                output_rows[row.meta_id] = []
            output_rows[row.meta_id].append(row)

        return output_rows

    def add_error_messages(self, on_date: date, msg_type: str) -> list[dict[str, Any]]:
        """Recupera i messaggi marcati invalidi già nella fase di ingest."""
        # todo: fattibile con codice generico qui? dovrebbe capirli dai dati del flusso
        return []

    @abc.abstractmethod
    def translate(self, msg: dict[str, Any]) -> ABSMsg:
        """Torna un messaggio qtask valido o un messaggio qtask parziale col motivo della non validità."""
        pass

    def classify(self, msg: ABSMsg | InvalidABSMsg, msg_state: MsgState) -> None:
        if msg.is_valid:
            _classify(self.msgs, self.msgs_ids, msg, msg_state)
        else:
            _classify(self.invalid_msgs, self.invalid_msgs_ids, msg, msg_state)  # type: ignore

    def set_state(self, table: str, msg_id: int, msg_state: MessageState) -> None:
        self.cursor.execute(f"""UPDATE {table} set msg_state = '{msg_state.value}' WHERE id = ?""", msg_id)
        self.dbconn.commit()
