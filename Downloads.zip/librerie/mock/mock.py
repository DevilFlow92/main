from collections import namedtuple
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional, Union

try:
    from sqlalchemy.engine import Connection, Transaction
    from sqlalchemy.orm.exc import MultipleResultsFound
except:  # noqa  # nosec , I don't want to really have alchemy as a dependency, will be in the project
    Connection = object
    Transaction = object

DBType = Union[None, str, int, float, Decimal, date, datetime, bool]
QuerySetRow = tuple[DBType, ...]
FixtureRow = dict[str, DBType] | QuerySetRow
Fixture = dict[str, list[FixtureRow] | None]
ResultSet = tuple[tuple[DBType, ...], ...]


def _dict_to_nt(mocked_rows: list[FixtureRow] | None) -> ResultSet:
    if mocked_rows is None:
        return ()

    if isinstance(mocked_rows[0], tuple):
        return tuple(mocked_rows)  # type: ignore

    nt = namedtuple("nt", list(mocked_rows[0].keys()))  # type: ignore
    return tuple([nt(*d.values()) for d in mocked_rows])  # type: ignore


def _dict_to_description(mocked_rows: list[FixtureRow] | None) -> Optional[list[tuple[str, ...]]]:
    if mocked_rows is None:
        return None

    if isinstance(mocked_rows[0], tuple):
        return None

    return [(k,) for k in mocked_rows[0].keys()]


class MockedCursor:
    def __init__(self, fixture: Fixture) -> None:
        self.fixture = fixture
        self.rows: ResultSet = ((),)
        self.passed_args: dict[str, tuple[Any, ...]] = {}
        self.select_args: dict[str, tuple[Any, ...]] = {}
        self.description: Optional[list[tuple[str, ...]]] = None

    def execute(self, query: str, *args: DBType) -> None:
        clean_query = " ".join(query.replace("\n", "").split())
        args_key = clean_query
        if (
            clean_query.startswith("INSERT")
            or clean_query.startswith("UPDATE")
            or clean_query.startswith("DECLARE")
            or clean_query.startswith("DELETE")
            or clean_query.startswith("IF NOT EXISTS")
        ):  # save passed args in order to call asserts on them later
            while args_key in self.passed_args:
                args_key = "_" + args_key
            self.passed_args[args_key] = args

        if clean_query.startswith("SELECT") or (clean_query.startswith("INSERT") and "OUTPUT" in clean_query):
            self.rows = _dict_to_nt(self.fixture[clean_query])
            self.description = _dict_to_description(self.fixture[clean_query])
            while args_key in self.select_args:
                args_key = "_" + args_key
            self.select_args[args_key] = args

            new_fixture = {}
            for key, value in self.fixture.items():
                if key.endswith(clean_query):
                    new_fixture[key[0].replace("_", "") + key[1:]] = value
                else:
                    new_fixture[key] = value
            self.fixture = new_fixture

    def fetchone(self) -> Optional[QuerySetRow]:
        if len(self.rows) > 0:
            return self.rows[0]
        return None

    def fetchall(self) -> tuple[QuerySetRow, ...]:
        return self.rows

    def commit(self) -> None:
        pass

    def rollback(self) -> None:
        pass

    def close(self) -> None:
        pass


class MockedODBCCursor(MockedCursor):
    pass


class MockedAlchemyQuerySet:
    class AQSIterator:  # noqa ,  D106
        def __init__(self, qs: "MockedAlchemyQuerySet"):
            self._qs = qs
            self._index = 0

        def __next__(self) -> QuerySetRow:
            if self._index < len(self._qs._rows):
                result = self._qs._rows[self._index]
                self._index += 1
                return result
            raise StopIteration

    def __init__(self, rows: ResultSet):
        self._rows = rows

    def __iter__(self) -> AQSIterator:
        return MockedAlchemyQuerySet.AQSIterator(self)

    def __getitem__(self, key: int) -> tuple[DBType, ...]:
        return self._rows[key]

    def all(self) -> ResultSet:
        return self._rows

    def fetchall(self) -> ResultSet:
        return self._rows

    def one_or_none(self) -> Optional[tuple[DBType, ...]]:
        """Return at most one result or raise an exception.

        Returns None if the query selects no rows. Raises sqlalchemy.orm.exc.MultipleResultsFound if multiple object
        identities are returned, or if multiple rows are returned for a query that returns only scalar values
        as opposed to full identity-mapped entities.
        """
        if len(self._rows) > 1:
            raise MultipleResultsFound()
        if len(self._rows) == 0:
            return None
        return self._rows[0]

    def scalar(self) -> Optional[DBType]:
        """Return the first element of the first result or None if no rows present.

        If multiple rows are returned, raises MultipleResultsFound.
        """
        if len(self._rows) > 1:
            raise MultipleResultsFound()
        if len(self._rows) == 0:
            return None
        return self._rows[0][0]

    def scalar_one_or_none(self) -> Optional[DBType]:
        if len(self._rows) > 1:
            raise MultipleResultsFound()
        if len(self._rows) == 0:
            return None
        return self._rows[0][0]


class MockedAlchemyTransaction(Transaction):
    def __init__(self, connection: "MockedAlchemyConnection") -> None:
        self.is_active = True
        self.connection = connection

    def __enter__(self) -> "MockedAlchemyTransaction":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass

    def commit(self) -> None:
        self.is_active = False
        self.connection.transaction_state = "committ"

    def rollback(self) -> None:
        self.is_active = False
        self.connection.transaction_state = "rollback"


class MockedAlchemyConnection(Connection):
    def __init__(self, fixture: Fixture) -> None:
        self.qs: MockedAlchemyQuerySet
        self.fixture = fixture
        self.passed_args: dict[str, tuple[Any, ...]] = {}
        self.select_args: dict[str, tuple[Any, ...]] = {}
        self.description: Optional[list[tuple[str, ...]]] = None
        self.transaction: MockedAlchemyTransaction | None = None
        self.transaction_state: str | None = None

    def __enter__(self) -> "MockedAlchemyConnection":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass

    def begin(self) -> MockedAlchemyTransaction:
        self.transaction_state = "begin"
        self.transaction = MockedAlchemyTransaction(self)
        return self.transaction

    def get_transaction(self) -> MockedAlchemyTransaction | None:
        return self.transaction

    def execute(self, query: str, *args: DBType) -> Optional[MockedAlchemyQuerySet]:
        clean_query = " ".join(query.replace("\n", "").split())
        if (
            clean_query.startswith("INSERT")
            or clean_query.startswith("UPDATE")
            or clean_query.startswith("DECLARE")
            or clean_query.startswith("DELETE")
            or clean_query.startswith("IF NOT EXISTS")
        ):
            args_key = clean_query
            while args_key in self.passed_args:
                args_key = "_" + args_key
            self.passed_args[args_key] = args

            return None

        elif (
            clean_query.startswith("SELECT")
            or (clean_query.startswith("INSERT") and "OUTPUT" in clean_query)
            or clean_query.startswith("vd.")
        ):
            self.qs = MockedAlchemyQuerySet(_dict_to_nt(self.fixture[clean_query]))
            self.description = _dict_to_description(self.fixture[clean_query])
            args_key = clean_query
            while args_key in self.select_args:
                args_key = "_" + args_key
            self.select_args[args_key] = args

            new_fixture = {}
            for key, value in self.fixture.items():
                if key.endswith(clean_query):
                    new_fixture[key[0].replace("_", "") + key[1:]] = value
                else:
                    new_fixture[key] = value
            self.fixture = new_fixture

            return self.qs

        else:
            raise NotImplementedError(f"Query {query} is not supported")


class MockedRow:
    def __init__(self, payload: dict[str, Any]):
        for key in payload.keys():
            setattr(self, key, payload[key])

    def __getattr__(self, key: str) -> Any:
        if key == "cursor_description":
            return [(key, "") for key in self.__dict__.keys()]
        return self.__dict__[key]
