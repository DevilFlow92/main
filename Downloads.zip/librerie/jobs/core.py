import json
import os
from dataclasses import dataclass
from datetime import timedelta
from functools import partial
from pathlib import Path
from typing import Any, Callable, Optional

import prefect
from prefect import Flow as PrefectFlow
from prefect import Task as PrefectTask
from slugify import slugify

from pymol import logger
from pymol.jobs.evtl.utils import apprise_alert, env_params
from pymol.logger import LogLevel
from pymol.logger import log as _log
from pymol.validation import Coerce

MAX_RETRIES = 2
RETRY_DELAY = timedelta(seconds=4)


def _get_results_root() -> str:
    return "/tmp/results"


class ScheduledDate:
    plus_days = 0

    def __init__(self, plus_days: int = 0):
        self.plus_days = plus_days


def _on_failure(
    task: "Task",
    state: prefect.engine.state.State,
    func: Optional[Callable[[PrefectTask, prefect.engine.state.State], None]] = None,
) -> None:

    _params = env_params()

    _msg = f"""
        Su {_params["host"]}
        la run del task {_params["flow_name"]}::{task.name} ({_params["run_name"]}) è fallita per errore inatteso :
        "{state.message}"
        """
    _title = f"[{_params['project_name']}] Fallito task {_params['flow_name']}::{task.name}"

    res = apprise_alert(message=_msg, title=_title, type="failure")

    if res is not None and res.status_code != 200:
        task.log.message(f"Fail chiamando l'alert server : {res.status_code}, {res.text}", LogLevel.WARNING)
    if func is not None:
        func(task, state)


class Task(PrefectTask):
    """Rappresenta uno step di lavoro atomico all'interno di un Flow.

    Ogni implementazione del metodo run deve prendere ad input zero o un solo argomento di tipo TaskData,
    e restituire ad output uno ed uno solo oggetto TaskData.

    TaskData è un dizionario con tre chiavi predefinite ( non deve definirne altre ) :
    {"data", "errors", "meta"}

    "data" deve sempre essere valorizzata con un Iterable, se non ci sono dati deve essere una lista vuota.

    "errors" può essere una lista, eventualmente vuota a indicare assenza di errori, o non presente se
    non ha senso avere errori per il tipo di dati rappresentati.

    "meta" è un dizionario, può avere zero o più elementi o non essere presente, i valori devono essere accumulati
    nel passaggio fra Task.

    Se "errors" e "meta" sono presenti in ingresso a un Task vengono mantenuti in uscita anche se "data"
    viene modificato (a meno che non faccia parte della funzione del task modificarli).
    """

    def __init__(self, on_failure=None, *args, **kwargs) -> None:  # type: ignore
        super().__init__(on_failure=partial(_on_failure, func=on_failure), *args, **kwargs)  # type: ignore

    @property
    def dirspace(self) -> Path:
        results_root = _get_results_root()
        flow_name = slugify(str(prefect.context.flow_name))
        run_name = "runs" if os.getenv("DEPLOY_ENV") == "loc" else prefect.context.flow_run_name
        p = Path(f"{results_root}/{flow_name}/{run_name}/{prefect.context.task_run_count}")
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def log(self) -> Any:
        return _log


class Flow(PrefectFlow):
    def __enter__(self) -> "Flow":
        logger.init(service=self.name)
        return super().__enter__()  # type: ignore

    def run(  # type: ignore
        self,
        **kwargs: Any,
    ) -> "prefect.engine.state.State":
        with _log.start_action(self.name), _log.timed(""):
            return super().run(**kwargs)  # type: ignore


def raise_job_fail(resp: Any) -> None:  # TODO resp: falcon Response obj
    try:
        for e in resp.json()["errors"]:
            raise prefect.engine.signals.FAIL(f'{e["title"]}: {e["code"]} from dpegate with id {e["id"]}') from None
    except json.decoder.JSONDecodeError:  # error before dpegate ( es. service down )
        raise prefect.engine.signals.FAIL(f"{resp.reason}: {resp.status_code} calling {resp.url[:60]}...") from None


@dataclass(frozen=True)
class FieldRule:
    type_: type | Coerce  # tipo base contro cui validare i dati letti dal feed
    ingest_column: str | None = None  # nome della colonna di ingest se diversa da quello nel feed
    external: bool = False  # campo inferito e non presente esplicitamente nelle colonne del feed


SheetRules = dict[str, dict[str, FieldRule]]
RuleDict = dict[str, SheetRules]
"""
rule = {
    r"feed_file_regex": {
        "sheet_name": {  # "-" if csv
            "field_name": FieldRule(type_, ingest_column),
            ...
        },
        ...
    },
    ...
}
"""
