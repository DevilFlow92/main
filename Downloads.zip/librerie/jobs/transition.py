import json
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Callable, Optional, Union

import pyodbc

from pymol.ext.auth import from_vault
from pymol.ext.services import close_service, service
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import MessageState, TaskData


class BusinessStateError(Exception):
    pass


TransitionResult = tuple[
    str,  # lo stato in cui mi sono spostato
    dict[str, Any],  # eventuali dati recuperati
    list[dict[str, str]],  # eventuali messaggi da loggare
]

TransitionFunction = Callable[
    [
        Any,  # pyodbc.Row
        dict[str, Any],  # data from previous call
        dict[str, Any],  # services
    ],
    TransitionResult,
]


RecoverDataFunction = Callable[
    [
        Any,  # pyodbc.Row
        dict[str, Any],  # services
    ],
    dict[str, Any],
]


class _Encoder(json.JSONEncoder):
    def default(self, o: Any) -> Any:
        if isinstance(o, date):
            return o.isoformat()
        if isinstance(o, datetime):
            return o.isoformat()
        if isinstance(o, Decimal):
            return str(o)
        return super(_Encoder, self).default(o)


class Transition(Task):
    def __init__(
        self,
        db_label: str,
        services: set[str],
        states: dict[str, tuple[TransitionFunction, Optional[RecoverDataFunction]]],
        state_table: str,
        order_by: Optional[list[tuple[str, str]]] = None,
        state_column: str = "msg_state",
        skip_column: Optional[str] = None,
        id_column: str = "id",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db_label = db_label
        self.services = services
        self.states = states
        self.state_table = state_table
        self.order_by = order_by
        self.state_column = state_column
        self.id_column = id_column
        self.skip_column = skip_column
        self.service: dict[str, Any] = {}
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        self.dbconn = None
        auth_db = from_vault(self.db_label)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

        for service_label in self.services:
            self.service[service_label] = service(service_label)

    def close(self) -> None:
        for label, handler in self.service.items():
            close_service(label, handler)

        if self.dbconn is not None:
            self.dbconn.close()

    def get_messages(self, ext_params: dict[str, Union[int, str, float, bool]]) -> Any:
        skip = f" AND {self.skip_column} != 1" if self.skip_column else ""
        select_query = f"""SELECT * FROM {self.state_table}
            WHERE ({self.state_column} IN ('{MessageState.Unprocessed.value}', '{MessageState.GaveError.value}')
            OR {self.state_column} LIKE 'S%'){skip}
            """

        xtrafilter = " AND ".join([f"{k.lstrip('+')} = '{v}'" for k, v in ext_params.items() if k.startswith("+")])
        if xtrafilter:
            select_query += f" AND {xtrafilter}"

        if self.order_by:
            order_by_clause = " ORDER BY "
            order_by_clause += ", ".join([" ".join([field, direction]) for field, direction in self.order_by])
            select_query += order_by_clause

        self.cursor.execute(select_query)
        return self.cursor.fetchall()

    def transition(
        self, msg: Any, ext_params: dict[str, Union[int, str, float, bool]]
    ) -> tuple[dict[str, Any], list[dict[str, str]]]:
        state = str(getattr(msg, self.state_column)).strip()
        logsdata = []
        data = ext_params
        if state not in ("UNP", "ERR"):
            _, rec = self.states[state]
            if rec is None:
                raise ValueError(f"Manca una funzione di recupero per ripartire da {state}")
            data.update(rec(msg, self.service))
        while state != "PRC":
            fun, _ = self.states[state]
            try:
                with self.log.timed(f"transition from {state}"):
                    state, res, msglogs = fun(msg, data, self.service)
                data = ext_params
                data.update(res)
                data["_last_state"] = state
                logsdata.extend(msglogs)
                self.cursor.execute(
                    f"UPDATE {self.state_table} SET {self.state_column} = ? WHERE {self.id_column} = ?",
                    state,
                    getattr(msg, self.id_column),
                )
            except (BusinessStateError, BusinessValueError) as ex:
                if state == "UNP":
                    self.cursor.execute(
                        f"UPDATE {self.state_table} SET {self.state_column} = 'ERR' WHERE {self.id_column} = ?",
                        getattr(msg, self.id_column),
                    )
                self.log.warning(str(ex))
                data["_last_state"] = state
                return data, logsdata
            finally:
                if self.dbconn is not None:
                    self.cursor.commit()
        data["_last_state"] = state
        return data, logsdata

    def run(  # type: ignore[override]
        self, ext_params: dict[str, Union[int, str, float, bool]]
    ) -> tuple[TaskData, dict[str, TaskData]]:
        self.run_logs: TaskData = {
            "data": [],
            "errors": [],
            "meta": {},
        }
        self.output: TaskData = {
            "data": [],
            "errors": [],
            "meta": {},
        }
        self.reports: dict[str, TaskData] = {}
        with self.log.start_action(self.name), self.log.timed(self.name):
            try:
                self.open()
                for msg in self.get_messages(ext_params):
                    lastdata, _ = self.transition(msg, ext_params)
                    if lastdata["_last_state"] == "PRC":
                        self.output["data"].append(
                            {
                                f"{self.state_table}.{ getattr(msg, self.id_column)}": {
                                    k: lastdata[k] for k in sorted(lastdata)
                                }
                            }
                        )
                    else:
                        self.output["errors"].append(
                            {
                                "error": json.dumps({k: lastdata[k] for k in sorted(lastdata)}, cls=_Encoder),
                                "source": {f"{self.state_table}.{self.id_column}": getattr(msg, self.id_column)},
                            }
                        )
                self.reports.update({"run_logs": self.run_logs})
                self.output["meta"]["hasErrors"] = len(self.output["errors"]) > 0
                self.output["meta"]["isEmpty"] = len(self.output["data"]) == 0
                return self.output, self.reports
            finally:
                self.close()
