import re
import time
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Iterable, Union

import holidays
import pendulum
import prefect
from mdutils.mdutils import MdUtils
from prefect import Client, task
from prefect.artifacts import create_markdown
from prefect.backend.flow import FlowView
from prefect.engine import signals
from prefect.engine.signals import signal_from_state
from prefect.run_configs import RunConfig

from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.jobs.fun import shift_date as shift_date_fun
from pymol.types.jobs import TaskData

ANY_INVALID = 1
ALL_INVALID = 2


class Policies(Enum):
    STRICT = 1
    CONTAINS = 2


@task
def start_flow_run(
    flow_id: str | None = None,
    flow_name: str | None = None,
    project_name: str | None = "",
    parameters: dict | None = None,  # type: ignore
    context: dict | None = None,  # type: ignore
    labels: Iterable[str] | None = None,
    run_name: str | None = None,
    run_config: RunConfig | None = None,
    scheduled_start_time: pendulum.DateTime | datetime | None = None,  # type: ignore
    wait_for: Any | None = None,  # noqa
) -> str:
    """
    Lancia un flow registrato su prefect ( non funziona da locale ).

    Esempio:

    ```
    start_flow_run(flow_name="process", project_name="bibanca", parameters=params_dict, wait_for=altro_output)
    ```
    """
    if flow_id and flow_name:
        raise ValueError("Received both `flow_id` and `flow_name`. Only one flow identifier " "can be passed.")
    if not flow_id and not flow_name:
        raise ValueError("Both `flow_id` and `flow_name` are null. You must pass a flow " "identifier")

    logger = prefect.context.logger
    logger.debug("Looking up flow metadata...")

    if flow_id:
        flow = FlowView.from_id(flow_id)

    if flow_name:
        flow = FlowView.from_flow_name(flow_name, project_name=project_name)  # type: ignore

    # Generate a 'sub-flow' run name
    if not run_name:
        current_run = prefect.context.get("flow_run_name")
        if current_run:
            run_name = f"{current_run}-{flow.name}"

    # A run name for logging display; robust to 'run_name' being empty
    run_name_dsp = run_name or "<generated-name>"

    logger.info(f"Creating flow run {run_name_dsp!r} for flow {flow.name!r}...")

    client = Client()
    flow_run_id = client.create_flow_run(
        flow_id=flow.flow_id,
        parameters=parameters,  # type: ignore
        context=context,  # type: ignore
        labels=labels,  # type: ignore
        run_name=run_name,  # type: ignore
        run_config=run_config,  # type: ignore
        scheduled_start_time=scheduled_start_time,  # type: ignore
    )

    run_url = client.get_cloud_url("flow-run", flow_run_id)
    logger.info(f"Created flow run {run_name_dsp!r}: {run_url}")

    while True:
        time.sleep(10)
        flow_run_state = client.get_flow_run_info(flow_run_id).state
        if flow_run_state.is_finished():
            exc = signal_from_state(flow_run_state)(f"{flow_run_id} finished in state {flow_run_state}")
            raise exc


class CheckCondition(Task):
    """Fallisce se la funzione passata come condition torna False.

    Esempio:

    ```
    fallisci_se_righe_di_errore = CheckCondition(
        # esistono diverse funzioni di condition, iniziano sempre per 'fail_on_'
        condition=fail_on_errors(jobs.ANY_INVALID)
        )
    result = fallisci_se_righe_di_errore(data_rows)
    ```
    """

    def __init__(
        self,
        condition: Callable[[Any], bool],
        skip: bool = False,
        **kwargs: Any,
    ) -> None:
        self.condition = condition
        self.skip = skip
        super().__init__(**kwargs)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            if self.condition(data):
                return data
            if self.skip:
                raise signals.SKIP(f"Forcing SKIP due to failing {self.name} condition")
            raise signals.FAIL(f"Forcing FAIL due to failing {self.name} condition")


def fail_on_errors(fail_on: int) -> Callable[[Any], bool]:
    def _fu(data: TaskData) -> bool:
        if fail_on == ANY_INVALID and data["errors"]:
            return False
        if fail_on == ALL_INVALID and data["errors"] and not data["data"]:
            return False
        return True

    return _fu


def fail_on_empty_data() -> Callable[[Any], bool]:
    def _fu(data: TaskData) -> bool:
        if len(data["data"]) == 0:
            return False
        return True

    return _fu


class WaitForData(Task):
    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)

    def run(self, data: TaskData, wait: TaskData) -> TaskData:  # type: ignore
        return data


class CountOccurrencies(Task):
    """Conta le occorrenze di più regex in un  TaskData.

    Esempio:

    ```
    count = CountOccurrencies(
        mapping={"label": ("col_name", r"regex to search")},
        count_dups=True # conta quante volte compare in una stessa riga
    )
    ```
    """

    def __init__(
        self,
        mapping: dict[str, tuple[str, str]],
        count_dups: bool,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.mapping = mapping
        self.count_dups = count_dups
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        out = dict()
        for k, v in self.mapping.items():
            label = k
            column, regex = v[0], v[1]
            out[label] = 0
            pattern = re.compile(regex)

            for row in data["data"]:
                for col, data_col in row.items():
                    if col == column:
                        match = re.findall(pattern, data_col)
                        if match:
                            out[label] += len(match) if self.count_dups else 1

        return {
            "data": [
                out,
            ],
            "errors": [],
            "meta": data["meta"].copy(),
        }


class ExtendData(Task):
    def __init__(
        self,
        columns: set[str],
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.columns = columns
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: list[TaskData]) -> TaskData:  # type: ignore
        outdata = []

        for datarow in data:
            for row in datarow["data"]:
                outdata.append({k: v for k, v in row.items() if k in self.columns})

        return {"data": outdata, "errors": [], "meta": {"isEmpty": len(outdata) == 0}}


class ReportAsMarkdown(Task):
    def run(self, data: TaskData) -> TaskData:  # type: ignore
        messages = {
            "error": ["text", "from msg"],
            "warning": ["text", "from msg"],
            "info": ["text", "from msg"],
        }

        for row in data["data"]:
            messages[row["type"]].extend([row["message"], row["source"]])

        md = MdUtils(file_name="_", title="_")
        md.new_header(level=1, title="ERRORS")
        md.new_table(columns=2, rows=int(len(messages["error"]) / 2), text=messages["error"])
        md.new_header(level=1, title="WARNINGS")
        md.new_table(columns=2, rows=int(len(messages["warning"]) / 2), text=messages["warning"])
        md.new_header(level=1, title="INFOS")
        md.new_table(columns=2, rows=int(len(messages["info"]) / 2), text=messages["info"])

        create_markdown(md.file_data_text)

        return data


@task
def shift_date(
    feed_date: str,
    days: Union[str, int],
    skip_weekends: bool,
    skip_holidays: bool = False,
    countries: set[str] = {"IT"},
) -> str:
    if type(days) == str:
        _days = str(days).strip() if len(str(days)) > 0 else "0"
        if _days != "0" and _days[0] not in ("+", "-"):
            raise ValueError(f"days sign is required for {days}")
    else:
        _days = days  # type: ignore

    if not feed_date:
        _date = prefect.context.scheduled_start_time.date()
    else:
        _date = datetime.strptime(feed_date.strip(), "%Y-%m-%d").date()

    return shift_date_fun(_date, int(_days), skip_weekends, skip_holidays, countries).isoformat()


def _get_dates(
    from_date: str, to_date: str, skip_weekends: bool, skip_holidays: bool, countries: set[str] = {"IT"}
) -> list[dict[str, str]]:
    output = []
    start_date = datetime.strptime(from_date, "%Y-%m-%d")
    end_date = datetime.strptime(to_date, "%Y-%m-%d")
    delta = end_date - start_date

    for i in range(delta.days + 1):
        day = start_date + timedelta(days=i)
        _date = pendulum.datetime(day.year, day.month, day.day)
        skip = False
        if skip_weekends and _date.day_of_week in (pendulum.SATURDAY, pendulum.SUNDAY):  # type: ignore
            skip = True

        if skip_holidays:
            for country in countries:
                if _date in getattr(holidays, country)():
                    skip = True

        if skip is False:
            output.append({"on_date": str(_date.date())})  # type: ignore
    return output


@task
def get_dates(
    dates: str, skip_weekends: bool, skip_holidays: bool, countries: set[str] = {"IT"}
) -> list[dict[str, str]]:
    """Prende una stringa di intervalli e restituisce una lista di feed_dates.

    ```
    dates_ = get_dates(
            dates="2021-08-02>2021-08-04,2021-08-11,2021-08-16>2021-08-18", #intervalli di date
            skip_weekends=False, # ignora i giorni del weekend
            skip_holidays=False, # ignora i giorni festivi
            countries={"IT",}, # paesi di riferimento)

    assert dates_ == [
        {"feed_date": "2021-08-02"},
        {"feed_date": "2021-08-03"},
        {"feed_date": "2021-08-04"},
        {"feed_date": "2021-08-11"},
        {"feed_date": "2021-08-16"},
        {"feed_date": "2021-08-17"},
        {"feed_date": "2021-08-18"},]
    ```
    """
    output = []

    dates_ = dates.split(",")
    chunk_dates_: list[tuple[str, str]] = []

    for date_ in dates_:
        tmp_ = date_.split(">")
        chunk_dates_.append((tmp_[0], tmp_[1]) if len(tmp_) > 1 else (tmp_[0], tmp_[0]))

    for chunk in chunk_dates_:
        output.extend(
            _get_dates(
                from_date=chunk[0],
                to_date=chunk[1],
                skip_holidays=skip_holidays,
                skip_weekends=skip_weekends,
                countries=countries,
            )
        )

    return output


@task
def merge_taskdata(policy: Enum, columns: set[str], taskdata: list[TaskData]) -> TaskData:
    for _task in taskdata:
        for _dict in _task["data"]:
            keys = _dict.keys()
            intersect = set(keys) & columns

            if (len(intersect) != len(columns)) or (
                policy == Policies.STRICT and len(intersect) == len(columns) and len(keys) != len(intersect)
            ):
                raise ValueError("TaskData incompatibile con la policy")

    meta = taskdata[0]["meta"]
    outdata = []
    errors = []
    for _task in taskdata:
        for _data in _task["data"]:
            outdata.append(_data)
        for _error in _task["errors"]:
            errors.append(_error)

    return {"data": outdata, "errors": errors, "meta": meta}
