import sys
from pathlib import Path

from pymol.jobs.utils.mappings.core import MapTemplate, _replace, _slug

common = MapTemplate(vault_label="db_clc_w", template_file="__init__.txt", bu="clc", normalize=_replace)
common.add("d_cliente", "SELECT codice, descrizione FROM D_Cliente", normalize=_slug)
common.add("d_stato", "SELECT codice, descrizione FROM D_Stato", normalize=_slug)
common.add("movimenti_conto", "SELECT codice, descrizione FROM D_TipoMovimentoContoBancario", retrieve=False)
common.add("titoli_finanziari", "SELECT codice, descrizione FROM D_TipoTitoloFinanziario", retrieve=False)
common.add(
    "operazioni",
    """SELECT DISTINCT S_OperazioneContoBancario.IdOperazioneContoBancario,
S_OperazioneContoBancario.NomeOperazione FROM T_MovimentoContoBancario
INNER JOIN T_ContoBancarioPerAnno
ON T_MovimentoContoBancario.IdContoBancarioPerAnno = T_ContoBancarioPerAnno.IdContoBancarioPerAnno
INNER JOIN T_Incarico ON T_ContoBancarioPerAnno.IdIncarico = T_Incarico.IdIncarico
INNER JOIN S_OperazioneContoBancario
ON T_MovimentoContoBancario.IdOperazioneContoBancario =
S_OperazioneContoBancario.IdOperazioneContoBancario
WHERE T_Incarico.CodCliente IN (53,195)""",
    retrieve=False,
)
common.add(key="valute", qs="SELECT sigla, codice FROM D_Valuta", retrieve=False)

italcredi = MapTemplate(vault_label="db_clc_w", template_file="italcredi.txt", bu="clc", normalize=_slug)
italcredi.add(
    "e_produttore",
    f"""SELECT codice, RagioneSociale1 + ISNULL(RagioneSociale2,'') as descrizione
    FROM E_Produttore WHERE codcliente = {common.d_cliente.ITALCREDI}""",  # type: ignore
)


def make(path: Path = Path("."), to_out: bool = False) -> dict[str, str] | None:
    """."""
    c = common.set_output_dir(path).render(to_out=to_out)
    i = italcredi.set_output_dir(path).render(to_out=to_out)
    return {"italcredi.py": i, "__init__.py": c}


if __name__ == "__main__":
    if len(sys.argv) > 1:
        make(Path(sys.argv[1]))
    else:
        make()
