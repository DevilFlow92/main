import sys
from pathlib import Path

from pymol.jobs.utils.mappings.core import MapTemplate, _replace

common = MapTemplate(vault_label="db_zuclc_w", template_file="__init__.txt", bu="gsa", normalize=_replace)
common.add("movimenti_conto", "SELECT codice, descrizione FROM D_TipoMovimentoContoBancario", retrieve=False)
common.add("titoli_finanziari", "SELECT codice, descrizione FROM D_TipoTitoloFinanziario", retrieve=False)
common.add(
    "operazioni",
    "SELECT IdOperazioneContoBancario, NomeOperazione, SegnoTitolo FROM S_OperazioneContoBancario",
    retrieve=False,
)
common.add(key="valute", qs="SELECT sigla, codice FROM D_Valuta", retrieve=False)
common.add("segni_titoli", "SELECT SegnoTitolo, NomeOperazione FROM S_OperazioneContoBancario", retrieve=False)
common.add("segni_importi", "SELECT SegnoImporto, NomeOperazione FROM S_OperazioneContoBancario", retrieve=False)
common.add("schede_contabili", "SELECT id, descrizione FROM vd.D_SchedaHolding", retrieve=False)
common.add("tipi_scrittura", "SELECT ID, Descrizione FROM vd.D_TipoScrittura", retrieve=False)


def make(path: Path = Path("."), to_out: bool = False) -> dict[str, str] | None:
    """."""
    return {"__init__.py": common.set_output_dir(path).render(to_out=to_out)}


if __name__ == "__main__":
    if len(sys.argv) > 1:
        make(Path(sys.argv[1]))
    else:
        make()
