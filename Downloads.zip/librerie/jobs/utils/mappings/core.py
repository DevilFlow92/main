"""."""
import difflib
import importlib.util
import os
import re
import sys
import tempfile
from collections import namedtuple
from difflib import Differ
from os import getcwd, listdir
from pathlib import Path
from typing import Any, Callable, Union, cast

import pyodbc
import unidecode
from jinja2 import Environment, FileSystemLoader, select_autoescape
from slugify import slugify

from pymol.auth import from_vault
from pymol.ext.services import service


def _slug(value: str | int) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{str(value)} should be a string")

    slug = slugify(value, max_length=20, word_boundary=True, separator="_").upper()

    m = re.match(r"(^\d.)(.*)", slug)
    if m:
        return "".join(m.groups()[::-1])
    return slug


def _replace(value: str | int) -> str:
    if not isinstance(value, int):
        stripped = value.upper().replace("-", "").replace(".", "").replace("(", "").replace(")", "").replace("/", "")

        stripped = re.sub(r"\s+", " ", stripped)
        modified = (
            stripped.upper()
            .replace(" ", "_")
            .replace("'", "_")
            .replace(",", "_")
            .replace("+", "PIU")
            .replace("%", "PERC")
        )

    return str(unidecode.unidecode(modified)) if not isinstance(value, int) else str(value)


class MapTemplate:
    """."""

    def __init__(
        self,
        vault_label: str,
        template_file: str,
        output_dir: Union[None, Path] = None,
        bu: Union[None, str] = None,
        output_file: Union[None, str] = None,
        normalize: Callable[[str | int], str] = _slug,
    ) -> None:
        self.vault_label = vault_label
        self.template_file = template_file
        self.output_file = output_file if output_file else template_file.replace("txt", "py")
        self.bu = Path(getcwd()).name if not bu else bu
        self.output_dir = Path(Path(__file__).parent, self.bu) if not output_dir else output_dir
        self.mapping: dict[str, tuple[str, Union[None, Callable[[str | int], str]]]] = {}
        self.mapped: dict[str, Union[None, dict[str | int, int | str]]] = {}
        self.normalize = normalize

    def set_output_dir(self, path: Path) -> Any:
        self.output_dir = path
        return self

    def add(
        self, key: str, qs: str, retrieve: bool = True, normalize: Union[None, Callable[[str | int], str]] = None
    ) -> Any:
        """."""
        self.mapping[key] = (qs, normalize)
        self.mapped[key] = None

        if retrieve:
            mapped = self._map_one(key, qs, normalize)
            Nt = namedtuple("Nt", ", ".join(mapped.keys()))  # type: ignore
            setattr(self, key, Nt(**mapped))

        return self

    def _map_one(
        self, key: str, qs: str, normalize: Union[None, Callable[[str | int], str]]
    ) -> dict[str | int, int | str]:
        res = cast(dict[str, Union[pyodbc.Connection, pyodbc.Cursor]], service(self.vault_label))
        tmp_map: dict[str | int, int | str] = {}

        res["cursor"].execute(qs)
        res2 = res["cursor"].fetchall()
        if res2:
            for value in res2:
                if not normalize:
                    tmp_map[self.normalize(value[1])] = value[0]
                else:
                    tmp_map[normalize(value[1])] = value[0]

        self.mapped[key] = tmp_map
        return tmp_map

    def _map_rest(self) -> None:
        for k in self.mapping:
            if not self.mapped[k]:
                self.mapped[k] = self._map_one(k, self.mapping[k][0], self.mapping[k][1])

    def render(self, alt_dir: Union[None, Path] = None, to_out: bool = False) -> str | None:
        """."""
        file_loader = FileSystemLoader(Path(Path(__file__).parent, self.bu, "templates"))
        env = Environment(loader=file_loader, autoescape=select_autoescape())
        template = env.get_template(self.template_file)

        self._map_rest()

        out = template.render(self.mapped)
        if to_out:
            return out
        target_dir = self.output_dir if not alt_dir else alt_dir
        with open(Path(target_dir, self.output_file), "w+") as f:
            f.write(out)
        return None

    def get_diff(self, fname: Union[None, str] = None) -> dict[str, str]:
        diff_alert = ("+ ", "- ", "? ")
        differ = difflib.Differ(charjunk=lambda x: x.isspace(), linejunk=lambda x: x.isspace())
        delta: list[str] = []
        out: dict[str, str] = {}

        with tempfile.TemporaryDirectory() as tmpdir:
            self.render(Path(tmpdir))

            lookup = (
                [
                    fname,
                ]
                if fname
                else listdir(Path(tmpdir))
            )
            for fname in lookup:
                with open(Path(self.output_dir, fname), "r") as fold, open(Path(tmpdir, fname), "r") as fnew:
                    old_ = fold.read()
                    new_ = fnew.read()
                    for item in differ.compare(new_, old_):
                        if item.startswith(diff_alert):
                            for _ in diff_alert:
                                item = item.replace(_, "")
                            if item:
                                delta.append(item)

                    out.update({fname: "".join(delta).strip()})  # noqa

        return out


def check_mapping_sync(tenancy: str) -> dict[str, list[str]]:
    output = {}
    GIT_TOKEN = from_vault("gitlab")["pycc"]
    if not Path("/tmp/pycc").exists():
        os.system(  # nosec
            f"cd /tmp && git clone "
            f"https://pycc:{GIT_TOKEN}@gitlab.gruppomol.lcl/innovation/core-projects/pycc.git --depth 1"
        )
    else:
        os.system("cd /tmp/pycc && git config pull.rebase false && git pull")  # nosec

    module_name = "pymol.jobs.utils.mappings.{tenancy}.render"
    spec = importlib.util.spec_from_file_location(module_name, Path(Path(__file__).parent, tenancy, "render.py"))
    module = importlib.util.module_from_spec(spec)  # type: ignore
    sys.modules[module_name] = module
    spec.loader.exec_module(module)  # type: ignore
    db_map = module.make(to_out=True)

    for k, v in db_map.items():
        with open(f"/tmp/pycc/Libraries/types/src/pymol/types/mappings/{tenancy}/{k}", "r") as f:
            foobar = f.read()
            differ = Differ()
            not_hash_code = "".join(e for e in foobar if e.isalnum())
            not_hash_db = "".join(e for e in v if e.isalnum())
            if not_hash_code != not_hash_db:
                f.seek(0)
                output[k] = [
                    line
                    for line in differ.compare(f.readlines(), v.splitlines(keepends=True))
                    if line[0] != " " and len(line.replace(" ", "")) > 2 and line[0] != "?"
                ]

    return output
