import base64
import random
import re
import subprocess  # nosec
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile

import prefect
import pyodbc
from prefect import task

from pymol.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, ErrorRow, TaskData


class DeleteFile(Task):
    """Cancella uno o più file da una share remota.

     Esempio:

    ```
    delete = DeleteFile(
        auth_label="test_sftp",
        older_than="2",  # cancella i file della lista piu vecchi di 2 giorni
    )
    delete(
        {
            "data": [
                    {"path": "path_file/delete1.txt"},
                    {"path": "path_file/delete2.txt"},
                    {"path": "path_file/delete3.txt"},
                ],
            "errors" : [],
            "meta": {},
        }
    )
    """

    def __init__(
        self,
        auth_label: str | None = None,
        path_label: str = "path",
        older_than: str | None = None,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.auth_label = auth_label
        self.path_label = path_label
        self.older_than = older_than
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData, auth_label: str | None = None) -> TaskData:  # type: ignore
        output: list[DataRow] = []
        errors: list[ErrorRow] = []
        with self.log.start_action(self.name), self.log.timed(self.name):
            if auth_label is not None:
                self.auth_label = auth_label
            if self.auth_label is None:
                raise ValueError("auth_label is required")
            with ftp_conn(from_vault(self.auth_label)) as conn:
                for row in data["data"]:
                    try:
                        path = row[self.path_label]
                        if not self.older_than:
                            conn.delete(path)
                            output.append({"path": path})
                        else:
                            _date = datetime.today().date() - timedelta(days=int(self.older_than))
                            if len(conn.describe(path)):
                                for _, meta in conn.describe(path).items():

                                    _date_file = meta.modify.date()
                                    if _date_file <= _date:
                                        conn.delete(path)
                                    output.append({"path": path})
                            else:
                                errors.append({"error": f"File {row[self.path_label]} not found", "source": row})
                    except Exception as ex:
                        errors.append({"error": str(ex), "source": row})

            return {"data": output, "errors": errors, "meta": {"isEmpty": len(output) == 0}}


class ZipFiles(Task):
    """Zippa più files.

    Esempio:

    ```
    zip = ZipFiles(
        # il nome del file zip
        filename = "archivio",
        )
    path_filezip = zip(data)
    ```
    """

    def __init__(
        self,
        filename: str | None = None,
        path_label: str = "path",
        chunks_size: str | None = None,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.filename = filename
        self.path_label = path_label
        self.chunks_size = chunks_size
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData, filename: str | None = None) -> TaskData:  # type: ignore
        with self.log.start_action("zip files"), self.log.timed(self.name):
            execution_date = prefect.context.scheduled_start_time
            fn = (
                f"{filename.lstrip('/')}.zip"
                if filename
                else f"{self.filename}_{execution_date.strftime('%Y_%m_%d')}.zip"
            )
            zipname = self.dirspace / fn

            with ZipFile(file=zipname, mode="w", compression=ZIP_DEFLATED, compresslevel=9) as zipfile:
                for row in data["data"]:
                    filepath = row["path"]
                    try:
                        zipfile.write(filepath, filepath.relative_to(self.dirspace))
                    except ValueError:
                        zipfile.write(filepath)

            if self.chunks_size:
                chunks_name = (
                    f"{filename.lstrip('/')}_{self.chunks_size}.zip"
                    if filename
                    else f"{self.filename}_{execution_date.strftime('%Y_%m_%d')}_{self.chunks_size}.zip"
                )
                chunks_basename = str(self.dirspace / chunks_name)
                subprocess.run(["zip", zipname, "--out", chunks_basename, "-s", self.chunks_size])  # nosec
                output = [{"path": o} for o in self.dirspace.glob(f"**/{chunks_name[:-4]}*")]
                return {"data": output, "errors": [], "meta": {"isEmpty": len(output) == 0}}
            return {
                "data": [
                    {"path": Path(zipname)},
                ],
                "errors": [],
                "meta": {},
            }


class UnzipFile(Task):
    """Unzippa un file.

    Esempio:

    ```
    unzip = UnzipFile()
    path_files_estratti = unzip(path_filezip)
    ```
    """

    def __init__(
        self,
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.path_label = path_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: DataRow) -> TaskData:  # type: ignore
        with self.log.start_action("unzip files"), self.log.timed(self.name):
            output = []
            with ZipFile(data[self.path_label]) as zfile:
                rnd_suffix = "".join(random.choice("0123456789ABCDEF") for i in range(16))  # nosec
                zfile.extractall(self.dirspace / rnd_suffix)
                for fname in zfile.namelist():
                    if Path(self.dirspace / rnd_suffix / fname).is_file():
                        output.append({"path": Path(self.dirspace / rnd_suffix / fname)})

            meta_dict = {k: v for k, v in data.items()}
            meta_dict["isEmpty"] = len(output) == 0
            return {"data": output, "errors": [], "meta": meta_dict}


class DecryptFile(Task):
    """Decripta il contenuto di un file.

    La stringa corretta da salvare nel vault viene generata nel seguente modo :

    - importarsi la chiave privata in locale

        ```
        gpg --import --no-tty --batch --yes priv.key
        ```

    - riesportarla in file base64

        ```
        gpg --export-secret-keys  | base64 > secret.b64
        ```

    In caso di problemi durante il decrypt, dalla shell del docker rimuovere ogni configurazione salvata da gnupg :

        ```
        rm -fr root/.gnupg/
        ```

    Se la chiave è stata fornita in formatto putty, convertirla in openssh col seguente comando

        ```
        puttygen putty_file.ppk -O public-openssh -o [pub.key]
        puttygen putty_file.ppk -O private-openssh -o [priv.key]
        ```
    """

    def __init__(
        self,
        key_label: str,
        path_label: str = "path",
        **kwargs: Any,
    ) -> None:
        self.key_label = key_label
        self.path_label = path_label
        super().__init__(**kwargs)

    def run(self, data: DataRow) -> DataRow:  # type: ignore
        with self.log.start_action("decrypt file"), self.log.timed(self.name):
            keys = from_vault(self.key_label)
            suffix = Path(data[self.path_label]).suffix
            outfile = str(data[self.path_label]).replace(suffix, "")

            private_binary_key = base64.b64decode(str(keys["private_key"]))
            try:
                subprocess.run(  # nosec
                    ["gpg", "--import", "--no-tty", "--batch", "--yes"], input=private_binary_key, check=True
                )
                subprocess.run(  # nosec
                    [
                        "gpg",
                        "--batch",
                        "--pinentry-mode=loopback",
                        "--passphrase",
                        str(keys["passphrase"]),
                        "--decrypt",
                        "-o",
                        outfile,
                        data[self.path_label],
                    ],
                    check=True,
                )
            except Exception:
                raise ChildProcessError(f"Errore nel decriptare il file: {data[self.path_label]}")

            return {"path": outfile, "source_path": data["source_path"], "timestamp": data["timestamp"]}


class FindFile(Task):
    """Trova un file all'interno di una lista.

    Esempio:

    ```
    find = FindFile()
    path_files_trovato = find(path_files, regex_voluta)
    ```
    """

    def __init__(
        self,
        path_label: str = "path",
        max_retries: int = 0,
        retry_delay: timedelta | None = None,
        **kwargs: Any,
    ) -> None:
        self.path_label = path_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData, regex: str) -> TaskData:  # type: ignore
        prog = re.compile(regex)
        output = []
        with self.log.start_action("find file"), self.log.timed(self.name):
            for row in data["data"]:
                if prog.search(str(row[self.path_label]), len(str(self.dirspace))):
                    output.append(row)
            return {"data": output, "errors": [], "meta": {"isEmpty": len(output) == 0}}


class FilterIngestedFile(Task):
    """Filtra una lista di file, lasciando solo i file non ancora caricati nella tabella meta del database."""

    def __init__(
        self,
        db: str,
        db_schema: str | None = None,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        self.db_schema = db_schema or "pycc"
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']}"
        )
        self.dbconn = pyodbc.connect(self.db_params)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        self.dbconn.close()

    def run(self, data: list[DataRow]) -> list[DataRow]:  # type: ignore
        with self.log.start_action("filter ingested files"), self.log.timed(self.name):
            output = []
            try:
                self.open()
                for inputFile in data:
                    self.cursor.execute(
                        f"""
                    SELECT id, ingested, ingest_ts FROM {self.db_schema}.E_Meta WHERE source_file = ?
                    """,
                        str(inputFile["source_path"]),
                    )
                    rs = self.cursor.fetchone()

                    if not rs:
                        output.append(inputFile)

            except Exception as exc:
                self.dbconn.rollback()
                self.logger.warning(f"Errore {exc.__class__} : {exc}. Processando il file : {id}")
            finally:
                self.close()

        return output


@task
def days_from_paths(
    data: TaskData,
    add_discarded: bool = False,
    regex: str = r"\/(?P<year>\d{4})\/(?P<month>\d{2})\/(?P<day>\d{2})",
    from_dir: bool = True,
) -> TaskData:
    """
    Estrapola una data dal percorso di archiviazione del file, regex deve contenere i parametri year, month, day.

    Se in_dir è False cerca la regex nel nome del file e non nella directory parent.

    >>> path = "/ftp_ocs/2021/06/11/Estraz_Istr_CNT_CO_20210512-15071699.csv@2021-05-12T13-07-18+00-00"
    >>> days_from_paths( {"data": path, "meta": {} } )
    >>> {"data": [date(2021, 06, 11)], "errors": [], "meta": {}}
    """
    filename_regex = r"[A-Za-z0-9-_,\s]+[.]{1}[A-Za-z0-9]{3,4}"
    distinct_dates = set()
    for line in data["data"]:
        if not line["is_discarded"] or add_discarded:
            path = Path(line["path"])
            if not from_dir:
                found = re.search(filename_regex, path.name, re.X | re.M)
                if found is None:
                    raise ValueError(f"Il percorso {path} non contiene un file.")

            m = re.search(regex, str(path.parent) if from_dir else str(path.name), re.X | re.M)
            if m:
                gd = m.groupdict()
                day = int(gd["day"])
                month = int(gd["month"])
                year = int(gd["year"])
                distinct_dates.add(date(year, month, day).isoformat())
            else:
                raise ValueError(f"{path} non contiene indicazione di data ( o la regex è sbagliata ? )")

    return {"data": [{"date": v} for v in sorted(distinct_dates)], "errors": [], "meta": data["meta"]}


@task
def replace_sourcepath(
    data: TaskData, split_key_from: str, split_index: int, previous_source_type: str = "zip"
) -> dict[str, DataRow]:
    """Sostituisce i source_path di una lista di file.

    In caso di sorgente zip sostituisce con identificativo del sorgente originale
    arricchito del nome del file specifico.

    In questo modo è possibile eseguire il flusso

    PullStream -> DetectDelivery -> DownloadRemoteFiles -> Read* -> Ingest

    anche con file presenti all'interno di archivi :

    ```
    download = DownloadRemoteFiles()
    zipped_file = download()

    unzip = UnzipFile()
    unzipped_files = unzip(zipped_files)

    mapped_files = map_files(unzipped_files)

    deserialize = ReadCsv(...
    data = deserialize(mapped_files["NomeFile"])

    # in data il source_path è dato dalla combinazione di nome zip+nome file in esame
    # in questo modo un successivo task di Ingest resta idempotente a esecuzioni multiple
    # ( con solo il nome dello zip non saprebbe distinguere fra i dati dei diversi file interni )
    ```
    """
    output = {}
    for line in data["data"]:
        key = Path(line["path"]).name.split(split_key_from)[split_index]
        output[key] = {k: v for k, v in line.items()}

        if ".zip" in str(data["meta"]["source_path"]):
            path = Path(line["path"]).name
            dirn = Path(data["meta"]["source_path"]).parent
            name_zip = Path(str(data["meta"]["source_path"])).name.split("@")[0]
            source_path = f"{dirn}/{name_zip}:{path}@{data['meta']['timestamp'].replace(':','-')}"

            output[key].update({"source_path": source_path, "timestamp": data["meta"]["timestamp"]})
        else:
            output[key].update({"source_path": line["path"], "timestamp": data["meta"]["timestamp"]})

    return output
