import email
import imaplib
import os
import re
import smtplib
import ssl
from datetime import datetime, timedelta
from email.message import EmailMessage
from pathlib import Path
from typing import Any, List, Optional

import prefect
from prefect import Client

from pymol.ext.auth import from_vault
from pymol.jobs.core import Task
from pymol.jobs.evtl.utils import apprise_alert
from pymol.logger import LogLevel
from pymol.types.jobs import DataRow, TaskData


class SendMessage(Task):
    """Invia un messaggio su Teams.

    Esempio:

    ```
    send = SendMessage(
        limit_env=["prd", "stg"] # ambienti su cui inviare, di default solo prd
    )
    send({"subject": "some text",
          "msg": jinja_template,
          "type": "info",}) # è il the default, altri valori sono "success", "warning", "failure"
    ```
    """

    def __init__(
        self,
        limit_envs: list[str] = [
            "prd",
        ],
        **kwargs: Any,
    ):
        self.limit_envs = limit_envs
        super().__init__(**kwargs)

    def run(self, data: DataRow) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            _type = data["type"] if "type" in data else "info"
            res = apprise_alert(message=data["msg"], title=data["subject"], type=_type, limit_envs=self.limit_envs)

            if res is not None and res.status_code != 200:
                self.log.message(f"Fail chiamando l'alert server : {res.status_code}, {res.text}", LogLevel.WARNING)

        return {"data": [], "errors": [], "meta": {"hasErrors": res is not None and res.status_code != 200}}


class SendMail(Task):
    """Invia una Mail.

    Esempio:

    ```
    send = SendMail(conf="vault_mail_label")
    send({"subject": str,
          "from": str,
          "to": [str,...],
          "cc": [str,...],
          "bcc": [str,...],
          "msg": [str,...],}
          "attachments": [{"path": path/file/to/attach1.txt}, ..]")
    ```
    """

    def __init__(
        self,
        conf: str,
        subject_prefix: bool = True,
        **kwargs: Any,
    ):
        self._conf = conf
        self.subject_prefix = subject_prefix
        super().__init__(**kwargs)

    def _send(self, server: smtplib.SMTP, message: EmailMessage, data: dict[str, str]) -> None:
        if "cc" in data:
            message["Cc"] = data["cc"]
        if "bcc" in data:
            message["Bcc"] = data["bcc"]
        message.add_alternative(data["msg"], subtype="html")
        if "attachments" in data:
            for file_ in data["attachments"]:
                try:
                    with open(str(file_["path"]), "rb") as fp:  # type: ignore
                        file_data = fp.read()
                        message.add_attachment(
                            file_data,
                            maintype="application",
                            subtype=Path(file_["path"]).name.split("@")[0].split(".")[-1],  # type: ignore
                            filename=Path(file_["path"]).name,  # type: ignore
                        )

                except Exception as ex:
                    self.log.message(
                        f"Impossibile inviare mail: {str(ex)}",
                        LogLevel.ERROR,
                    )

        server.send_message(message)

    def run(  # type: ignore
        self,
        data: DataRow,
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            self.conf = from_vault(self._conf)
            message = EmailMessage()

            client = Client()

            try:
                flow_res = client.get_flow_run_info(prefect.context.flow_run_id)
                tenancy_ = os.getenv("TENANCY")
                project_ = flow_res.project
                subject_prefix = f"[{tenancy_}][{project_.name}]" if self.subject_prefix else ""
            except prefect.exceptions.ClientError:
                subject_prefix = "[loc]"

            message["Subject"] = f"{subject_prefix} {data['subject']}"
            message["From"] = data["from"]
            message["To"] = data["to"]

            if "username" in self.conf:
                with smtplib.SMTP(str(self.conf["server"])) as server:
                    try:
                        server.ehlo()
                        server.starttls(context=ssl.create_default_context())
                        server.login(str(self.conf["username"]), str(self.conf["password"]))
                        self._send(server, message, data)
                    except Exception as ex:
                        self.log.message(
                            f"Impossibile inviare mail: {str(ex)}",
                            LogLevel.ERROR,
                        )
                        return {"data": [], "errors": [], "meta": {"hasErrors": True}}
                    finally:
                        server.quit()
            else:
                with smtplib.SMTP(str(self.conf["server"])) as server:
                    try:
                        self._send(server, message, data)
                    except Exception as ex:
                        self.log.message(
                            f"Impossibile inviare mail: {str(ex)}",
                            LogLevel.ERROR,
                        )
                        return {"data": [], "errors": [], "meta": {"hasErrors": True}}
                    finally:
                        server.quit()

        return {"data": [], "errors": [], "meta": {"hasErrors": False}}


class ReadMail(Task):
    """Invia una Mail.

    Esempio:

    ```
    read = ReadMail(conf="vault_mail_label")
    read(
        folders = ["inbox",] #Lista delle cartelle
        unread_only = True #se si vogliono solo leggere le mail ancora non lette
        date_filter = "2022-02-11"  #filtro per data
        from_regex = ".*" #filtro mittente
        subject_regex = ".*" filtro per oggetto mail

    )
    ```
    Esempio da locale con Gmail
    1) assicurarsi di aver abilitata l'opzione "less secure apps" al link https://myaccount.google.com/lesssecureapps
    2) agiungere sul vault locale una configurazione ```vault_mail_label``` del tipo:
    ```
        {
            "password": "tuapassword",
            "server": "imap.gmail.com",
            "username": "tuousername@gmail.com"
        }
    ```

    """

    def __init__(
        self,
        conf: str,
        **kwargs: Any,
    ):
        self._conf = conf
        super().__init__(**kwargs)

    def get_body(self, msg) -> Any:  # type: ignore
        if msg.is_multipart():
            return self.get_body(msg.get_payload(0))  #
        else:
            return msg.get_payload(None, True)

    def get_emails(self, result_bytes) -> Any:  # type: ignore
        msgs = []
        for num in result_bytes[0].split():
            _, data = self.conn.fetch(num, "(RFC822)")
            msgs.append(data)
        return msgs

    def get_folders(self, conn: Any) -> List[str]:
        folders = conn.list()[1]
        _folders = [folder.decode("UTF-8").split('"')[3] for folder in folders]
        return _folders

    def match_rule(self, rule: str, value: str) -> bool:
        reg_ = re.compile(rule)
        match = re.search(reg_, value)
        if match:
            return True
        return False

    def add_to_output(
        self,
        row: Any,
        output: list[DataRow],
        check_condition: dict[str, bool],
        from_regex: str | None,
        subject_regex: str | None,
    ) -> None:
        if type(row) is tuple:
            email_ = email.message_from_bytes(row[1])
            if email_.is_multipart():
                for part in email_.walk():
                    ctype = part.get_content_type()
                    cdispo = str(part.get("Content-Disposition"))

                    if ctype == "text/plain" and "attachment" not in cdispo:
                        body = part.get_payload(decode=True)
            else:
                body = email_.get_payload(decode=True)

            if from_regex:
                check_condition["from_regex"] = self.match_rule(from_regex, email_["from"])

            if subject_regex:
                check_condition["subject_regex"] = self.match_rule(subject_regex, email_["subject"])

            if all(check_condition.values()):
                output.append(
                    {
                        "from": email_["from"],
                        "to": email_["to"],
                        "subject": email_["subject"],
                        "date": email_["date"],
                        "text": body,
                    }
                )

    def run(  # type:ignore
        self,
        folders: List[str] = [],
        unread_only: bool = False,
        date_filter: Optional[str] = None,
        from_regex: Optional[str] = None,
        subject_regex: Optional[str] = None,
    ) -> TaskData:
        output: list[DataRow] = []

        self.conf = from_vault(self._conf)
        user = str(self.conf["username"])
        password = str(self.conf["password"])
        imap_url = str(self.conf["server"])

        check_condition: dict[str, bool] = {}

        if from_regex:
            check_condition.update({"from_regex": False})

        if subject_regex:
            check_condition.update({"subject_regex": False})

        self.conn = imaplib.IMAP4_SSL(imap_url)
        self.conn.login(user, password)

        if date_filter:
            tmp_date = datetime.strptime(date_filter, "%Y-%m-%d")
            start_date = datetime.strftime(tmp_date, "%d-%b-%Y")
            end_date = datetime.strftime(tmp_date + timedelta(days=1), "%d-%b-%Y")
            grep_date = f'SINCE "{start_date}" BEFORE "{end_date}"'
        else:
            grep_date = ""

        only_unread = " UNSEEN" if unread_only else ""

        rule = f"({grep_date}{only_unread})"

        _folders = folders if len(folders) > 0 else self.get_folders(self.conn)
        for folder in _folders:
            folder_exists = self.conn.select(mailbox=f'"{folder}"')
            if folder_exists[0] == "OK":
                _, data = self.conn.search(None, rule)
                messages = self.get_emails(data)

                for message in messages[::-1]:
                    for row in message:
                        self.add_to_output(row, output, check_condition, from_regex, subject_regex)

        return {"data": output, "errors": [], "meta": {}}
