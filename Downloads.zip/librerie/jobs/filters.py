import pprint
from typing import Any, Optional, Set

import prefect
from prefect import task

from pymol.jobs.core import Task
from pymol.types.jobs import TaskData


@task
def peek(  # noqa
    rows: TaskData, show_lines: int = 1, desc: Optional[str] = None, errors: bool = False
) -> TaskData:  # pragma: nocover
    """Mostra a log le prime n righe di dati.

    Esempio:

    ```
    write = WriteCsv(
        fields=("a", "b", "c")...
    )
    write(peek(dati, 2, "esempio"))

    >> prime 2 righe da `esempio`
    >> {"a": ...}
    ```
    """
    logger = prefect.context.get("logger")
    _fetch = "data" if not errors else "errors"
    if not rows[_fetch]:  # type: ignore
        logger.warning(f"(nessuna riga {'in `'+desc+'`' if desc else _fetch})")
    else:
        logger.info(f"(prime {show_lines} righe {'da `'+desc+'`' if desc else _fetch})")
        pp = pprint.PrettyPrinter(indent=2)  # noqa
        peeked_rows = pp.pformat([d for d in rows[_fetch][0:show_lines]])  # type: ignore
        logger.info(peeked_rows)

    return rows


@task
def pick(data: TaskData, keys: Set[str]) -> TaskData:
    """Prende valori selezionati dai dati passati.

    Esempio:
    ```
    read = ReadCsv(
        fields=("a", "b", "c")...
    )
    dati = read("file")
    pick(dati, {"a"})

    >> [{"a": 1}, {"a": 2 ...
    ```
    """
    output = []
    for row in data["data"]:
        r = {}
        for key in keys:
            if "." in key:
                k1, k2 = key.split(".")
                r[f"{k1}__{k2}"] = row[k1][k2]
            else:
                r[key] = row[key]
        output.append(r)
    return {"data": output, "errors": data["errors"], "meta": data["meta"]}


class Pick(Task):
    def __init__(
        self,
        keys: Set[str],
        **kwargs: Any,
    ) -> None:
        self.keys = keys
        super().__init__(**kwargs)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        output = []
        for row in data["data"]:
            r = {}
            for key in self.keys:
                if "." in key:
                    k1, k2 = key.split(".")
                    r[f"{k1}__{k2}"] = row[k1][k2]
                else:
                    r[key] = row[key]
            output.append(r)
        return {"data": output, "errors": data["errors"], "meta": data["meta"]}
