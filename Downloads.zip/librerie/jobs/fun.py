from datetime import date
from typing import cast

import holidays
import pendulum


def _calculate_days(date_: date, days: int, skip_weekends: bool, skip_holidays: bool, countries: set[str]) -> date:
    if days == 0:
        return date_

    pdate = pendulum.datetime(date_.year, date_.month, date_.day)
    i = 0
    while i < abs(days):
        pdate = pdate.add(days=(-1 if days < 0 else +1))
        if not skip_weekends and not skip_holidays:
            i += 1
            continue

        skip_today = False
        if skip_holidays:
            for country in countries:
                if pdate.date() in getattr(holidays, country)():  # type: ignore
                    skip_today = True

        skip_weekend = False
        if skip_weekends and pdate.day_of_week in (pendulum.SATURDAY, pendulum.SUNDAY):  # type: ignore
            skip_weekend = True

        if not skip_today and not skip_weekend:
            i += 1

    return cast(date, pdate.date())  # type: ignore


def shift_date(date_: date, days: int, skip_weekends: bool, skip_holidays: bool, countries: set[str] = {"IT"}) -> date:
    return _calculate_days(date_, days, skip_weekends, skip_holidays, countries)
