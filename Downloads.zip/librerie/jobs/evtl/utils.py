import os
import re
from datetime import date, datetime, timezone
from typing import Any, Dict, NamedTuple, Optional, Union, cast

import prefect
import requests

key_pattern = re.compile(r"(?P<source>\w+)/(?P<date>\d{4}/\d{2}/\d{2})/(?P<filename>.+)@(?P<mtime>.*)")


class Key(NamedTuple):
    source: str
    date_: str
    date_obj: date
    filename: str
    mtime: str
    mtime_obj: datetime


def split_key(key: str) -> Key:
    """Split S3 key of a source file in all its component: source, date, filename, mtime.

    ```
    split_key("dsfi/2018/04/22/Market-2018-04-22.csv.gz@2018-04-23T18:15:56+00:00")
    Key(source='dsfi',
        date_='2018/04/22',
        date_obj=datetime.date(2018, 4, 22),
        filename='Market-2018-04-22.csv.gz',
        mtime='2018-04-23T18:15:56+00:00'
        mtime_obj=datetime.datetime(2018, 4, 23, 18, 15, 56, tzinfo=datetime.timezone.utc)
    ```
    """
    match = re.fullmatch(key_pattern, key)

    if not match:
        raise RuntimeError(f"Bad s3 key format: {key}")

    gd = match.groupdict()

    # workaround, pysmb cannot write filenames containing ":"
    mtime_l, mtime_r = gd["mtime"].split("T")
    mtime_obj = datetime.fromisoformat(f"{mtime_l}T{mtime_r.replace('-', ':')}")

    return Key(
        source=gd["source"],
        date_=gd["date"],
        date_obj=date(*(int(v) for v in gd["date"].split("/"))),
        filename=gd["filename"],
        mtime=gd["mtime"],
        mtime_obj=mtime_obj,
    )


def build_key(
    source: Optional[str],
    date_: Optional[Union[str, date]],
    filename: Optional[str],
    mtime: Optional[Union[str, datetime]],
) -> str:
    """Build S3 key where to store the downloaded file."""
    key = ""

    if source:
        key += f"{source}/"

    if date_:
        key += f"{_build_date(date_)}/"

    if filename:
        key += f"{filename}"

        if mtime:
            key += f"@{_build_datetime(mtime)}"

    return key


def _build_date(date_: Union[str, date]) -> str:
    if type(date_) is date:
        return date_.strftime("%Y/%m/%d")
    else:
        return cast(str, date_)


def _build_datetime(datetime_: Union[str, datetime]) -> str:
    if type(datetime_) is datetime:
        d = datetime_.replace(microsecond=0)
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        # workaround, pysmb cannot write filenames containing ":"
        return d.isoformat().replace(":", "-")
    else:
        return cast(str, datetime_)


def env_params() -> Dict[str, Any]:
    verbose_envs = {
        "tst": "pycc-test",
        "stg": "pycc-staging",
        "prd": "pycc",
        "aip": "aiml",
        "dts": "pycc-dmz-test",
        "loc": "local",
    }

    env = os.environ["DEPLOY_ENV"]
    tenancy = os.environ["TENANCY"] if "TENANCY" in os.environ else None
    project_name = prefect.context.__dict__["project_name"] if "project_name" in prefect.context.__dict__ else None
    host = f"https://prefect-{tenancy}.{verbose_envs[env]}.gmolapps.lcl/"
    run_name = prefect.context.__dict__["flow_run_name"] if "flow_run_name" in prefect.context.__dict__ else None
    flow_name = prefect.context.__dict__["flow_name"] if "flow_name" in prefect.context.__dict__ else None

    return {
        "env": env,
        "tenancy": tenancy,
        "project_name": project_name,
        "host": host,
        "verbose_envs": verbose_envs,
        "run_name": run_name,
        "flow_name": flow_name,
    }


def apprise_alert(
    message: str,
    title: str,
    type: str,
    limit_envs: list[str] = [
        "prd",
    ],
) -> requests.Response | None:
    res: requests.Response | None = None

    if "TENANCY" in os.environ:  # se non sono su una tenancy non mi importa di allertare
        _params = env_params()

        if os.environ["DEPLOY_ENV"] in limit_envs:
            res = requests.post(
                f"{os.environ['ALERT_SERVER']}/{_params['tenancy']}",
                json={"body": message, "title": title, "type": type},
            )
    return res
