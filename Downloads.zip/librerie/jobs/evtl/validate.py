import re
from collections import defaultdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import PosixPath
from typing import Any, Callable, Optional, Set, Union, cast

from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, ErrorRow, TaskData
from pymol.validation import Schema, SchemaError


class ValidateData(Task):
    """Valida dei dati in confronto ad uno schema.

    Esempio:

    ```
    valida = ValidateData(
        name="test_validate_data",
        schema=Schema({"id": int}),
        )
    dati = [
        {"id": 1, ....},    # passa, finisce in dati_e_errori["rows"]
        {"id": 1.0, ....},  # non passa, finisce in dati_e_errori["errors"]
        {"id": "1", ....},  # non passa, finisce in dati_e_errori["errors"]
    ]
    dati_e_errori = validate_function(dati)
    ```
    """

    def __init__(self, schema: Schema, **kwargs: Any) -> None:
        self.schema = schema
        super().__init__(**kwargs)

    def _validate(self, row: DataRow) -> tuple[bool, Union[DataRow, ErrorRow]]:
        try:
            validated = self.schema.validate(row)
        except SchemaError as err:
            msg = str(err).replace("\n", " ")
            return False, cast(ErrorRow, {"error": msg, "row": row.copy(), "source": row.copy()})
        return True, cast(DataRow, validated)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output, errors = [], []
            for row in data["data"]:
                is_valid, result = self._validate(row)
                if is_valid:
                    output.append(cast(DataRow, result))
                else:
                    self.log.warning(result)
                    errors.append(cast(ErrorRow, result))

            meta = data["meta"]
            meta["hasErrors"] = len(errors) > 0
            return cast(TaskData, dict(data=output, errors=errors, meta=meta))


# regexp -> filename -> matched groups
FilenamesGroupsType = dict[str, dict[str, Any]]
MatchesType = dict[str, FilenamesGroupsType]


def _any_strategy(regexps: set[str], regexp_matches: MatchesType) -> bool:
    # At least 1 match for any regexp
    return bool(regexp_matches)


def _all_strategy(regexps: set[str], regexp_matches: MatchesType) -> bool:
    # At least 1 match for each regexp
    return len(regexps) == len(regexp_matches)


def _exactly_any_strategy(regexps: set[str], regexp_matches: MatchesType) -> bool:
    # At least 1 match for any regexp but no more than 1 for any regexp
    return bool(regexp_matches) and all(len(matches) == 1 for matches in regexp_matches.values())


def _exactly_all_strategy(regexps: set[str], regexp_matches: MatchesType) -> bool:
    # Exactly 1 match for each regexp
    return len(regexps) == len(regexp_matches) and all(len(matches) == 1 for matches in regexp_matches.values())


def _is_valid_group(matches: FilenamesGroupsType) -> bool:
    if not matches:
        return False
    # Get OF from first match, they should all have the same OF value
    total_files = [int(d.get("OF", "0")) for d in matches.values()][0]
    # build sorted list of NUM values to compare with the expected
    all_numbers = sorted(int(d.get("NUM", "0")) for d in matches.values())
    return all_numbers == list(range(1, total_files + 1))


def _group_of_strategy(regexps: set[str], regexp_matches: MatchesType) -> bool:
    return all(_is_valid_group(regexp_matches.get(regepx, {})) for regepx in regexps)


class RuleStrategy(Enum):
    ANY = 1
    ALL = 2
    EXACTLY_ANY = 3
    EXACTLY_ALL = 4
    GROUP_OF = 5


RULE_STRATEGIES: dict[RuleStrategy, Callable[[set[str], MatchesType], bool]] = {
    RuleStrategy.ANY: _any_strategy,
    RuleStrategy.ALL: _all_strategy,
    RuleStrategy.EXACTLY_ANY: _exactly_any_strategy,
    RuleStrategy.EXACTLY_ALL: _exactly_all_strategy,
    RuleStrategy.GROUP_OF: _group_of_strategy,
}


def extract_filename(key: str) -> Any:
    return PosixPath(key).name.split("@")[0]


class DetectDelivery(Task):
    def __init__(
        self,
        repo_label: str,
        source_label: str,
        rule: Set[str],
        repo_path: str = "",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        rule_strategy: RuleStrategy = RuleStrategy.ANY,
        **kwargs: Any,
    ) -> None:
        self.repo_label = repo_label
        self.repo_path = repo_path.strip("/")
        self.source_label = source_label
        self.rule = rule
        self.rule_strategy = rule_strategy
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def follows_rule(self, filename: str, rule: Set[str]) -> bool:
        for rx in rule:
            m = re.match(rx, filename, re.X | re.M)
            if m:
                return True
        return False

    def follows_rule_strategy(self, keys: list[dict[str, str]]) -> bool:
        regexp_matches: MatchesType = defaultdict(dict)
        # Build regex -> filename -> groups dictionary so we can check if
        # the received files match the rule
        for filename in (extract_filename(k["path"]) for k in keys):
            for rx in self.rule:
                m = re.match(rx, filename, re.X | re.M)
                if m:
                    regexp_matches[rx][filename] = m.groupdict()
        return RULE_STRATEGIES[self.rule_strategy](self.rule, regexp_matches)

    def run(self, feed_date: str, rule_override: Optional[Set[str]] = None) -> TaskData:  # type: ignore
        output = []
        with self.log.start_action(self.name), self.log.timed(self.name):
            _date = datetime.strptime(feed_date, "%Y-%m-%d")

            if rule_override:
                self.rule = rule_override

            repo_conf = from_vault(self.repo_label)
            with ftp_conn(repo_conf) as conn:
                files = conn.describe(PosixPath(self.repo_path, self.source_label, _date.strftime("%Y/%m/%d")))
                for _, m in files.items():
                    filename = extract_filename(m.key)
                    if self.follows_rule(filename=filename, rule=self.rule):
                        output.append({"path": m.key})

            if not output:
                return cast(TaskData, dict(data=[], errors=[], meta={"isEmpty": True}))
            elif self.follows_rule_strategy(output):
                return cast(TaskData, dict(data=output, errors=[], meta={"isEmpty": False}))
            else:
                meta = {
                    "isEmpty": True,
                    "hasErrors": True,
                }
                errors = [
                    {"error": f'File {d["path"]} does not match rule {self.rule_strategy}', "source": d} for d in output
                ]
                return cast(TaskData, dict(data=[], errors=errors, meta=meta))


class DetectDeliveries(DetectDelivery):
    """Recupera la delivery del giorno e quella precedente.

    Se non ci sono delivery precedenti entro backtrack_days giorni va in errore.
    """

    def run(self, feed_date: str, backtrack_days: str) -> TaskData:  # type: ignore
        data = []
        feed_res = super().run(feed_date)
        if feed_res["meta"]["isEmpty"]:
            return feed_res

        data.extend(feed_res["data"])
        date_ = datetime.strptime(feed_date, "%Y-%m-%d")
        for _ in range(1, int(backtrack_days) + 1):
            date_ = date_ - timedelta(days=1)
            res = super().run(date_.strftime("%Y-%m-%d"))
            if not res["meta"]["isEmpty"]:
                data.extend(res["data"])
                return {"data": data, "errors": [], "meta": {"isEmpty": False}}

        return {
            "data": [],
            "errors": [{"error": f"Nessun file precedente per {backtrack_days} giorni", "source": {}}],
            "meta": {"isEmpty": True},
        }
