from datetime import date
from enum import Enum
from typing import Optional

import pyodbc

from pymol.types.exceptions import BusinessValueError


class TipoTransazione(Enum):
    MovimentoContoBancario = 1
    MovimentoContoTitoli = 2
    SaldoContoTitoli = 3
    Giroconto = 4
    ReportDa940 = 5
    CancellazioneMovimento = 6
    ReportMetalliDa940 = 7
    ReportDa941 = 8
    Multi940 = 9
    MovimentoContoBancarioCrea = 10
    Skip = 11
    ConsolidamentoGiroconto = 12
    GirocontoLombard = 13
    MovimentoConSaldoTitoli = 14
    OperazioneConImposte = 15
    ConsolidamentoCambioValuta = 16


class DbVal(Enum):
    NULL = 1
    DEFAULT = 2


def convert_fx(
    cursor: pyodbc.Cursor, src_cod_currency: int, dst_cod_currency: int, amount: float, fx_date: date = date.today()
) -> float:
    """Converti l'amount dalla currency src alla currency dst."""
    if int(src_cod_currency) == (dst_cod_currency):
        return amount

    cursor.execute(
        """SELECT Cambio FROM S_CambioValuta WHERE Data = ? and CodTipoCambioValuta = 1 AND CodValuta = ?""",
        fx_date,
        dst_cod_currency,
    )
    row = cursor.fetchone()
    if not row:
        cursor.execute("""SELECT Descrizione FROM D_Valuta WHERE Codice = ?""", dst_cod_currency)
        line = cursor.fetchone()
        raise BusinessValueError(f"Can't find {str(fx_date)} EUR to {line.Descrizione} FX")
    euro_to_dst = float(row[0])
    if src_cod_currency == 1:
        return round(float(amount * euro_to_dst), 6)

    cursor.execute(
        """SELECT Cambio FROM S_CambioValuta WHERE Data = ? and CodTipoCambioValuta = 1 AND CodValuta = ?""",
        fx_date,
        src_cod_currency,
    )
    row = cursor.fetchone()
    if not row:
        cursor.execute("""SELECT Descrizione FROM D_Valuta WHERE Codice = ?""", src_cod_currency)
        line = cursor.fetchone()
        raise BusinessValueError(f"Can't find {str(fx_date)} EUR to {src_cod_currency} FX")
    euro_to_src = float(row[0])
    amount_in_euro = amount * (1 / euro_to_src)

    return round(float(amount_in_euro * euro_to_dst), 6)


def merge_amount(
    cursor: pyodbc.Cursor, amounts: list[tuple[float, int]], desired_currency: int, fx_date: date = date.today()
) -> Optional[float]:
    output = 0.0
    for partial_amount, amount_currency in amounts:
        output += convert_fx(cursor, amount_currency, desired_currency, partial_amount, fx_date)
    return output


def next_progressivo_conto(cursor: pyodbc.Cursor, id_conto_bancario_annuo: int) -> int:
    cursor.execute(
        """
    SELECT  MAX(T_MovimentoContoBancario.Progressivo)
    FROM T_MovimentoContoBancario
    WHERE T_MovimentoContoBancario.IdContoBancarioPerAnno = ?""",
        id_conto_bancario_annuo,
    )
    res = cursor.fetchone()
    if res[0]:
        return int(res[0]) + 1
    return 1


COD_VALUTA: dict[str, int] = {
    "EUR": 1,
    "CHF": 2,
    "GBP": 3,
    "USD": 4,
    "AAA": 6,
    "DKK": 7,
    "NOK": 8,
    "SEK": 9,
    "TRL": 10,
    "CAD": 12,
    "KES": 22,
    "PKR": 26,
    "CLP": 29,
    "INR": 31,
    "LBP": 32,
    "MTL": 33,
    "VEB": 35,
    "SYP": 36,
    "COP": 40,
    "XAF": 43,
    "GIP": 44,
    "BGL": 45,
    "CYP": 46,
    "ALL": 47,
    "ZWD": 51,
    "UYU": 53,
    "MYR": 55,
    "IRR": 57,
    "LKR": 58,
    "ISK": 62,
    "SOS": 65,
    "PHP": 66,
    "CUP": 67,
    "ETB": 68,
    "LYD": 69,
    "EGP": 70,
    "JPY": 71,
    "THB": 73,
    "BOB": 74,
    "SAR": 75,
    "CRC": 77,
    "GTQ": 78,
    "SDD": 79,
    "TND": 80,
    "NGN": 81,
    "ZAR": 82,
    "DJF": 83,
    "MAD": 84,
    "AOA": 87,
    "JOD": 89,
    "IQD": 93,
    "PYG": 101,
    "KWD": 102,
    "HKD": 103,
    "XPF": 105,
    "DZD": 106,
    "MMK": 107,
    "AUD": 109,
    "GHC": 111,
    "NZD": 113,
    "AFN": 115,
    "DOP": 116,
    "SVC": 117,
    "HNL": 118,
    "KRW": 119,
    "NIO": 120,
    "YER": 122,
    "IDR": 123,
    "SGD": 124,
    "TZS": 125,
    "UGX": 126,
    "ZMK": 127,
    "GNF": 129,
    "MGF": 130,
    "ROL": 131,
    "ANG": 132,
    "MZM": 133,
    "BSD": 135,
    "BHD": 136,
    "XCD": 137,
    "BMD": 138,
    "BND": 139,
    "BIF": 140,
    "KHR": 141,
    "JMD": 142,
    "TWD": 143,
    "CNY": 144,
    "VND": 145,
    "FKP": 146,
    "FJD": 147,
    "ZMW": 148,
    "GYD": 149,
    "SRG": 150,
    "HTG": 151,
    "BZD": 152,
    "HUF": 153,
    "LAK": 154,
    "LRD": 155,
    "MOP": 156,
    "MWK": 157,
    "MVR": 158,
    "MNT": 160,
    "NPR": 161,
    "PAB": 162,
    "RWF": 163,
    "WST": 164,
    "SLL": 165,
    "TTD": 166,
    "TOP": 167,
    "MUR": 170,
    "BWP": 171,
    "LSL": 172,
    "SZL": 173,
    "BDT": 174,
    "BTN": 180,
    "CVE": 181,
    "KPW": 182,
    "OMR": 184,
    "SCR": 185,
    "AED": 187,
    "XDR": 188,
    "QAR": 189,
    "PGK": 190,
    "STD": 191,
    "GMD": 193,
    "BBD": 195,
    "MRO": 196,
    "PEN": 201,
    "ILS": 203,
    "KYD": 205,
    "SBD": 206,
    "SHP": 207,
    "VUV": 208,
    "XOF": 209,
    "KMF": 210,
    "AWG": 211,
    "YUM": 214,
    "SIT": 215,
    "ARS": 216,
    "EEK": 218,
    "LVL": 219,
    "LTL": 221,
    "MXN": 222,
    "CZK": 223,
    "SKK": 224,
    "KGS": 225,
    "TMM": 228,
    "HRK": 229,
    "GEL": 230,
    "KZT": 231,
    "UZS": 232,
    "BRL": 234,
    "MDL": 235,
    "MKD": 236,
    "PLN": 237,
    "AZM": 238,
    "BAM": 240,
    "UAH": 241,
    "ERN": 243,
    "RUB": 244,
    "ADP": 245,
    "AMD": 246,
    "NAD": 252,
    "CDF": 261,
    "BGN": 262,
    "BYR": 263,
    "TJS": 264,
    "CSD": 265,
    "SRD": 266,
    "TRY": 267,
    "MGA": 268,
    "RON": 270,
    "AZN": 271,
    "MZN": 272,
    "RSD": 274,
    "SDG": 275,
    "GHS": 276,
    "VEF": 277,
    "TMT": 278,
    "SSP": 279,
    "NLG": 280,
    "M_V": 281,
    "VTS": 999,
}
