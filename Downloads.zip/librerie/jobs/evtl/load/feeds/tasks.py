import json
import os
import re
from collections import namedtuple
from datetime import date, datetime, timedelta
from decimal import Decimal as D
from typing import Any, Iterable, Optional, Set, Union, cast

import pendulum
import pyodbc
import requests
from prefect import context
from pyodbc import Cursor, OperationalError, Row

from pymol.ext.auth import from_vault
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, FieldRule, RuleDict, Task
from pymol.jobs.evtl.extract.csv import ReadCsv
from pymol.jobs.evtl.extract.xls import ReadExcel
from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import AdditionalParams, DataRow, DBObject, ExtParams, MessageState, TaskData
from pymol.validation import Schema, SchemaError

from .utils import _file_date, _file_time

tz_rome = pendulum.timezone("Europe/Rome")  # type: ignore


def from_swift_tag(values: list[str], key: str, index: int, sep: str = "/") -> str:
    for obj in values:
        if obj[0 : len(key)] == key:
            return obj.split(sep)[index]
    raise BusinessValueError(f"Tag SWIFT malformato: {str(values)}")


def _eventually_rename_columns(msg: DataRow, schema: dict[str, FieldRule]) -> DataRow:
    if all([fr.ingest_column is None for fr in schema.values()]):
        return msg

    out_row: DataRow = {}
    for key, value in msg.items():
        if schema[key].ingest_column is not None:
            out_row[schema[key].ingest_column] = value  # type: ignore
        else:
            out_row[key] = value
    return out_row


class ReadExcelDelivery(Task):
    """."""

    def __init__(
        self,
        rule: RuleDict,
        data_start_row: int,
        path_label: str = "path",
        headless: bool = False,
        header_row: int | None = None,
        duplicated_columns: bool = False,
        fix_powerapp_columns: bool = False,
        fix_dimensions: bool = True,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.rule = rule
        self.data_start_row = data_start_row
        self.path_label = path_label
        self.headless = headless
        self.header_row = header_row
        self.duplicated_columns = duplicated_columns
        self.fix_powerapp_columns = fix_powerapp_columns
        self.fix_dimensions = fix_dimensions

        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: DataRow, encoding: Optional[str] = None) -> list[TaskData]:  # type: ignore
        output = []
        for file_ in data["data"]:
            filename = file_["path"].name
            for regex, sheets in self.rule.items():
                if re.search(regex, filename) is not None:
                    for sheet in sheets:
                        schema = self.rule[regex][sheet]
                        output.append(
                            ReadExcel(
                                fields=schema.keys(),
                                sheet_name=sheet,
                                data_start_row=self.data_start_row,
                                path_label=self.path_label,
                                headless=self.headless,
                                header_row=self.header_row,
                                duplicated_columns=self.duplicated_columns,
                                fix_powerapp_columns=self.fix_powerapp_columns,
                                fix_dimensions=self.fix_dimensions,
                                external_fields=tuple([f for f in schema.keys() if schema[f].external]),
                            ).run(data=file_),
                        )
                    break
            else:
                error = f'Impossibile trovare una regola per il file {file_["path"].name}'
                self.logger.warning(error)
                return [{"data": [], "errors": [{"error": error, "source": file_["path"].name}], "meta": data["meta"]}]

        return output


class ReadCsvDelivery(Task):
    """."""

    def __init__(
        self,
        rule: RuleDict,
        headless: bool = False,
        encoding: str = "utf-8",
        skip_lines: int = 0,
        allow_missing_cols: bool = False,
        custom_nones: set[str] = set(),
        options: dict[str, str] = {},
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.rule = rule
        self.headless = headless
        self.encoding = encoding
        self.skip_lines = skip_lines
        self.allow_missing_cols = allow_missing_cols
        self.custom_nones = custom_nones
        self.options = options
        self.path_label = path_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: DataRow, encoding: Optional[str] = None) -> TaskData:  # type: ignore
        filename = data["path"].name
        for regex in self.rule:
            if re.search(regex, filename) is not None:
                if "-" not in self.rule[regex]:
                    raise RuntimeError("La regola dei file csv deve avere un solo foglio '-'")
                schema = self.rule[regex]["-"]
                break
        else:
            error = f"Impossibile trovare una regola per il file {data['path']}"
            self.logger.warning(error)
            return {"data": [], "errors": [{"error": error, "source": data["path"]}], "meta": {}}

        output = ReadCsv(
            fields=schema.keys(),  # type: ignore
            headless=self.headless,
            encoding=self.encoding,
            skip_lines=self.skip_lines,
            allow_missing_cols=self.allow_missing_cols,
            custom_nones=self.custom_nones,
            options=self.options,
            path_label=self.path_label,
        ).run(data=data, encoding=encoding)

        return output


class IngestFeedFast(Task):
    """Salva dati letti da una sorgente su db.

    Metadati relativi al momento dell'esecuzione e sorgente dei dati vengono salvati in una tabella comune 'E_Meta'

    Esempio:

    ```
    ingest = IngestFeed(
        db="il_db",
        provider="la_banca",
        feed="il_flusso",
        )
    ingest(data)
    ```
    """

    def __init__(
        self,
        db: str,
        provider: str,
        feed: str,
        schema: Schema | None = None,
        rules: dict[str, FieldRule] = {},
        values_from_filename: str | None = None,
        time_rx: str | None = None,
        scrap_tags: tuple[str, ...] = (),
        overwrite: bool = False,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        self.provider = provider
        self.feed = feed
        self.values_from_filename = values_from_filename
        self.time_rx = time_rx
        self.scrap_tags = scrap_tags
        self.schema = schema
        self.rules = rules
        self.overwrite = overwrite
        self._accumulated_rows: dict[str, list[DataRow]] = {}

        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']}"
        )
        self.dbconn = pyodbc.connect(self.db_params)
        self.cursor = self.dbconn.cursor()

    def get_msgtype(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> str | None:
        """Torna il msg_type o uno SchemaError."""
        return None

    def get_routing_tags(self, values: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> list[str]:
        """Torna una lista di tags operativi associati al messaggio."""
        return []

    def get_msgvalues(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> tuple[str, DataRow]:
        try:
            output = self.from_msg(msg, extra_values)
            self.logger.warning("Deprecato: usare get_msgtype, get_msgvalues, get_msgtags invece di from_msg")
            return output
        except Exception as ex:
            raise ex

    def from_msg(self, values: DataRow, extra_values: DataRow) -> tuple[str, DataRow]:
        raise NotImplementedError(
            "Devi implementare la logica di estrazione dei valori del messaggio: "
            "get_msgtype, get_routing_tags e get_msgvalues."
        )

    def close(self) -> None:
        if self.dbconn:
            self.dbconn.close()

    def log_meta(
        self, source_path: str, pull_ts: datetime, validation_errors: int, sheet_name: str = "-"
    ) -> tuple[int, bool]:
        fname = str(source_path).split("@")[0]
        self.cursor.execute(  # todo questa query non funziona per i file zippati
            """SELECT id, ingested, ingest_ts FROM pycc.E_Meta WHERE source_file LIKE ?""",
            f"{fname}%",
        )

        rs = self.cursor.fetchone()
        if rs:
            if self.overwrite:
                self.cursor.execute(
                    """
                UPDATE pycc.E_Meta SET source_file = ?, pull_ts = ?, ingest_ts = ?, validation_errors = ? WHERE id = ?
                """,
                    str(source_path),
                    pull_ts,
                    datetime.now(),
                    validation_errors,
                    rs.id,
                )
            json_dict = json.loads(rs.ingested)
            self.dbconn.commit()
            return rs.id, (sheet_name in json_dict and json_dict[sheet_name] == 1)

        file_date = _file_date(str(source_path))
        file_time = _file_time(str(source_path), self.time_rx) if self.time_rx else None

        self.cursor.execute(
            """
        INSERT INTO pycc.E_Meta
        (source_file, file_date, file_time, pull_ts, ingest_ts, validation_errors, ingested, provider, feed)
        OUTPUT Inserted.id
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            str(source_path),
            file_date,
            file_time,
            pull_ts,
            datetime.now(),
            validation_errors,
            json.dumps({sheet_name: 0}),
            self.provider,
            self.feed,
        )
        meta_id = self.cursor.fetchone()[0]
        self.dbconn.commit()
        return meta_id, False

    def set_ingested(self, meta_id: int, sheet_name: str = "-") -> None:
        self.cursor.execute(
            """
        SELECT ingested FROM pycc.E_Meta WHERE id = ?
        """,
            meta_id,
        )

        ingested_json = json.loads(self.cursor.fetchone()[0])
        ingested_json[sheet_name] = 1

        self.cursor.execute(
            """
        UPDATE pycc.E_Meta SET ingested = ? WHERE id = ?
        """,
            json.dumps(ingested_json),
            meta_id,
        )

    def write_error(self, meta_id: int, msg: str, error_msg: str, msg_type: str | None) -> None:
        self.cursor.execute(
            """
        INSERT INTO pycc.E_Scraps VALUES (?, ?, ?, ?, ?, ?)
        """,
            meta_id,
            msg,
            error_msg,
            msg_type,
            "UNP",
            json.dumps({t: "UNP" for t in self.scrap_tags}) if len(self.scrap_tags) > 0 else "{}",
        )

    def delete_row(self, meta_id: int, values: DataRow, extra_values: DataRow) -> None:
        already_deleted = set()
        try:
            table, _ = self.from_msg(values, extra_values)
        except BusinessValueError as exc:
            self.logger.warning(f"Impossibile estrarre il messaggio: {exc}")
        else:
            if table not in already_deleted:
                self.cursor.execute(f"DELETE FROM {table} WHERE meta_id = ?", meta_id)
                already_deleted.add(table)

    def _accumulate_row(
        self,
        meta_id: int,
        values: DataRow,
        extra_values: DataRow,
        task_meta: dict[str, Any],
        msg_type: str | None,
        routing_tags: list[str],
    ) -> None:
        try:
            table, values = self.get_msgvalues(values, extra_values, task_meta)
            values["routing_state"] = json.dumps({t: "UNP" for t in routing_tags}) if len(routing_tags) > 0 else "{}"
        except BusinessValueError as exc:
            self.logger.warning(f"Impossibile estrarre il messaggio: {exc}")
        else:
            if table is not None:
                values["meta_id"] = meta_id
                if "msg_type" not in values:  # todo remove once migrated
                    values["msg_type"] = msg_type
                if table in self._accumulated_rows:
                    self._accumulated_rows[table].append(values)
                else:
                    self._accumulated_rows[table] = [values]

    def _source_path_and_ts(self, data: TaskData, source_path: Optional[str]) -> tuple[str, datetime]:
        if not source_path and "source_path" not in data["meta"]:
            raise ValueError(
                "Il source file per i dati deve; o essere presente nel meta di TaskData "
                "o specificato / overridato come argomento"
            )

        if source_path:
            _file_date(source_path)
            pull_ts = datetime.now()
        else:
            source_path = str(data["meta"]["source_path"])
            pull_ts = datetime.strptime(data["meta"]["timestamp"], "%Y-%m-%dT%H:%M:%S+00:00")

        return (source_path, pull_ts)

    def accumulate_row(
        self, msg_: DataRow, source_path_: str, task_meta: dict[str, Any], is_ingested: bool, meta_id: int
    ) -> None:
        msg = msg_.copy()
        xvals = _extra_values(
            rule=self.values_from_filename,
            source_path=source_path_,
        )
        msg_type = None
        try:
            msg_type = self.get_msgtype(msg, xvals, task_meta)
            routing_tags = self.get_routing_tags(msg, xvals, task_meta)
            if self.schema:
                msg = (
                    _eventually_rename_columns(self.schema.validate(msg), self.rules)
                    if self.rules
                    else self.schema.validate(msg)
                )

            if is_ingested and self.overwrite:
                self.delete_row(meta_id, msg, xvals)
            self._accumulate_row(
                meta_id,
                msg,
                xvals,
                task_meta,
                msg_type,
                routing_tags,
            )
        except SchemaError as err:
            error_msg = str(err).replace("\n", " ")
            self.write_error(meta_id, str(msg), error_msg, msg_type)

    def write_bulks(self) -> None:
        for table, rows in self._accumulated_rows.items():
            if len(rows) > 0:
                self.cursor.fast_executemany = True
                self.cursor.executemany(
                    f"""
                INSERT INTO {table}
                ([{'],['.join(rows[0].keys())}])
                VALUES ({','.join(['?'] * len(rows[0]))})""",
                    [tuple(row.values()) for row in rows],
                )

    def run(  # type: ignore[override]
        self, data: TaskData, source_path: str | None = None, overwrite: bool | None = None
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            task_meta = data["meta"].copy()
            task_meta["overridden_source_path"] = source_path
            source_path_, pull_ts = self._source_path_and_ts(data, source_path)
            self.overwrite = overwrite if overwrite is not None else self.overwrite
            try:
                self.open()
                meta_id, is_ingested = self.log_meta(
                    source_path_,
                    pull_ts,
                    len(data["errors"]),
                    data["meta"]["sheet"] if "sheet" in data["meta"] and data["meta"]["sheet"] else "-",
                )
                if not is_ingested or (is_ingested and self.overwrite):
                    ld = len(data["data"])
                    for count, msg_ in enumerate(data["data"]):
                        if count % 1000 == 0:
                            self.logger.info(f"Accumulati {count} di {ld} messaggi")
                        self.accumulate_row(msg_, source_path_, task_meta, is_ingested, meta_id)
                    for invalid_msg in data["errors"]:
                        self.write_error(meta_id, str(invalid_msg["source"]), invalid_msg["error"], None)
                    self.write_bulks()
                    self.set_ingested(
                        meta_id, data["meta"]["sheet"] if "sheet" in data["meta"] and data["meta"]["sheet"] else "-"
                    )
                else:
                    self.logger.info(f"Skippo file già salvato: {source_path_}")
                self.dbconn.commit()
                return data
            except OperationalError as exc:
                self.logger.warning(f"Impossibile connettersi al database '{self.db}': {exc}")
                raise exc
            except Exception as exc:
                self.dbconn.rollback()
                self.logger.error(f"Errore inatteso {exc.__class__} : {exc}. Processando il file (meta id): {meta_id}")
                raise exc
            finally:
                self.close()


class IngestFeed(Task):
    """Salva dati letti da una sorgente su db.

    Metadati relativi al momento dell'esecuzione e sorgente dei dati vengono salvati in una tabella comune 'E_Meta'

    Esempio:

    ```
    ingest = IngestFeed(
        db="il_db",
        provider="la_banca",
        feed="il_flusso",
        )
    ingest(data)
    ```
    """

    def __init__(
        self,
        db: str,
        provider: str,
        feed: str,
        schema: Schema | None = None,
        rules: dict[str, FieldRule] = {},
        values_from_filename: str | None = None,
        time_rx: str | None = None,
        scrap_tags: tuple[str, ...] = (),
        overwrite: bool = False,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        self.provider = provider
        self.feed = feed
        self.values_from_filename = values_from_filename
        self.time_rx = time_rx
        self.scrap_tags = scrap_tags
        self.schema = schema
        self.rules = rules
        self.overwrite = overwrite

        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']}"
        )
        self.dbconn = pyodbc.connect(self.db_params)
        self.cursor = self.dbconn.cursor()

    def get_msgtype(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> str | None:
        """Torna il msg_type o uno SchemaError."""
        return None

    def get_routing_tags(self, values: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> list[str]:
        """Torna una lista di tags operativi associati al messaggio."""
        return []

    def get_msgvalues(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> tuple[str, DataRow]:
        try:
            output = self.from_msg(msg, extra_values)
            self.logger.warning("Deprecato: usare get_msgtype, get_msgvalues, get_msgtags invece di from_msg")
            return output
        except Exception as ex:
            raise ex

    def from_msg(self, values: DataRow, extra_values: DataRow) -> tuple[str, DataRow]:
        raise NotImplementedError(
            "Devi implementare la logica di estrazione dei valori del messaggio: "
            "get_msgtype, get_routing_tags e get_msgvalues."
        )

    def close(self) -> None:
        if self.dbconn:
            self.dbconn.close()

    def log_meta(
        self, source_path: str, pull_ts: datetime, validation_errors: int, sheet_name: str = "-"
    ) -> tuple[int, bool]:
        fname = str(source_path).split("@")[0]
        self.cursor.execute(  # todo questa query non funziona per i file zippati
            """SELECT id, ingested, ingest_ts FROM pycc.E_Meta WHERE source_file LIKE ?""",
            f"{fname}%",
        )

        rs = self.cursor.fetchone()
        if rs:
            if self.overwrite:
                self.cursor.execute(
                    """
                UPDATE pycc.E_Meta SET source_file = ?, pull_ts = ?, ingest_ts = ?, validation_errors = ? WHERE id = ?
                """,
                    str(source_path),
                    pull_ts,
                    datetime.now(),
                    validation_errors,
                    rs.id,
                )
            json_dict = json.loads(rs.ingested)
            self.dbconn.commit()
            return rs.id, (sheet_name in json_dict and json_dict[sheet_name] == 1)

        file_date = _file_date(str(source_path))
        file_time = _file_time(str(source_path), self.time_rx) if self.time_rx else None

        self.cursor.execute(
            """
        INSERT INTO pycc.E_Meta
        (source_file, file_date, file_time, pull_ts, ingest_ts, validation_errors, ingested, provider, feed)
        OUTPUT Inserted.id
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            str(source_path),
            file_date,
            file_time,
            pull_ts,
            datetime.now(),
            validation_errors,
            json.dumps({sheet_name: 0}),
            self.provider,
            self.feed,
        )
        meta_id = self.cursor.fetchone()[0]
        self.dbconn.commit()
        return meta_id, False

    def set_ingested(self, meta_id: int, sheet_name: str = "-") -> None:
        self.cursor.execute(
            """
        SELECT ingested FROM pycc.E_Meta WHERE id = ?
        """,
            meta_id,
        )

        ingested_json = json.loads(self.cursor.fetchone()[0])
        ingested_json[sheet_name] = 1

        self.cursor.execute(
            """
        UPDATE pycc.E_Meta SET ingested = ? WHERE id = ?
        """,
            json.dumps(ingested_json),
            meta_id,
        )

    def write_error(self, meta_id: int, msg: str, error_msg: str, msg_type: str | None) -> None:
        self.cursor.execute(
            """
        INSERT INTO pycc.E_Scraps VALUES (?, ?, ?, ?, ?, ?)
        """,
            meta_id,
            msg,
            error_msg,
            msg_type,
            "UNP",
            json.dumps({t: "UNP" for t in self.scrap_tags}) if len(self.scrap_tags) > 0 else "{}",
        )

    def delete_row(self, meta_id: int, values: DataRow, extra_values: DataRow) -> None:
        already_deleted = set()
        try:
            table, _ = self.from_msg(values, extra_values)
        except BusinessValueError as exc:
            self.logger.warning(f"Impossibile estrarre il messaggio: {exc}")
        else:
            if table not in already_deleted:
                self.cursor.execute(f"DELETE FROM {table} WHERE meta_id = ?", meta_id)
                already_deleted.add(table)

    def _write_row(
        self,
        meta_id: int,
        values: DataRow,
        extra_values: DataRow,
        task_meta: dict[str, Any],
        msg_type: str | None,
        routing_tags: list[str],
    ) -> None:
        try:
            table, values = self.get_msgvalues(values, extra_values, task_meta)
            values["routing_state"] = json.dumps({t: "UNP" for t in routing_tags}) if len(routing_tags) > 0 else "{}"
        except BusinessValueError as exc:
            self.logger.warning(f"Impossibile estrarre il messaggio: {exc}")
        else:
            if table is not None:
                values["meta_id"] = meta_id
                if "msg_type" not in values:  # todo remove once migrated
                    values["msg_type"] = msg_type
                self.cursor.execute(
                    f"""
                        INSERT INTO {table}
                        ([{'],['.join(values.keys())}])
                        VALUES ({','.join(['?' for _ in values.values()])})""",
                    *[values[c] for c in values],
                )

    def _source_path_and_ts(self, data: TaskData, source_path: Optional[str]) -> tuple[str, datetime]:
        if not source_path and "source_path" not in data["meta"]:
            raise ValueError(
                "Il source file per i dati deve; o essere presente nel meta di TaskData "
                "o specificato / overridato come argomento"
            )

        if source_path:
            _file_date(source_path)
            pull_ts = datetime.now()
        else:
            source_path = str(data["meta"]["source_path"])
            pull_ts = datetime.strptime(data["meta"]["timestamp"], "%Y-%m-%dT%H:%M:%S+00:00")

        return (source_path, pull_ts)

    def write_row(
        self, msg_: DataRow, source_path_: str, task_meta: dict[str, Any], is_ingested: bool, meta_id: int
    ) -> None:
        msg = msg_.copy()
        xvals = _extra_values(
            rule=self.values_from_filename,
            source_path=source_path_,
        )
        msg_type = None
        try:
            msg_type = self.get_msgtype(msg, xvals, task_meta)
            routing_tags = self.get_routing_tags(msg, xvals, task_meta)
            if self.schema:
                msg = (
                    _eventually_rename_columns(self.schema.validate(msg), self.rules)
                    if self.rules
                    else self.schema.validate(msg)
                )

            if is_ingested and self.overwrite:
                self.delete_row(meta_id, msg, xvals)
            self._write_row(
                meta_id,
                msg,
                xvals,
                task_meta,
                msg_type,
                routing_tags,
            )
        except SchemaError as err:
            error_msg = str(err).replace("\n", " ")
            self.write_error(meta_id, str(msg), error_msg, msg_type)

    def run(  # type: ignore[override]
        self, data: TaskData, source_path: str | None = None, overwrite: bool | None = None
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            task_meta = data["meta"].copy()
            task_meta["overridden_source_path"] = source_path
            source_path_, pull_ts = self._source_path_and_ts(data, source_path)
            self.overwrite = overwrite if overwrite is not None else self.overwrite
            try:
                self.open()
                meta_id, is_ingested = self.log_meta(
                    source_path_,
                    pull_ts,
                    len(data["errors"]),
                    data["meta"]["sheet"] if "sheet" in data["meta"] and data["meta"]["sheet"] else "-",
                )
                if not is_ingested or (is_ingested and self.overwrite):
                    ld = len(data["data"])
                    for count, msg_ in enumerate(data["data"]):
                        if count % 1000 == 0:
                            self.logger.info(f"CHECK - {ld-count} messaggi alla fine dell'ingest")
                        self.write_row(msg_, source_path_, task_meta, is_ingested, meta_id)
                    for invalid_msg in data["errors"]:
                        self.write_error(meta_id, str(invalid_msg["source"]), invalid_msg["error"], None)
                    self.set_ingested(
                        meta_id, data["meta"]["sheet"] if "sheet" in data["meta"] and data["meta"]["sheet"] else "-"
                    )
                else:
                    self.logger.info(f"Skippo file già salvato: {source_path_}")
                self.dbconn.commit()
                return data
            except OperationalError as exc:
                self.logger.warning(f"Impossibile connettersi al database '{self.db}': {exc}")
                raise exc
            except Exception as exc:
                self.dbconn.rollback()
                self.logger.error(f"Errore inatteso {exc.__class__} : {exc}. Processando il file (meta id): {meta_id}")
                raise exc
            finally:
                self.close()


class IngestDelivery(Task):
    def __init__(
        self,
        db: str,
        provider: str,
        feed: str,
        rule: dict[str, dict[str, Any]],
        ingest_class: type[IngestFeed],
        values_from_filename: str | None = None,
        time_rx: str | None = None,
        scrap_tags: tuple[str, ...] = (),
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        self.provider = provider
        self.feed = feed
        self.rule = rule
        self.ingest_class = ingest_class
        self.values_from_filename = values_from_filename
        self.time_rx = time_rx
        self.scrap_tags = scrap_tags
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData, feed_override: Optional[str] = None) -> TaskData:  # type: ignore
        filename = data["meta"]["path"].name
        for regex in self.rule:
            if re.search(regex, filename) is not None:
                schema = {k: v.type_ for k, v in self.rule[regex][data["meta"]["sheet"]].items()}
                rule = self.rule[regex][data["meta"]["sheet"]]
                break
        else:
            error = f"Impossibile trovare una regola per il file {data['meta']['path']}"
            self.logger.warning(error)
            return {"data": [], "errors": [{"error": error, "source": data["meta"]["path"]}], "meta": {}}

        output = self.ingest_class(
            db=self.db,
            provider=self.provider,
            feed=self.feed if not feed_override else feed_override,
            schema=Schema(schema),
            rules=rule,
            values_from_filename=self.values_from_filename,
            scrap_tags=self.scrap_tags,
        ).run(data)

        return output


class TranslateDelivery(Task):
    def __init__(
        self,
        db: str,
        provider: str,
        feed: str,
        tables: list[str],
        factory: type,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        self.provider = provider
        self.feed = feed
        self.tables = tables
        self.factory_ = factory
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']}"
        )
        self.dbconn = pyodbc.connect(self.db_params)
        self.cursor = self.dbconn.cursor()
        self.factory = self.factory_(self.cursor)

    def close(self) -> None:
        self.dbconn.close()

    def get_messages(
        self, table: str, on_date: date, msg_type: str, valid_destinations: str, chiave_cliente: str, provider: str
    ) -> Iterable[Any]:
        join_chiave_cliente = ""
        filter_chiave_cliente = ""
        if chiave_cliente:
            join_chiave_cliente = " JOIN pycc.E_InfoAccount_Qtask iaq ON account_number_1 = iaq.account"
            chiavi = ", ".join(f"'{p.strip()}'" for p in chiave_cliente.split(","))
            filter_chiave_cliente = f"AND iaq.chiaveClienteMaster IN ({chiavi}) AND iaq.provider = '{provider}'"

        if msg_type:
            msg_filter = f"AND msg_type = '{msg_type}'"
        else:
            msg_filter = ""

        valid_dest = ""
        if valid_destinations:
            dests = valid_destinations.split(",")
            for dest in dests:
                valid_dest += (
                    f"(routing_state LIKE '%{dest}%')" if not valid_dest else f" OR (routing_state LIKE '%{dest}%')"
                )

        self.cursor.execute(
            f"""SELECT {table}.*, E_Meta.provider, E_Meta.feed, CONCAT('{table}:', {table}.id) AS source FROM
            {table} JOIN pycc.E_Meta ON meta_id = pycc.E_Meta.id {join_chiave_cliente}
            WHERE {table}.msg_state IN
            ('{MessageState.Unprocessed.value}', '{MessageState.GaveError.value}') AND
            pycc.E_Meta.file_date = ? {msg_filter} AND ({valid_dest}) {filter_chiave_cliente}
            ORDER BY pycc.E_Meta.file_time, pycc.E_Meta.ingest_ts ASC""",
            on_date,
        )
        rows = self.cursor.fetchall()
        return cast(Iterable[Any], rows)

    def get_scarti(self, on_date: date) -> Iterable[Any]:
        table = "pycc.E_Scraps"
        self.cursor.execute(
            f"""SELECT {table}.*, E_Meta.provider, E_Meta.feed, CONCAT('{table}:', {table}.id) AS source FROM
            {table} JOIN pycc.E_Meta ON meta_id = pycc.E_Meta.id
            WHERE {table}.msg_state IN
            ('{MessageState.Unprocessed.value}', '{MessageState.GaveError.value}')
            AND pycc.E_Meta.file_date = ? AND pycc.E_Meta.provider = ? AND pycc.E_Meta.feed = ?
            ORDER BY pycc.E_Meta.file_time, pycc.E_Meta.ingest_ts ASC""",
            on_date,
            self.provider,
            self.feed,
        )
        rows = self.cursor.fetchall()
        return cast(Iterable[Any], rows)

    def msg_translate(self, feed_msg: Row) -> list[tuple[str, dict[str, Any]]]:
        try:
            msgs = self.factory.translate(feed_msg)
        except BusinessValueError as ex:
            msg_asdict = {
                "msg_type": feed_msg.msg_type,
                "msg_state": feed_msg.msg_state,
                "meta_": {
                    "provider": feed_msg.provider,
                    "feed": feed_msg.feed,
                    "routing_state": json.loads(feed_msg.routing_state),
                    "id": feed_msg.source,
                    "row": {t[0]: getattr(feed_msg, t[0]) for t in feed_msg.cursor_description},
                    "errors": [
                        str(ex),
                    ],
                    "ver": 1,
                    "sender": None,
                    "call_global_id": None,
                    "call_single_id": None,
                },
            }
            return [
                ("Scarti", msg_asdict),
            ]
        else:
            output = []
            for msg in msgs:
                classname = type(msg).__name__
                output.append((classname, msg))
            return output

    def accumulate(
        self,
        _on_date: date,
        translated_msgs: dict[str, list[Any]],
        _msg_types: list[str],
        output: dict[str, TaskData],
        valid_destinations: str,
        chiave_cliente: str,
        provider: str,
    ) -> None:
        for table in self.tables:
            for msg_type in _msg_types:
                for feed_msg in self.get_messages(
                    table, _on_date, msg_type, valid_destinations, chiave_cliente, provider
                ):
                    for classname, msg in self.msg_translate(feed_msg):
                        if classname not in output:
                            output[classname] = {"data": [], "errors": [], "meta": {}}
                            translated_msgs[classname] = []
                        translated_msgs[classname].append(msg)

    def run(  # type: ignore[override]
        self,
        on_date: str,
        provider: str,
        msg_types: str = "",
        valid_destinations: str = "fee,qtk",
        chiave_cliente: str = "",
        feed_override: Optional[str] = None,
        tables_override: Optional[list[str]] = None,
    ) -> dict[str, TaskData]:
        with self.log.start_action(self.name), self.log.timed(self.name):
            translated_msgs: dict[str, list[Any]] = {"Scarti": []}
            output: dict[str, TaskData] = {"Scarti": {"data": [], "errors": [], "meta": {}}}
            self.feed = feed_override if feed_override else self.feed
            self.tables = tables_override if tables_override else self.tables
            _on_date = context.scheduled_start_time if on_date == "" else datetime.strptime(on_date, "%Y-%m-%d")
            _msg_types = (
                [
                    "",
                ]
                if msg_types == ""
                else [m.strip() for m in msg_types.split(",")]
            )

            try:
                self.open()
                self.accumulate(
                    _on_date, translated_msgs, _msg_types, output, valid_destinations, chiave_cliente, provider
                )
                self.factory.complete()
                for feed_msg in self.get_scarti(_on_date):
                    msg_asdict = {
                        "msg_type": feed_msg.msg_type,
                        "msg_state": feed_msg.msg_state,
                        "meta_": {
                            "provider": feed_msg.provider,
                            "feed": feed_msg.feed,
                            "routing_state": json.loads(feed_msg.routing_state),
                            "id": feed_msg.source,
                            "row": feed_msg.raw_msg,
                            "errors": [
                                feed_msg.error,
                            ],
                            "ver": 1,
                            "sender": None,
                            "call_global_id": None,
                            "call_single_id": None,
                        },
                    }
                    output["Scarti"]["data"].append(msg_asdict)
                for k in translated_msgs.keys():
                    if k == "Scarti":
                        output["Scarti"]["data"].extend(translated_msgs[k])
                    if k != "Scarti":
                        output[k]["data"] = [m.as_dict() for m in translated_msgs[k]]
                return output
            except Exception as exc:
                self.dbconn.rollback()
                raise exc
            finally:
                self.close()


class RouteDelivery(Task):
    def __init__(
        self,
        db: str,
        rule: dict[str, type],
        skip_states: set[str] = {
            "PRC",
            "SLN",
        },
        sender: str = "tiss",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        self.rule = rule
        self.skip_states = skip_states
        self.sender = sender
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _group_by_tag(
        self, data: dict[str, TaskData], call_global_id: Any, call_single_id: Any = None
    ) -> dict[str, dict[str, list[DataRow]]]:
        grouped_tags_data: dict[str, dict[str, list[DataRow]]] = {}  # tag -> msg_type -> msgs
        counter = 0
        for msg_type, msgs in data.items():
            for msg in msgs["data"]:
                msg["meta_"]["call_global_id"] = call_global_id
                msg["meta_"]["call_single_id"] = (
                    f"{call_global_id}_{counter}"
                    if not call_single_id
                    else f"{call_global_id}-{call_single_id}_{counter}"
                )
                msg["meta_"]["sender"] = self.sender
                if "movimento_in" in msg.keys():
                    msg["movimento_in"]["meta_"]["sender"] = self.sender
                    msg["movimento_in"]["meta_"]["call_global_id"] = call_global_id
                    msg["movimento_in"]["meta_"]["call_single_id"] = (
                        f"{call_global_id}_{counter}"
                        if not call_single_id
                        else f"{call_global_id}-{call_single_id}_{counter}"
                    )
                    if "movimento_out" in msg and msg["movimento_out"] and "meta_" in msg["movimento_out"]:
                        msg["movimento_out"]["meta_"]["sender"] = self.sender
                        msg["movimento_out"]["meta_"]["call_single_id"] = (
                            f"{call_global_id}_{counter}"
                            if not call_single_id
                            else f"{call_global_id}-{call_single_id}_{counter}"
                        )
                        msg["movimento_out"]["meta_"]["call_global_id"] = call_global_id
                for tag in msg["meta_"]["routing_state"].keys():
                    if tag not in grouped_tags_data:
                        grouped_tags_data[tag] = {}
                    if msg_type not in grouped_tags_data[tag]:
                        grouped_tags_data[tag][msg_type] = []
                    if msg["meta_"]["routing_state"][tag] not in self.skip_states:
                        grouped_tags_data[tag][msg_type].append(msg)

                counter += 1
        return grouped_tags_data

    def run(  # type: ignore
        self,
        data: dict[str, TaskData],
        additional_parameters: AdditionalParams,
        valid_destinations: str = "fee,qtk",
        call_global_id: Any = None,
    ) -> TaskData:
        output: TaskData = {"data": [], "errors": [], "meta": {}}
        grouped_tags_data = self._group_by_tag(
            data,
            call_global_id if call_global_id else context.flow_run_name,
            context.flow_run_id if call_global_id else None,
        )
        for routing_tag in grouped_tags_data:
            if routing_tag in self.rule and routing_tag in valid_destinations:
                fun = self.rule[routing_tag](db=self.db, route=routing_tag)
                fun.run(
                    data=grouped_tags_data[routing_tag],
                    additional_parameters=additional_parameters | {"routing_tags": routing_tag},
                )

        return output


class ProcessDelivery(Task):
    def __init__(self, db: str, route: str, **kwargs: Any) -> None:
        self.db = db
        self.route = route
        super().__init__(**kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        self.dbconn.close()


class ProcessDeliveryTypes(ProcessDelivery):
    def process(self, data: dict[str, list[DataRow]]) -> dict[str, str]:
        raise NotImplementedError("process() must be implemented by subclass")

    def run(self, data: dict[str, list[DataRow]], additional_parameters: AdditionalParams) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            bulk_results: TaskData = {"data": [], "errors": [], "meta": {}}
            self.open()
            try:
                for msg_type in data:
                    output = self.process({msg_type: data[msg_type]})
                    for source_, state in output.items():
                        source, id_ = source_.split(":")
                        route = self.route
                        rs = self.dbconn.execute(
                            f"""
                        SELECT routing_state FROM {source} WHERE id = ?
                        """,
                            id_,
                        )
                        routing_state = json.loads(rs.fetchone()[0])
                        routing_state[route] = state
                        self.dbconn.execute(
                            f"""
                        UPDATE {source} SET routing_state = ? WHERE id = ?
                        """,
                            json.dumps(routing_state),
                            id_,
                        )
                        self.dbconn.commit()

                        if any([v == "ERR" for v in routing_state.values()]):
                            self.dbconn.execute(
                                f"""
                            UPDATE {source} SET msg_state = 'ERR' WHERE id = ?
                            """,
                                id_,
                            )
                            self.dbconn.commit()

                        if all([v == "PRC" or v == "SLN" for v in routing_state.values()]) and any(
                            [v == "PRC" for v in routing_state.values()]
                        ):
                            self.dbconn.execute(
                                f"""
                            UPDATE {source} SET msg_state = 'PRC' WHERE id = ?
                            """,
                                id_,
                            )
                            self.dbconn.commit()
                    bulk_results["data"].append(output)
                return bulk_results
            finally:
                self.close()


class ProcessDeliveryMsgs(ProcessDelivery):
    def process(self, data: tuple[str, DataRow]) -> str:
        raise NotImplementedError("process() must be implemented by subclass")

    def run(self, data: dict[str, list[DataRow]], additional_parameters: AdditionalParams) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output: TaskData = {"data": [], "errors": [], "meta": {}}
            try:
                self.open()
                for msg_type in data:
                    for msg in data[msg_type]:
                        state = self.process((msg_type, msg))
                        route = self.route

                        source_in, id_in = (
                            msg["movimento_in"]["meta_"]["id"].replace("'", "").split(":")
                            if "CambioValuta" in msg_type or "Giroconto" in msg_type
                            else msg["meta_"]["id"].split(":")
                        )

                        rs = self.dbconn.execute(
                            f"""
                        SELECT routing_state FROM {source_in} WHERE id = ?
                        """,
                            id_in,
                        )
                        routing_state = json.loads(rs.fetchone()[0])
                        routing_state[route] = state
                        self.dbconn.execute(
                            f"""
                        UPDATE {source_in} SET routing_state = ? WHERE id = ?
                        """,
                            json.dumps(routing_state),
                            id_in,
                        )
                        self.dbconn.commit()

                        if any([v == "ERR" for v in routing_state.values()]):
                            self.dbconn.execute(
                                f"""
                            UPDATE {source_in} SET msg_state = 'ERR' WHERE id = ?
                            """,
                                id_in,
                            )
                            self.dbconn.commit()

                        if all([v == "PRC" or v == "SLN" for v in routing_state.values()]) and any(
                            [v == "PRC" for v in routing_state.values()]
                        ):
                            self.dbconn.execute(
                                f"""
                            UPDATE {source_in} SET msg_state = 'PRC' WHERE id = ?
                            """,
                                id_in,
                            )

                        if (
                            ("CambioValuta" in msg_type or "Giroconto" in msg_type)
                            and msg["movimento_out"]
                            and "meta_" in msg["movimento_out"]
                        ):
                            source_out, id_out = msg["movimento_out"]["meta_"]["id"].replace("'", "").split(":")

                            rs = self.dbconn.execute(
                                f"""
                            SELECT routing_state FROM {source_out} WHERE id = ?
                            """,
                                id_out,
                            )
                            routing_state = json.loads(rs.fetchone()[0])
                            routing_state[route] = state
                            self.dbconn.execute(
                                f"""
                            UPDATE {source_out} SET routing_state = ? WHERE id = ?
                            """,
                                json.dumps(routing_state),
                                id_out,
                            )
                            self.dbconn.commit()

                            if any([v == "ERR" for v in routing_state.values()]):
                                self.dbconn.execute(
                                    f"""
                                UPDATE {source_out} SET msg_state = 'ERR' WHERE id = ?
                                """,
                                    id_out,
                                )
                                self.dbconn.commit()

                            if all([v == "PRC" or v == "SLN" for v in routing_state.values()]) and any(
                                [v == "PRC" for v in routing_state.values()]
                            ):
                                self.dbconn.execute(
                                    f"""
                                UPDATE {source_out} SET msg_state = 'PRC' WHERE id = ?
                                """,
                                    id_out,
                                )

                        self.dbconn.commit()
                return output
            finally:
                self.close()


class ProcessQTK(ProcessDeliveryMsgs):
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)

    def process(self, data: tuple[str, DataRow]) -> str:
        self.logger.info(f"Processing {data}")
        if data[0] != "Scarti" and "Invalid" not in data[0]:
            msg: dict[str, Any] = {"msg_type": data[0], "msg_body": data[1]}
            headers: dict[str, str] = {}
            if "Giroconto" in data[0] or "CambioValuta" in data[0]:
                data[1]["movimento_in"]["meta_"]["row"].pop("routing_state")
                data[1]["movimento_in"]["meta_"].pop("routing_state")
                if "meta_" in data[1]["movimento_out"]:
                    data[1]["movimento_out"]["meta_"]["row"].pop("routing_state")
                    data[1]["movimento_out"]["meta_"].pop("routing_state")
                data[1]["meta_"]["row"].pop("routing_state")
                data[1]["meta_"].pop("routing_state")
            else:
                msg["msg_body"]["meta_"]["row"].pop("routing_state")
                msg["msg_body"]["meta_"].pop("routing_state")
            base_url = from_vault(label="internal_endpoints")["api_qtask"]

            res = requests.post(
                f"{base_url}/api/v1/finance/msg",
                headers=headers,
                data=json.dumps(msg, default=serialize).replace("'", ""),
            )
            state = "PRC" if str(res.status_code).startswith("2") else "ERR"
            return state
        else:
            insert_msg_table_appoggio_scarti(self.cursor, data[1], "SKP")
            msg_state = "ERR"
            if "Giroconto" not in data[0] and "CambioValuta" not in data[0]:
                table = data[1]["meta_"]["row"]["source"].split(":")[0]
                id = data[1]["meta_"]["row"]["source"].split(":")[1]
                self.cursor.execute(f"""SELECT msg_state FROM {table} WHERE id = ?""", id)
                msg_state = msg_state if self.cursor.fetchone()[0].strip() != "PRC" else "PRC"

            return msg_state


def insert_msg_table_appoggio_scarti(cursor: pyodbc.Cursor, msg: Any, msg_state: str) -> None:
    cursor.execute(
        """SELECT id FROM pycc.out_of_feed WHERE sender = ? AND provider = ? AND feed = ?
        AND source_table = ? AND source_id = ?""",
        msg["meta_"]["sender"],
        msg["meta_"]["provider"],
        msg["meta_"]["feed"],
        msg["meta_"]["id"].split(":")[0],
        msg["meta_"]["id"].split(":")[1],
    )

    res = cursor.fetchone()
    if res:
        # riga presente -> UPDATE
        cursor.execute(
            """UPDATE pycc.out_of_feed SET call_global_id = ?, call_single_id = ?, msg = ?,
                msg_type = ?, source_table_2 = ?, source_id_2 = ?, motivo = ?,
                ts = getutcdate()
                WHERE id = ?""",
            msg["meta_"]["call_global_id"],
            msg["meta_"]["call_single_id"],
            "",
            "Scarti",
            None,
            None,
            json.dumps(msg["meta_"]["errors"]) if "errors" in msg["meta_"] else None,
            res.id,
        ),

    else:
        cursor.execute(
            """INSERT INTO pycc.out_of_feed (sender, provider, feed, call_global_id, call_single_id,
            msg, msg_type, source_table, source_id, source_table_2, source_id_2, msg_state, motivo, retry)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)""",
            msg["meta_"]["sender"],
            msg["meta_"]["provider"],
            msg["meta_"]["feed"],
            msg["meta_"]["call_global_id"],
            msg["meta_"]["call_single_id"],
            "",
            "Scarti",
            msg["meta_"]["id"].split(":")[0],
            msg["meta_"]["id"].split(":")[1],
            None,
            None,
            msg_state,
            json.dumps(msg["meta_"]["errors"]) if "errors" in msg["meta_"] else None,
        )
    cursor.commit()


class LogMsg(Task):
    def __init__(
        self,
        sender: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.sender = sender
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: dict[str, TaskData]) -> TaskData:  # type: ignore
        output: TaskData = {"data": [], "errors": [], "meta": {}}
        headers: dict[str, str] = {}
        base_url = from_vault(label="internal_endpoints")["api_logmsg"]
        for msg_type, msgs in data.items():
            for msg_ in msgs["data"]:
                msg_["meta_"]["sender"] = self.sender
                msg: dict[str, Any] = {"msg_type": msg_type, "msg_body": msg_}
                requests.post(
                    f"{base_url}/api/v1/msgs/msg",
                    headers=headers,
                    data=json.dumps(msg, default=serialize).replace("'", ""),
                )
        return output


def serialize(obj):  # type: ignore
    if isinstance(obj, (date,)):
        return obj.isoformat()[0:10]
    if isinstance(obj, (datetime,)):
        return obj.date().isoformat()[0:10]
    if isinstance(obj, (D,)):
        return float(obj)


def _extra_values(rule: Optional[str], source_path: str) -> dict[str, str]:
    if not rule:
        return {}

    _, fname = os.path.split(source_path)
    regex_string = re.compile(rule)
    match = re.search(regex_string, fname)
    if match:
        return match.groupdict()
    else:
        raise ValueError(f"Regex for extra_values doesn't match filename : {fname}")


def _create_links(cursor: Cursor, table: str, msg_id: int, db_objects: list[DBObject]) -> Set[int]:
    output = set()
    for db_obj in db_objects:
        cursor.execute(
            """
            INSERT INTO pycc.E_Links (msgs_table, msg_id, objs_table, obj_idcol, obj_id, db_action)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            table,
            msg_id,
            db_obj.table,
            db_obj.idcol,
            db_obj.id,
            db_obj.action.value,
        )
        cursor.execute("""SELECT @@IDENTITY""")
        output.add(cursor.fetchone()[0])
    return output


class ProcessFeed(Task):
    def __init__(
        self,
        db: str,
        provider: str,
        feed: str,
        tables: list[tuple[str, str]],
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        destination_filter: Optional[str] = None,
        old_destination_filter: bool = True,
        **kwargs: Any,
    ) -> None:
        self.provider = provider
        self.feed = feed
        self.tables = tables
        self.db = db
        self.destination_filter = destination_filter
        self.old_destination_filter = old_destination_filter
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()
        self.cursor.execute("""SET NOCOUNT ON""")

    def close(self) -> None:
        self.cursor.execute("""SET NOCOUNT OFF""")
        self.dbconn.close()

    def handle_run_log(
        self, table: str, description: str, idcol: Optional[str] = None, msg: Optional[Any] = None, type_: str = "info"
    ) -> None:
        if msg and idcol:
            source_id = getattr(msg, idcol)
            getattr(self.logger, type_)(f"{description}. Processando il messaggio : {table},{idcol},{source_id}")
        else:
            source_id = None
            getattr(self.logger, type_)(f"{description}. Processando la tabella : {table}")

        self.run_logs["data"].append(
            {
                "type": type_,
                "message": description,
                "source": table + (f".{idcol}.{source_id}" if source_id else ""),
            }
        )

    def do_process(
        self,
        table: str,
        idcol: str,
        msg: Any,
        on_date: str,
        msg_types: str,
        links_for_type: Set[int],
    ) -> int:
        prc_msg = 0
        try:
            created_db_objects, report_msgs = self.process(msg)
            if "run_logs" in report_msgs:
                raise BusinessValueError("Non puoi chiamare un report 'run_logs'")
            self.set_state(table, getattr(msg, idcol), MessageState.Processed)
        except BusinessValueError as exc:
            self.dbconn.rollback()
            self.set_state(table, getattr(msg, idcol), MessageState.GaveError)
            self.dbconn.commit()
            self.handle_run_log(
                table=table,
                description=f"Errore messaggio {msg.msg_type}: {exc}",
                idcol=idcol,
                msg=msg,
                type_="warning",
            )
        except Exception as exc:
            self.dbconn.rollback()
            self.handle_run_log(
                table=table,
                description=f"{exc.__class__} : {exc}",
                idcol=idcol,
                msg=msg,
                type_="error",
            )
        else:
            created_links = _create_links(self.cursor, table, getattr(msg, idcol), created_db_objects)
            links_for_type.update(created_links)
            for k, v in report_msgs.items():
                if k == "info":
                    for message in v:
                        self.handle_run_log(table=table, description=message["info"], idcol=idcol, msg=msg)
                else:
                    if k in self.reports:
                        self.reports[k]["data"].extend(v)
                    else:
                        self.reports[k] = {
                            "data": v,
                            "errors": [],
                            "meta": {
                                "on_date": on_date if on_date else "all",
                                "msg_type": msg_types if msg_types else "all",
                            },
                        }
            self.dbconn.commit()
            prc_msg += 1

        return prc_msg

    def run(  # type: ignore[override]
        self,
        on_date: str,
        msg_types: str,
        ext_params: ExtParams,
        wait_for: Optional[Union[TaskData, list[DataRow], DataRow]] = None,
    ) -> dict[str, TaskData]:
        self.ext_params = ext_params
        self.run_logs: TaskData = {
            "data": [],
            "errors": [],
            "meta": {"on_date": on_date if on_date else "all", "msg_type": msg_types if msg_types else "all"},
        }
        self.reports: dict[str, TaskData] = {}
        with self.log.start_action(self.name), self.log.timed(self.name):
            _on_date = context.scheduled_start_time if on_date == "" else datetime.strptime(on_date, "%Y-%m-%d")
            for_msgs = (
                [
                    "",
                ]
                if msg_types == ""
                else [m.strip() for m in msg_types.split(",")]
            )

            try:
                self.open()
                total_processed_msgs, total_count = 0, 0
                for table, idcol in self.tables:
                    for for_msg in for_msgs:
                        processed_msgs, count = 0, 0
                        links_for_type: Set[int] = set()
                        messages = self.get_messages(table, _on_date, for_msg)
                        for count, msg in enumerate(messages, 1):
                            processed = self.do_process(
                                table,
                                idcol,
                                msg,
                                on_date,
                                msg_types,
                                links_for_type,
                            )
                            processed_msgs += processed
                            total_processed_msgs += processed
                        try:
                            created_db_objects, post_msg = self.postprocess(for_msg, links_for_type, on_date)
                        except BusinessValueError as exc:
                            self.dbconn.rollback()
                            self.handle_run_log(
                                table=table, description=f"Errore postprocess {for_msg}: {exc}", type_="warning"
                            )
                        except Exception as exc:
                            self.dbconn.rollback()
                            self.handle_run_log(table=table, description=f"{exc.__class__} : {exc}", type_="error")
                        else:
                            if "info" in post_msg:
                                for message in post_msg["info"]:
                                    self.handle_run_log(table=table, description=message["info"])
                            self.dbconn.commit()

                        self.logger.info(f"Processati {processed_msgs} messaggi {for_msg} su {count}")
                        total_count += count

                self.logger.info(f"Processati {total_processed_msgs} messaggi su {total_count}")
            finally:
                self.close()

        self.reports.update({"run_logs": self.run_logs})
        return self.reports

    def get_messages(self, table: str, on_date: date, msg_type: Optional[str]) -> Iterable[Any]:
        if msg_type:
            msg_filter = f"AND msg_type = '{msg_type}'"
        else:
            msg_filter = ""

        if self.destination_filter:
            if self.old_destination_filter:
                msg_filter_dest = f"AND msg_destination = '{self.destination_filter}'"
            else:
                msg_filter_dest = f"AND routing_state LIKE '%\"{self.destination_filter}\":%'"
        else:
            msg_filter_dest = ""

        self.cursor.execute(
            f"""SELECT {table}.* FROM
            {table} JOIN pycc.E_Meta ON meta_id = pycc.E_Meta.id
            WHERE {table}.msg_state IN
            ('{MessageState.Unprocessed.value}', '{MessageState.GaveError.value}') AND
            pycc.E_Meta.file_date = ? {msg_filter} {msg_filter_dest}
            ORDER BY pycc.E_Meta.file_time, pycc.E_Meta.ingest_ts ASC""",
            on_date,
        )
        rows = self.cursor.fetchall()
        return cast(Iterable[Any], rows)

    def prepare_message(self, cursor: Cursor, msg: Row, ext_params: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError("Need to implement prepare_message logic in a child class")

    def process_message(
        self, cursor: Cursor, ext_params: dict[str, Any], values: dict[str, Any], ts: datetime
    ) -> tuple[list[DBObject], dict[str, list[dict[str, str]]]]:
        raise NotImplementedError("Need to implement process_message logic in a child class")

    def process(self, msg: Any) -> tuple[list[DBObject], dict[str, list[dict[str, str]]]]:
        ts = tz_rome.convert(datetime.now())
        values = self.prepare_message(self.cursor, msg, self.ext_params)
        return self.process_message(self.cursor, self.ext_params, values, ts)

    def process_msg_type(
        self,
        cursor: Cursor,
        ext_params: dict[str, Any],
        msg_type: str,
        links: set[int],
        ts: datetime,
        date: str,
    ) -> tuple[list[DBObject], dict[str, list[dict[str, str]]]]:
        return [], {}

    def postprocess(
        self, msg_type: str, links: Set[int], date: str
    ) -> tuple[list[DBObject], dict[str, list[dict[str, str]]]]:
        ts = tz_rome.convert(datetime.now())
        return self.process_msg_type(self.cursor, self.ext_params, msg_type, links, ts, date)

    def set_state(self, table: str, msg_id: int, msg_state: MessageState) -> None:
        self.cursor.execute(f"""UPDATE {table} set msg_state = '{msg_state.value}' WHERE id = ?""", msg_id)
        self.dbconn.commit()


def _delete_links(cursor: Cursor, day: date, msg_table: str, msgs: Optional[str], start_from: Optional[str]) -> None:
    in_msgs = ""
    if msgs:
        foobar = ",".join([f"'{m}'" for m in msgs.split(",")])
        in_msgs = f"AND msgt.msg_type IN ({foobar})"

    cursor.execute(
        f"""
        SELECT el.objs_table, el.obj_idcol FROM pycc.E_Links el
        JOIN {msg_table} msgt ON el.msg_id  = msgt.id
        JOIN pycc.E_Meta em ON msgt.meta_id = em.id
        WHERE el.msgs_table = ? AND em.file_date = ? {in_msgs}
        GROUP BY el.objs_table, el.obj_idcol
        """,
        msg_table,
        day,
    )

    _row = namedtuple("_row", ("objs_table", "obj_idcol"))
    rows = [_row(row.objs_table, row.obj_idcol) for row in cursor.fetchall()]
    these_first = []
    if start_from:
        for table in start_from.split(","):
            for row in rows:
                if row.objs_table == table:
                    these_first.append(_row(row.objs_table, row.obj_idcol))
                    rows.pop(rows.index(row))

    for row in these_first + rows:
        cursor.execute(
            f"""
            DELETE FROM {row.objs_table} WHERE {row.obj_idcol} IN (
            SELECT el.obj_id FROM pycc.E_Links el
            JOIN {msg_table} msgt ON el.msg_id  = msgt.id
            JOIN pycc.E_Meta em ON msgt.meta_id = em.id
            WHERE el.msgs_table = ? AND em.file_date = ?
            AND el.objs_table = ? {in_msgs})
            """,
            msg_table,
            day,
            row.objs_table,
        )

    cursor.execute(
        f"""
    UPDATE {msg_table} SET msg_state = 'UNP'
    FROM {msg_table} msgt JOIN pycc.E_Meta em ON msgt.meta_id = em.id
    WHERE em.file_date = ? {in_msgs}
    """,
        day,
    )

    cursor.execute(
        f"""
        DELETE FROM pycc.E_Links WHERE id IN (
        SELECT el.id FROM pycc.E_Links el
        JOIN {msg_table} msgt ON el.msg_id  = msgt.id
        JOIN pycc.E_Meta em ON msgt.meta_id = em.id
        WHERE el.msgs_table = ? AND em.file_date = ? {in_msgs})
        """,
        msg_table,
        day,
    )


class ResetProcess(Task):
    def __init__(
        self,
        db: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        self.dbconn.close()

    def run(  # type: ignore[override]
        self, msg_tables: list[str], from_date: str, msgs: Optional[str] = None, start_from: Optional[str] = None
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            self.open()
            start_date = date.today()
            end_date = datetime.strptime(from_date, "%Y-%m-%d").date()
            delta = start_date - end_date

            try:
                for msg_table in msg_tables:
                    for i in range(delta.days + 1):
                        day = start_date - timedelta(days=i)
                        _delete_links(self.cursor, day, msg_table, msgs, start_from)
                        self.dbconn.commit()
                        self.logger.info(f"Cancellate le azioni del giorno {day}")
            except Exception as exc:
                self.dbconn.rollback()
                return {
                    "data": [],
                    "errors": [{"error": str(exc), "source": {"msg_tables": msg_tables, "from_date": from_date}}],
                    "meta": {},
                }
            else:
                self.dbconn.commit()
            finally:
                self.close()

        return {"data": [], "errors": [], "meta": {}}


class SilenceErrors(Task):
    def __init__(
        self,
        db: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        self.dbconn.close()

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            self.open()
            try:
                for row in data["data"]:
                    self.cursor.execute(
                        f"""
                        UPDATE {row["table"]} SET msg_state = ?
                        WHERE {row['idcol']} = ?
                        """,
                        MessageState.Silenced.value,
                        row["msg_id"],
                    )
                    self.cursor.execute(
                        """
                    INSERT INTO pycc.E_Silenced (msg_table, idcol, msg_id, reason)
                    VALUES (?,?,?,?)
                    """,
                        row["table"],
                        row["idcol"],
                        row["msg_id"],
                        row["reason"],
                    )
                self.dbconn.commit()
            except Exception as exc:
                self.dbconn.rollback()
                raise exc
            finally:
                self.close()
            return {"data": [], "errors": [], "meta": {}}
