from datetime import timedelta
from typing import Any, cast

import requests

from pymol.ext.auth import from_vault, local_token
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.logger import LogLevel
from pymol.types.jobs import ErrorRow, TaskData


class QTaskCreaIncarichi(Task):
    def __init__(
        self,
        cod_area_label: str,
        cod_cliente_label: str,
        tipo_incarico_label: str,
        chiave_cliente_label: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.cod_area_label = cod_area_label
        self.cod_cliente_label = cod_cliente_label
        self.tipo_incarico_label = tipo_incarico_label
        self.chiave_cliente_label = chiave_cliente_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        output, errors = [], []
        gate = from_vault("gate_dn")

        for row in data["data"]:
            cod_area = row[self.cod_area_label]
            cod_cliente = row[self.cod_cliente_label]
            tipo_incarico = row[self.tipo_incarico_label]
            chiave_cliente = row[self.chiave_cliente_label]

            params = {
                "cod_area": cod_area,
                "cod_cliente": cod_cliente,
                "cod_tipo_incarico": tipo_incarico,
                "chiave_cliente": chiave_cliente,
            }
            resp = requests.get(f"{gate['host']}qtask/incarico", params=params, headers={"BEARER": local_token()})
            if resp.status_code == 200:
                params.update({"id_incarico": resp.json()["id_incarico"]})
                output.append(params.copy())
            else:
                error = f"error creating incarico {tipo_incarico} cliente {cod_cliente}, "
                f"server response code {resp.status_code}",
                errors.append(cast(ErrorRow, {"error": error, **params.copy()}))
                self.log.message(
                    error,
                    LogLevel.WARNING,
                )

        return {"data": output, "errors": errors, "meta": {"isEmpty": len(output) == 0}}


class QTaskCreaPersone(Task):
    def __init__(
        self,
        cod_cliente_label: str,
        cod_tipo_persona_label: str,
        chiave_cliente_label: str,
        nome_label: str,
        cognome_label: str,
        codice_fiscale_label: str,
        partita_iva_label: str,
        ragione_sociale_label: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.cod_cliente_label = cod_cliente_label
        self.cod_tipo_persona_label = cod_tipo_persona_label
        self.chiave_cliente_label = chiave_cliente_label
        self.nome_label = nome_label
        self.cognome_label = cognome_label
        self.codice_fiscale_label = codice_fiscale_label
        self.partita_iva_label = partita_iva_label
        self.ragione_sociale_label = ragione_sociale_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        output, errors = [], []
        gate = from_vault("gate_dn")

        for row in data["data"]:
            cod_cliente = row[self.cod_cliente_label]
            cod_tipo_persona = row[self.cod_tipo_persona_label]
            chiave_cliente = row[self.chiave_cliente_label]
            nome = row[self.nome_label]
            cognome = row[self.cognome_label]
            codice_fiscale = row[self.codice_fiscale_label]
            partita_iva = row[self.partita_iva_label]
            ragione_sociale = row[self.ragione_sociale_label]

            params = {
                "cod_cliente": cod_cliente,
                "cod_tipo_persona": cod_tipo_persona,
                "chiave_cliente": chiave_cliente,
                "nome": nome,
                "cognome": cognome,
                "codice_fiscale": codice_fiscale,
                "partita_iva": partita_iva,
                "ragione_sociale": ragione_sociale,
            }
            resp = requests.get(f"{gate['host']}qtask/persona", params=params, headers={"BEARER": local_token()})
            if resp.status_code == 200:
                params.update({"id_persona": resp.json()["id_persona"]})
                output.append(params.copy())
            else:
                error = f"error creating persona {cod_tipo_persona} cliente {cod_cliente}, "
                f"server response code {resp.status_code}"
                errors.append(cast(ErrorRow, {"error": error, **params.copy()}))
                self.log.message(
                    error,
                    LogLevel.WARNING,
                )

        return {"data": output, "errors": errors, "meta": {"isEmpty": len(output) == 0}}
