import csv
import io
import json
import unicodedata
from collections import namedtuple
from datetime import date, datetime, timedelta
from enum import Enum
from typing import Any, Callable, Union, cast

import pyodbc
from prefect import task

from pymol.ext.auth import from_vault
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, ErrorRow, TaskData

LookupSchema = namedtuple("LookupSchema", ["schema", "table", "source_col", "dest_col"])


def replace_in(text: str, replacements: tuple[tuple[str, str]]) -> str:
    output = text
    for replacement in replacements:
        output = output.replace(*replacement)
    return output


def strip_extra_spaces(text: str) -> str:
    return " ".join(text.split())


def clean_text(text: str) -> str:
    return strip_extra_spaces(" ".join(word for word in text.split() if unicodedata.category(word[0])[0] != "C"))


def mult(a: str, b: str) -> str:
    return str(float(a) * float(b))


REMAP_CONTEXT = {
    "replace_in": replace_in,
    "strip_extra_spaces": strip_extra_spaces,
    "mult": mult,
    "clean_text": clean_text,
}


class RemapData(Task):
    """Rimappa i dati in ingresso con semplici trasformazioni.

    Esempio:

    ```
    remap = RemapData(
        # un dizionario "nuovo nome colonna": "trasformazione dei valori"
        mapping = {
            # dentro le graffe sostituiamo col valore
            "nuovo_nome" = "{vecchio_nome}",
            # possiamo unire più colonne in una
            "nome_cognome" = "{nome} {cognome}",
            # sostituire valori
            "costo" = "{replace_in(costo, (('euro', '€'),))},
            # fare semplici operazioni
            "peso_kg" = "{mult(peso_grammi, 1000)}",
            })
    dati_trasformati = remap(dati_originali)
    """

    def __init__(self, mapping: dict[str, str], **kwargs: Any) -> None:
        self.mapping = mapping
        super().__init__(**kwargs)

    def _transform(self, input: dict[str, Any]) -> dict[str, Any]:
        input_ = {k.replace(" ", ""): v for k, v in input.items()}
        output = {}
        for k, v in self.mapping.items():
            v_ = v.replace(" ", "")
            # breakpoint()
            output[k] = eval(f'f"{v_}"', REMAP_CONTEXT, input_)
        return output

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output = []
            for row in data["data"]:
                output.append(self._transform(row))

            meta_dict = data["meta"]
            meta_dict["isEmpty"] = len(output) == 0
            return {"data": output, "errors": data["errors"], "meta": meta_dict}


class DBLookup(Task):
    def __init__(
        self,
        db: str,
        lookup_schema: dict[str, LookupSchema],
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.lookup_schema = lookup_schema
        self.db = db
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']}"
        )
        self.dbconn = pyodbc.connect(self.db_params)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        self.dbconn.close()

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            self.open()
            errors = []
            output_data = []
            for row in data["data"]:
                still_valid = True
                tmp_row = row.copy()
                for key in row:
                    if key in self.lookup_schema:
                        try:
                            result = get_conversion_text(self.cursor, self.lookup_schema[key], row[key])
                            tmp_row[key] = result
                        except ValueError as ex:
                            still_valid = False
                            errors.append(cast(ErrorRow, {"error": str(ex), "row": row.copy()}))
                            break
                if still_valid:
                    output_data.append(tmp_row)

            self.close()
            return {"data": output_data, "errors": errors, "meta": data["meta"]}


def get_conversion_text(cursor: pyodbc.Cursor, map: LookupSchema, value: Any) -> Any:
    cursor.execute(
        f"""
            SELECT {map.dest_col} FROM {map.schema}.{map.table} where {map.source_col} = ?
        """,
        value,
    )
    res = cursor.fetchone()
    if res is not None:
        return res[0]
    raise ValueError(f"{value} has no match in {map.schema}.{map.table}")


def _jsonify(
    values: dict[str, Union[None, datetime, float, bool, int, str]]
) -> dict[str, Union[None, datetime, float, bool, int, str]]:
    for k, v in values.items():
        if isinstance(v, date) or isinstance(v, datetime):
            values[k] = v.isoformat()
    return values


class OPERTYPE(Enum):
    """Crud operation type."""

    NEW_KEY = "INS"
    DEL_KEY = "DEL"
    MOD_KEY = "MOD"


@task
def make_deltaraw(
    data: DataRow,
    fields: tuple[str, ...],
    encoding: str = "utf-8",
    options: dict[str, str] = {"delimiter": "|"},
) -> tuple[TaskData, TaskData]:
    """Torna il delta fra due file csv.

    Confrontando le righe come stringa e non dizionario è molto veloce,
    ma non identifica con certezza l'operazione di modifica avvenuta.

    L'uscita è costituita da due TaskData;
    uno con i dati da cancellare o modificare,
    e uno con quelli da inserire o modificare per gestioni successive del solo delta fra i due.

    Esempio:
    ```
    file1:
    2,CCC,DDD
    3,EEE,FFF
    3,EEE,FFF
    4,GGG,HHH
    1,AAA,BBB

    file2:
    5,MMM,NNN
    2,CCC,DDD
    2,CCC,DDD
    3,EEE,FFF
    4,III,LLL

    output del task:
     ...
        {"k": "1", "cola": "AAA", "colb": "BBB"},
        {"k": "4", "cola": "GGG", "colb": "HHH"},
     ...
        {"k": "4", "cola": "III", "colb": "LLL"},
        {"k": "5", "cola": "MMM", "colb": "NNN"},
     ...
    ```
    """
    with open(data["as_is_filepath"], encoding=encoding) as as_is, open(
        data["to_be_filepath"], encoding=encoding
    ) as to_be:
        as_is_lines = set([line.strip() for line in as_is.readlines()])
        to_be_lines = set([line.strip() for line in to_be.readlines()])

    del_or_upd = "\n".join(as_is_lines.difference(to_be_lines))
    ins_or_upd = "\n".join(to_be_lines.difference(as_is_lines))

    data_del_or_upd = [
        row for row in csv.DictReader(io.StringIO(del_or_upd), fieldnames=fields, **options)  # type: ignore
    ]

    data_ins_or_upd = [
        row
        for row in csv.DictReader(  # type: ignore
            io.StringIO(ins_or_upd),
            fieldnames=fields,
            **options,
        )
    ]

    data["as_is_meta"].update({"isEmpty": len(data_del_or_upd) == 0})
    data["to_be_meta"].update({"isEmpty": len(data_ins_or_upd) == 0})

    return (
        {"data": data_ins_or_upd, "errors": [], "meta": data["to_be_meta"]},
        {"data": data_del_or_upd, "errors": [], "meta": data["as_is_meta"]},
    )


@task
def make_delta(
    data: tuple[TaskData, TaskData],
    pk: tuple[str, ...] = ("ChiaveEsterna",),
    merge_rule: Union[None, Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]] = None,
    keep_complete_payload: bool = False,
    ignore_fields: set[str] = set(),
) -> TaskData:
    """Torna la diff tra le liste data di due TaskData.

    Per grosse moli di dati si può velocizzare l'esecuzione "filtrando" i due ingressi con un make_deltaraw a monte.
    Le DataRow in uscita specificano l'operazione per portare i dati "asis" allo stato "tobe".
    """
    output = []
    tobe_data = data[0]["data"]
    asis_data = data[1]["data"]
    tobe_k: dict[Any, Any] = {}
    asis_k: dict[Any, Any] = {}

    # from dict {k1:v1, k2:v2, ...} to "pk-dict" { (k1, k2, k3): {k4:v3, k5:v5, ...} }
    # as unique key enforced by a merge rule
    for couple in [(tobe_data, tobe_k), (asis_data, asis_k)]:
        source, target = couple[0], couple[1]
        for row in source:

            key = tuple(v for k, v in row.items() if k in pk)
            payload = {k: v for k, v in row.items() if k not in pk}

            if target.get(key) and merge_rule:
                target[key] = merge_rule(target[key], payload)
            else:
                target[key] = payload

    diff = set(tobe_k.keys()) ^ set(asis_k.keys())
    # handle set differences in keys as new keys to insert or wiped keys to close
    for key in diff:
        diff_key = tobe_k.get(key)
        json_key = json.dumps(_jsonify(dict(zip(pk, key))))
        if diff_key:
            output.append(
                {
                    "msg_key": json_key,
                    "payload": json.dumps(_jsonify(diff_key)),
                    "msg_type": OPERTYPE.NEW_KEY.value,
                }
            )
        else:
            output.append({"msg_key": json_key, "msg_type": OPERTYPE.DEL_KEY.value})
    del diff

    common = set(tobe_k.keys()) & set(asis_k.keys())
    # handle common keys
    for key in common:
        maybe_changed = tobe_k[key]
        if hash(f"{maybe_changed.values()}") - hash(f"{asis_k[key].values()}"):
            if keep_complete_payload:  # don't forget unchanged fields in output
                changes = {k: v for k, v in maybe_changed.items()}
                changes.update({f"_{k}": v for k, v in maybe_changed.items() if asis_k[key].get(k) != v})
            else:
                changes = {k: v for k, v in maybe_changed.items() if asis_k[key].get(k) != v}
            if changes.keys() - ignore_fields:  # skip output if only ignorable fields changed
                output.append(
                    {
                        "msg_key": json.dumps(_jsonify(dict(zip(pk, key)))),
                        "payload": json.dumps(_jsonify(changes)),
                        "msg_type": OPERTYPE.MOD_KEY.value,
                    }
                )

    return {"data": output, "errors": [], "meta": data[0]["meta"]}
