from datetime import timedelta
from typing import Any, Optional, Union, cast

import pyodbc
from prefect import context

from pymol.ext.auth import from_vault
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, ErrorRow, TaskData
from pymol.validation import Schema, SchemaError


class ReadDB(Task):
    """Recupera dati da un DB.

    Esempio:

    ```
    ```
    """

    def __init__(
        self,
        db: str,
        schema: Schema,
        query: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.query = query
        self.schema = schema
        self.db = db
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def _validate(self, row: DataRow) -> tuple[bool, Union[DataRow, ErrorRow]]:
        try:
            validated = self.schema.validate(row)
        except SchemaError as err:
            msg = str(err).replace("\n", " ")
            return False, cast(ErrorRow, {"error": msg, "row": row.copy()})
        return True, validated

    def run(self, params: tuple[Any, ...]) -> TaskData:  # type: ignore
        output, errors = [], []
        with self.log.start_action(self.name), self.log.timed(self.name):
            self.open()
            self.cursor.execute(self.query, *params)
            for row in self.cursor.fetchall():
                outrow = {}
                for k in self.schema.schema.keys():
                    outrow[k] = getattr(row, k)
                is_valid, result = self._validate(outrow)
                if is_valid:
                    output.append(cast(DataRow, result))
                else:
                    self.log.warning(f"skippo riga non valida dal db : {result['error']}")
                    errors.append(cast(ErrorRow, result))
            self.close()

            return {
                "data": output,
                "errors": errors,
                "meta": {
                    "query": self.query,
                    "scheduled_date": context.scheduled_start_time.date().isoformat(),
                    "isEmpty": len(output) == 0,
                    "hasErrors": len(errors) > 0,
                },
            }

    def close(self) -> None:
        self.dbconn.close()
