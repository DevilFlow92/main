from datetime import timedelta
from typing import Any, Iterator, cast

from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, SheetRules, Task
from pymol.types.jobs import DataRow, ErrorRow, TaskData
from pymol.validation import Coerce, Or, Schema, SchemaError, to_float, to_int

CMX: dict[type | Coerce, Coerce] = {
    int: Coerce(to_int()),
    float: Coerce(to_float()),
}


class ReadAndValidate(Task):
    _common_options: dict[str, tuple[type, Any]] = {
        "encoding": (str, "utf-8"),
        "allow_missing_keys": (bool, False),
        "custom_nones": (set, set()),
        "path_label": (str, "path"),
        "sheet_label": (str, "sheet"),
        "external_fields": (tuple, ()),
    }
    _options: dict[str, tuple[type, Any]] = {}

    def __init__(
        self,
        rules: SheetRules,
        options: dict[str, Any] | None = None,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta | None = RETRY_DELAY,
        **kwargs: Any,
    ):
        self.rules = rules
        self.options = self._check_options(options)
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _check_options(self, options: dict[str, Any] | None) -> dict[str, Any]:
        output = {}
        ops = self._common_options.copy()
        ops.update(self._options)
        self._options = ops

        if options is not None:
            for k, v in options.items():
                if k not in self._options:
                    raise ValueError(f"Option {k} is not supported")
                if not isinstance(v, self._options[k][0]):
                    raise ValueError(f"Option {k} must be of type {self._options[k][0].__name__}")
                output[k] = v
        for k, v in self._options.items():
            if k not in output:
                output[k] = v[1]
        return output

    def _clean(self, row: DataRow) -> DataRow:
        _row = dict(
            [
                (k, v if v not in self.op("custom_nones") else None)
                for k, v in row.items()
                if k in self.fieldnames and v != "*_MISSING_COL_*"
            ]
        )
        diff = set(self.fieldnames).difference(set(_row.keys()))
        if diff and not self.op("allow_missing_keys"):
            raise ValueError(f"Skipped row, missing required columns: {diff} in row: {row}") from None
        try:
            output = cast(DataRow, self.schema.validate(_row))
            return {self.renames[k]: v for k, v in output.items()}
        except SchemaError as exc:
            fellon = exc.autos[0].replace("'", '"')
            felony = exc.autos[2].split("raised")[1].rpartition('("')[2].replace("'", '"').replace('")', "")
            raise ValueError(f"Skipped row, {fellon} {felony}") from None

    def _run(
        self, data: DataRow, option_overrides: dict[str, Any] = {}
    ) -> Iterator[tuple[DataRow, None] | tuple[None, ErrorRow | None]]:
        raise NotImplementedError()

    def op(self, k: str) -> Any:
        return self.options[k]

    def run(self, data: DataRow, option_overrides: dict[str, Any] = {}) -> TaskData:  # type: ignore
        sheet_name = data.get(self.op("sheet_label"), "-")
        rule = self.rules[sheet_name]
        self.fieldnames = list(rule.keys())
        schema = {k: CMX[v.type_] if v.type_ in CMX else v.type_ for k, v in rule.items()}
        if self.op("allow_missing_keys"):
            schema = {k: Or(None, v) for k, v in schema.items()}
        self.schema = Schema(schema)
        self.renames = {k: v.ingest_column if v.ingest_column else k for k, v in rule.items()}

        output: list[DataRow] = []
        errors: list[ErrorRow] = []

        for count, (row, error) in enumerate(self._run(data, option_overrides), 1):
            if error is not None:
                self.log.warning(f"Error in row {count}: {error}")
                errors.append(error)
            if row is not None:
                output.append(row)
            if count % 1000 == 0:
                self.logger.info(f"Processed {count} rows")

        meta = {k: v for k, v in data.items()}
        meta["isEmpty"] = len(output) == 0
        meta["hasErrors"] = len(errors) > 0
        meta["sheet"] = sheet_name
        return {"data": output, "errors": errors, "meta": meta}
