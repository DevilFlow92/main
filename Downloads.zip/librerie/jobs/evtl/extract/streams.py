import enum
import re
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path, PosixPath
from tempfile import TemporaryDirectory
from typing import Any, Callable, Iterable, Mapping, NamedTuple, Optional, Set

from pymol.ext.auth import from_vault
from pymol.ext.ftp import FileMetadata as FtpFileMetadata
from pymol.ext.ftp import RemoteFtpFiles, ftp_conn
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.jobs.evtl.utils import apprise_alert, build_key
from pymol.types.jobs import DataRow, TaskData


class FileMeta(NamedTuple):
    key: str
    filename: str
    timestamp: str
    size: int


class Source(NamedTuple):
    label: str
    whitelist: Set[str]
    ignorelist: Set[str]
    path: str
    infer_date: Optional[Callable[[str, FtpFileMetadata], datetime]] = None


class RegexWarning(Warning):
    pass


def _infer_file_date(
    filename: str,
    day: Optional[str] = None,
    month: Optional[str] = None,
    year: Optional[str] = None,
) -> date:
    """Infer date for a source file.

    The default implementation is based on the common assumption that the filename explicitly
    declares the date, and this is matched with named groups in the matching whitelist.
    """
    if not day or not month or not year:
        raise ValueError("Inconsistent regex whitelist")

    return date(year=int(year), month=int(month), day=int(day))


def _ignored(source_feed: Source, filename: str) -> bool:
    for regex in source_feed.ignorelist:
        m = re.match(regex, filename, re.X | re.M)
        if m:
            return True
    return False


def _dest_date_and_name(source_feed: Source, filename: str, source_meta: FtpFileMetadata) -> tuple[date, str, bool]:
    """Return (filedate, filename, is_dated).

    If date is in filename is_dated is assigned to True, otherwise to False when the date is inferred
    using ad hoc function of filename and timestamp
    """
    dated_whitelist = [_ for _ in source_feed.whitelist if "year" in _ and "month" in _ and "day" in _]
    undated_whitelist = [_ for _ in source_feed.whitelist if _ not in dated_whitelist]

    for regex in dated_whitelist:
        m = re.match(regex, filename, re.X | re.M)
        if m:
            gd = m.groupdict()
            day = gd.get("day", None)
            month = gd.get("month", None)
            year_ = gd.get("year", None)
            year = year_ if len(year_) == 4 else f"20{year_}"

            return (_infer_file_date(filename, day=day, month=month, year=year), filename, True)

    for regex in undated_whitelist:
        m = re.match(regex, filename, re.X | re.M)
        if m:
            if source_feed.infer_date:
                return (
                    source_feed.infer_date(filename, source_meta).date(),
                    filename,
                    False,
                )
            else:
                raise ValueError("A infer_date function is needed for undated files.")  # pragma: no cover

    raise RegexWarning(f"File non atteso sulla sorgente {source_feed.label}: {filename}")  # pragma: no cover


class ModifyStatus(enum.Enum):
    NEW = "new"
    UNCHANGED = "unchanged"
    TIMESTAMP_CHANGED = "timestamp_changed"
    SIZE_CHANGED = "size_changed"


class DiscardedAlertPolicy(enum.Enum):
    TIMESTAMP = "timestamp"
    SIZE = "size"


class PullStream(Task):  # pragma: nocover
    def __init__(
        self,
        source_label: str,
        source_path: Set[str],
        whitelist: Set[str],
        dest_label: str,
        ignorelist: Set[str] = set(),
        dest_path: str = "",
        days_of_unrecognized_file_warning: int = 15,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        infer_date: Optional[Callable[[str, FtpFileMetadata], datetime]] = None,
        discarded_alert_policy: DiscardedAlertPolicy = DiscardedAlertPolicy.TIMESTAMP,
        delete_from_source: bool = False,
        **kwargs: Any,
    ) -> None:
        self.source_label = source_label
        self.source_path = source_path
        self.whitelist = whitelist
        self.dest_label = dest_label
        self.ignorelist = ignorelist
        self.dest_path = f"{dest_path.strip('/')}/"
        self.days_of_unrecognized_file_warning = days_of_unrecognized_file_warning
        self.infer_date = infer_date
        # ignore_changes_in_source_timestamp was a keyword argument that has been removed
        kwargs.pop("ignore_changes_in_source_timestamp", None)
        self.discarded_alert_policy = discarded_alert_policy
        self.delete_from_source = delete_from_source

        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(  # type:ignore
        self,
        source_label_override: Optional[str] = None,
        source_path_override: Optional[str] = None,
        whitelist_override: Optional[str] = None,
        fail_on_foreign_files: bool = False,
    ) -> TaskData:
        self.source_conf = from_vault(self.source_label)
        self.dest_conf = from_vault(self.dest_label)
        with self.log.start_action(self.name), self.log.timed(self.name):
            if source_label_override:
                self.source_label = source_label_override
            if source_path_override:
                self.source_path = {
                    source_path_override,
                }
            if whitelist_override:
                self.whitelist = {
                    whitelist_override,
                }

            with ftp_conn(self.source_conf) as conn:
                files_pulled_to_dest = []
                for path_ in self.source_path:
                    path = PosixPath(str(self.source_conf["path"]), f"{path_.strip('/')}/")
                    source_feed = Source(
                        label=self.source_label,
                        whitelist=self.whitelist,
                        ignorelist=self.ignorelist,
                        path=str(path_),
                        infer_date=self.infer_date,
                    )
                    self.logger.info(f"Looking for files in {self.source_label}")
                    all_files_on_source = conn.describe(PosixPath(path_))
                    files_on_source = {
                        filename: meta
                        for filename, meta in all_files_on_source.items()
                        if not _ignored(source_feed, filename)
                    }
                    self.logger.info(
                        f"Found {len(all_files_on_source)} files in {self.source_conf['host']}:{path} "
                        f"(ignoring {len(all_files_on_source) - len(files_on_source)})"
                    )
                    files_status = self.files_to_download(source_feed, files_on_source, fail_on_foreign_files)
                    for status in (ModifyStatus.NEW, ModifyStatus.SIZE_CHANGED, ModifyStatus.TIMESTAMP_CHANGED):
                        if status in files_status:
                            files_pulled_to_dest.extend(self.pull_stream(source_feed, files_status[status], status))

        return {"data": files_pulled_to_dest, "errors": [], "meta": {"isEmpty": len(files_pulled_to_dest) == 0}}

    def files_to_download(
        self, source_feed: Source, files_on_source: RemoteFtpFiles, fail_on_foreign_files: bool
    ) -> Mapping[ModifyStatus, RemoteFtpFiles]:
        objs_on_dest = {
            obj.filename: obj for obj in self.files_on_dest(source_feed, files_on_source, fail_on_foreign_files)
        }
        status_candidates_list = defaultdict(list)
        for source_filename, source_meta in files_on_source.items():
            if not _ignored(source_feed, source_filename):
                try:
                    date_, _, is_dated = _dest_date_and_name(source_feed, source_filename, source_meta)
                    clean_key = build_key(self.source_label, date_, source_filename, source_meta.modify)
                    modify_status = self.get_modify_status(
                        source_filename, source_meta, clean_key, objs_on_dest, is_dated
                    )
                    status_candidates_list[modify_status].append((Path(clean_key).name, source_meta))
                except ValueError as exc:
                    self.logger.warning(str(exc))
                except RegexWarning as exc:
                    if source_meta.modify > datetime.now(tz=timezone.utc) - timedelta(
                        days=self.days_of_unrecognized_file_warning
                    ):
                        self.logger.warning(str(exc))

        status_candidates = {}
        for status, candidates in status_candidates_list.items():
            # Sort by filename so that keys in dict are also sorted
            sorted_candidates = sorted(candidates, key=lambda tup: tup[0])
            status_candidates[status] = dict(sorted_candidates)

        return status_candidates

    def get_modify_status(
        self,
        source_filename: str,
        source_meta: FtpFileMetadata,
        clean_key: str,
        objs_on_dest: dict[str, FileMeta],
        dated_filename: bool,
    ) -> ModifyStatus:
        """
        If the file doesn't exist in the destination it is UNCHANGED.

        If the size has changed the timestamp has also changed and the file is SIZE_CHANGED.

        If date is in filename file has been modified if filename is the same but timestamp changes, ie:
        - yesterday's file has arrived today too.
        - today's file has been loaded twice at different times

        If date is not in filename file has been modified if filename is the same, timestamp's date is
        the same, but time is different, ie:
        - "undated_file.csv" being changed every hour will be discarded 23 times, having been pulled the first time

        If the size is the same but the date changes it is TIMESTAMP_CHANGED
        """
        obj = objs_on_dest.get(source_filename)
        if not obj:
            return ModifyStatus.NEW
        else:
            if obj.size != source_meta.size:
                return ModifyStatus.SIZE_CHANGED

            if dated_filename and obj.timestamp[0:19] != self.get_timestamp_from_path(clean_key):
                return ModifyStatus.TIMESTAMP_CHANGED

            if not dated_filename and self.infer_date:
                src_date = self.infer_date(source_filename, source_meta).date().isoformat()
                dest_date = obj.timestamp[0:10]
                # Replace - with : since this timestamp is taken from the filename and due to windows
                # filenames cannot contain :
                src_timestamp = self.infer_date(source_filename, source_meta).isoformat().replace("-", ":")
                dest_timestamp = obj.timestamp[0:19].replace("-", ":")
                if src_date != dest_date:
                    # Even if the name is the same, if the dates are different they should be considered different
                    # files
                    return ModifyStatus.NEW
                elif src_timestamp != dest_timestamp:
                    # If the dates match but the time doesn't the file for this specific day has been changed
                    return ModifyStatus.TIMESTAMP_CHANGED

            # UNCHANGED is returned only iff size and timestamp haven't changed
            return ModifyStatus.UNCHANGED

    def get_timestamp_from_path(self, clean_key: str) -> str:
        match = re.search(r"\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}", clean_key)
        if match:
            return match.group(0)
        return ""

    def files_on_dest(
        self, source_feed: Source, files_on_source: RemoteFtpFiles, fail_on_foreign_files: bool
    ) -> Iterable[FileMeta]:
        dest_dirs_to_search = set()
        for name, filemeta in files_on_source.items():
            try:
                dest_dirs_to_search.add(self.calendarized_dirname(source_feed, name, filemeta))
            except RegexWarning:
                pass

        with ftp_conn(from_vault(self.dest_label)) as conn:
            output = []
            for prefix in dest_dirs_to_search:
                for key, val in conn.describe(PosixPath(prefix)).items():
                    check_for_foreign_files(
                        prefix, key, self.whitelist, self.infer_date is None, source_feed, fail_on_foreign_files
                    )
                    output.append(
                        FileMeta(key=val.key, size=val.size, filename=key.split("@")[0], timestamp=key.split("@")[1])
                    )
        return sorted(output, key=lambda meta: meta.key)

    def pull_stream(
        self, source_feed: Source, files_to_download: RemoteFtpFiles, modify_status: ModifyStatus
    ) -> list[DataRow]:
        self.logger.debug(
            "Processando file %s in stato %s", ", ".join(ftp.key for ftp in files_to_download.values()), modify_status
        )
        output = []
        with ftp_conn(self.source_conf) as conn, ftp_conn(self.dest_conf) as dest_conn:
            for filename, filemeta in files_to_download.items():
                remote_filename, remote_timestamp = filename.rsplit("@", 1)
                with TemporaryDirectory() as tmpdirname:
                    local_file = conn.retrieve(
                        PosixPath(source_feed.path) / remote_filename, PosixPath(tmpdirname) / remote_filename
                    )
                    date_, filename_, _ = _dest_date_and_name(source_feed, remote_filename, filemeta)
                    srcdate_, srctime_ = remote_timestamp.split("T")
                    remote_key = build_key(
                        self.source_label,
                        date_,
                        filename_,
                        datetime.fromisoformat(f"{srcdate_}T{srctime_.replace('-', ':')}"),
                    )

                    if modify_status in (ModifyStatus.TIMESTAMP_CHANGED, ModifyStatus.SIZE_CHANGED):
                        discarded_path = "discarded_" + remote_key
                        # Ignore this duplicate file if:
                        #  1 The new file has only different timestamp (same size) and the policy is set to SIZE
                        #  2 We have already handled this specific file (with same timestamp and size)
                        # | Policy    | Status            | Action |
                        # |-----------|-------------------|--------|
                        # | SIZE      | SIZE_CHANGED      | Alert  |
                        # | SIZE      | TIMESTAMP_CHANGED | Ignore |
                        # | TIMESTAMP | SIZE_CHANGED      | Alert  |
                        # | TIMESTAMP | TIMSTAMP_CHANGED  | Alert  |
                        policy_matches = not (
                            self.discarded_alert_policy == DiscardedAlertPolicy.SIZE
                            and modify_status == ModifyStatus.TIMESTAMP_CHANGED
                        )
                        if policy_matches and not dest_conn.describe(PosixPath(self.dest_path, discarded_path)):
                            dest_conn.store(local_file, PosixPath(self.dest_path, discarded_path))
                            output.append(
                                {
                                    "source_path": str(PosixPath(source_feed.path) / remote_filename),
                                    "path": self.dest_path + discarded_path,
                                    "is_discarded": True,
                                }
                            )
                            self.logger.warning(f"Trovato file modificato alla sorgente, scaricato in {discarded_path}")
                            apprise_alert(
                                message=f"Trovato file modificato alla sorgente, scaricato in {discarded_path}",
                                title="File modificato in PullStream",
                                type="warning",
                            )
                    else:
                        dest_conn.store(local_file, PosixPath(self.dest_path, remote_key))
                        output.append(
                            {
                                "source_path": str(PosixPath(source_feed.path) / remote_filename),
                                "path": self.dest_path + remote_key,
                                "is_discarded": False,
                            }
                        )
                if self.delete_from_source:
                    conn.delete(PosixPath(source_feed.path) / remote_filename)

        if modify_status == ModifyStatus.NEW and len(output) > 0:
            self.logger.info(f"New files ( {len(output)} ) have been pulled")
        return output

    def calendarized_dirname(self, source_feed: Source, filename: str, filemeta: FtpFileMetadata) -> str:
        date_, _, _ = _dest_date_and_name(source_feed, filename, filemeta)
        return str(PosixPath(f"{self.dest_path.strip('/')}/", build_key(self.source_label, date_, None, None)))


def check_for_foreign_files(
    prefix: str, filename: str, date_regexes: set[str], check_date_name: bool, source_feed: Source, check: bool
) -> None:
    if not check or _ignored(source_feed, filename):
        return

    WARN = "Non mettere file a mano nelle directory calendarizzate dai Flow! "
    try:
        filename_, timestamp = filename.split("@")
    except ValueError:
        raise ValueError(f"{WARN} ( {filename} non è un filename valido )")
    ts_pattern = r"^(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}\+\d{2}-\d{2})$"
    if not re.search(ts_pattern, timestamp):
        raise ValueError(f"{WARN} ( {filename} non è un filename valido )")

    if check_date_name:
        y, m, f = prefix.split("/")[-3:]
        prefix_date = date(int(y), int(m), int(f))
        for regex in date_regexes:
            match = re.fullmatch(regex, filename_)
            if match:
                gd = match.groupdict()
                gd["year"] = y if len(gd["year"]) == 4 else f"20{gd['year']}"
                if date(int(gd["year"]), int(gd["month"]), int(gd["day"])) != prefix_date:
                    raise ValueError(
                        f"{WARN} ( {filename} si riferisce ad una data diversa da quella della directory )"
                    )
                return
        raise ValueError(f"{WARN} ( {filename} non è un filename valido )")
