import re
from datetime import timedelta
from pathlib import PosixPath
from typing import Any, cast

from pymol.ext.auth import from_vault
from pymol.ext.ftp import RemoteFtpFiles, ftp_conn
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import ErrorRow, TaskData


class ListRemoteFiles(Task):  # pragma: nocover
    """Lista i file presenti su una risorsa remota.

    Esempio:

    ```
    list = ListRemoteFiles(
        # la label di configurazione della risorsa
        auth_label="ftp-banca",
        )
    files = list("/path/to/search/")
    ```
    """

    def __init__(
        self,
        auth_label: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.auth_label = auth_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, remote_path: PosixPath) -> RemoteFtpFiles:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            with ftp_conn(from_vault(self.auth_label)) as conn:
                return conn.describe(remote_path)


class DownloadRemoteFiles(Task):  # pragma: nocover
    """Scarica file da una  risorsa remota.

    Esempio:

    ```
    download = DownloadRemoteFiles(
        auth_label = "ftp-banca", # la chiave vault di configurazione della risorsa
        path_label = "path", # la colonna dei data che contiene il path dei file da scaricare
        )

    local_paths = download(data_rows)

    accetta un TaskData fatto così :

    {   "data": [
            {"path": "directory/dove/cercare", "rx": r"^regex da cercare"},
            # scarica tutti i file col nome che segue la regex
            {"path": "directory/e/file.csv"},
            # scarica quel file se presente
            {"path": "directory/dove/cercare}
            # scarica tutti i file nella directory
        ] ...

    e restituisce un TaskData fatto così:

    {   "data": [
            {"path": "path locale del file scaricato",
             "source_path": "path remoto del file",
             "timestamp": "timestamp del file remoto"},
        ...

    ```
    """

    def __init__(
        self,
        auth_label: str,
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.auth_label = auth_label
        self.path_label = path_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: TaskData) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output = []
            errors: list[ErrorRow] = []
            source_conf = from_vault(self.auth_label)

            with ftp_conn(source_conf) as conn:
                for row in data["data"]:
                    try:
                        if "rx" not in row:
                            dirlist = conn.describe(PosixPath(row["path"]))
                            for filename in dirlist:
                                remote_path = PosixPath(dirlist[filename].key)
                                local_path = conn.retrieve(remote_path, cast(PosixPath, self.dirspace))
                                found = {
                                    "path": local_path,
                                    "source_path": remote_path,
                                    "timestamp": dirlist[filename].modify.isoformat(),
                                }
                                output.append(found)

                        else:
                            dirlist = conn.describe(PosixPath(row["path"]))
                            for filename in dirlist:
                                remote_path = PosixPath(dirlist[filename].key)
                                reg_ = re.compile(row["rx"])
                                match = re.search(reg_, filename)
                                if match:
                                    local_path = conn.retrieve(remote_path, cast(PosixPath, self.dirspace))
                                    found = {
                                        "path": local_path,
                                        "source_path": remote_path,
                                        "timestamp": dirlist[filename].modify.isoformat(),
                                    }
                                    output.append(found)
                    except Exception as e:
                        errors.append({"error": str(e), "source": row})

            return {
                "data": output,
                "errors": errors,
                "meta": {"isEmpty": len(output) == 0, "hasErrors": len(errors) > 0},
            }
