from datetime import timedelta
from typing import Any, Optional, cast

import prefect
import requests

from pymol.ext.auth import from_vault, local_token
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, ScheduledDate, Task, raise_job_fail
from pymol.types.jobs import TaskData


def _inject_params(params: dict[str, str]) -> dict[str, str]:
    output = params.copy()
    for k, v in params.items():
        if isinstance(v, ScheduledDate):
            output[k] = (prefect.context.scheduled_start_time + timedelta(days=v.plus_days)).strftime("%Y-%m-%d")
        else:
            output[k] = v
    return output


class RawQueryCLC(Task):
    """Recupera dati da query SQL sul database CLC.

    Esempio:

    ```
    query = RawQueryCLC(
        # il nome che vogliamo vedere a UI
        name="query note",
        # la query, con ':' davanti al nome per identificare i parametri
        query="SELECT nome FROM clienti WHERE cod_cliente = :cod",
        )
    dati = query(params={"cod": 246}) # i valori dei parametri
    ```
    """

    def __init__(
        self,
        query: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.query = query
        super().__init__(**kwargs)

    def run(self, params: dict[str, Any] = {}) -> TaskData:  # type:ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            payload = {"query_": self.query}
            payload.update(_inject_params(params))

            try:
                gate = from_vault("gate_dn")
                resp = requests.get(f"{gate['host']}clc/raw-query", params=payload, headers={"BEARER": local_token()})
            except requests.exceptions.ConnectionError as error:
                raise prefect.engine.signals.FAIL(f"ConnectionError: {str(error)[:128]}") from None

            if resp.status_code != 200:
                raise_job_fail(resp)
            return cast(TaskData, resp.json().get("data"))


class QueryCLC(Task):  # pragma: nocover
    """Recupera dati dal database CLC.

    Esempio:

    ```
    query = QueryCLC(
        # il nome che vogliamo vedere a UI
        name="query note",
        # il tipo di query
        query="note_cliente",
        )
    dati = query(params={"cod_cliente": 246, "data_inizio ... # i valori dei parametri
    ```
    """

    def __init__(
        self,
        query: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.query = query
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, params: dict[str, Any] = {}) -> TaskData:  # type:ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            payload = {"query": self.query}
            payload.update(_inject_params(params))

            gate = from_vault("gate_dn")
            resp = requests.get(f"{gate['host']}clc/query", params=payload, headers={"BEARER": local_token()})

            if resp.status_code != 200:
                raise_job_fail(resp)
            return cast(TaskData, resp.json().get("data"))
