import json
import re
from datetime import timedelta
from typing import Any, Iterator, Match, Optional, Union, cast

from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, TaskData

REG_HEADS = re.compile(r"{1:[^}]+}", re.DOTALL)
REG_BODIES = re.compile(r"{1:[^}]+}({2:[^}]+})?({3:[^}]+})?({4:[^}]+-})?({5:[^}]+})?", re.DOTALL)

TEXT_TAGS = re.compile(r":\d{2}\w?:", re.DOTALL)

BASIC_ = re.compile("({1:(?P<basic_header>[^}]+)})?", re.DOTALL)
APPLICATION_ = re.compile(r"({2:(?P<application_header>(I|O)[^}]+)})?", re.DOTALL)
USER_ = re.compile(
    r"({3:"
    r"(?P<user_header>"
    r"({113:[A-Z]{4}})?"
    r"({108:[A-Z 0-9]{0,16}})?"
    r"({111:[0-9]{3}})?"
    r"({121:[a-zA-Z0-9]{8}-[a-zA-Z0-9]{4}-4[a-zA-Z0-9]{3}-[89ab][a-zA-Z0-9]{3}-[a-zA-Z0-9]{12}})?"
    r")"
    r"})?",
    re.DOTALL,
)
TEXT_ = re.compile(r"({4:\s*(?P<text>.+?)\s*-})?", re.DOTALL)
TRAILER_ = re.compile(r"({5:(?P<trailer>.+)})?", re.DOTALL)

BASIC = re.compile(
    r"{1:(?P<payload>(?P<application_id>\w)(?P<service_id>\d{2})(?P<terminal_address>\w{12})"
    r"(?P<session>\d{4})(?P<sequence>\d{6}))}",
    re.DOTALL,
)
APPLICATION = re.compile(
    r"{2:(?P<payload>(?P<mode>I)(?P<mt>\d{3})(?P<bic>\w{8})(?P<logical_terminal_code>\w)"
    r"(?P<branch_code>\w{3})(?P<priority>\w)"
    r"(?P<delivery_monitoring>\d)?(?P<non_delivery_notification_period>\d{3})?)}",
    re.DOTALL,
)
USER = re.compile(
    r"({3:(?P<payload>"
    r"(?P<bank_priority_code>{113:[A-Z]{4}})?"
    r"(?P<message_user_reference>{108:[A-Z 0-9]{0,16}})?"
    r"(?P<search_me_a>{111:[0-9]{3}})?"
    r"(?P<search_me_b>{121:[a-zA-Z0-9]{8}-[a-zA-Z0-9]{4}-4[a-zA-Z0-9]{3}-[89ab][a-zA-Z0-9]{3}-[a-zA-Z0-9]{12}})?"
    r")})?",
    re.DOTALL,
)
TEXT = re.compile(r"({4:\s*(?P<payload>.+?)\s*-})?", re.DOTALL)
TRAILER = re.compile(r"({5:(?P<payload>.+)})?", re.DOTALL)

OPTIONALS = {
    "940": (
        "61",
        ("86",),
    ),
    "941": (
        "62F",
        ("86",),
    ),
}


class ReadSwift(Task):
    """Recupera dati da un file SWIFT.

    Esempio:

    ```
    read = ReadSwift()
    dati = read("/path/to/swift.txt")
    ```
    """

    def __init__(
        self,
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        encoding: str = "utf-8",
        **kwargs: Any,
    ) -> None:
        self.path_label = path_label
        self.encoding = encoding
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def split(self, m: str) -> Iterator[list[str]]:
        heads = re.findall(REG_HEADS, m)
        bodies = re.findall(REG_BODIES, m)
        for head, body in zip(heads, bodies):
            raw_message = head, *body
            yield cast(list[str], raw_message)

    def _parse_basic(self, block: Match[Any]) -> dict[str, str]:
        m = re.match(BASIC, block.string)
        if not m:
            raise ValueError
        return m.groupdict()

    def _parse_application(self, block: Match[Any]) -> dict[str, str]:
        m = re.match(APPLICATION, block.string)
        if not m:
            raise ValueError
        return m.groupdict()

    def _parse_user(self, block: Match[Any]) -> dict[str, str]:
        m = re.match(USER, block.string)
        if not m:
            raise ValueError
        return m.groupdict()

    def _init_optionals_tracking(self, mt: str) -> None:
        if mt in OPTIONALS:
            self._block_tag = OPTIONALS[mt][0]
            self._tracked_optionals = {k: False for k in OPTIONALS[mt][1]}
            self._first_block_tag = True

    def _track_optionals(self, mt: str, key: str, json_payload: dict[str, list[str]]) -> None:
        if mt in OPTIONALS:
            if key == self._block_tag and not self._first_block_tag:
                for k in self._tracked_optionals:
                    if k not in json_payload and not self._tracked_optionals[k]:
                        json_payload[k] = [
                            "",
                        ]
                    else:
                        if not self._tracked_optionals[k]:
                            json_payload[k].append("")
                self._tracked_optionals = {k: False for k in OPTIONALS[mt][1]}
            elif key == self._block_tag and self._first_block_tag:
                self._first_block_tag = False
            elif key != self._block_tag and not self._first_block_tag and key in self._tracked_optionals:
                self._tracked_optionals[key] = True

    def _pad_optionals(self, mt: str, json_payload: dict[str, list[str]]) -> None:
        if mt in OPTIONALS:
            for k in OPTIONALS[mt][1]:
                if k in json_payload:
                    if len(json_payload[k]) < len(json_payload[OPTIONALS[mt][0]]):
                        json_payload[k].append("")
                else:
                    json_payload[k] = [
                        "",
                    ]

    def _parse_text(self, block: Match[Any], mt: str) -> dict[str, list[str]]:
        output = {}
        m = re.match(TEXT, block.string)
        if not m:
            raise ValueError
        text = m["payload"]
        output["payload"] = m["payload"]
        tags = re.findall(TEXT_TAGS, text)
        json_payload: dict[str, list[str]] = {}

        self._init_optionals_tracking(mt)

        for i in range(len(tags)):
            tag = tags[i]
            to_tag = tags[i + 1] if i + 1 < len(tags) else "$"
            contained_text = re.search(f"{tag}(?P<value>.+?){to_tag}", text, re.DOTALL)
            text = text[contained_text.span()[1] - len(to_tag) :]  # type: ignore
            value = contained_text["value"].strip(":\n ")  # type: ignore
            key = tag.strip(":")

            self._track_optionals(mt, key, json_payload)

            if key not in json_payload:
                json_payload[key] = [
                    value,
                ]
            else:
                json_payload[key].append(value)

        self._pad_optionals(mt, json_payload)
        output["json_payload"] = json.dumps(json_payload)
        return cast(dict[str, list[str]], output)

    def _parse_trailer(self, block: Match[Any]) -> dict[str, str]:
        m = re.match(TRAILER, block.string)
        if not m:
            raise ValueError
        return m.groupdict()

    def parse(self, message: list[str]) -> dict[str, Union[dict[str, str], dict[str, list[str]]]]:
        basic = re.search(BASIC_, message[0])
        application = re.search(APPLICATION_, message[1])
        user = re.search(USER_, message[2])
        text = re.search(TEXT_, message[3])
        trailer = re.search(TRAILER_, message[4])

        if not all((basic, application, user, text, trailer)):
            raise ValueError

        application_ = self._parse_application(cast(Match[Any], application))

        return {
            "basic": self._parse_basic(cast(Match[Any], basic)),
            "application": application_,
            "user": self._parse_user(cast(Match[Any], user)),
            "text": self._parse_text(cast(Match[Any], text), application_["mt"]),
            "trailer": self._parse_trailer(cast(Match[Any], trailer)),
        }

    def run(self, data: DataRow, encoding: Optional[str] = None) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output = []
            filepath = data[self.path_label]
            with open(filepath, encoding=encoding if encoding else self.encoding) as file:
                for raw_message in self.split(file.read()):
                    message = self.parse(raw_message)
                    output.append(message)

            meta_dict = {k: v for k, v in data.items()}
            meta_dict["isEmpty"] = len(output) == 0
            return {"data": output, "errors": [], "meta": meta_dict}


class ReadSwiftNew(ReadSwift):
    def __init__(
        self,
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.path_label = path_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _parse_text(self, block: Match[Any], mt: str) -> dict[str, list[str]]:  # noqa
        output = {}
        m = re.match(TEXT, block.string)
        if not m:
            raise ValueError
        text = m["payload"]
        output["payload"] = m["payload"]
        tags = re.findall(TEXT_TAGS, text)
        payload: dict[str, Any] = {}

        last_seen_node = None
        current_node: list[str] = []
        repetition_pointer = 0
        for i in range(len(tags)):
            tag = tags[i]
            to_tag = tags[i + 1] if i + 1 < len(tags) else "$"
            contained_text = re.search(f"{tag}(?P<value>.+?){to_tag}", text, re.DOTALL)
            text = text[contained_text.span()[1] - len(to_tag) :]  # type: ignore
            val = contained_text["value"].strip(":\n ")  # type: ignore
            key = tag.strip(":")
            if key == "16R":
                node_key = f"{key}_{val}"
                current_node.append(node_key)
                pointer = payload
                for k in current_node[:-1]:
                    pointer = pointer[k]
                if node_key == last_seen_node:  # repeating
                    if isinstance(pointer[node_key], dict):
                        pointer[node_key] = [
                            pointer[node_key],
                        ]
                        repetition_pointer = 0
                    pointer[node_key].append({})
                    repetition_pointer += 1
                else:
                    repetition_pointer = 0
                    pointer[node_key] = {}

            if key == "16S":
                last_seen_node = current_node.pop()

            if key not in ("16R", "16S"):
                pointer = payload
                for k in current_node:
                    pointer = pointer[k]
                if isinstance(pointer, dict):  # non repetitive
                    if key in pointer:
                        if isinstance(pointer[key], str):
                            pointer[key] = [
                                pointer[key],
                            ]
                        pointer[key].append(val)
                    else:
                        pointer[key] = val
                if isinstance(pointer, list):  # repetitive
                    inside_pointer = pointer[repetition_pointer]
                    if key in inside_pointer:
                        if isinstance(inside_pointer[key], str):
                            inside_pointer[key] = [
                                inside_pointer[key],
                            ]
                        inside_pointer[key].append(val)
                    else:
                        inside_pointer[key] = val

        output["json_payload"] = json.dumps(payload)
        return cast(dict[str, list[str]], output)
