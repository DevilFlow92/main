from datetime import timedelta
from typing import Any, Optional

import xmltodict

from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, TaskData


class ReadXMLAsDict(Task):
    """Trasforma un file XML in un dizionario.

    In presenza di attributi gli attributi diventano chiavi prefisse da "@" e il testo
    viene prefisso da "#text".

    Esempio:

    ```
    read = ReadXMLAsDict()
    dati = read({"path": "path/to/file.xml"})  # {"data": {"xmlasdict": { .... }}}
    """

    def __init__(
        self,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, filepath: DataRow) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            with open(filepath["path"], "r") as f:
                output = xmltodict.parse(f.read())

            return {
                "data": [
                    {"xmlasdict": output},
                ],
                "errors": [],
                "meta": {"isEmpty": len(output.keys()) == 0},
            }
