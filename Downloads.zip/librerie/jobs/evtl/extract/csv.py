import csv
import re
from datetime import timedelta
from typing import Any, Iterator, Optional, Set, cast

from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.jobs.evtl.extract.core import ReadAndValidate
from pymol.logger import LogLevel
from pymol.types.jobs import DataRow, ErrorRow, TaskData


def _apply_skip_lines(skip_lines, csvfile) -> Iterator[str]:  # type: ignore
    for _ in range(skip_lines):
        try:
            csvfile.readline()
        except StopIteration:
            raise ValueError(f"Not enough lines to skip (skip_lines={skip_lines})")

    return csvfile  # type: ignore


class ValidateCsv(ReadAndValidate):
    """Legge e valida dati contenuti in un file CSV.

    Esempio:

    ```
    read = ValidateCsv(
        # i nomi e regole di validazione delle colonne da leggere
        rules={
            "-": # usiamo questo valore di default per avere un formato
            # compatibile con le regole dei fogli excel
            {
                "nome": FieldRule(str),
                # qualsiasi opzione di un campo Schema è applicavile a FieldRule
                "cognome": FieldRule(Coerce(to_stripped_string()))
            },},
        options={ # i valori sono quelli di default
            "encoding": "utf-8",
            "allow_missing_keys": False,
            "custom_nones": set(),
            "path_label": "path",
            "sheet_label": "sheet",
            }
        )
    dati = read({"path": "path/to/file.csv"}) # righe non validate saranno in errors
    ```
    """

    _options = {
        "headless": (bool, False),
        "sep": (str, ","),
        "skip_lines": (int, 0),
    }

    def _run(
        self, data: DataRow, option_overrides: dict[str, Any] = {}
    ) -> Iterator[tuple[DataRow, None] | tuple[None, ErrorRow]]:
        with open(data[self.op("path_label")], encoding=self.op("encoding")) as csvfile:
            input_rows = _apply_skip_lines(self.op("skip_lines"), csvfile)
            reader = csv.DictReader(
                input_rows,
                fieldnames=[f for f in self.rules["-"]] if self.op("headless") else None,
                restval="*_MISSING_COL_*" if not self.op("allow_missing_keys") else None,
                delimiter=self.op("sep"),
            )
            try:
                for row in reader:
                    try:
                        yield self._clean(row), None
                    except ValueError as exc:
                        yield None, cast(ErrorRow, {"error": str(exc), "source": row})
            except UnicodeDecodeError as exc:
                self.log.message(
                    f"Non riesco a leggere {data[self.op('path_label')]} ({exc}), "
                    "setta l'encoding corretto con options={'encoding':... nella configurazione del Task.",
                    LogLevel.ERROR,
                )
                raise exc from None


class ReadCsv(Task):
    """Legge i dati contenuti in un file CSV.

    Esempio:

    ```
    read = ReadCsv(
        # i nomi delle colonne che si vogliono recuperare
        fields=("nome", "cognome"),
        # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
        encoding="cp-1252",
        )
    dati = read("path/to/file.csv")
    ```
    """

    def __init__(
        self,
        fields: tuple[str, ...],
        headless: bool = False,
        encoding: str = "utf-8",
        skip_lines: int = 0,
        allow_missing_cols: bool = False,
        custom_nones: Set[str] = set(),
        options: dict[str, str] = {},
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta | None = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.fieldnames = fields
        self.headless = headless
        self.encoding = encoding
        self.skip_lines = skip_lines
        self.allow_missing_cols = allow_missing_cols
        self.custom_nones = custom_nones
        self.options = options
        self.path_label = path_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _clean(self, row: DataRow) -> DataRow:
        _row = dict(
            [
                (k, v if v not in self.custom_nones else None)
                for k, v in row.items()
                if k in self.fieldnames and v != "*_MISSING_COL_*"
            ]
        )
        diff = set(self.fieldnames).difference(set(_row.keys()))
        if diff and not self.allow_missing_cols:
            raise ValueError(f"Skipped row, missing required columns: {diff} in row: {row}")
        return _row

    def run(self, data: DataRow, encoding: Optional[str] = None) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output, errors = [], []
            with open(data[self.path_label], encoding=encoding if encoding else self.encoding) as csvfile:
                input_rows = _apply_skip_lines(self.skip_lines, csvfile)
                reader = csv.DictReader(  # type: ignore
                    input_rows,
                    fieldnames=[f for f in self.fieldnames] if self.headless else None,
                    restval="*_MISSING_COL_*" if not self.allow_missing_cols else None,
                    **self.options,
                )
                try:
                    for row in reader:
                        try:
                            output.append(self._clean(row))
                        except ValueError as exc:
                            errors.append(cast(ErrorRow, {"error": str(exc), "source": row}))
                except UnicodeDecodeError as exc:
                    self.log.message(
                        f"Non riesco a leggere {data[self.path_label]} ({exc}), "
                        "setta l'encoding corretto con 'encoding=...' nella configurazione del Task.",
                        LogLevel.ERROR,
                    )
                    raise exc

            meta_dict = {k: v for k, v in data.items()}
            meta_dict["isEmpty"] = len(output) == 0
            meta_dict["sheet"] = "-"
            return {"data": output, "errors": errors, "meta": meta_dict}


class ReadDynamicFixedWidth(Task):
    """Recupera dati da un file con colonne di larghezza variabile.

    Esempio:

    ```
    read = ReadDynamicFixedWidth(
        # mappatura delle colonne in base ai caratteri ad inizio riga
        fields=fields={
                "01": {
                    "a": (0, 3),
                    "b": (3, 5),
                },
                "02": {
                    "x": (0, 2),
                    "y": (2, 5),
                },
            },
        # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
        encoding="cp-1252",
        )
    dati = read("path/to/file.csv")
    ```
    """

    def __init__(
        self,
        fields: dict[str, dict[str, tuple[int, Optional[int]]]],
        skip_lines: int = 0,
        encoding: str = "utf-8",
        allow_missing_cols: bool = True,
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        accept_line_re: list[str] = [],
        reject_line_re: list[str] = [],
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.fields = fields
        self.skip_lines = skip_lines
        self.encoding = encoding
        self.allow_missing_cols = allow_missing_cols
        self.path_label = path_label
        self.accept_line_re = accept_line_re
        self.reject_line_re = reject_line_re
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _parsable(self, row: str) -> bool:
        """Da usare per filtrare la linea prima del parsing."""
        if self.accept_line_re and not self.reject_line_re:
            for reg in self.accept_line_re:
                match = re.findall(reg, row)
                if match:
                    return True

            return False

        if not self.accept_line_re and self.reject_line_re:
            for reg in self.reject_line_re:
                match = re.findall(reg, row)
                if match:
                    return False

            return True

        if self.accept_line_re and self.reject_line_re:
            raise NotImplementedError("Non è possibile inserire sia un criterio di accettazione che di rifiuto.")

        return True

    def _parse(self, row: str) -> DataRow:
        output = {}
        for kk in self.fields.keys():
            if row.startswith(kk):
                for k, v in self.fields[kk].items():
                    if (
                        v[1] is None or len(row) >= v[1] or self.allow_missing_cols
                    ):  # avoid values shorter than declared width unless specified
                        val = row[v[0] + len(kk) : v[1] + len(kk) if v[1] is not None else len(row)]
                        output[k] = val if len(val) else None
                    else:
                        incomplete_val = row[v[0] + len(kk) : len(row)]
                        raise ValueError(f"Valore incompleto per '{k}' : {incomplete_val}")
                output["row_type"] = kk
                return output
        else:
            raise ValueError(f"Non esiste regola per parsare la riga: {row}")

    def run(self, data: DataRow) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output, errors = [], []
            source_path = data[self.path_label]
            with open(source_path, encoding=self.encoding) as fwfile:
                input_rows = _apply_skip_lines(self.skip_lines, fwfile)
                for row in input_rows:
                    try:
                        if self._parsable(row.strip()):
                            output.append(self._parse(row.strip()))
                    except ValueError as exc:
                        errors.append(cast(ErrorRow, {"error": str(exc), "row": row}))

            meta_dict = {k: v for k, v in data.items()}
            meta_dict["isEmpty"] = len(output) == 0
            return {"data": output, "errors": errors, "meta": meta_dict}


class ReadFixedWidth(Task):
    def __init__(
        self,
        fields: dict[str, tuple[int, Optional[int]]],
        skip_lines: int = 0,
        encoding: str = "utf-8",
        allow_missing_cols: bool = True,
        path_label: str = "path",
        max_retries: int = MAX_RETRIES,
        accept_line_re: list[str] = [],
        reject_line_re: list[str] = [],
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.fields = fields
        self.skip_lines = skip_lines
        self.encoding = encoding
        self.allow_missing_cols = allow_missing_cols
        self.path_label = path_label
        self.accept_line_re = accept_line_re
        self.reject_line_re = reject_line_re
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, data: DataRow) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output, errors = [], []
            source_path = data[self.path_label]
            with open(source_path, encoding=self.encoding) as csvfile:
                input_rows = _apply_skip_lines(self.skip_lines, csvfile)
                for row in input_rows:
                    try:
                        if self._parsable(row.strip()):
                            output.append(self._parse(row.strip()))
                    except ValueError as exc:
                        errors.append(cast(ErrorRow, {"error": str(exc), "row": row}))

            meta_dict = {k: v for k, v in data.items()}
            meta_dict["isEmpty"] = len(output) == 0
            return {"data": output, "errors": errors, "meta": meta_dict}

    def _parse(self, row: str) -> DataRow:
        output = {}
        for k, v in self.fields.items():
            if (
                v[1] is None or len(row) >= v[1] or self.allow_missing_cols
            ):  # avoid values shorter than declared width unless specified
                val = row[v[0] : v[1] if v[1] is not None else len(row)]
                output[k] = val if len(val) else None
            else:
                incomplete_val = row[v[0] : len(row)]
                raise ValueError(f"Valore incompleto per '{k}' : {incomplete_val}")

        return output

    def _parsable(self, row: str) -> bool:
        """Da usare per filtrare la linea prima del parsing."""
        if self.accept_line_re and not self.reject_line_re:
            for reg in self.accept_line_re:
                match = re.findall(reg, row)
                if match:
                    return True

            return False

        if not self.accept_line_re and self.reject_line_re:
            for reg in self.reject_line_re:
                match = re.findall(reg, row)
                if match:
                    return False

            return True

        if self.accept_line_re and self.reject_line_re:
            raise NotImplementedError("Non è possibile inserire sia un criterio di accettazione che di rifiuto.")

        return True
