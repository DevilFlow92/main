import re
from datetime import date, datetime, time, timedelta
from typing import Any, Callable, Collection, Iterator, Optional, Union, cast

import xlrd
from openpyxl import Workbook, cell, load_workbook

from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.jobs.evtl.extract.core import ReadAndValidate
from pymol.types.jobs import DataDict, DataMatrix, DataRow, ErrorRow, TaskData

CellValue = Union[float, str, int]
ParsedCellValue = Optional[CellValue]
CellCoordinates = tuple[int, int]

CellValueParser = Callable[[CellValue, Any], ParsedCellValue]


def _xw24_(hit: re.Match[str]) -> str:
    """."""
    m = hit.group(0)
    if type(m) == str:
        m = m.replace("_x", "").replace("_", "")
        index = int(m, 16)
        if index == 0:
            return ""
        return chr(index)
    return ""


def clean_unicode(
    string: str,
    pattern: str = r"_x\w{2,4}_",
    sub_fun: Callable[[re.Match[str]], str] = _xw24_,
    fix: None | bool = True,
) -> str:
    """."""
    if fix:
        return re.sub(pattern, sub_fun, string)
    return string


CORRUPTION_WARNING = """La lettura della riga torna meno colonne di quelle dichiarate.
Potrebbe essere corrotto e non dichiarare correttamente le sue dimensioni.
L'opzione 'fix_dimensions' -potrebbe- correggere il problema."""


def _read_excel(  # noqa C901
    log: Any,
    path: str,
    sheet_name: str | None = None,
    fields: Collection[str] = [],
    accept_duplicated: bool = False,
    headless: bool = False,
    header_row: int | None = 1,
    data_start_row: int = 2,
    fix_powerapp_columns: bool = False,
    fix_dimensions: bool = True,
    external_fields: Collection[str] = [],
    disable_row_checks: bool = False,
    load_as_rw: bool = False,
) -> Iterator[tuple[DataRow, None] | tuple[None, ErrorRow] | tuple[None, None]]:
    f = open(path, "rb")
    workbook = load_workbook(f, data_only=True, read_only=not load_as_rw, keep_links=False)
    if sheet_name is not None and sheet_name not in workbook.sheetnames:
        log.warning(f"Sheet '{sheet_name}' non presente nel file {path}")
        return None, None
    if sheet_name is None:
        sheet = workbook.active
        sheet_name = sheet.title
    else:
        sheet = workbook[sheet_name]
    if fix_dimensions:
        sheet.reset_dimensions()
    column_list = (
        [clean_unicode(cell.value, fix=fix_powerapp_columns) for cell in sheet[header_row]] if not headless else fields
    )
    if len(column_list) > len(set(column_list)) and not accept_duplicated:
        raise ValueError("Il file contiene intestazioni di colonna duplicate.")

    expected_rowlen = len(fields) - len(external_fields)
    for row in sheet.iter_rows(min_row=data_start_row):
        try:
            row_values = [ReadExcel.parse_cell_value(cell, workbook) for _, cell in enumerate(row)]
            if any(row_values):
                row_dict = dict(zip(column_list, row_values))
                row = {k: v for k, v in row_dict.items() if k in fields}
                if not disable_row_checks and len(row) != expected_rowlen:
                    raise ValueError(CORRUPTION_WARNING)
                yield row, None

        except Exception as ex:
            log.error(f"Errore nella lettura del file {path}")
            yield None, {"error": str(ex), "source": {"raw_data": str(row)}}  # type: ignore

    workbook.close()


class ValidateExcel(ReadAndValidate):
    """Legge e valida dati contenuti in un file Excel.

    Esempio:

    ```
    read = ValidateExcel(
        # i nomi e regole di validazione delle colonne da leggere, divise per foglio
        rules={
            "foglio1":
            {
                "nome": FieldRule(str),
                # qualsiasi opzione di un campo Schema è applicavile a FieldRule
                "cognome": FieldRule(Coerce(to_stripped_string()))
            },},
        options={ # i valori sono quelli di default
            "encoding": "utf-8",
            "sheet_label": "sheet",
            "headless": False,
            "header_row": 1,
            "data_start_row": 2,
            "fix_powerapp_columns": False,
            }
        )
    dati = read({"path": "path/to/file.csv", "sheet": "Foglio1"}) # righe non validate saranno in errors
    ```
    """

    _options = {
        "headless": (bool, False),
        "header_row": (int, 1),
        "data_start_row": (int, 2),
        "fix_powerapp_columns": (bool, False),
        "fix_dimensions": (bool, True),
        "accept_duplicated": (bool, False),
        "disable_row_checks": (bool, False),
        "load_as_rw": (bool, False),
    }

    def _run(
        self, data: DataRow, option_overrides: dict[str, Any] = {}
    ) -> Iterator[tuple[DataRow, None] | tuple[None, ErrorRow | None]]:
        for row, error in _read_excel(
            log=self.log,
            path=data["path"],
            sheet_name=data["sheet"],
            fields=self.rules[data["sheet"]].keys(),
            accept_duplicated=self.op("accept_duplicated"),
            headless=self.op("headless"),
            header_row=self.op("header_row"),
            data_start_row=self.op("data_start_row"),
            fix_powerapp_columns=self.op("fix_powerapp_columns"),
            fix_dimensions=self.op("fix_dimensions"),
            external_fields=self.op("external_fields"),
            disable_row_checks=self.op("disable_row_checks"),
            load_as_rw=self.op("load_as_rw"),
        ):
            if row is not None:
                try:
                    yield self._clean(row), None
                except ValueError as exc:
                    yield None, cast(ErrorRow, {"error": str(exc), "source": row})
            else:
                yield None, error


class ReadExcel(Task):
    """Recupera dati in forma tabellare da un file Excel.

    Esempio:

    ```
    read = ReadExcel(
        # i nomi delle colonne che si vogliono recuperare
        fields=("nome", "cognome"),
        # il nome del foglio che si vuole leggere
        sheet_name="anagrafica",
        # il numero riga che contiene l'header
        header_row=1,
        # il numero riga di inizio dei dati
        data_start_row=3,
        )
    read( data_to_be_read )
    ```

    Esempio senza header:
    ```
    read = ReadExcel(
        # i nomi delle colonne che si vogliono recuperare
        fields=("nome", "cognome"),
        # il nome del foglio che si vuole leggere
        sheet_name="anagrafica",
        # il numero riga di inizio dei dati
        data_start_row=3,
        # flag headless
        headless = True
        )
    read( data_to_be_read )
    ```

    Esempio colonne duplicate sul file.
    E' possibile leggere un excel con colonne duplicate specificando:
    headless = True
    duplicetad_columns = True

    NB: si dovranno specificare i fields nell' ordine di lettura del file:

    #header del file excel con duplicati
    Nome Cognome Importo Indirizzo Importo

    #fields del task
    fields = ("Nome", "Cognome, "Primo Importo", "Indirizzo", "Secondo Importo")

    ```
    read = ReadExcel(
        # i nomi delle colonne che si vogliono recuperare
        fields = ("Nome", "Cognome, "Primo Importo", "Indirizzo", "Secondo Importo")
        # il nome del foglio che si vuole leggere
        sheet_name="anagrafica",
        # il numero riga di inizio dei dati
        data_start_row=3,
        # flag headless
        headless = True
        #flag colonne duplicate
        duplicetad_columns = True
        )
    read( data_to_be_read )
    ```
    """

    def __init__(
        self,
        fields: Collection[str],
        data_start_row: int,
        sheet_name: str | None = None,
        path_label: str = "path",
        headless: bool = False,
        header_row: int | None = None,
        duplicated_columns: bool = False,
        fix_powerapp_columns: bool = False,
        fix_dimensions: bool = True,
        external_fields: Collection[str] = (),
        disable_row_checks: bool = False,
        load_as_rw: bool = False,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.fields = fields
        self.data_start_row = data_start_row
        self.sheet_name = sheet_name
        self.path_label = path_label
        self.headless = headless
        self.header_row = header_row
        self.accept_duplicated = duplicated_columns
        self.fix_powerapp_columns = fix_powerapp_columns
        self.fix_dimensions = fix_dimensions
        self.external_fields = external_fields
        self.disable_row_checks = disable_row_checks
        self.load_as_rw = load_as_rw
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    @staticmethod
    def passthrough(value: CellValue, workbook: Workbook) -> CellValue:
        if value:
            return value
        return ""

    @staticmethod
    def parse_bool(value: CellValue, workbook: Workbook) -> bool:
        return bool(value)

    @staticmethod
    def parse_numeric(value: CellValue, workbook: Workbook) -> Any:
        return value

    @staticmethod
    def parse_date(value: date | datetime, workbook: Workbook) -> str:
        if isinstance(value, datetime):
            return value.date().isoformat()
        return value.isoformat()

    @staticmethod
    def parse_time(value: time, workbook: Workbook) -> str:
        return value.isoformat()

    @staticmethod
    def handle_cell_error(value: int, workbook: Workbook) -> None:
        return None

    @staticmethod
    def parse_cell_value(cell: cell, workbook: Workbook) -> Any:
        parser = parsers[cell.data_type]
        return parser(cell.value, workbook)

    def run(self, data: DataRow) -> TaskData:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output = []
            errors = []

            for count, (row, error) in enumerate(
                _read_excel(
                    self.log,
                    data[self.path_label],
                    self.sheet_name,
                    self.fields,
                    self.accept_duplicated,
                    self.headless,
                    self.header_row,
                    self.data_start_row,
                    self.fix_powerapp_columns,
                    self.fix_dimensions,
                    self.external_fields,
                    self.disable_row_checks,
                    self.load_as_rw,
                )
            ):
                if row:
                    output.append(row)
                if error:
                    self.log.warning(f"Error in row {count}: {error}")
                    errors.append(error)

            meta_dict = {k: v for k, v in data.items()}
            meta_dict["isEmpty"] = len(output) == 0
            meta_dict["hasErrors"] = len(errors) > 0
            meta_dict["sheet"] = self.sheet_name if self.sheet_name else "-"
        return {"data": output, "errors": errors, "meta": meta_dict}


class ReadExcelAsMatrix(Task):
    """Recupera dati in forma di matrice da un file Excel.

    Esempio:

    ```
    read = ReadExcelAsMatrix(
        # il nome del foglio che si vuole leggere
        sheet_name="anagrafica",
        # il range di righe che contengono i dati
        rows_range=(3, 10),
        # il range di colonne che contengono i dati
        columns_range=(3, 10),
        )
    dati = read("path/to/file.xls")
    """

    def __init__(
        self,
        sheet_name: str,
        rows_range: tuple[int, int],
        columns_range: tuple[int, int],
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.sheet_name = sheet_name
        self.rows_range = list(rows_range)
        self.columns_range = list(columns_range)
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _read_excel(self, filename: str) -> dict[str, Any]:
        f = open(filename, "rb")
        workbook = load_workbook(f, data_only=True)

        if self.sheet_name not in workbook.sheetnames:
            self.logger.warning(f"Sheet '{self.sheet_name}' non presente nel file {filename}")
            return {}

        sheet = workbook[self.sheet_name]

        column_list = [cell.value for cell in sheet[1][self.columns_range[0] - 1 : self.columns_range[1]]]
        list_rows = []
        for row in sheet.iter_rows(
            min_row=self.rows_range[0],
            max_row=self.rows_range[1],
            min_col=self.columns_range[0],
            max_col=self.columns_range[1],
        ):

            row_values = [ReadExcel.parse_cell_value(cell, workbook) for column_idx, cell in enumerate(row)]

            row_dict = dict(zip(column_list, row_values))
            list_rows.append(row_dict)

        return dict(zip(column_list, list_rows))

    def run(self, filepath: DataRow) -> DataMatrix:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output = dict()
            filepath_ = filepath["path"]

            output = self._read_excel(filepath_)

            return {"data": output, "errors": [], "meta": {"isEmpty": len(output) == 0}}

        with xlrd.open_workbook(filename=filepath_) as workbook:
            sheet = workbook.sheet_by_name(self.sheet_name)
            for row_idx in range(self.rows_range[0], self.rows_range[1] + 1):
                row_key = ReadExcel.parse_cell_value(sheet.cell(row_idx, 0), workbook)
                row_dict = {}
                for col_idx in range(self.columns_range[0], self.columns_range[1] + 1):
                    col_key = ReadExcel.parse_cell_value(sheet.cell(0, col_idx), workbook)
                    row_dict[col_key] = ReadExcel.parse_cell_value(sheet.cell(row_idx, col_idx), workbook)
                output[row_key] = row_dict


class ReadExcelAsDict(Task):
    """Recupera dati in forma di dizionario da un file Excel.

    Esempio:

    ```
    read = ReadExcelAsDict(
        # il nome del foglio che si vuole leggere
        sheet_name="anagrafica",
        # la colonna che contiene le chiavi
        keys_column=2
        # la colonna che contiene i valori
        values_column=3
        # il numero riga di inizio dei dati
        data_start_row=2
        )
    dati = read("path/to/file.xls")
    """

    def __init__(
        self,
        sheet_name: str,
        keys_column: int,
        values_column: int,
        data_start_row: int,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.sheet_name = sheet_name
        self.keys_column = keys_column
        self.values_column = values_column
        self.data_start_row = data_start_row
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def _read_excel(self, filename: str) -> dict[str, Any]:
        output: dict[str, Any] = dict()
        f = open(filename, "rb")
        workbook = load_workbook(f, data_only=True)

        if self.sheet_name not in workbook.sheetnames:
            self.logger.warning(f"Sheet '{self.sheet_name}' non presente nel file {filename}")
            return output

        sheet = workbook[self.sheet_name]
        for row_idx in range(self.data_start_row, sheet.max_row + 1):
            k = ReadExcel.parse_cell_value(sheet.cell(row_idx, self.keys_column), workbook)
            v = ReadExcel.parse_cell_value(sheet.cell(row_idx, self.values_column), workbook)
            output[k] = v

        return output

    def run(self, filepath: DataRow) -> DataDict:  # type: ignore
        with self.log.start_action(self.name), self.log.timed(self.name):
            output = dict()
            filepath_ = filepath["path"]

            output = self._read_excel(filepath_)

            return {"data": output, "errors": [], "meta": {"isEmpty": len(output) == 0}}


"""
https://xlrd.readthedocs.io/en/latest/api.html#xlrd.sheet.Cell
XL_CELL_EMPTY	0	empty string ''
XL_CELL_TEXT	1	a Unicode string
XL_CELL_NUMBER	2	float
XL_CELL_DATE	3	float
XL_CELL_BOOLEAN	4	int; 1 means TRUE, 0 means FALSE
XL_CELL_ERROR	5	int representing internal Excel codes; for a text representation
                    refer to the supplied dictionary error_text_from_code
XL_CELL_BLANK	6	empty string ''.
                    Note: this type will appear only when open_workbook(..., formatting_info=True) is used.
"""

# those cast()s are needed to deal with the ctype/value Cell attributes
# (ie, value is a string when ctype is 0, a float when is 1, an int when is 4)
DATE_TYPES = (datetime, date)
TIME_TYPES = (time,)

parsers: dict[Any, CellValueParser] = {
    cell.cell.TYPE_STRING: ReadExcel.passthrough,
    DATE_TYPES: cast(CellValueParser, ReadExcel.parse_date),
    TIME_TYPES: cast(CellValueParser, ReadExcel.parse_time),
    "d": cast(CellValueParser, ReadExcel.parse_date),
    cell.cell.TYPE_NULL: ReadExcel.passthrough,
    cell.cell.TYPE_BOOL: ReadExcel.parse_bool,
    cell.cell.TYPE_ERROR: cast(CellValueParser, ReadExcel.handle_cell_error),
    cell.cell.TYPE_NUMERIC: cast(CellValueParser, ReadExcel.parse_numeric),
    cell.cell.TYPE_INLINE: ReadExcel.passthrough,
    cell.cell.TYPE_FORMULA_CACHE_STRING: ReadExcel.passthrough,
}
