"""Anthilia deposito file riconciliazione."""
from datetime import date
from typing import Any, List

import pyodbc
from prefect import task
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, UploadFiles, WriteCsv
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData

"Deposita il csv sull'SFTP Antana"


class DepositoCsv_BNPLUX_TIT(Task):
    """Pulisce i dati del csv e li carica a db pronti per essere processati."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self) -> TaskData:  # noqa
        errors = []
        with self.log.start_action(self.name):
            try:  # prova
                self.open()
                # mi procuro DataFlussoNormalizzata e IsPrimoGiornoMese per la creazione nome file
                self.cursor.execute(
                    """
                SELECT TOP 1
                V.DataFlussoNormalizzata
                ,V.IsPrimoGiornoMese
                FROM RS.v_Mikono_Anthilia_BNPLUX_SaldiQuote_AntanaDepositarie_csv AS V""",
                )
                Lettura_DB = self.cursor.fetchone()
                # Campi per preparazione nome file
                DataFlussoNormalizzata = Lettura_DB.DataFlussoNormalizzata
                IsPrimoGiornoMese = Lettura_DB.IsPrimoGiornoMese
                today = date.today().strftime("%Y%m%d")

                if IsPrimoGiornoMese:
                    NomeCsv = "FM_Anthilia_BNPLUX_TIT_" + DataFlussoNormalizzata + "_" + today + ".csv"
                else:
                    NomeCsv = "Anthilia_BNPLUX_TIT_" + DataFlussoNormalizzata + "_" + today + ".csv"

                self.cursor.execute(
                    """
                SELECT V.DataImportNormalizzata
                ,V.DataFlussoNormalizzata
                ,V.TipologiaMismatchFile
                ,V.BancaMismatch
                ,V.Banca
                ,V.depositarieBanca
                ,V.CheckQuantitaAntanaDepositarie
                ,CheckPrezzoAntanaDepositarie
                ,V.Account
                ,V.depositarieAccount
                ,V.Dossier_titoli
                ,V.depositarieDossier_titoli
                ,V.Isin
                ,V.depositarieIsin
                ,V.Descr_titolo
                ,V.depositarieDescr_titolo
                ,V.QuantitaAntanaDepositarie
                ,V.NoteOperatore
                ,V.Quantita
                ,V.depositarieQuantita
                ,V.PrezzoAntanaDepositarie
                ,V.Prezzo
                ,V.depositariePrezzo
                ,V.Divisa
                ,V.depositarieDivisa
                ,V.Cambio
                ,V.depositarieCambio
                ,V.dataFlusso
                ,V.depositarieDataFlusso
                ,V.FileImport
                ,V.depositarieFileImport
                ,V.IsPrimoGiornoMese
                FROM RS.v_Mikono_Anthilia_BNPLUX_SaldiQuote_AntanaDepositarie_csv AS V
                """,
                )
                Lettura = self.cursor.fetchall()

                Dizionario = []
                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

                # DatiDaScrivere, NomeCsv, x = FileLocale()

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere il DB: {str(ex)}")
                self.dbconn.rollback()
                errors.append(f"Presenti errori nel caricamento su SFTP anthana: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.dbconn.close()
                return {"data": Dizionario, "errors": errors, "meta": {"FileName": NomeCsv}}  # type: ignore


@task
def check_condition(errors: List[str]) -> int:
    return len(errors)


with Flow("Anthilia Deposito Csv BNPLUX TIT") as flow:

    FileLocale = DepositoCsv_BNPLUX_TIT(db="db_clc_w")
    DatiDaScrivere = FileLocale()

    write = WriteCsv(
        filename_meta=["FileName"],
        fields=[
            "DataImportNormalizzata",
            "DataFlussoNormalizzata",
            "TipologiaMismatchFile",
            "BancaMismatch",
            "Banca",
            "depositarieBanca",
            "CheckQuantitaAntanaDepositarie",
            "Account",
            "depositarieAccount",
            "Dossier_titoli",
            "depositarieDossier_titoli",
            "Isin",
            "depositarieIsin",
            "Descr_titolo",
            "depositarieDescr_titolo",
            "QuantitaAntanaDepositarie",
            "NoteOperatore",
            "Quantita",
            "depositarieQuantita",
            "Prezzo",
            "depositariePrezzo",
            "Divisa",
            "depositarieDivisa",
            "Cambio",
            "depositarieCambio",
            "dataFlusso",
            "depositarieDataFlusso",
            "FileImport",
            "depositarieFileImport",
            "IsPrimoGiornoMese",
        ],
        options={"delimiter": ";"},
    )
    written_files = write(DatiDaScrivere)
    upload = UploadFiles(auth_label="sftp_mikono_anthilia_antana", dest_prefix="upload")
    upload(written_files)


if __name__ == "__main__":
    res = flow.run()
