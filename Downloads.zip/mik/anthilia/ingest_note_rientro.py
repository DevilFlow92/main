"""Scarica csv con note da sftp mikono anthilia antana, e carica su db."""

import os
import shutil
from pathlib import PosixPath
from typing import Any, Dict, List

import pyodbc
from prefect import case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs import Flow, ReadCsv, SendMail, UploadFiles
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData

####################################################################################################
# DEFINIZIONI
####################################################################################################


@task
# Questo task si connette all'SFTP, e prende l'elenco dei files
def elenco_files() -> Dict[str, Any]:

    if not os.path.exists("/tmp/anthilia/"):
        os.mkdir("/tmp/anthilia/")

    p_locale = "/tmp/anthilia/note"
    shutil.rmtree(p_locale, ignore_errors=True)
    os.mkdir(p_locale)

    conn = ftp_conn(from_vault("sftp_mikono_anthilia_antana"))
    conn.open_connection()
    elenco = conn.describe(PosixPath("download"))

    elenco_files = sorted(
        [(k, v.modify, v.key) for k, v in elenco.items() if "Anthilia_" in k],
        key=lambda x: x[1],
        reverse=True,
    )
    All_Path = []
    FileName = []
    for n in elenco_files:
        percorsi = conn.retrieve(PosixPath(n[2]), PosixPath(p_locale))  # il 2 per tirar fuori v.key
        All_Path.append({"path": percorsi})
        FileName.append({"FileName": str(percorsi).replace(p_locale, "")})
    return {"data": All_Path, "error": [], "meta": FileName}


@task  # type: ignore
# Questo task si connette all'SFTP, e prende l'elenco dei files
def clean_dir_elab(data) -> None:
    conn = ftp_conn(from_vault("sftp_mikono_anthilia_antana"))
    conn.open_connection()
    elenco = conn.describe(PosixPath("download/Elab"))
    for n in data:
        nomefile = n["FileName"]
        if nomefile in elenco:
            conn.delete(PosixPath("download/Elab", nomefile))


@task
def clean_dir_tmp() -> None:  # nout
    p_locale = "/tmp/anthilia/note"
    shutil.rmtree(p_locale)


@task
def clean_data(data: TaskData) -> TaskData:
    note_presenti = []
    for row in data["data"]:
        if row["NoteOperatore"]:
            note_presenti.append(row)
    return {"data": note_presenti, "errors": [], "meta": []}  # type: ignore


@task
def check_condition(data: List[str]) -> TaskData:
    errors = []
    for file_ in data:
        errors.extend([x for x in file_["error"]])  # type: ignore

    return {"data": ",\n".join(errors), "errors": bool(len(errors)), "meta": {}}  # type: ignore


class ingest_note(Task):
    """Esegue SP."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData) -> TaskData:  # noqa
        errors = []
        with self.log.start_action(self.name):
            try:  # prova
                self.open()
                for row in data["data"]:
                    self.cursor.execute(
                        """EXEC rs.Mikono_Antana_Depositarie_Anthilia_Inserisce_Note
                        @Note = ?,
                        @Account = ?,
                        @Isin = ?,
                        @Divisa = ?,
                        @Fileimport = ?,
                        @Account_depositaria = ?,
                        @Divisa_depositaria = ?,
                        @Isin_depositaria = ?,
                        @Fileimport_depositaria = ?,
                        @Dateimport = ?""",
                        row["NoteOperatore"],
                        row["Account"],
                        row["Isin"],
                        row["Divisa"],
                        row["FileImport"],
                        row["depositarieAccount"],
                        row["depositarieDivisa"],
                        row["depositarieIsin"],
                        row["depositarieFileImport"],
                        row["DataImportNormalizzata"],
                    )
                    self.dbconn.commit()
                    # errors.append("Presenti errori nell'esecuzione della SP:")
            except Exception as ex:  # in caso di eccezione voglio fare rollback
                self.logger.error(f"Errore esecuzione SP per la riga: {str(ex)}")
                self.dbconn.rollback()
                errors.append(f"Presenti errori nell'esecuzione della SP: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.dbconn.close()
                return {"data": [], "errors": errors, "meta": {"FileName": []}}  # type: ignore
                # if errors == []:
                #    manda_mail = True
                # else:
                #    manda_mail = False


####################################################################################################
# PROCESSO
####################################################################################################

with Flow("ingest_note_rientro") as flow:

    percorsi = elenco_files()

    read_antana = ReadCsv(
        # i nomi delle colonne che si vogliono recuperare
        fields=(
            "Isin",
            "depositarieIsin",
            "Account",
            "depositarieAccount",
            "Divisa",
            "depositarieDivisa",
            "FileImport",
            "depositarieFileImport",
            "DataImportNormalizzata",
            "NoteOperatore",
        ),
        # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
        encoding="iso-8859-1",
        # headless=True,
        options={"delimiter": ";"},
    )

    dati_antana = read_antana.map(percorsi["data"])
    note = clean_data.map(dati_antana)

    clean_dir_elab(percorsi["meta"])

    upload = UploadFiles(auth_label="sftp_mikono_anthilia_antana", dest_prefix="download/Elab")
    Esito = upload(percorsi)

    inserimento = ingest_note(db="db_clc_w")
    esecuzione = inserimento.map(note)

    cond = check_condition(esecuzione)

    with case(cond["error"], True):
        message = """
        Errori durante il caricamento delle note: {errors}
        """

        body = StringFormatter(name="message body", template=message)
        output = body(errors=cond["data"])

        warn_empty_send_delivery = SendMail(conf="mail_locale")
        warn_empty_send_delivery(
            {
                "subject": "[MIKONO] anthilia_bnplux_liq - caricamento csn su SFTP Anthana",
                "from": "testinterno.pycc@gmail.com",
                "to": "DPE_tech@gruppomol.it",
                "msg": output,
            }
        )
        # "from": "noreply_pycc@gruppomol.it",
        # "cc": ["stefano.secci@gruppomol.it", "antonio.onida@gruppomol.it"],

    # clean_dir_tmp()

if __name__ == "__main__":
    res = flow.run()
