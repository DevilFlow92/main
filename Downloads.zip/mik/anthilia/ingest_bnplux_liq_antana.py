"""Scarica csv da sftp mikono anthilia antana, e carica su db."""

import os
from pathlib import PosixPath
from typing import Any, List, Tuple

import pyodbc
from prefect import case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs import Flow, ReadCsv, SendMail, ValidateData
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_date, to_decimal, to_stripped_string


@task
def ultimo_file() -> Tuple[Any, str]:
    # Si connette all'SFTP, e prende il file più recente che inizia con il nome "RICOLIQUIDITABNPLUX"
    conn = ftp_conn(from_vault("sftp_mikono_anthilia_antana"))
    conn.open_connection()
    elenco = conn.describe(PosixPath("EstrattoriBNPLUX/"))

    ultimo_file = sorted(
        [(k, v.modify, v.key) for k, v in elenco.items() if k.startswith("RICOLIQUIDITABNPLUX")],
        key=lambda x: x[1],
        reverse=True,
    )[0]
    local_path = conn.retrieve(PosixPath(ultimo_file[2]), PosixPath("/tmp/anthilia/"))  # il 2 per tirar fuori v.key
    FileName = ultimo_file[0]

    return {"path": str(local_path)}, FileName


@task
def prepare_data(data: TaskData) -> TaskData:
    for row in data["data"]:
        row["Quantità"] = row["Quantità"].replace(",", ".")
    return data


class Ingest_anthilia_bnplux_liq_antana(Task):
    """Esegue Query."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData, FileName: str) -> TaskData:  # noqa
        errors = []
        with self.log.start_action(self.name):
            try:  # prova
                self.open()
                DataFlusso = data["data"][0]["Data Situazione"]
                JobDescription = "anthilia_bnplux_liq_antana"
                self.cursor.execute("SELECT rs.DateAdd_GiorniLavorativi(302, ? ,1)", DataFlusso)
                DateImport = self.cursor.fetchone()[0]

                self.cursor.execute(
                    """SELECT TOP 1 IdImport FROM rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                    WHERE DateImport = ? AND JobDescription = ?""",
                    DateImport,
                    JobDescription,
                )
                Disattiva = self.cursor.fetchone()

                if Disattiva:
                    self.cursor.execute(
                        """UPDATE rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                        SET FlagAttivo = 0
                        WHERE DateImport = ?
                        AND JobDescription = ?
                        AND FlagAttivo = 1""",
                        DateImport,
                        JobDescription,
                    )
                    self.dbconn.commit()

                for row in data["data"]:
                    self.cursor.execute(
                        "insert into rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana "
                        "(Famiglia, Account, Linea, Titolo, Isin, Descr_titolo, Quantita, Prezzo, "
                        "Divisa, Valore_euro, Ndg, Dossier_titoli, Banca, Conto_corrente, Deposito, "
                        "FileImport, JobDescription, DateImport, Cambio, Nome, Cognome, RagioneSociale, "
                        "DataFlusso, DataImport_reale, NomePartner, CodiceAmbiente, CodiceTitolo) "
                        "VALUES (NULL, ?, NULL, ?, NULL, ?, ?, NULL, ?, NULL, NULL, NULL, 'BNP Lux', NULL, NULL, "
                        "?,?, ?, NULL,NULL,NULL,NULL, ?, getdate(), 'anthilia',NULL,?)",
                        row["Contratto"],
                        row["Titolo"],
                        row["Descrizione"],
                        row["Quantità"],
                        row["Divisa"],
                        FileName,
                        JobDescription,
                        DateImport,
                        DataFlusso,
                        row["Tipologie titolo"],
                    )
                    self.dbconn.commit()

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere: {str(ex)}")
                self.dbconn.rollback()
                errors.append(f"Presenti errori nel caricamento tabella: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.dbconn.close()
                Path = "/tmp/anthilia/" + FileName
                os.remove(Path)

                return {"data": [], "errors": data["errors"].extend(errors), "meta": {}}  # type: ignore


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


with Flow("ingest_bnplux_liq_antana") as flow:

    local_path, FileName = ultimo_file()

    read_antana = ReadCsv(
        # i nomi delle colonne che si vogliono recuperare
        fields=(
            "Tipologie titolo",
            "Contratto",
            "Titolo",
            "Descrizione",
            "Quantità",
            "Divisa",
            "Data Situazione",
        ),
        # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
        encoding="iso-8859-1",
        # headless=True,
        options={"delimiter": ";"},
    )

    dati_antana = read_antana(local_path)
    clean_data = prepare_data(dati_antana)

    schema_antana = Schema(
        {
            "Tipologie titolo": Coerce(to_stripped_string()),
            "Contratto": Coerce(to_stripped_string()),
            "Titolo": Coerce(to_stripped_string()),
            "Descrizione": Coerce(to_stripped_string()),
            "Quantità": Coerce(to_decimal(18, None, fixed_width=False)),
            "Divisa": Coerce(to_stripped_string()),
            "Data Situazione": Coerce(
                to_date(
                    [
                        "%d-%m-%Y",
                    ]
                )
            ),
        }
    )

    validate_schema_antana = ValidateData(schema=schema_antana)
    validated_antana = validate_schema_antana(clean_data)

    ingest_data = Ingest_anthilia_bnplux_liq_antana(db="db_clc_w")
    doit = ingest_data(validated_antana, FileName)

    cond = check_condition(doit["error"])

    with case(cond, True):
        prepare_body = StringFormatter()
        body = prepare_body(
            template="""Errori durante il caricamento in tabella
                        L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana: {errors_list}""",
            errors_list=doit["errors"],
        )
        warn_empty_send_delivery = SendMail(conf="mail_locale")
        warn_empty_send_delivery(
            {
                "subject": "[MIKONO] anthilia_bnplux_liq_antana",
                "from": "noreply_pycc@gruppomol.it",
                "to": "DPE_tech@gruppomol.it",
                "cc": ["stefano.secci@gruppomol.it", "antonio.onida@gruppomol.it"],
                "msg": body,
            }
        )

if __name__ == "__main__":
    res = flow.run()
