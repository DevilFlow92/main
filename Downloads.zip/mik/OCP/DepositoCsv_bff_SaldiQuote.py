"""Opencapital deposito file riconciliazione SaldiQuote."""
from datetime import date, datetime
from typing import Any, List

import pyodbc
from prefect import Parameter, task
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, UploadFiles, WriteCsv, shift_date
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData

"Classe Caricamento dati da db"


class CaricaDati(Task):
    """Richiama dati da db per scriverli in un csv da trasferire in sftp."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)

        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: str) -> TaskData:  # noqa
        errors = []
        Dizionario = []
        with self.log.start_action(self.name):
            try:  # prova
                self.open()

                # data = "2022-12-02" #solo per il primo test ##############
                DataImportNormalizzata = datetime.strptime(data, "%Y-%m-%d")

                DataImportNomeCSV = data.replace("-", "")
                q1 = """
                    SELECT top 1
                    CASE WHEN CAST(MIN(InizioMezzaGiornata)
                    OVER (ORDER BY InizioMezzaGiornata) as DATE) = ?
                    THEN 1 ELSE 0 END IsPrimoGiornoMese
                    FROM S_Calendario
                    WHERE CodCliente = 302
                    AND FlagLavorativo = 1
                    AND YEAR(InizioMezzaGiornata) = ?
                    AND MONTH(InizioMezzaGiornata) = ?
                    """

                self.cursor.execute(
                    q1,
                    DataImportNormalizzata,
                    DataImportNormalizzata.year,
                    DataImportNormalizzata.month,
                )
                Lettura_DB = self.cursor.fetchone()

                IsPrimoGiornoMese = Lettura_DB.IsPrimoGiornoMese
                today = date.today().strftime("%Y%m%d")

                if IsPrimoGiornoMese:
                    NomeCsv = "FM_OpenCapital_BFF_ControlloSaldiQuota_" + DataImportNomeCSV + "_" + today + ".csv"
                else:
                    NomeCsv = "OpenCapital_BFF_ControlloSaldiQuota_" + DataImportNomeCSV + "_" + today + ".csv"

                q2 = """SELECT DataImportNormalizzata
                        ,TipologiaMismatchFile
                        ,BancaMismatch
                        ,Banca
                        ,depositarieBanca
                        ,CheckQuantitaAntanaDepositarie
                        ,AccountTruncated
                        ,Dossier_titoli
                        ,depositarieDossier_titoli
                        ,Isin
                        ,depositarieIsin
                        ,Descr_titolo
                        ,REPLACE(CAST(CAST(QuantitaAntanaDepositarie as decimal(18,3)) as VARCHAR), '.', ',')
                        as QuantitaAntanaDepositarie
                        ,NoteOperatore
                        ,REPLACE(CAST(CAST(Quantita as decimal(18,3)) as VARCHAR), '.', ',') as Quantita
                        ,REPLACE(CAST(CAST(depositarieQuantita as decimal(18,3)) as VARCHAR), '.', ',')
                        as depositarieQuantita
                        ,REPLACE(CAST(CAST(Prezzo as decimal(18,3)) as VARCHAR), '.', ',') as Prezzo
                        ,REPLACE(CAST(CAST(depositariePrezzo as decimal(18,3)) as VARCHAR), '.', ',')
                        as depositariePrezzo
                        ,Divisa
                        ,depositarieDivisa
                        ,REPLACE(CAST(CAST(Cambio as decimal(18,3)) as VARCHAR), '.', ',') as Cambio
                        ,REPLACE(CAST(CAST(depositarieCambio as decimal(18,3)) as VARCHAR), '.', ',')
                        as depositarieCambio
                        ,dataFlusso
                        ,depositarieDataFlusso
                        ,FileImport
                        ,depositarieFileImport
                        ,IsPrimoGiornoMese
                    FROM rs.v_Mikono_OpenCapital_BFF_SaldiQuote_pycc
                    WHERE DataImportNormalizzata = ?
                    ORDER BY ABS(QuantitaAntanaDepositarie) DESC
                    """
                self.cursor.execute(q2, DataImportNormalizzata)
                Lettura = self.cursor.fetchall()

                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere il DB: {str(ex)}")
                self.dbconn.rollback()
                errors.append(f"Presenti errori nel caricamento su SFTP antana: {str(ex)}")
                raise ex
            finally:
                self.dbconn.close()
                # todo: errors ha il suo tipo, usare quello
                return {
                    "data": Dizionario,
                    "errors": errors,  # type: ignore
                    "meta": {"FileName": NomeCsv},
                }


@task
def check_condition(errors: List[str]) -> int:
    return len(errors)


with Flow("BFF_OCP_DepositoCsv_SaldiQuote") as flow:
    on_date_ = Parameter("on_date", default="")
    shift_days_ = Parameter("shift_days", default="0")
    date_ = shift_date(on_date_, shift_days_, skip_weekends=True)

    FileLocale = CaricaDati(name="Riconciliazione Saldi Quote", db="db_clc_w")
    DatiDaScrivere = FileLocale(data=date_)

    write = WriteCsv(
        name="Scrivi csv Riconciliazione Saldi Quote",
        filename_meta=["FileName"],
        fields=[
            "DataImportNormalizzata",
            "TipologiaMismatchFile",
            "BancaMismatch",
            "Banca",
            "depositarieBanca",
            "CheckQuantitaAntanaDepositarie",
            "AccountTruncated",
            "Dossier_titoli",
            "depositarieDossier_titoli",
            "Isin",
            "depositarieIsin",
            "Descr_titolo",
            "QuantitaAntanaDepositarie",
            "NoteOperatore",
            "Quantita",
            "depositarieQuantita",
            "Prezzo",
            "depositariePrezzo",
            "Divisa",
            "depositarieDivisa",
            "Cambio",
            "depositarieCambio",
            "dataFlusso",
            "depositarieDataFlusso",
            "FileImport",
            "depositarieFileImport",
            "IsPrimoGiornoMese ",
        ],
        options={"delimiter": ";"},
    )
    written_files = write(DatiDaScrivere)
    upload = UploadFiles(
        name="Caricamento File su sftp",
        auth_label="sftp_ocp_antana",
        dest_prefix="Lavorazione_backoffice/Check_SaldiQuota",
    )
    upload(written_files)


if __name__ == "__main__":
    res = flow.run()
