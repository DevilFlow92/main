"""Scarica csv da sftp antana, e carica su db."""

from datetime import timedelta
from pathlib import PosixPath
from typing import Any, List, Tuple

import pyodbc
from prefect import case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs import Flow, ReadCsv, SendMail, UploadFiles, ValidateData
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_date, to_decimal, to_stripped_string


class LastFile(Task):
    """Cerca l'ultimo documento nella cartella e lo scarica in locale."""

    def run(self) -> Tuple[dict[str, str], str, TaskData]:
        with self.log.start_action(self.name):
            try:
                conn = ftp_conn(from_vault("sftp_ocp_antana"))
                conn.open_connection()
                elenco = conn.describe(PosixPath("Saldi_Giornalieri_QuoteLiquid/"))

                ultimo_file = sorted(
                    [(k, v.modify, v.key) for k, v in elenco.items() if k.startswith("posizioniFondi")],
                    key=lambda x: x[1],
                    reverse=True,
                )[0]
                local_path = conn.retrieve(
                    PosixPath(ultimo_file[2]), PosixPath(self.dirspace)
                )  # il 2 per tirar fuori v.key
                FileName = ultimo_file[0]
                output = {"path": PosixPath(local_path)}
                # output devo passarglielo come lista
                return {"path": str(local_path)}, FileName, {"data": [output], "errors": [], "meta": {}}

            except Exception as ex:
                self.logger.error("Errore durante la connessione all' sftp_ocp_antana")
                raise ex


class Ingest_posizioni_antana(Task):
    """Inserisce righe in [rs].[L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana]."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData, FileName: str) -> TaskData:  # noqa
        errors = []
        with self.log.start_action(self.name):
            try:
                self.open()

                JobDescription = "opencapital_bff_antana"
                DataFlusso = data["data"][0]["data"]

                self.cursor.execute("SELECT rs.DateAdd_GiorniLavorativi(302, ? ,1)", DataFlusso)
                DateImport = self.cursor.fetchone()[0]

                self.cursor.execute(
                    """SELECT TOP 1 IdImport FROM rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                    WHERE DateImport = ? AND JobDescription = ?""",
                    DateImport,
                    JobDescription,
                )
                Disattiva = self.cursor.fetchone()
                if Disattiva:
                    self.cursor.execute(
                        """UPDATE rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                        SET FlagAttivo = 0
                        WHERE DateImport = ?
                        AND JobDescription = ?
                        AND FlagAttivo = 1""",
                        DateImport,
                        JobDescription,
                    )
                    self.dbconn.commit()

                for row in data["data"]:
                    self.cursor.execute(
                        """INSERT INTO rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                        (Account, Linea, Titolo, Isin, Descr_titolo, Quantita, Prezzo, Divisa,
                        Valore_euro, Banca, Conto_corrente, Deposito, FileImport, JobDescription,
                        DateImport, Cambio,  DataFlusso, DataImport_reale, NomePartner)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'BFF', ?, ?, ?, ?, ?, ?, ?, GETDATE(), 'OCP')""",
                        row["Account"],
                        row["Linea"],
                        row["Titolo"],
                        row["Isin"],
                        row["Descr_titolo"],
                        row["Quantita"],
                        row["Prezzo"],
                        row["Divisa"],
                        row["Valore_euro"],
                        row["conto_corrente"],
                        row["deposito"],
                        FileName,
                        JobDescription,
                        DateImport,
                        row["cambio"],
                        DataFlusso,
                    )
                    self.dbconn.commit()
            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere: {str(ex)}")
                # self.dbconn.rollback()
                errors.append(f"Presenti errori nel caricamento tabella: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.dbconn.close()
                # todo: extend torna None
                return {"data": [], "errors": data["errors"].extend(errors), "meta": {}}  # type: ignore


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


class DeleteFileSFTP(Task):
    """Cancella uno o più file da SFTP."""

    def __init__(
        self,
        auth_label: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:  # noqa D107
        self.auth_label = auth_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, FileName: str) -> None:  # , data: str
        with self.log.start_action(self.name):
            with ftp_conn(from_vault(self.auth_label)) as conn:
                try:
                    path = PosixPath("Saldi_Giornalieri_QuoteLiquid/", FileName)
                    conn.delete(path)
                except Exception:
                    self.logger.warning(
                        f"""Non è stato possibile eliminare il file{FileName}
                    da sftp_ocp_antana /Saldi_Giornalieri_QuoteLiquid"""
                    )


@task
def prepare_message(data: TaskData) -> TaskData:
    """Mi serve togliere i punti per riuscire a convertire."""
    data_ = data.copy()
    for row in data_["data"]:
        row["Quantita"] = row["Quantita"].replace(",", ".")
        row["Prezzo"] = row["Prezzo"].replace(",", ".")
        row["Valore_euro"] = row["Valore_euro"].replace(",", ".")
        row["cambio"] = row["cambio"].replace(",", ".")
    return data_


with Flow("ingest_bff_ocp_posizioni_antana") as flow:

    local_path, FileName, source_file = LastFile()

    read_antana = ReadCsv(
        # i nomi delle colonne che si vogliono recuperare
        fields=(
            "Account",
            "Linea",
            "Titolo",
            "Isin",
            "Descr_titolo",
            "Quantita",
            "Divisa",
            "Prezzo",
            "Valore_euro",
            "deposito",
            "conto_corrente",
            "cambio",
            "data",
        ),
        # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
        encoding="iso-8859-1",
        # headless=True,
        options={"delimiter": ";"},
    )
    dati_antana_ = read_antana(local_path)
    dati_antana = prepare_message(dati_antana_)

    schema_antana = Schema(
        {
            "Account": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "Linea": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "Titolo": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "Isin": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "Descr_titolo": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "Quantita": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "Divisa": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "Prezzo": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "Valore_euro": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "deposito": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "conto_corrente": Coerce(
                to_stripped_string(),
                nones=[
                    "",
                ],
            ),
            "cambio": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "data": Coerce(to_date(["%d/%m/%Y", "%Y/%m/%d", "%d-%m-%Y", "%Y-%m-%d"])),
        }
    )

    validate_schema_antana = ValidateData(schema=schema_antana)
    validated_antana = validate_schema_antana(dati_antana)

    ingest_data = Ingest_posizioni_antana(db="db_clc_w")
    doit = ingest_data(validated_antana, FileName)

    cond = check_condition(doit["errors"])

    upload = UploadFiles(auth_label="sftp_ocp_antana", dest_prefix="Saldi_Giornalieri_QuoteLiquid/Elab")
    uploaded = upload(source_file)
    with case(uploaded["meta"]["isEmpty"], False):
        delete = DeleteFileSFTP(auth_label="sftp_ocp_antana")
        deleted_ = delete(FileName)

    with case(cond, True):
        prepare_body = StringFormatter()
        body = prepare_body(
            template="""Errori durante il caricamento in tabella
                        rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana: {errors_list}""",
            errors_list=doit["errors"],
        )
        warn_empty_send_delivery = SendMail(conf="mail_server")
        warn_empty_send_delivery(
            {
                "subject": "[error] Ingest PosizioniFondi bff OCP Antana",
                "from": "info.mikono@gruppomol.it",
                "to": ["claudio.orru@gruppomol.it", "alessia.cadoni@gruppomol.it", "lorenzo.fiori@gruppomol.it"],
                "cc": ["reportdpecesam@gruppomol.it", "DPE_Tech@gruppomol.it"],
                "msg": body,
            }
        )


if __name__ == "__main__":
    res = flow.run()
