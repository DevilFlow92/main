import json
import os
from datetime import datetime, timedelta
from pathlib import PosixPath
from typing import Any, List, Tuple

import pyodbc
from prefect import Flow, case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs import ReadCBI, ReadDB, SendMail, UploadFiles
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_date, to_stripped_string
from pyodbc import Connection

Rule = dict[str, list[tuple[int, int, str]]]

DT: Rule = {
    "DT": [
        (1, 1, "filler1"),
        (2, 3, "tipo_record"),
        (4, 8, "mittente"),
        (9, 13, "ricevente"),
        (14, 19, "data_creazione"),
        (20, 39, "nome_supporto"),
        (40, 45, "campo_a_disposizione"),
        (46, 115, "filler"),
        (116, 120, "campo_non_disponibile"),
    ],
    "10": [
        (1, 1, "filler1"),
        (2, 3, "tipo_record"),
        (4, 10, "numero_progressivo"),
        (11, 28, "saldo_attuale"),
        (29, 33, "causale"),
        (34, 45, "codice ISIN"),
        (46, 65, "descrizione_del_titolo"),
        (66, 68, "codice_divisa"),
        (69, 73, "codice_abi_banca"),
        (74, 78, "cab_banca"),
        (79, 91, "numero dossier"),
        (92, 97, "data_del_saldo"),
        (98, 103, "data_scadenza_titolo"),
        (104, 107, "data_godimento_1"),
        (108, 111, "data_godimento_2"),
        (112, 115, "data_godimento_3"),
        (116, 119, "data_godimento_4"),
        (120, 120, "filler2"),
    ],
    "20": [
        (1, 1, "filler1"),
        (2, 3, "tipo_record"),
        (4, 10, "numero_progressivo"),
        (11, 22, "codice_ISIN"),
        (23, 42, "descrizione_del_titolo"),
        (43, 45, "codice_divisa"),
        (46, 63, "quantita_trattata"),
        (64, 64, "segno_operazione"),
        (65, 70, "data_del_movimento"),
        (71, 74, "causale_movimento"),
        (75, 79, "cab_giro"),
        (80, 92, "numero_dossier_giro"),
        (93, 110, "numero_riferimento"),
        (111, 120, "filler2"),
    ],
}


def _record_rule_dt(row: str, last_record: str, last_message: dict[str, Any]) -> list[tuple[int, int, str]]:  # noqa
    tipo_record = row[1:3]

    if tipo_record == "10":
        if last_record in ("DT", "10", "20"):
            return DT["10"]
    if tipo_record == "20":
        if last_record in ("10", "20"):
            return DT["20"]

    raise ValueError(f"Non so come interpretare la riga {row[0:12]}... del flusso")


class OrganizeIngest(Task):
    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.dbconn: Connection | None = None
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        if self.dbconn:
            self.dbconn.close()

    def run(self, data: TaskData, max_id: TaskData) -> TaskData:
        """Insert per i soli record di tipo 10."""
        id_import = max_id["data"][0]["IdImport"]
        id_import += 1
        path_origine = data["meta"]["path"]
        filename = os.path.basename(path_origine)

        with self.log.start_action(self.name):
            self.open()
            for riga in data["data"]:
                payload = json.loads(riga["payload"])
                for record in payload["records"]:

                    if record["tipo_record"] == "10":
                        data_del_saldo = datetime.strptime(record["data_del_saldo"], "%d%m%y")
                        data_scadenza_titolo = datetime.strptime(record["data_scadenza_titolo"], "%d%m%y")
                        saldo_attuale = float(record["saldo_attuale"].replace(",", "."))
                        try:
                            self.cursor.execute(
                                """INSERT INTO orga.MIKONO_FlussoCBI_Titoli
                                (NomeFileOrigine, IdImport, TipoMessaggio, Progressivo, SaldoAttuale,
                                Causale, ISIN, Titolo, Divisa, ABI, CAB, Dossier, DataSaldo, DataScadenzaTitolo)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                                filename,
                                id_import,
                                record["tipo_record"],
                                record["numero_progressivo"],
                                saldo_attuale,
                                record["causale"],
                                record["codice ISIN"],
                                record["descrizione_del_titolo"],
                                record["codice_divisa"],
                                record["codice_abi_banca"],
                                record["cab_banca"],
                                record["numero dossier"],
                                data_del_saldo,
                                data_scadenza_titolo,
                            )
                            self.cursor.commit()
                        except Exception as ex:  # in caso di eccezione vogliamo fare rollback
                            if self.dbconn:
                                self.dbconn.rollback()
                            self.logger.error(f"Errore inatteso : {str(ex)}")
                            # raise ex
                        # finally:
            self.close()
            # todo: data devono essere dizionari
            return {
                "data": [data_del_saldo],  # type: ignore
                "errors": [],
                "meta": {"isEmpty": False},
            }


class LastFile(Task):
    """Cerca l'ultimo documento nella cartella e lo scarica in locale."""

    def run(self) -> Tuple[dict[str, str], str, TaskData]:
        with self.log.start_action(self.name):
            try:
                conn = ftp_conn(from_vault("sftp_ocp_antana"))

                conn.open_connection()
                elenco = conn.describe(PosixPath("BFF/"))

                ultimo_file = sorted(
                    [(k, v.modify, v.key) for k, v in elenco.items() if k.startswith("CBITITO")],
                    key=lambda x: x[1],
                    reverse=True,
                )[0]
                local_path = conn.retrieve(
                    PosixPath(ultimo_file[2]), PosixPath(self.dirspace)
                )  # il 2 per tirar fuori v.key
                FileName = ultimo_file[0]
                output = {"path": PosixPath(local_path)}
                # output devo passarglielo come lista
                return {"path": str(local_path)}, FileName, {"data": [output], "errors": [], "meta": {}}

            except Exception as ex:
                self.logger.error("Errore durante la connessione all' sftp_ocp_antana")
                raise ex


class Ingest_tit_bff_ocp_depositaria(Task):
    """Inserisce righe in rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData, FileName: str, DataFlusso: Any) -> TaskData:  # noqa
        errors = []
        with self.log.start_action(self.name):
            try:

                JobDescription = "opencapital_bff_titoli"
                self.open()
                self.cursor.execute(
                    """SELECT TOP 1 IdImport FROM rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                    WHERE DataFlusso = ? AND JobDescription = ?""",
                    DataFlusso,
                    JobDescription,
                )
                Disattiva = self.cursor.fetchone()

                if Disattiva:
                    self.cursor.execute(
                        """UPDATE rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                        SET FlagAttivo = 0
                        WHERE DataFlusso = ?
                        AND JobDescription = ?
                        AND FlagAttivo = 1""",
                        DataFlusso,
                        JobDescription,
                    )
                    self.dbconn.commit()

                for row in data["data"]:

                    # data_contabile = datetime.strptime(row["DataContabile_61"], '%d%m%y')
                    self.cursor.execute("SELECT rs.DateAdd_GiorniLavorativi(302, ? ,1)", row["DataSaldo"])
                    DateImport = self.cursor.fetchone()[0]

                    self.cursor.execute(
                        """INSERT INTO rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                        (Conto_corrente, Isin, Descr_titolo, Quantita, Divisa, DataFlusso, NomePartner,
                        JobDescription, DateImport, FileImport, Banca, DataImport_reale, FlagAttivo)
                        VALUES (?, ?, ?, ?, ?, ?, 'OCP', ?, ?, ?, 'BFF', GETDATE(), 1)""",
                        row["Dossier"],
                        row["ISIN"],
                        row["Titolo"],
                        row["SaldoAttuale"],
                        row["Divisa"],
                        row["DataSaldo"],
                        JobDescription,
                        DateImport,
                        FileName,
                    )
                    self.dbconn.commit()
            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere: {str(ex)}")
                # self.dbconn.rollback()
                errors.append(f"Presenti errori nel caricamento tabella: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.close()
                # todo: da extend esce None
                return {"data": [], "errors": data["errors"].extend(errors), "meta": {}}  # type: ignore


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


class DeleteFileSFTP(Task):
    """Cancella uno o più file da SFTP."""

    def __init__(
        self,
        auth_label: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:  # noqa D107
        self.auth_label = auth_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, FileName: str) -> None:  # , data: str
        with self.log.start_action(self.name):
            with ftp_conn(from_vault(self.auth_label)) as conn:
                try:
                    path = PosixPath("BFF/", FileName)
                    conn.delete(path)
                except Exception:
                    self.logger.warning(
                        f"""Non è stato possibile eliminare il file{FileName}
                    da sftp_ocp_antana /BFF"""
                    )


with Flow("ingest_bff_ocp_tit_depositarie") as flow:

    local_path, FileName, source_file = LastFile()

    letturaCBI = ReadCBI(rules_override={"DT": _record_rule_dt})
    DatiDaScrivere = letturaCBI(data=local_path)

    query_id = """SELECT MAX(IdImport) AS IdImport
                FROM [orga].[MIKONO_FlussoCBI_Titoli]"""
    schema_id = Schema({"IdImport": int})
    max_id_ = ReadDB(db="db_clc_w", schema=schema_id, query=query_id)
    max_id = max_id_(params=())

    organize_ingest = OrganizeIngest(db="db_clc_w")
    new_data = organize_ingest(DatiDaScrivere, max_id)

    with case(new_data["meta"]["isEmpty"], False):

        query_ingest = """SELECT * FROM orga.MIKONO_FlussoCBI_Titoli
                        WHERE IdImport = (SELECT MAX(IdImport) AS IdImport
                                          FROM orga.MIKONO_FlussoCBI_Titoli)"""
        schema_ingest = Schema(
            {
                "Dossier": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "ISIN": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "Titolo": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "SaldoAttuale": Coerce(
                    float,
                    nones=[
                        "",
                    ],
                ),
                "Divisa": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "DataSaldo": Coerce(
                    to_date(["%Y%m%d", "%Y-%m-%d", "%Y/%m/%d"]),
                    nones=[
                        "",
                    ],
                ),
            }
        )
        data_to_ingest_ = ReadDB(db="db_clc_w", schema=schema_ingest, query=query_ingest)
        readed_ = data_to_ingest_(params=())

        ingest_data = Ingest_tit_bff_ocp_depositaria(db="db_clc_w")
        doit = ingest_data(readed_, FileName, new_data["data"][0])

        cond = check_condition(doit["errors"])

        upload = UploadFiles(auth_label="sftp_ocp_antana", dest_prefix="BFF/Elab")
        uploaded = upload(source_file)
        with case(uploaded["meta"]["isEmpty"], False):
            delete = DeleteFileSFTP(auth_label="sftp_ocp_antana")
            deleted_ = delete(FileName)

        with case(cond, True):
            prepare_body = StringFormatter()
            body = prepare_body(
                template="""Errori durante il caricamento in tabella
                            rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie: {errors_list}""",
                errors_list=doit["errors"],
            )
            warn_empty_send_delivery = SendMail(conf="mail_server")
            warn_empty_send_delivery(
                {
                    "subject": "[error] Ingest_saldi_titoli_bff_ocp_depositaria",
                    "from": "info.mikono@gruppomol.it",
                    "to": ["claudio.orru@gruppomol.it", "alessia.cadoni@gruppomol.it", "lorenzo.fiori@gruppomol.it"],
                    "cc": ["reportdpecesam@gruppomol.it", "DPE_Tech@gruppomol.it"],
                    "msg": body,
                }
            )

if __name__ == "__main__":
    res = flow.run()
