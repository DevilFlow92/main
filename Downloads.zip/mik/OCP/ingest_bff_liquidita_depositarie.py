import json
import os
from datetime import datetime, timedelta
from pathlib import PosixPath
from typing import Any, List, Tuple

import pyodbc
from prefect import Flow, case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs import ReadCBI, ReadDB, SendMail, UploadFiles
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_date, to_stripped_string
from pyodbc import Connection


class ChooseIngest(Task):
    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.dbconn: Connection | None = None
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        if self.dbconn:
            self.dbconn.close()

    def run(self, data: TaskData, max_id: TaskData) -> None:  # noqa
        """Scelta della insert in base al tipo record"""
        id_rendicontazione = max_id["data"][0]["IdRendicontazione"]
        path_origine = data["meta"]["path"]
        filename = os.path.basename(path_origine)

        with self.log.start_action(self.name):

            for riga in data["data"]:
                id_rendicontazione += 1
                # messaggio = riga["msg_reference"]
                payload = json.loads(riga["payload"])
                data_creazione = datetime.strptime(payload["testa"]["data_creazione"], "%d%m%y")

                try:
                    self.open()
                    # inserisci in tabella la riga di testa RH
                    self.cursor.execute(
                        """INSERT INTO [orga].[L_MIKONO_FlussoCBI_SaldiLiquid]
                        (NomeFileOrigine, IdRendicontazione, TipoMessaggio,
                        Mittente_RH, Ricevente_RH, DataCreazione_RH, NomeSupporto_RH)
                        VALUES (?, ?, ?, ?, ?, ?, ?);""",
                        filename,
                        id_rendicontazione,
                        payload["testa"]["tipo_record"],
                        # messaggio,
                        payload["testa"]["mittente"],
                        payload["testa"]["ricevente"],
                        data_creazione,
                        payload["testa"]["nome_supporto"],
                    )
                    self.cursor.commit()

                    # inserisci in tabella tutte le righe tra 61 e 65
                    for record in payload["records"]:

                        if record["tipo_record"] == "61":
                            saldo_iniziale_quadratura = float(record["saldo_iniziale_quadratura"].replace(",", "."))
                            data_contabile = datetime.strptime(record["data_contabile"], "%d%m%y")
                            self.cursor.execute(
                                """INSERT INTO orga.L_MIKONO_FlussoCBI_SaldiLiquid
                                (NomeFileOrigine, IdRendicontazione, TipoMessaggio,
                                Progressivo_61, ABIOriginarioBanca_61, Causale_61, Descrizione_61,
                                TipoConto_61, CIN_61, ABI_61, CAB_61, NumeroConto_61, CodiceDivisa_61,
                                DataContabile_61, Segno_61, SaldoInizialeQuadratura_61, CodicePaese_61,
                                CheckDigit_61)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                                filename,
                                id_rendicontazione,
                                record["tipo_record"],
                                # messaggio,
                                record["numero_progressivo"],
                                record["codice_abi_originario_banca"],
                                record["causale"],
                                record["descrizione"],
                                record["tipo_conto"],
                                record["cin"],
                                record["codice_abi_banca"],
                                record["cab_banca"],
                                record["conto_corrente"],
                                record["codice_divisa"],
                                data_contabile,
                                record["segno"],
                                saldo_iniziale_quadratura,
                                record["codice_paese"],
                                record["check_digit"],
                            )
                            self.cursor.commit()

                        if record["tipo_record"] == "62":
                            importo_movimento = float(record["importo_movimento"].replace(",", "."))
                            data_valuta = datetime.strptime(record["data_valuta"], "%d%m%y")
                            data_registrazione_eo_contabile = datetime.strptime(
                                record["data_registrazione_eo_contabile"], "%d%m%y"
                            )
                            self.cursor.execute(
                                """INSERT INTO orga.L_MIKONO_FlussoCBI_SaldiLiquid
                                (NomeFileOrigine, IdRendicontazione, TipoMessaggio,
                                NumeroProgressivo_62, ProgressivoMovimento_62, DataValuta_62,
                                DataRegistrazione_Contabile_62, SegnoMovimento_62, ImportoMovimento_62,
                                CausaleCBI_62, CausaleInterna_62, NumeroAssegno_62, RiferimentoBanca_62,
                                TipoRiferimentoCliente_62, RiferimentoCliente_62)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                                filename,
                                id_rendicontazione,
                                record["tipo_record"],
                                # messaggio,
                                record["numero_progressivo"],
                                record["progressivo_movimento"],
                                data_valuta,
                                data_registrazione_eo_contabile,
                                record["segno_movimento"],
                                importo_movimento,
                                record["causale cbi"],
                                record["causale_interna"],
                                record["numero_assegno"],
                                record["riferimento_banca"],
                                record["tipo_riferimento_cliente"],
                                record["riferimento_cliente_descrizione_movimento"],
                            )
                            self.cursor.commit()

                        if record["tipo_record"] == "63":
                            self.cursor.execute(
                                """INSERT INTO orga.L_MIKONO_FlussoCBI_SaldiLiquid
                                (NomeFileOrigine, IdRendicontazione, TipoMessaggio)
                                VALUES (?, ?, ?);""",
                                filename,
                                id_rendicontazione,
                                record["tipo_record"],
                            )
                            self.cursor.commit()

                        if record["tipo_record"] == "64":
                            saldo_contabile = float(record["saldo_contabile"].replace(",", "."))
                            saldo_liquido = float(record["saldo_liquido"].replace(",", "."))
                            data_contabile = datetime.strptime(record["data_contabile"], "%d%m%y")
                            self.cursor.execute(
                                """INSERT INTO orga.L_MIKONO_FlussoCBI_SaldiLiquid
                                (NomeFileOrigine, IdRendicontazione, TipoMessaggio, Progressivo_64,
                                CodiceDivisa_64, DataContabile_64, SegnoSaldoContabile_64,
                                SaldoContabile_64, SegnoSaldoLiquido_64, SaldoLiquido_64)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                                filename,
                                id_rendicontazione,
                                record["tipo_record"],
                                # messaggio,
                                record["numero_progressivo"],
                                record["codice_divisa"],
                                data_contabile,
                                record["segno_saldo_contabile"],
                                saldo_contabile,
                                record["segno saldo liquido"],
                                saldo_liquido,
                            )
                            self.cursor.commit()

                        if record["tipo_record"] == "65":

                            saldo_liquido_1 = float(record["saldo_liquido_1"].replace(",", "."))
                            saldo_liquido_2 = float(record["saldo_liquido_2"].replace(",", "."))
                            saldo_liquido_3 = float(record["saldo_liquido_3"].replace(",", "."))
                            saldo_liquido_4 = float(record["saldo_liquido_4"].replace(",", "."))
                            saldo_liquido_5 = float(record["saldo_liquido_5"].replace(",", "."))

                            self.cursor.execute(
                                """INSERT INTO orga.L_MIKONO_FlussoCBI_SaldiLiquid
                                (NomeFileOrigine, IdRendicontazione, TipoMessaggio, Progressivo_65,
                                data_liquidita_1_65, segno_1_65, saldo_liquido_1_65, data_liquidita_2_65,
                                segno_2_65, saldo_liquido_2_65, data_liquidita_3_65, segno_3_65,
                                saldo_liquido_3_65, data_liquidita_4_65, segno_4_65, saldo_liquido_4_65,
                                data_liquidita_5_65, segno_5_65, saldo_liquido_5_65)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                                filename,
                                id_rendicontazione,
                                record["tipo_record"],
                                # messaggio,
                                record["numero_progressivo"],
                                record["data_liquidita_1"],
                                record["segno_1"],
                                saldo_liquido_1,
                                record["data_liquidita_2"],
                                record["segno_2"],
                                saldo_liquido_2,
                                record["data_liquidita_3"],
                                record["segno_3"],
                                saldo_liquido_3,
                                record["data_liquidita_4"],
                                record["segno_4"],
                                saldo_liquido_4,
                                record["data_liquidita_5"],
                                record["segno_5"],
                                saldo_liquido_5,
                            )
                            self.cursor.commit()

                    # inserisci in tabella la riga di coda EF
                    data_creazione = datetime.strptime(payload["coda"]["data_creazione"], "%d%m%y")
                    self.cursor.execute(
                        """INSERT INTO orga.L_MIKONO_FlussoCBI_SaldiLiquid
                        (NomeFileOrigine, IdRendicontazione, TipoMessaggio,
                        EF_Mittente, EF_Ricevente, EF_DataCreazione,
                        EF_NomeSupporto, EF_NumeroRendicontazioni, EF_NumeroRecord)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                        filename,
                        id_rendicontazione,
                        payload["coda"]["tipo_record"],
                        # messaggio,
                        payload["coda"]["mittente"],
                        payload["coda"]["ricevente"],
                        data_creazione,
                        payload["coda"]["nome_supporto"],
                        payload["coda"]["numero_disposizioni"],
                        payload["coda"]["numero_record"],
                    )
                    self.cursor.commit()

                except Exception as ex:  # in caso di eccezione vogliamo fare rollback
                    if self.dbconn:
                        self.dbconn.rollback()
                    self.logger.error(f"Errore nell': {str(ex)}")
                    raise ex
                finally:
                    self.close()


class OrganizeIngest(Task):
    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.dbconn: Connection | None = None
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        if self.dbconn:
            self.dbconn.close()

    def run(self, data: TaskData, max_id: TaskData, IdImport: TaskData) -> TaskData:
        """Insert per i soli record interessati 61, 64."""
        id_rendicontazione = max_id["data"][0]["IdRendicontazione"]
        id_import = IdImport["data"][0]["IdImport"]
        id_import += 1
        path_origine = data["meta"]["path"]
        filename = os.path.basename(path_origine)

        with self.log.start_action(self.name):
            self.open()
            unione_riga: List[Any] = []
            for riga in data["data"]:
                id_rendicontazione += 1
                payload = json.loads(riga["payload"])

                for record in payload["records"]:

                    if record["tipo_record"] == "61":
                        unione_riga.append(record["conto_corrente"])
                        data_contabile = datetime.strptime(record["data_contabile"], "%d%m%y")
                        unione_riga.append(data_contabile)

                    if record["tipo_record"] == "64":
                        unione_riga.append(record["codice_divisa"])
                        unione_riga.append(record["segno_saldo_contabile"])
                        unione_riga.append(float(record["saldo_contabile"].replace(",", ".")))  # saldo_contabile =
                        unione_riga.append(record["segno saldo liquido"])
                        unione_riga.append(float(record["saldo_liquido"].replace(",", ".")))  # saldo_liquido =

                    if len(unione_riga) == 7:
                        try:
                            self.cursor.execute(
                                """INSERT INTO orga.MIKONO_FlussoCBI_SaldiLiquid
                                (NomeFileOrigine, IdImport, IdRendicontazione, NumeroConto_61,
                                DataContabile_61, CodiceDivisa_64, SegnoSaldoContabile_64,
                                SaldoContabile_64, SegnoSaldoLiquido_64, SaldoLiquido_64)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);""",
                                filename,
                                id_import,
                                id_rendicontazione,
                                unione_riga[0],
                                unione_riga[1],
                                unione_riga[2],
                                unione_riga[3],
                                unione_riga[4],
                                unione_riga[5],
                                unione_riga[6],
                            )
                            self.cursor.commit()
                            # unione_riga = []
                        except Exception as ex:  # in caso di eccezione vogliamo fare rollback
                            if self.dbconn:
                                self.dbconn.rollback()
                            self.logger.error(f"Errore inatteso : {str(ex)}")
                            # raise ex
                        finally:
                            unione_riga = []
            self.close()
            return {  # todo data devono essere dizionari
                "data": [data_contabile],  # type: ignore
                "errors": [],
                "meta": {"isEmpty": False},
            }


class LastFile(Task):
    """Cerca l'ultimo documento nella cartella e lo scarica in locale."""

    def run(self) -> Tuple[Any, str, TaskData]:
        with self.log.start_action(self.name):
            try:
                conn = ftp_conn(from_vault("sftp_ocp_antana"))
                conn.open_connection()
                elenco = conn.describe(PosixPath("BFF/"))

                ultimo_file = sorted(
                    [(k, v.modify, v.key) for k, v in elenco.items() if k.startswith("CBICASH")],
                    key=lambda x: x[1],
                    reverse=True,
                )[0]
                local_path = conn.retrieve(
                    PosixPath(ultimo_file[2]), PosixPath(self.dirspace)
                )  # il 2 per tirar fuori v.key
                FileName = ultimo_file[0]
                output = {"path": PosixPath(local_path)}
                # output devo passarglielo come lista
                return {"path": str(local_path)}, FileName, {"data": [output], "errors": [], "meta": {}}

            except Exception as ex:
                self.logger.error("Errore durante la connessione all' sftp_ocp_antana")
                raise ex


class Ingest_liq_bff_ocp_depositaria(Task):
    """Inserisce righe in rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData, FileName: str, DataFlusso: Any) -> TaskData:  # noqa
        errors = []
        with self.log.start_action(self.name):
            try:
                JobDescription = "opencapital_bff_liquid"
                # DataFlusso_NomeFile = FileName[8:16]
                # DataFile = datetime.strptime(DataFlusso_NomeFile, "%Y%m%d")

                self.open()
                self.cursor.execute(
                    """SELECT TOP 1 IdImport FROM rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                    WHERE DataFlusso = ? AND JobDescription = ?""",
                    DataFlusso,
                    JobDescription,
                )
                Disattiva = self.cursor.fetchone()

                if Disattiva:
                    self.cursor.execute(
                        """UPDATE rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                        SET FlagAttivo = 0
                        WHERE DataFlusso = ?
                        AND JobDescription = ?
                        AND FlagAttivo = 1""",
                        DataFlusso,
                        JobDescription,
                    )
                    self.dbconn.commit()

                for row in data["data"]:

                    if row["SegnoSaldoContabile_64"] == "C":
                        Quantita = row["SaldoContabile_64"]
                    else:
                        Quantita = row["SaldoContabile_64"] * -1

                    if row["SegnoSaldoLiquido_64"] == "C":
                        Valore_euro = row["SaldoLiquido_64"]
                    else:
                        Valore_euro = row["SaldoLiquido_64"] * -1

                    # data_contabile = datetime.strptime(row["DataContabile_61"], '%d%m%y')
                    self.cursor.execute("SELECT rs.DateAdd_GiorniLavorativi(302, ? ,1)", row["DataContabile_61"])
                    DateImport = self.cursor.fetchone()[0]

                    self.cursor.execute(
                        """INSERT INTO rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                        (Titolo, Quantita, Divisa, Valore_euro, Conto_corrente, Banca, FileImport,
                        JobDescription, DateImport, DataFlusso, DataImport_reale, NomePartner, FlagAttivo)
                        VALUES ('LIQUID', ?, ?, ?, ?, 'BFF', ?, ?, ?, ?,
                        GETDATE(), 'OCP', 1)""",
                        Quantita,
                        row["CodiceDivisa_64"],
                        Valore_euro,
                        row["NumeroConto_61"],
                        FileName,
                        JobDescription,
                        DateImport,
                        row["DataContabile_61"],
                    )
                    self.dbconn.commit()
            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere: {str(ex)}")
                # self.dbconn.rollback()
                errors.append(f"Presenti errori nel caricamento tabella: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.close()
                # todo: extend torna None
                return {"data": [], "errors": data["errors"].extend(errors), "meta": {}}  # type: ignore


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


class DeleteFileSFTP(Task):
    """Cancella uno o più file da SFTP."""

    def __init__(
        self,
        auth_label: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:  # noqa D107
        self.auth_label = auth_label
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, FileName: str) -> None:  # , data: str
        with self.log.start_action(self.name):
            with ftp_conn(from_vault(self.auth_label)) as conn:
                try:
                    path = PosixPath("BFF/", FileName)
                    conn.delete(path)
                except Exception:
                    self.logger.warning(
                        f"""Non è stato possibile eliminare il file{FileName}
                    da sftp_ocp_antana /BFF"""
                    )


with Flow("ingest_bff_ocp_liq_depositarie") as flow:

    local_path, FileName, source_file = LastFile()

    letturaCBI = ReadCBI()
    DatiDaScrivere = letturaCBI(data=local_path)

    query_id = """SELECT MAX(IdRendicontazione) AS IdRendicontazione
                FROM [orga].[L_MIKONO_FlussoCBI_SaldiLiquid]"""
    schema_id = Schema({"IdRendicontazione": int})
    max_id_ = ReadDB(db="db_clc_w", schema=schema_id, query=query_id)
    max_id = max_id_(params=())

    choose_ingest = ChooseIngest(db="db_clc_w")
    choose_ingest(DatiDaScrivere, max_id)

    query_import_id = """SELECT MAX(IdImport) AS IdImport
                    FROM [orga].[MIKONO_FlussoCBI_SaldiLiquid]"""
    schema_id = Schema({"IdImport": int})
    import_id = ReadDB(db="db_clc_w", schema=schema_id, query=query_import_id)
    IdImport = import_id(params=())

    organize_ingest = OrganizeIngest(db="db_clc_w")
    new_data = organize_ingest(DatiDaScrivere, max_id, IdImport)

    with case(new_data["meta"]["isEmpty"], False):

        query_ingest = """SELECT * FROM orga.v_ingest_MIKONO_FlussoCBI_SaldiLiquid"""
        schema_ingest = Schema(
            {
                "NomeFileOrigine": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "NumeroConto_61": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "DataContabile_61": Coerce(
                    to_date(["%Y%m%d", "%Y-%m-%d", "%Y/%m/%d"]),
                    nones=[
                        "",
                    ],
                ),
                "CodiceDivisa_64": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "SegnoSaldoContabile_64": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "SaldoContabile_64": Coerce(
                    float,
                    nones=[
                        "",
                    ],
                ),
                "SegnoSaldoLiquido_64": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "SaldoLiquido_64": Coerce(
                    float,
                    nones=[
                        "",
                    ],
                ),
            }
        )
        data_to_ingest_ = ReadDB(db="db_clc_w", schema=schema_ingest, query=query_ingest)
        readed_ = data_to_ingest_(params=())

        ingest_data = Ingest_liq_bff_ocp_depositaria(db="db_clc_w")
        doit = ingest_data(readed_, FileName, new_data["data"][0])

        cond = check_condition(doit["errors"])

        upload = UploadFiles(auth_label="sftp_ocp_antana", dest_prefix="BFF/Elab")
        uploaded = upload(source_file)
        with case(uploaded["meta"]["isEmpty"], False):
            delete = DeleteFileSFTP(auth_label="sftp_ocp_antana")
            deleted_ = delete(FileName)

        with case(cond, True):
            prepare_body = StringFormatter()
            body = prepare_body(
                template="""Errori durante il caricamento in tabella
                            rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie: {errors_list}""",
                errors_list=doit["errors"],
            )
            warn_empty_send_delivery = SendMail(conf="mail_server")
            warn_empty_send_delivery(
                {
                    "subject": "[error] Ingest_saldi_titoli_bff_ocp_depositaria",
                    "from": "info.mikono@gruppomol.it",
                    "to": ["claudio.orru@gruppomol.it", "alessia.cadoni@gruppomol.it", "lorenzo.fiori@gruppomol.it"],
                    "cc": ["reportdpecesam@gruppomol.it", "DPE_Tech@gruppomol.it"],
                    "msg": body,
                }
            )

if __name__ == "__main__":
    res = flow.run()
