"""."""
import json
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Tuple, Union, cast

import requests
from pymol.ext.auth import from_vault, qtask_token
from pymol.types.exceptions import BusinessValueError

# from pymol.types.exceptions import BusinessValueError

Raw_Body_Data = Dict[str, Optional[Union[str, int, datetime, date]]]
Body_Data = Dict[str, Union[str, int]]


api_params = from_vault("api_cesam")
HEADERS, _ = qtask_token(api_params)
HEADERS["Content-Type"] = "application/json; charset=utf-8"
HOST = api_params["host"]


# API utils
def strip_body(body: Raw_Body_Data) -> Dict[str, Union[str, int, datetime, date]]:
    """Elimina voci di dizionario nulle."""
    stripped_body = {k: v for k, v in body.items() if v is not None}

    if stripped_body == {}:
        raise BusinessValueError(f"Body is empyt {body}.")

    return stripped_body


def format_date(body: Dict[str, Union[str, int, datetime, date]]) -> Body_Data:
    """Oggetti data nel formato stringa richiesto."""
    formatted_body: Body_Data = {}

    for k, v in body.items():
        if isinstance(v, date) or isinstance(v, datetime):
            formatted_body[k] = v.strftime("%Y-%m-%d")
        else:
            formatted_body[k] = v

    return formatted_body


def prepare_body(body: Raw_Body_Data) -> bytes:
    """Prepara dati per chiamata."""
    data = json.dumps(format_date(strip_body(body))).encode("utf-8")
    return data


def add_data(
    diz: Dict[str, Any], k: str, v: Union[str, int, float, datetime, date, None], type_: Optional[str] = None
) -> None:
    """Aggiungo dati ad un dizionario, a seconda del tipo faccio anche cast a data o divido per cento."""
    if v == "" or v is None:
        return
    if type_ is None:
        diz[k] = v
    if type_ == "d":
        diz[k] = v.strftime("%Y-%m-%d")  # type: ignore
    elif type_ == "c":
        diz[k] = float(v.replace(",", ".")) / 100 if v is not None else 0.0  # type: ignore


# Response status code handlers
def check_response(
    endpoint: str, response: requests.Response, whitelist: List[int] = [200, 204, 404, 400], raising: bool = True
) -> Optional[bool]:
    """Check response status code is in whitelist, raise Error as default."""
    if response.status_code not in whitelist:
        if raising:
            raise BusinessValueError(f"{HOST}{endpoint}, {response.status_code=}, {response.content=}")
        else:
            return False
    else:
        return True


# esegui_transizione_incarico
def esegui_transizione_incarico(idincarico: int, CodStatoWorkflowIncarico: int) -> Any:
    """Esegui Transizione di stato."""
    endpoint = f"Incarico/{idincarico}/statoWorkflow/{CodStatoWorkflowIncarico}"
    response = requests.put(f"{HOST}{endpoint}", headers=HEADERS)
    check_response(endpoint, response, [200, 204])


# associa persona a incarico
def associa_persona_incarico(idincarico: int, idpersona: int, codruolopersona: int) -> Any:
    """Associa persona a incarico."""
    endpoint = f"Incarico/{idincarico}/relazionePersona"
    data = {"IdPersona": idpersona, "CodRuoloRichiedente": codruolopersona}
    response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
    check_response(endpoint, response, [200, 204])


# Gestione incarichi
def ricerca_incarichi(pratica: List[str], codarea: int, codcliente: int, codtipoincarico: int) -> Any:
    """Ricerca incarichi per pratica."""
    endpoint = "RicercaIncarichi"
    data = {
        "CodArea": codarea,
        "CodCliente": codcliente,
        "CodTipoIncarico": codtipoincarico,
        "ListaChiaveCliente": pratica,
    }
    response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))

    check_response(
        endpoint,
        response,
        whitelist=[
            200,
        ],
    )
    incarichi = response.json()
    return incarichi


def crea_nuovo_incarico(pratica: str, codarea: int, codcliente: int, codtipoincarico: int) -> Any:
    """Crea nuovo incarico per la pratica."""
    data = {"CodArea": codarea, "CodCliente": codcliente, "CodTipoIncarico": codtipoincarico, "ChiaveCliente": pratica}
    endpoint = "Incarico"
    response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))

    check_response(
        endpoint,
        response,
        whitelist=[
            200,
        ],
    )
    nuovo_incarico = response.json()
    return nuovo_incarico


def lista_incarichi(
    pratica: str, codarea: int, codcliente: int, codtipoincarico: int, codstatoworkflow: int
) -> List[Raw_Body_Data]:
    """Crea lista incarichi per ricerca esistenti o creazione nuovo incarico."""
    incarichi: List[Raw_Body_Data] = []
    pratiche: list[str] = []
    pratiche.append(pratica)
    incarichi = ricerca_incarichi(pratiche, codarea, codcliente, codtipoincarico)
    if incarichi == []:
        nuovo_incarico = crea_nuovo_incarico(pratica, codarea, codcliente, codtipoincarico)
        incarichi.append(
            {
                "IdIncarico": int(nuovo_incarico),
                "CodArea": codarea,
                "CodCliente": codcliente,
                "CodTipoIncarico": codtipoincarico,
                "ChiaveCliente": pratica,
                "CodStatoWorkflowIncarico": codstatoworkflow,
                "AttributoIncarico": "null",
            }
        )

    return incarichi


def lista_incarichi_reitera(
    pratiche: List[str], codarea: int, codcliente: int, codtipoincarico: int, codstatoworkflow: int
) -> List[Raw_Body_Data]:
    """Crea lista incarichi per ricerca esistenti o creazione nuovo incarico."""
    incarichi: List[Raw_Body_Data] = []
    incarichi = ricerca_incarichi(pratiche, codarea, codcliente, codtipoincarico)
    incarichi_presenti: List[str] = []
    for incarico in incarichi:
        incarichi_presenti.append(cast(str, incarico["ChiaveCliente"]))
    for pratica in pratiche:
        if pratica not in incarichi_presenti:
            nuovo_incarico = crea_nuovo_incarico(pratica, codarea, codcliente, codtipoincarico)
            incarichi.append(
                {
                    "IdIncarico": int(nuovo_incarico),
                    "CodArea": codarea,
                    "CodCliente": codcliente,
                    "CodTipoIncarico": codtipoincarico,
                    "ChiaveCliente": pratica,
                    "CodStatoWorkflowIncarico": codstatoworkflow,
                    "AttributoIncarico": "null",
                }
            )

    return incarichi


def inserisci_cancella_subincarichi(idincarico: int, flagcancella: bool, lista_subincarichi_: Any) -> None:
    """Cerca subincarico se flag true cancella quelli che non devono esserci."""
    subincarichi_: List[Raw_Body_Data] = []
    subincarichi: list[int] = []
    lista_subincarichi: list[int] = []
    subincarichi_ = ricerca_subincarichi(idincarico)
    sb: int = 0
    i: int = 0
    for row in subincarichi_:
        sb = cast(int, row["IdIncarico"])
        subincarichi.append(sb)  # subincarichi associati
    for row in lista_subincarichi_:
        i = cast(int, row["IdIncarico"])
        lista_subincarichi.append(i)  # subincarichi da associare

    if flagcancella is True:
        for subincarico in subincarichi:
            if subincarico not in (lista_subincarichi):
                cancella_subincarico(idincarico, subincarico)
            else:
                continue
    for subincarico in lista_subincarichi:
        if subincarico not in (subincarichi):
            inserisci_subincarico(idincarico, subincarico)
        else:
            continue


def ricerca_subincarichi(idincarico: int) -> Any:
    """Ricerca subincarichi per incarico master."""
    endpoint = f"Incarico/{idincarico}/collezioneSubIncarichi"
    response = requests.get(f"{HOST}{endpoint}", headers=HEADERS)

    check_response(
        endpoint,
        response,
        whitelist=[
            200,
        ],
    )
    subincarichi = response.json()
    return subincarichi


def cancella_subincarico(idincarico: int, idsubincarico: int) -> None:
    """Ricerca subincarichi per incarico master."""
    endpoint = f"Incarico/{idincarico}/cancellaRelazioneSubIncarico/{idsubincarico}"
    response = requests.delete(f"{HOST}{endpoint}", headers=HEADERS)

    check_response(
        endpoint,
        response,
        whitelist=[
            200,
            204,
        ],
    )


def inserisci_subincarico(idincarico: int, idsubincarico: int) -> None:
    """Ricerca subincarichi per incarico master."""
    endpoint = f"Incarico/{idincarico}/relazioneSubIncarico/{idsubincarico}"
    response = requests.post(f"{HOST}{endpoint}", headers=HEADERS)

    check_response(
        endpoint,
        response,
        whitelist=[
            200,
            204,
        ],
    )


# Dati aggiuntivi
def aggiungi_o_aggiorna_dato_aggiuntivo_incarico(
    id_incarico: int, datoaggiuntivo: Tuple[str, int, Any], data: Any
) -> None:
    """Aggiungi dati aggiuntivo o aggiorna esistente."""
    endpoint = f"Incarico/{id_incarico}/datoAggiuntivo"
    response = requests.get(f"{HOST}{endpoint}/{datoaggiuntivo[1]}", headers=HEADERS)

    _data = prepare_body(data)

    if response.status_code == 404:
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=_data)
        check_response(endpoint, response, whitelist=[200, 204])

    elif response.status_code in (200, 204):
        response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=_data)
        check_response(endpoint, response, whitelist=[200, 204])


# Gestione persone
def ricerca_persona(ndg: str, codice_fiscale: str, codcliente: int) -> requests.Response:
    """Ricerca persona."""
    data = {
        "CodCliente": codcliente,
        "ChiaveCliente": ndg,
        "CodiceFiscale": codice_fiscale,
    }
    endpoint = "/Persona/RicercaPersone"
    response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
    check_response(endpoint, response, whitelist=[200, 204])
    return response


def ricerca_crea_o_aggiorna_persona(ndg: str, codice_fiscale: str, codcliente: int, dati_persona: Raw_Body_Data) -> int:
    """Ricerca, crea o aggiorna dati persona."""
    response = ricerca_persona(ndg, codice_fiscale, codcliente)
    id_persona: int

    if check_response("/Persona/RicercaPersone", response, whitelist=[200, 204], raising=False) and not response.json():
        # crea nuova persona
        endpoint = "Persona"
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(dati_persona))
        check_response("/Persona/RicercaPersone", response, whitelist=[200, 204])
        id_persona = response.json()

    elif check_response("/Persona/RicercaPersone", response, whitelist=[200, 204], raising=False):
        # aggiorno dati persona
        id_persona = [pp["IdPersona"] for pp in response.json()][0]
        endpoint = f"Persona/{id_persona}"
        response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(dati_persona))
        check_response("/Persona/RicercaPersone", response, whitelist=[200, 204])

    else:
        raise BusinessValueError("Persona non censita")

    return id_persona


def crea_o_aggiorna_dati_aggiuntivi_persona(id_persona: int, data: Any) -> None:
    """Crea, aggiorna dati aggiuntivi della persona."""
    endpoint = f"Persona/{id_persona}/datiAggiuntiviPersona"
    response = requests.get(f"{HOST}{endpoint}", headers=HEADERS)
    check_response(endpoint, response)

    if check_response(endpoint, response, whitelist=[200, 404], raising=False) and not response.json():
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(data))
        check_response(endpoint, response, whitelist=[200, 204])
    elif check_response(endpoint, response, whitelist=[200, 204], raising=False):
        response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(data))
        check_response(endpoint, response, whitelist=[200, 204])


def aggiungi_o_aggiorna_indirizzi_persona(id_persona: int, sede: Any, altra_sede: Any, persona: Any) -> None:
    """Aggiungi o aggiorna indirizzi persona."""
    endpoint = f"Persona/{id_persona}/collezioneIndirizzi"
    response_collezioneIndirizzi = requests.get(f"{HOST}{endpoint}", headers=HEADERS)
    check_response(endpoint, response_collezioneIndirizzi, whitelist=[200, 204, 400])

    endpoint = f"Persona/{id_persona}/indirizzo"

    if response_collezioneIndirizzi.status_code == 404:
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(sede))
        check_response(endpoint, response, whitelist=[200, 204])
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(altra_sede))
        check_response(endpoint, response, whitelist=[200, 204])

    elif response_collezioneIndirizzi.status_code in (200, 204):
        indirizzi = [rr["CodTipoIndirizzo"] for rr in response_collezioneIndirizzi.json()]

        if persona.sede0CodTipoIndirizzo not in indirizzi:
            response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(sede))
            check_response(endpoint, response, whitelist=[200, 204])

        if persona.sede1CodTipoIndirizzo not in indirizzi:
            response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(altra_sede))
            check_response(endpoint, response, whitelist=[200, 204])

        for row in response_collezioneIndirizzi.json():
            idindirizzo = row["IdIndirizzo"]
            endpoint = f"Persona/{id_persona}/indirizzo/{idindirizzo}"

            if persona.sede0CodTipoIndirizzo == row["CodTipoIndirizzo"]:
                response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(sede))
                check_response(endpoint, response, whitelist=[200, 204])

            if persona.sede1CodTipoIndirizzo == row["CodTipoIndirizzo"]:
                response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(altra_sede))
                check_response(endpoint, response, whitelist=[200, 204])


def aggiungi_o_aggiorna_contatto_persona(id_persona: int, ruolo_contatto: int, dati_contatto: Raw_Body_Data) -> None:
    """Aggiungi o aggiorna contatti persona."""
    endpoint_persona_contatti = f"Persona/{id_persona}/collezioneContatti"
    response_persona_contatti = requests.get(f"{HOST}{endpoint_persona_contatti}", headers=HEADERS)
    check_response(endpoint_persona_contatti, response_persona_contatti, whitelist=[200, 204, 400])

    endpoint_persona_contatto = f"Persona/{id_persona}/contatto"

    if response_persona_contatti.status_code == 404:
        response = requests.post(
            f"{HOST}{endpoint_persona_contatto}", headers=HEADERS, data=prepare_body(dati_contatto)
        )
        check_response(endpoint_persona_contatto, response, [200, 204])

    elif response_persona_contatti.status_code in (200, 204):
        contatti = [rr["CodRuoloContatto"] for rr in response_persona_contatti.json()]

        if ruolo_contatto not in contatti:
            response = requests.post(
                f"{HOST}{endpoint_persona_contatto}", headers=HEADERS, data=prepare_body(dati_contatto)
            )
            check_response(endpoint_persona_contatto, response, [200, 204])

        for row in response_persona_contatti.json():
            idcontatto = row["IdContatto"]
            endpoint_contatto = f"Persona/{id_persona}/contatto/{idcontatto}"

            if ruolo_contatto == row["CodRuoloContatto"]:
                response = requests.put(f"{HOST}{endpoint_contatto}", headers=HEADERS, data=prepare_body(dati_contatto))
                check_response(endpoint_contatto, response, [200, 204])


def aggiungi_o_aggiorna_doc_identita(id_persona: int, dati_documento: Raw_Body_Data) -> None:
    """."""
    endpoint = f"Persona/{id_persona}/documentoIdentita"
    response = requests.get(f"{HOST}{endpoint}", headers=HEADERS)
    check_response(endpoint, response)

    if response.status_code == 404:
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(dati_documento))
        check_response(endpoint, response)

    elif response.status_code in (200, 204):
        response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=prepare_body(dati_documento))
        check_response(endpoint, response)


# dubbio, l'api_handlers a livello dei flussi non lo utilizza
# def aggiungi_relazione_persona_persona(
#     id_persona: int, id_incarico: int, id_persona_cliente: int, ruolo: str, lista_persone: Any
# ) -> None:
#     """."""
#     endpoint = f"Persona/relazionePersonaPersona/{id_persona_cliente}"
#     response_personapersona = requests.get(f"{HOST}{endpoint}", headers=HEADERS)
#     check_response(endpoint, response_personapersona)

#     if response_personapersona.status_code == 404:
#         endpoint = f"Incarico/{id_incarico}/relazionePersonaPersona"
#         data = {
#             "IdPersonaUno": id_persona_cliente,
#             "IdPersonaDue": id_persona,
#             "CodRuoloPersona": ruolo,
#         }
#         response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
#         check_response(endpoint, response, [200, 204])

#     elif response_personapersona.status_code in (200, 204):
#         for row in response_personapersona.json():
#             str_personapersona = (row["IdPersonaDue"], row["IdRuoloPersona"])
#             lista_persone.append(str_personapersona)

#         str_personapersona = (id_persona, ruolo)
#         if str_personapersona not in lista_persone:
#             endpoint = f"Incarico/{id_incarico}/relazionePersonaPersona"
#             data = {
#                 "IdPersonaUno": id_persona_cliente,
#                 "IdPersonaDue": id_persona,
#                 "CodRuoloPersona": ruolo,
#             }
#             response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
#             check_response(endpoint, response, [200, 204])


def aggiungi_relazione_persona_persona(
    id_persona: int, id_incarico: int, id_persona_cliente: int, ruolo: str
) -> List[Any]:
    """Aggiunge relazione persona persona."""
    lista_persone: List[Any] = []
    endpoint = f"Persona/relazionePersonaPersona/{id_persona_cliente}"
    response_personapersona = requests.get(f"{HOST}{endpoint}", headers=HEADERS)
    check_response(endpoint, response_personapersona)

    if response_personapersona.status_code == 404:
        endpoint = f"Incarico/{id_incarico}/relazionePersonaPersona"
        data = {
            "IdPersonaUno": id_persona_cliente,
            "IdPersonaDue": id_persona,
            "CodRuoloPersona": ruolo,
        }
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
        check_response(endpoint, response, [200, 204])
        str_personapersona = (id_persona, ruolo)
        lista_persone.append(str_personapersona)

    elif response_personapersona.status_code in (200, 204):
        for row in response_personapersona.json():
            str_personapersona = (row["IdPersonaDue"], row["IdRuoloPersona"])
            lista_persone.append(str_personapersona)

        str_personapersona = (id_persona, ruolo)
        if str_personapersona not in lista_persone:
            endpoint = f"Incarico/{id_incarico}/relazionePersonaPersona"
            data = {
                "IdPersonaUno": id_persona_cliente,
                "IdPersonaDue": id_persona,
                "CodRuoloPersona": ruolo,
            }
            response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
            check_response(endpoint, response, [200, 204])
    return lista_persone


def aggiungi_o_aggiorna_dato_aggiuntivo_incarico_per_tipo(id_incarico: int, tipo: int, data: Any) -> None:
    """Aggiungi o aggiorna dato aggiuntivo incarico per tipo."""
    endpoint = f"Incarico/{id_incarico}/datoAggiuntivo"
    response = requests.get(f"{HOST}{endpoint}/{tipo}", headers=HEADERS)
    check_response(endpoint, response)

    if response.status_code == 404:
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
        check_response(endpoint, response, [200, 204])

    elif response.status_code == 200:
        response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
        check_response(endpoint, response, [200, 204])


def aggiungi_o_aggiorna_pratica_finanziamento(id_incarico: int, data: Any) -> None:
    """."""
    endpoint = f"Incarico/{id_incarico}/praticaFinanziamento"
    response = requests.get(f"{HOST}{endpoint}", headers=HEADERS)

    if response.status_code == 404:
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
        check_response(endpoint, response, [200, 204])

    elif response.status_code == 200:
        response = requests.put(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
        check_response(endpoint, response, [200, 204])

    else:
        check_response(endpoint, response, [200, 204, 404])


def upload_documenti_incarico(data: Any) -> None:
    endpoint = "Documento"
    response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
    check_response(endpoint, response, [200, 204])


def aggiungi_o_aggiorna_dato_aggiuntivo_incarico_per_tipo_noupdate(id_incarico: int, tipo: int, data: Any) -> None:
    """Aggiungi o aggiorna dato aggiuntivo incarico per tipo non fa update."""
    endpoint = f"Incarico/{id_incarico}/datoAggiuntivo"
    response = requests.get(f"{HOST}{endpoint}/{tipo}", headers=HEADERS)
    check_response(endpoint, response)

    if response.status_code == 404:
        response = requests.post(f"{HOST}{endpoint}", headers=HEADERS, data=str(data))
        check_response(endpoint, response, [200, 204])
