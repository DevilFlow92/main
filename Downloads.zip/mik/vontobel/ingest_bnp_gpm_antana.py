"""Scarica csv da sftp antana vontobel, e carica su db."""

from typing import Any, List

import pyodbc
from prefect import case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, ReadCsv, SendMail, UploadFiles, ValidateData
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_date, to_decimal, to_stripped_string

from mikono.vontobel.jobs import DeleteFileSFTP, LastFile, getmailparams


class Ingest_bnp_gpm_antana(Task):
    """Inserisce righe in L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData, FileName: str) -> TaskData:  # noqa
        with self.log.start_action(self.name):
            try:
                self.open()
                if data["data"] == []:
                    # caso del file trovato ma vuoto
                    # non voglio che il task esploda, semplicemente torno subito
                    # il taskdata prima di fare qualunque cosa
                    # in questo modo il task va avanti per limitarsi a spostare il file
                    # e terminare senza segnalare errori inattesi
                    return {
                        "data": [],
                        "errors": [],
                        "meta": data["meta"],
                    }
                DataFlusso = data["data"][0]["data"]
                JobDescription = "vontobel_gpm_bnp_antana"
                CodiceAmbiente = "GPM"
                self.cursor.execute("SELECT rs.DateAdd_GiorniLavorativi(302, ? ,1)", DataFlusso)
                DateImport = self.cursor.fetchone()[0]
                self.cursor.execute(
                    """SELECT TOP 1 IdImport FROM rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                    WHERE DateImport = ? AND JobDescription = ?""",
                    DateImport,
                    JobDescription,
                )
                Disattiva = self.cursor.fetchone()
                if Disattiva:
                    self.cursor.execute(
                        """UPDATE rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana
                        SET FlagAttivo = 0
                        WHERE DateImport = ?
                        AND JobDescription = ?
                        AND FlagAttivo = 1""",
                        DateImport,
                        JobDescription,
                    )
                    self.dbconn.commit()

                for row in data["data"]:
                    try:
                        self.cursor.execute(
                            "INSERT INTO rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana "
                            "(Famiglia, Account, Linea, Titolo, Isin, Descr_titolo, Quantita, Prezzo, "
                            "Divisa, Valore_euro, Ndg, Dossier_titoli, Banca, Conto_corrente, Deposito, "
                            "FileImport, JobDescription, DateImport, Cambio, Nome, Cognome, RagioneSociale, "
                            "DataFlusso, DataImport_reale, NomePartner, CodiceAmbiente, CodiceTitolo) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'BNP', ?, ?,"
                            "?, ?, ?, ?, ?, ?, NULL, ?, getdate(), 'Vontobel', ?, ?)",
                            row["Famiglia"],
                            row["Account"],
                            row["Linea"],
                            row["Titolo"],
                            row["Isin"],
                            row["Descr_titolo"],
                            row["Quantita"],
                            row["Prezzo"],
                            row["Divisa"],
                            row["Valore_euro"],
                            row["Ndg"],
                            row["dossier_titoli"],
                            row["conto_corrente"],
                            row["Deposito"],
                            FileName,
                            JobDescription,
                            DateImport,
                            row["cambio"],
                            row["nome"],
                            row["cognome"],
                            DataFlusso,
                            CodiceAmbiente,
                            row["COD4"],
                        )
                    except Exception as dbex:
                        self.dbconn.rollback()
                        return {
                            "data": [],
                            "errors": [
                                {"error": str(dbex), "source": row},
                            ],
                            "meta": {},
                        }
                self.dbconn.commit()
                return {"data": [], "errors": [], "meta": {}}

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Errore inatteso: {str(ex)}")
                self.dbconn.rollback()
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                if self.dbconn:
                    self.dbconn.close()


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


@task
def prepare_message(data: TaskData) -> TaskData:
    """Mi serve togliere i punti per riuscire a convertire."""
    data_ = data.copy()
    for row in data_["data"]:
        row["Quantita"] = row["Quantita"].replace(",", ".")
        row["cambio"] = row["cambio"].replace(",", ".")
        row["Prezzo"] = row["Prezzo"].replace(",", ".")
        row["Valore_euro"] = row["Valore_euro"].replace(",", ".")
    return data_


with Flow("ingest_vontobel_bnp_gpm_antana") as flow:

    lastfile_ = LastFile(
        sftp_label="sftp_vontobel",
        path="flussi_antana/Flussi",
        startswith="SaldiBNP_GPM",
        nomatch="",
    )
    local_path, FileName, source_file = lastfile_()

    check_filefound = check_condition(source_file["errors"])

    with case(check_filefound, True):
        prepare_body = StringFormatter()
        body = prepare_body(
            template="""No File Found.""",
        )
        mailparams = getmailparams(db="db_clc_w")
        subject_, from_, to_, cc_ = mailparams("SELECT * FROM rs.v_Mikono_DatiMailErrore")

        warn_empty_send_delivery = SendMail(conf="mail_server")
        warn_empty_send_delivery(
            {
                "subject": subject_,
                "from": from_,
                "to": to_,
                "cc": cc_,
                "msg": body,
            }
        )

    with case(check_filefound, False):
        read_antana = ReadCsv(
            # i nomi delle colonne che si vogliono recuperare
            fields=(
                "Famiglia",
                "Account",
                "Linea",
                "Titolo",
                "Isin",
                "Descr_titolo",
                "Quantita",
                "Prezzo",
                "Divisa",
                "Valore_euro",
                "Ndg",
                "dossier_titoli",
                "Banca",
                "conto_corrente",
                "Deposito",
                "cambio",
                "nome",
                "cognome",
                "data",
                "ANTASIMG",
                "COD4",
            ),
            # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
            encoding="iso-8859-1",
            # headless=True,
            options={"delimiter": ";"},
        )

        dati_antana_ = read_antana(local_path)
        dati_antana = prepare_message(dati_antana_)

        schema_antana = Schema(
            {
                "Famiglia": Coerce(to_stripped_string()),
                "Account": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "Linea": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "Titolo": Coerce(to_stripped_string()),
                "Isin": Coerce(to_stripped_string()),
                "Descr_titolo": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                # "Quantita": Coerce(float, nones=["",]),
                "Quantita": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
                "Prezzo": Coerce(
                    float,
                    nones=[
                        "",
                    ],
                ),
                "Divisa": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "Valore_euro": Coerce(
                    float,
                    nones=[
                        "",
                    ],
                ),
                "Ndg": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "dossier_titoli": Coerce(to_stripped_string()),
                "Banca": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "conto_corrente": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "Deposito": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "cambio": Coerce(float, nones=[""]),
                "nome": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "cognome": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "data": Coerce(to_date(["%d/%m/%Y", "%Y/%m/%d", "%d-%m-%Y", "%Y-%m-%d"]), nones=[""]),
                "ANTASIMG": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
                "COD4": Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                ),
            }
        )

        validate_schema_antana = ValidateData(schema=schema_antana)
        validated_antana = validate_schema_antana(dati_antana)

        ingest_data = Ingest_bnp_gpm_antana(db="db_clc_w")
        doit = ingest_data(validated_antana, FileName)

        cond = check_condition(doit["errors"])

        with case(cond, False):
            upload = UploadFiles(auth_label="sftp_vontobel", dest_prefix="flussi_antana/Flussi/Elab")
            uploaded = upload(source_file)
            with case(uploaded["meta"]["isEmpty"], False):
                delete = DeleteFileSFTP(auth_label="sftp_vontobel", path="flussi_antana/Flussi")
                deleted_ = delete(FileName)

        with case(cond, True):
            prepare_body = StringFormatter()
            body = prepare_body(
                template="""Errori durante il caricamento in tabella
                            L_Import_Mikono_SaldiQuote_SaldiLiquidi_Antana: {errors_list}""",
                errors_list=doit["errors"],
            )
            mailparams = getmailparams(db="db_clc_w")
            subject_, from_, to_, cc_ = mailparams("SELECT * FROM rs.v_Mikono_DatiMailErrore")

            warn_empty_send_delivery = SendMail(conf="mail_server")
            warn_empty_send_delivery(
                {
                    "subject": subject_,
                    "from": from_,
                    "to": to_,
                    "cc": cc_,
                    "msg": body,
                }
            )

if __name__ == "__main__":
    res = flow.run()
