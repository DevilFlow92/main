"""Pull Vontobel files.

...
"""
from pymol.jobs import Flow, PullStream

with Flow("pull files") as flow:
    pull = PullStream(
        name="pull stream",
        source_label="sftp_vontobel",
        source_path={
            "flussi_antana/KPI/",
            "download/Backup/EndOfDay/Basic",
            "download/Backup/EndOfDay/Index",
            "download/Backup/EndOfDay/YieldCurves",
            "download/Backup/EndOfDay/MifidII",
            "download/Backup/EndOfDay/Issuers",
            "download/Backup/EndOfDay",
            "flussi_antana/Lavorazione_backoffice/Check_SaldiQuota/Elab",
            "flussi_antana/Lavorazione_backoffice/Check_SaldiLiquid/Elab",
        },
        whitelist={
            # flussi_antana/KPI/
            r"KPI\w{3}(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"KPIantana(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.(xlsx|csv)",
            r"VONT_ONLS_[A-Z]+(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})(\d{4})?\.txt",
            r"ControlloDT(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"EstrazioneIban(All|Principale)(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Vontobel_ContrattiDossier_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            # download/Backup/EndOfDay/Basic
            r"Antana_Asset_Prices_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Antana_New_Asset_Price_History_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            # download/Backup/EndOfDay/Index
            r"Antana_Index_Prices_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            # download/Backup/EndOfDay/YieldCurves
            r"Antana_Yield_Curves_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            # download/Backup/EndOfDay/MifidII
            r"Antana_Mifid_Costs_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            # download/Backup/EndOfDay/Issuers
            r"Antana_Asset_Issuer_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            # download/Backup/EndOfDay
            r"antana_hist_prices_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            # flussi_antana/Lavorazione_backoffice/Check_SaldiQuota/Elab
            r"Vontobel_RON_ControlloSaldiQuota_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            r"Vontobel_OLS_RON_ControlloSaldiQuota_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            r"Vontobel_GPM_ControlloSaldiQuota_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            # flussi_antana/Lavorazione_backoffice/Check_SaldiLiquid/Elab
            r"Vontobel_RON_ControlloSaldiLiquid_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            r"Vontobel_GPM_ControlloSaldiLiquid_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
        },
        ignorelist={
            r"^AntanaFeed$",
            r"^Basic$",
            r"^Docs$",
            r"^Antana_Markets_NonMainCCy_\d{8}\.csv$",
            r"^Antana_Mifid_Costs_ValUnit_Report_\d{8}\.csv$",
            r"^ControlliPreInvioOLS\d{8}(_)?\.csv$",
            r"^ElabVontobel_ContrattiDossier_\d{8}_\d{8}\.csv$",
            r"^Elab$",
            r"^FM_Vontobel_\w{3}_ControlloSaldi\w+_\d{8}_\d{8}\.csv$",
            r"^Index$",
            r"^Issuers",
            r"^YieldCurves$",
            r"^MifidII$",
            r"^Reconciliation$",
            r"^(FM_)?Vontobel_(NOMATCH|OLS_RON)_ControlloSaldi\w+_\d{8}(_\d{8})?\.csv$",
            r"^VONT_ONLS_ORDIN202107131517 Orig.txt$",
            r"^VONT_ONLS_ORDIN202106241503 err.txt$",
            r"^test$",
        },
        dest_label="sftp_vontobel",
        dest_path="flussi_antana/KPI/Elab",
        timeout=60 * 15,
    )
    downloaded_files = pull()


if __name__ == "__main__":
    flow.run()
