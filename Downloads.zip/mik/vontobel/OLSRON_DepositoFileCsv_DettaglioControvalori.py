"""Vontobel deposito file riconciliazione."""
import sys
from typing import Any

import pyodbc
from prefect import Parameter
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, UploadFiles, WriteCsv, shift_date
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData


class CaricaDati(Task):
    """Richiama dati da db per scriverli in un csv da trasferire in sftp."""

    def __init__(
        self,
        db: str,
        query: str,
        nomefile: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.query_ = query
        self.nomefile_ = nomefile
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)

        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: str) -> TaskData:  # noqa
        Dizionario = []
        with self.log.start_action(self.name):
            try:
                self.open()
                NomeCsv_ = self.nomefile_
                DataImportNormalizzata = data
                # DataImportNormalizzata = "2022-05-12"

                DataImportNomeCSV = DataImportNormalizzata.replace("-", "")

                # estrarre il primo giorno del mese [inizio]
                q1 = """
SELECT top 1
CASE WHEN CAST(MIN(InizioMezzaGiornata) OVER (ORDER BY InizioMezzaGiornata) as DATE) = CAST(? AS DATE)
THEN 1
ELSE 0
END IsPrimoGiornoMese
FROM S_Calendario
WHERE CodCliente = 302
AND FlagLavorativo = 1
AND YEAR(InizioMezzaGiornata) = YEAR(?)
AND MONTH(InizioMezzaGiornata) = MONTH(?)
                """
                self.cursor.execute(
                    q1,
                    DataImportNormalizzata,
                    DataImportNormalizzata,
                    DataImportNormalizzata,
                )
                Lettura_DB = self.cursor.fetchone()
                IsPrimoGiornoMese = Lettura_DB.IsPrimoGiornoMese
                # estrarre il primo giorno del mese [fine]

                # today = date.today().strftime("%Y%m%d")
                # controllo se è il primo giorno del mese per modificare dinamicamente
                # il nome del file
                if IsPrimoGiornoMese:
                    NomeCsv = f"FM_CheckSaldiTotali_{DataImportNomeCSV}_{NomeCsv_}.csv"
                else:
                    NomeCsv = f"CheckSaldiTotali_{DataImportNomeCSV}_{NomeCsv_}.csv"

                # estrarre i dati [inizio]
                q2 = self.query_

                self.cursor.execute(
                    q2,
                    DataImportNormalizzata,
                )
                Lettura = self.cursor.fetchall()
                # estrarre i dati [fine]

                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

                return {"data": Dizionario, "errors": [], "meta": {"FileName": NomeCsv}}

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere il DB: {str(ex)}")
                self.dbconn.rollback()
                raise ex
            finally:
                if self.dbconn:
                    self.dbconn.close()


with Flow("OLSRON_DepositoFilesCSV_DettaglioControvalori") as flow:
    on_date_ = Parameter("on_date", default="")
    shift_days_ = Parameter("shift_days", default="0")
    date_ = shift_date(on_date_, shift_days_, skip_weekends=True)

    queryCtvQuote = """
SELECT TipologiaMismatchFile
,BancaMismatch
,Banca
,depositarieBanca
,FORMAT(DataImportNormalizzata, 'yyyyMMdd') DataImportNormalizzata
,CheckDivisaDiversa
,AccountTruncated
,Dossier_titoli
,depositarieDossier_titoli
,Isin
,depositarieIsin
,Descr_titolo
,CASE WHEN Quantita = 0
    then '0'
    else REPLACE(FORMAT(Quantita ,'####.####') ,'.',',')
END Quantita
,CASE WHEN depositarieQuantita = 0
    then '0'
    else REPLACE(FORMAT(depositarieQuantita ,'####.####'),'.',',')
end depositarieQuantita
,case when Prezzo = 0
    then '0'
    else REPLACE(FORMAT(Prezzo ,'####.####'), '.',',')
end Prezzo
,case when depositariePrezzo = 0
    then '0'
    else REPLACE(FORMAT(depositariePrezzo,'####.####'),'.',',')
end depositariePrezzo
,Divisa
,depositarieDivisa
,case when Cambio = 0
    then '0'
    else REPLACE(FORMAT(Cambio ,'####.####'),'.',',')
end Cambio
,case when depositarieCambio = 0
    then '0'
    else REPLACE(FORMAT(depositarieCambio ,'####.####'),'.',',')
end depositarieCambio
,FileImport
,depositarieFileImport
,case when [CTV ANTANA] = 0
    THEN '0'
    ELSE replace(FORMAT([CTV ANTANA] ,'####.####'),'.',',')
END [CTV ANTANA]
,CASE WHEN [CTV DEPO] = 0
    THEN '0'
    ELSE replace(FORMAT([CTV DEPO] ,'####.####'),'.',',')
END [CTV DEPO]
,CASE WHEN Differenza = 0
    then '0'
    else replace(FORMAT(Differenza ,'####.####'),'.',',')
end Differenza
,REPLACE([Differenza su patrimonio],'.',',') [Differenza su patrimonio]
,CASE WHEN Patrimonio = 0
    then '0'
    else REPLACE(FORMAT(Patrimonio ,'####.####'),',','.')
end Patrimonio
,NULL Note
FROM rs.v_Mikono_Vontobel_OLSRON_DettaglioControvalori_Quote_pycc
WHERE DataImportNormalizzata = ?
ORDER BY ABS_DifferenzaPatrimonio DESC
"""

    FileLocaleCtvQuote = CaricaDati(
        name="Carica Dati Dettaglio CTV Quote",
        db="db_clc_w",
        query=queryCtvQuote,
        nomefile="DettaglioControvalori_Quote",
    )

    DatiDaScrivereCTVQuote = FileLocaleCtvQuote(data=date_)

    writeCTVQuote = WriteCsv(
        name="Scrivi csv Controvalori Quote",
        filename_meta=["FileName"],
        fields=[
            "TipologiaMismatchFile",
            "BancaMismatch",
            "Banca",
            "depositarieBanca",
            "DataImportNormalizzata",
            "CheckDivisaDiversa",
            "AccountTruncated",
            "Dossier_titoli",
            "depositarieDossier_titoli",
            "Isin",
            "depositarieIsin",
            "Descr_titolo",
            "Quantita",
            "depositarieQuantita",
            "Prezzo",
            "depositariePrezzo",
            "Divisa",
            "depositarieDivisa",
            "Cambio",
            "depositarieCambio",
            "FileImport",
            "depositarieFileImport",
            "CTV ANTANA",
            "CTV DEPO",
            "Differenza",
            "Differenza su patrimonio",
            "Patrimonio Totale",
            "Note",
        ],
        options={"delimiter": ";"},
    )

    written_filesCTVQuote = writeCTVQuote(DatiDaScrivereCTVQuote)

    upload = UploadFiles(
        auth_label="sftp_vontobel",
        dest_prefix="flussi_antana/Lavorazione_backoffice/Check_SaldiTotali",
    )

    upload(written_filesCTVQuote)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1]})
