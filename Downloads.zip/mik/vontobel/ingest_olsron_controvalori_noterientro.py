"""Scarica csv per importare contenuto su tabella statica."""
import sys
from typing import List

import prefect
from prefect import Parameter, case, task
from prefect.tasks.templates import StringFormatter
from pymol.jobs import DownloadRemoteFiles, Flow, IngestFeed, ReadCsv, SendMail, ValidateData, shift_date
from pymol.types.jobs import DataRow, TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_decimal, to_stripped_string

from mikono.vontobel.jobs import getmailparams


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


@task
def detectfiles(date: str) -> TaskData:
    """Detect file to be ingested."""
    date_ = date.replace("-", "")
    data = {
        "data": [
            {
                "path": "flussi_antana/Lavorazione_backoffice/Check_SaldiTotali",
                "rx": rf"CheckSaldiTotali_{date_}_ValoriTotali.csv",
            },
        ],
    }
    return data  # type: ignore


@task
def prepare_message(
    data: TaskData,
) -> TaskData:
    """Gestione separatori decimali per passare la validazione."""
    for row in data["data"]:
        row["VALORE ANTANA"] = row["VALORE ANTANA"].replace(",", ".")
        row["VALORE DEPOSITARIA"] = row["VALORE DEPOSITARIA"].replace(",", ".")
        row["DIFF."] = row["DIFF."].replace(",", ".")

    return data


@task
def fake_filename(date_: str) -> str:
    # imposto nome fittizio: mi serve per sfruttare la IngestFeed
    # altrimenti non funziona
    tt = prefect.context.scheduled_start_time.time().strftime("%H-%M")
    return (
        f"/sftp_vontobel/lavorazione_backoffice/Check_SaldiTotali/{date_.replace('-', '/')}/lsdir@{date_}T{tt}-00+00-00"
    )


class IngestKPI(IngestFeed):
    def from_msg(self, values: DataRow, extra_values: dict[str, str]) -> tuple[str, DataRow]:
        """Passo taskdata validato per fare insert a db."""
        # k è la chiave del dizionario, v è il valore
        # nel mio caso il dizionario ha solo una riga
        output = {k: v if v is not None else 0 for k, v in values.items()}
        output.update({"msg_type": "Ingest_note_olsron"})  # setto il msg_type a piacere
        return "pycc.E_Mikono_SaldiTotali_note", output  # questo mi va a generare la insert


with Flow("Ingest OLS RON note rientro") as flow:
    """Flusso di acquisizione file operativo da importare a db.
    Al termine dell'import, sposta file su Elab.
    """
    on_date_ = Parameter("on_date", default="")
    on_date = shift_date(on_date_, 0, skip_weekends=True)

    data = detectfiles(date=on_date)
    download = DownloadRemoteFiles(
        auth_label="sftp_vontobel",
    )
    dled_file = download(data)
    read_csv = ReadCsv(
        fields=(
            "DataImportNormalizzata",
            "Famiglia",
            "DOSSIER BANCA",
            "Banca",
            "VALORE ANTANA",
            "VALORE DEPOSITARIA",
            "DIFF.",
            "SCOSTAMENTO",
            "RISULTATO",
            "NOTE",
        ),
        # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
        encoding="iso-8859-1",
        # headless=True,
        options={"delimiter": ";"},
    )

    dati = read_csv(dled_file["data"][0])
    prepared_data = prepare_message(dati)

    schema_ = Schema(
        {
            "DataImportNormalizzata": Coerce(to_stripped_string()),
            "Famiglia": Coerce(to_stripped_string()),
            "DOSSIER BANCA": Coerce(to_stripped_string()),
            "Banca": Coerce(to_stripped_string()),
            "VALORE ANTANA": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "VALORE DEPOSITARIA": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "DIFF.": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
            "SCOSTAMENTO": Coerce(to_stripped_string()),
            "RISULTATO": Coerce(to_stripped_string()),
            "NOTE": Coerce(to_stripped_string()),
        }
    )

    validate_schema = ValidateData(schema=schema_)
    validated_data = validate_schema(prepared_data)

    source_path = fake_filename(on_date)

    ingest = IngestKPI(db="db_clc_w", provider="vontobel", feed="saldi_totali_olsron")
    doit = ingest(data=validated_data, source_path=source_path)

    cond = check_condition(doit["errors"])

    with case(cond, True):
        prepare_body = StringFormatter()
        body = prepare_body(
            template="""Errori durante caricamento in tabella
            [pycc].[E_Mikono_SaldiTotali_note]:
            {errors_list}""",
            errors_list=doit["errors"],
        )
        mailparams = getmailparams(db="db_clc_w")
        subject_, from_, to_, cc_ = mailparams("SELECT * FROM rs.v_Mikono_DatiMailErrore")

        warn_empty_send_delivery = SendMail(conf="mail_server")
        warn_empty_send_delivery(
            {
                "subject": subject_,
                "from": from_,
                "to": to_,
                "cc": cc_,
                "msg": body,
            }
        )

if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1]})
