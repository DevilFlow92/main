"""Scarica csv da sftp mikono anthilia depositarie, e carica su db."""
from typing import Any, List

import pyodbc
from prefect import case, task
from prefect.tasks.templates import StringFormatter
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, ReadCsv, SendMail, UploadFiles, ValidateData
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData
from pymol.validation import Coerce, Schema
from pymol.validation.coerce import to_date, to_decimal, to_stripped_string

from mikono.vontobel.jobs import DeleteFileSFTP, LastFile, getmailparams


@task
def prepare_message(data: TaskData) -> TaskData:
    """Mi serve togliere la virgola per riuscire a convertire."""
    data_ = data.copy()
    for row in data_["data"]:
        row["Quantita"] = row["Quantita"].replace(",", "")
        row["prezzo"] = row["prezzo"].replace(",", "")
        row["valore_euro"] = row["valore_euro"].replace(",", "")
        row["Controvalore"] = row["Controvalore"].replace(",", "")
    return data_


class Ingest_saldi_titoli_bnp_vontobel_depositaria(Task):
    """Inserisce righe in rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: TaskData, FileName: str) -> TaskData:  # noqa
        with self.log.start_action(self.name):
            try:
                self.open()
                if data["data"] == []:
                    # caso del file trovato ma vuoto
                    # non voglio che il task esploda, semplicemente torno subito
                    # il taskdata prima di fare qualunque cosa
                    # in questo modo il task va avanti per limitarsi a spostare il file
                    # e terminare senza segnalare errori inattesi
                    return {
                        "data": [],
                        "errors": [],
                        "meta": data["meta"],
                    }
                JobDescription = "vontobel_bnp_titoli"
                DataFlusso = data["data"][0]["Data_Flusso"]
                self.cursor.execute("SELECT rs.DateAdd_GiorniLavorativi(302, ? ,1)", DataFlusso)
                DateImport = self.cursor.fetchone()[0]
                self.cursor.execute(
                    """SELECT TOP 1 IdImport FROM rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                    WHERE DataFlusso = ? AND JobDescription = ?""",
                    DataFlusso,
                    JobDescription,
                )
                Disattiva = self.cursor.fetchone()
                if Disattiva:
                    self.cursor.execute(
                        """UPDATE rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                        SET FlagAttivo = 0
                        WHERE DataFlusso = ?
                        AND JobDescription = ?
                        AND FlagAttivo = 1""",
                        DataFlusso,
                        JobDescription,
                    )
                    self.dbconn.commit()

                for row in data["data"]:
                    if row["j"] == "Settled":
                        try:
                            self.cursor.execute(
                                """INSERT INTO rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie
                                (Titolo, Isin, Descr_titolo, Quantita, Prezzo, Divisa, Valore_euro,
                                Dossier_titoli, Banca, FileImport, JobDescription, DateImport, DataFlusso,
                                DataImport_reale, NomePartner, FlagAttivo, Controvalore)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'BNP', ?, ?, ?, ?,
                                GETDATE(), 'Vontobel', 1, ?)""",
                                row["Titolo"],
                                row["Isin"],
                                row["Descr_titolo"],
                                row["Quantita"],
                                row["prezzo"],
                                row["Divisa"],
                                row["valore_euro"],
                                row["Dossier_titoli"],
                                FileName,
                                JobDescription,
                                DateImport,
                                DataFlusso,
                                row["Controvalore"],
                            )
                        except Exception as dbex:
                            self.dbconn.rollback()
                            return {
                                "data": [],
                                "errors": [
                                    {"error": str(dbex), "source": row},
                                ],
                                "meta": {},
                            }
                self.dbconn.commit()
                return {"data": [], "errors": [], "meta": {}}

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Errore inatteso: {str(ex)}")
                self.dbconn.rollback()
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione (se non già chiusa nel try)
                if self.dbconn:
                    self.dbconn.close()


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


with Flow("ingest_saldi_titoli_bnp_vontobel_depositaria") as flow:

    lastfile_ = LastFile(
        sftp_label="sftp_vontobel",
        path="flussi_antana/Flussi",
        startswith="POSI_ALL001_Saldotitoli",
        nomatch="",
    )
    local_path, FileName, source_file = lastfile_()

    check_filefound = check_condition(source_file["errors"])

    with case(check_filefound, True):
        prepare_body = StringFormatter()
        body = prepare_body(
            template="""No File Found.""",
        )
        mailparams = getmailparams(db="db_clc_w")
        subject_, from_, to_, cc_ = mailparams("SELECT * FROM rs.v_Mikono_DatiMailErrore")

        warn_empty_send_delivery = SendMail(conf="mail_server")
        warn_empty_send_delivery(
            {
                "subject": subject_,
                "from": from_,
                "to": to_,
                "cc": cc_,
                "msg": body,
            }
        )

    with case(check_filefound, False):
        read_depositaria = ReadCsv(
            fields=(
                "a",
                "Dossier_titoli",
                "Titolo",
                "Isin",
                "e",
                "f",
                "Descr_titolo",
                "Data_Flusso",
                "i",
                "j",
                "k",
                "l",
                "m",
                "n",
                "o",
                "p",
                "q",
                "r",
                "s",
                "t",
                "u",
                "v",
                "w",
                "x",
                "y",
                "z",
                "aa",
                "ab",
                "ac",
                "ad",
                "ae",
                "Quantita",
                "ag",
                "ah",
                "prezzo",
                "aj",
                "ak",
                "al",
                "am",
                "an",
                "ao",
                "Controvalore",
                "aq",
                "valore_euro",
                "as",
                "at",
                "au",
                "av",
                "aw",
                "ax",
                "ay",
                "Divisa",
                "ba",
                "bb",
                "bc",
                "bd",
                "be",
                "bf",
                "bg",
                "bh",
                "bi",
                "bj",
                "bk",
                "bl",
                "bm",
                "bn",
                "bo",
                "bp",
                "bq",
                "br",
                "bs",
                "bt",
                "bu",
                "bv",
                "bw",
                "bx",
                "by",
                "bz",
                "ca",
                "cb",
                "cc",
            ),
            headless=True,
            # opzionalmente l'encoding del file ( se diverso da 'utf-8' )
            encoding="iso-8859-1",
            # headless=True,
            options={"delimiter": ";"},
        )

        dati_depositaria_ = read_depositaria(local_path)
        dati_depositaria = prepare_message(dati_depositaria_)

        schema_depositaria = Schema(
            {
                "a": Coerce(to_stripped_string(), nones=[""]),
                "Dossier_titoli": Coerce(to_stripped_string(), nones=[""]),
                "Titolo": Coerce(to_stripped_string(), nones=[""]),
                "Isin": Coerce(to_stripped_string(), nones=[""]),
                "e": Coerce(to_stripped_string(), nones=[""]),
                "f": Coerce(to_stripped_string(), nones=[""]),
                "Descr_titolo": Coerce(to_stripped_string(), nones=[""]),
                "Data_Flusso": Coerce(to_date(["%d/%m/%Y", "%Y/%m/%d", "%d-%m-%Y", "%Y-%m-%d"]), nones=[""]),
                "i": Coerce(to_stripped_string(), nones=[""]),
                "j": Coerce(to_stripped_string(), nones=[""]),
                "k": Coerce(to_stripped_string(), nones=[""]),
                "l": Coerce(to_stripped_string(), nones=[""]),
                "m": Coerce(to_stripped_string(), nones=[""]),
                "n": Coerce(to_stripped_string(), nones=[""]),
                "o": Coerce(to_stripped_string(), nones=[""]),
                "p": Coerce(to_stripped_string(), nones=[""]),
                "q": Coerce(to_stripped_string(), nones=[""]),
                "r": Coerce(to_stripped_string(), nones=[""]),
                "s": Coerce(to_stripped_string(), nones=[""]),
                "t": Coerce(to_stripped_string(), nones=[""]),
                "u": Coerce(to_stripped_string(), nones=[""]),
                "v": Coerce(to_stripped_string(), nones=[""]),
                "w": Coerce(to_stripped_string(), nones=[""]),
                "x": Coerce(to_stripped_string(), nones=[""]),
                "y": Coerce(to_stripped_string(), nones=[""]),
                "z": Coerce(to_stripped_string(), nones=[""]),
                "aa": Coerce(to_stripped_string(), nones=[""]),
                "ab": Coerce(to_stripped_string(), nones=[""]),
                "ac": Coerce(to_stripped_string(), nones=[""]),
                "ad": Coerce(to_stripped_string(), nones=[""]),
                "ae": Coerce(to_stripped_string(), nones=[""]),
                "Quantita": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
                "ag": Coerce(to_stripped_string(), nones=[""]),
                "ah": Coerce(to_stripped_string(), nones=[""]),
                "prezzo": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
                "aj": Coerce(to_stripped_string(), nones=[""]),
                "ak": Coerce(to_stripped_string(), nones=[""]),
                "al": Coerce(to_stripped_string(), nones=[""]),
                "am": Coerce(to_stripped_string(), nones=[""]),
                "an": Coerce(to_stripped_string(), nones=[""]),
                "ao": Coerce(to_stripped_string(), nones=[""]),
                "Controvalore": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
                "aq": Coerce(to_stripped_string(), nones=[""]),
                "valore_euro": Coerce(to_decimal(None, None, fixed_width=False), nones=[""]),
                "as": Coerce(to_stripped_string(), nones=[""]),
                "at": Coerce(to_stripped_string(), nones=[""]),
                "au": Coerce(to_stripped_string(), nones=[""]),
                "av": Coerce(to_stripped_string(), nones=[""]),
                "aw": Coerce(to_stripped_string(), nones=[""]),
                "ax": Coerce(to_stripped_string(), nones=[""]),
                "ay": Coerce(to_stripped_string(), nones=[""]),
                "Divisa": Coerce(to_stripped_string(), nones=[""]),
                "ba": Coerce(to_stripped_string(), nones=[""]),
                "bb": Coerce(to_stripped_string(), nones=[""]),
                "bc": Coerce(to_stripped_string(), nones=[""]),
                "bd": Coerce(to_stripped_string(), nones=[""]),
                "be": Coerce(to_stripped_string(), nones=[""]),
                "bf": Coerce(to_stripped_string(), nones=[""]),
                "bg": Coerce(to_stripped_string(), nones=[""]),
                "bh": Coerce(to_stripped_string(), nones=[""]),
                "bi": Coerce(to_stripped_string(), nones=[""]),
                "bj": Coerce(to_stripped_string(), nones=[""]),
                "bk": Coerce(to_stripped_string(), nones=[""]),
                "bl": Coerce(to_stripped_string(), nones=[""]),
                "bm": Coerce(to_stripped_string(), nones=[""]),
                "bn": Coerce(to_stripped_string(), nones=[""]),
                "bo": Coerce(to_stripped_string(), nones=[""]),
                "bp": Coerce(to_stripped_string(), nones=[""]),
                "bq": Coerce(to_stripped_string(), nones=[""]),
                "br": Coerce(to_stripped_string(), nones=[""]),
                "bs": Coerce(to_stripped_string(), nones=[""]),
                "bt": Coerce(to_stripped_string(), nones=[""]),
                "bu": Coerce(to_stripped_string(), nones=[""]),
                "bv": Coerce(to_stripped_string(), nones=[""]),
                "bw": Coerce(to_stripped_string(), nones=[""]),
                "bx": Coerce(to_stripped_string(), nones=[""]),
                "by": Coerce(to_stripped_string(), nones=[""]),
                "bz": Coerce(to_stripped_string(), nones=[""]),
                "ca": Coerce(to_stripped_string(), nones=[""]),
                "cb": Coerce(to_stripped_string(), nones=[""]),
                "cc": Coerce(to_stripped_string(), nones=[""]),
            }
        )

        validate_schema = ValidateData(schema=schema_depositaria)
        validated_bnp = validate_schema(dati_depositaria)

        ingest_data = Ingest_saldi_titoli_bnp_vontobel_depositaria(db="db_clc_w")
        doit = ingest_data(validated_bnp, FileName)

        cond = check_condition(doit["errors"])

        upload = UploadFiles(auth_label="sftp_vontobel", dest_prefix="flussi_antana/Flussi/Elab")
        uploaded = upload(source_file)
        with case(uploaded["meta"]["isEmpty"], False):
            delete = DeleteFileSFTP(auth_label="sftp_vontobel", path="flussi_antana/Flussi")
            deleted_ = delete(FileName)

        with case(cond, True):
            prepare_body = StringFormatter()
            body = prepare_body(
                template="""Errori durante il caricamento in tabella
                            rs.L_Import_Mikono_SaldiQuote_SaldiLiquidi_Depositarie: {errors_list}""",
                errors_list=doit["errors"],
            )
            mailparams = getmailparams(db="db_clc_w")
            subject_, from_, to_, cc_ = mailparams("SELECT * FROM rs.v_Mikono_DatiMailErrore")

            warn_empty_send_delivery = SendMail(conf="mail_server")
            warn_empty_send_delivery(
                {
                    "subject": subject_,
                    "from": from_,
                    "to": to_,
                    "cc": cc_,
                    "msg": body,
                }
            )

if __name__ == "__main__":
    res = flow.run()
