"""Storicizzazione KPI."""
import sys
from typing import List

import prefect
from prefect import Parameter, task
from pymol.jobs import DownloadRemoteFiles, Flow, IngestFeed, ReadExcel, shift_date
from pymol.types.jobs import DataRow, TaskData


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


@task
def detectfiles(date: str) -> TaskData:
    data = {
        "data": [
            {"path": f"flussi_antana/KPI/Elab/Todo/Import/InviatiControparte/report_{date}.xlsx"},
        ],
    }
    return data  # type: ignore


@task
def prepare_report_data(
    data: TaskData,
    feed_date: str,
) -> TaskData:
    skip_header_rows = (0, 1, 2, 11, 12, 16, 20, 21, 34, 35, 38, 39)
    sequenza = []  # inizialmente la creo come list, perché mutabile
    for k in range(0, 90):
        sequenza.append(str(k))  # sequenza in indici stringati

    # inizialmente assegno tutti valori 0
    # per la sequenza di campi per la insert
    output = dict.fromkeys(sequenza, 0)

    i = 0  # contatore da usare solo quando devo registrare dati
    # ciclo per tutte le righe dell'excel
    for count, row in enumerate(data["data"]):
        # ciclo per le colonne dove vado a prendere i dati
        for r in row["B"], row["C"], row["D"]:
            # ci sono in mezzo righe che devo ignorare (skip_header_rows)
            if count not in skip_header_rows:
                if r is not None:
                    i_s = str(i)  # converto in stringa per cercare la chiave giusta del dizionario
                    output[i_s] += int(r)  # sovrascrivo 0 con i dati reali
                i += 1

    # modifico i nomi delle chiavi del dizionario, devono uscire
    # pari alle colonne della tabella oggetto di insert
    output["KP01_OrdiniBorsaEur"] = output.pop("0")
    output["KP01_OKPostCorrezione"] = output.pop("1")
    output["KP01_KO"] = output.pop("2")
    output["KP02_OrdiniBorsaDivisa"] = output.pop("3")
    output["KP02_OKPostCorrezione"] = output.pop("4")
    output["KP02_KO"] = output.pop("5")
    output["KP03_OrdiniInviatiOLS"] = output.pop("6")
    output["KP03_OKPostCorrezione"] = output.pop("7")
    output["KP03_KO"] = output.pop("8")
    output["KP04_ConfermeEsecuzioniOLS"] = output.pop("9")
    output["KP04_OKPostCorrezione"] = output.pop("10")
    output["KP04_KO"] = output.pop("11")
    output["KP05_RegistrazioniApportiPrelievi"] = output.pop("12")
    output["KP05_OKPostCorrezione"] = output.pop("13")
    output["KP05_KO"] = output.pop("14")
    output["KP06_RegistrazioniCorporateActions"] = output.pop("15")
    output["KP06_OKPostCorrezione"] = output.pop("16")
    output["KP06_KO"] = output.pop("17")
    output["KP07_AltreRegistrazioniEur"] = output.pop("18")
    output["KP07_OKPostCorrezione"] = output.pop("19")
    output["KP07_KO"] = output.pop("20")
    output["KP08_AltreRegistrazioniDivisa"] = output.pop("21")
    output["KP08_OKPostCorrezione"] = output.pop("22")
    output["KP08_KO"] = output.pop("23")
    output["KP09_FlussoOrdiniCESAMvsOLS"] = output.pop("24")
    output["KP09_OKPostCorrezione"] = output.pop("25")
    output["KP09_KO"] = output.pop("26")
    output["KP10_FlussoOrdiniOLSvsCESAM"] = output.pop("27")
    output["KP10_OKPostCorrezione"] = output.pop("28")
    output["KP10_KO"] = output.pop("29")
    output["KP11_FlussoPagamentiCESAMvsVTLugano"] = output.pop("30")
    output["KP11_OKPostCorrezione"] = output.pop("31")
    output["KP11_KO"] = output.pop("32")
    output["KP12_IdentificativiNonUnivociAntana"] = output.pop("33")
    output["KP12_OKPostCorrezione"] = output.pop("34")
    output["KP12_KO"] = output.pop("35")
    output["KP13_IdentificaviNoDeposit"] = output.pop("36")
    output["KP13_OKPostCorrezione"] = output.pop("37")
    output["KP13_KO"] = output.pop("38")
    output["KP14_IdentificativiNoAntana"] = output.pop("39")
    output["KP14_OKPostCorrezione"] = output.pop("40")
    output["KP14_KO"] = output.pop("41")
    output["KP15_AcquisizionePrezzi"] = output.pop("42")
    output["KP15_OKPostCorrezione"] = output.pop("43")
    output["KP15_KO"] = output.pop("44")
    output["KP16_AcquisizioneCambi"] = output.pop("45")
    output["KP16_OKPostCorrezione"] = output.pop("46")
    output["KP16_KO"] = output.pop("47")
    output["KP17_AcquisizioneIndici"] = output.pop("48")
    output["KP17_OKPostCorrezione"] = output.pop("49")
    output["KP17_KO"] = output.pop("50")
    output["KP18_AcquisizioneCurveTassi"] = output.pop("51")
    output["KP18_OKPostCorrezione"] = output.pop("52")
    output["KP18_KO"] = output.pop("53")
    output["KP19_AcquisizioneCostCharges"] = output.pop("54")
    output["KP19_OKPostCorrezione"] = output.pop("55")
    output["KP19_KO"] = output.pop("56")
    output["KP20_AcquisizioneEmittentiGruppi"] = output.pop("57")
    output["KP20_OKPostCorrezione"] = output.pop("58")
    output["KP20_KO"] = output.pop("59")
    output["KP21_AcquisizioneRating"] = output.pop("60")
    output["KP21_OKPostCorrezione"] = output.pop("61")
    output["KP21_KO"] = output.pop("62")
    output["KP22_AcquisizioneCausaliTitoliGruppo"] = output.pop("63")
    output["KP22_OKPostCorrezione"] = output.pop("64")
    output["KP22_KO"] = output.pop("65")
    output["KP23_AcquisizioneEmittentiTitoliGruppo"] = output.pop("66")
    output["KP23_OKPostCorrezione"] = output.pop("67")
    output["KP23_KO"] = output.pop("68")
    output["KP24_AcquisizioneDatiSensibili"] = output.pop("69")
    output["KP24_OKPostCorrezione"] = output.pop("70")
    output["KP24_KO"] = output.pop("71")
    output["KP25_CoerenzaTipologiaFondi"] = output.pop("72")
    output["KP25_OKPostCorrezione"] = output.pop("73")
    output["KP25_KO"] = output.pop("74")
    output["KP26_ControlloVariazioniPrezziStorici"] = output.pop("75")
    output["KP26_OKPostCorrezione"] = output.pop("76")
    output["KP26_KO"] = output.pop("77")
    output["KP28_IBANUnivociAntana"] = output.pop("78")
    output["KP28_OKPostCorrezione"] = output.pop("79")
    output["KP28_KO"] = output.pop("80")
    output["KP29_CorrispondenzaIBANPrincipale"] = output.pop("81")
    output["KP29_OKPostVerifica"] = output.pop("82")
    output["KP29_KO"] = output.pop("83")
    output["KP30_SaldiTitoliOK"] = output.pop("84")
    output["KP32_SaldiTitoliOKPostVerificaScarto"] = output.pop("85")
    output["KP34_SaldiTitoliKO"] = output.pop("86")
    output["KP31_SaldiLiquiditaOK"] = output.pop("87")
    output["KP33_SaldiLiquiditaOKPostVerificaScarto"] = output.pop("88")
    output["KP35_SaldiLiquiditaKO"] = output.pop("89")

    return {
        "data": [
            output,
        ],
        "errors": [],
        "meta": {"filename": f"report_{feed_date}"},
    }


@task
def fake_filename(date_: str) -> str:
    # imposto nome fittizio: mi serve per sfruttare la IngestFeed
    # altrimenti non funziona
    tt = prefect.context.scheduled_start_time.time().strftime("%H-%M")
    return f"/sftp_vontobel/{date_.replace('-', '/')}/lsdir@{date_}T{tt}-00+00-00"


class IngestKPI(IngestFeed):
    def from_msg(self, values: DataRow, extra_values: dict[str, str]) -> tuple[str, DataRow]:
        # k è la chiave del dizionario, v è il valore
        # nel mio caso il dizionario ha solo una riga
        output = {k: v if v is not None else 0 for k, v in values.items()}
        output.update({"msg_type": "KPI"})  # setto il msg_type a piacere
        return "pycc.E_VontobelKPI_report", output  # questo mi va a generare la insert


with Flow("Ingest Storico KPI Vontobel") as flow:
    on_date_ = Parameter("on_date", default="")
    past_days_ = Parameter("past_days", default="-2")
    on_date = shift_date(on_date_, past_days_, skip_weekends=True)

    data = detectfiles(date=on_date)
    download = DownloadRemoteFiles(
        auth_label="sftp_vontobel",
    )
    dled_files = download(data)

    read_xls = ReadExcel(
        fields=("A", "B", "C", "D", "E"),
        sheet_name="report",
        data_start_row=0,
        headless=True,
    )
    data_xls = read_xls(dled_files["data"][0])

    report_data = prepare_report_data(data_xls, on_date)

    source_path = fake_filename(on_date)  # file sorgente
    ingest = IngestKPI(db="db_clc_w", provider="vontobel", feed="kpi", overwrite=True)
    ingest(data=report_data, source_path=source_path, overwrite=True)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1], "past_days": "-2"})
