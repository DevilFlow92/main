"""Process messages for a range of dates in the past."""
import sys

from prefect import Parameter, task
from prefect.utilities.edges import unmapped
from pymol.jobs import Flow, get_dates, start_flow_run
from pymol.types.jobs import DataRow


@task
def get_params(feed_dates: list[DataRow]) -> list[DataRow]:
    output = []
    for feed_date in feed_dates:
        output.append(
            {
                "on_date": feed_date["on_date"],
            }
        )
    return output


with Flow("Ingest Storico KPI Vontobel Massivo") as flow:
    dates_ = Parameter("dates", default="")
    dates = get_dates(dates=dates_, skip_weekends=False, skip_holidays=False)
    params = get_params(feed_dates=dates)
    hist = start_flow_run.map(
        flow_name=unmapped("Ingest Storico KPI Vontobel"),
        project_name=unmapped("vontobel"),
        wait_for=unmapped(True),
        parameters=params,
    )


if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"dates": sys.argv[1]})
