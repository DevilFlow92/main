"""Report Vontobel KPI."""
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

from prefect import Parameter, task
from pymol.jobs import (
    CountOccurrencies,
    DetectDelivery,
    DownloadRemoteFiles,
    Flow,
    ReadCsv,
    UploadFiles,
    WriteExcelTemplate,
    shift_date,
)
from pymol.jobs.core import Task
from pymol.types.jobs import TaskData


@task
def aggregate(rows: List[TaskData]) -> TaskData:
    """Somma i conteggi di ogni colonna in un'unica riga."""
    output = dict()
    for row in rows:
        for datarow in row["data"]:
            for k, v in datarow.items():
                if k not in output:
                    output[k] = 0
                output[k] += v
    return {
        "data": [
            output,
        ],
        "errors": [],
        "meta": {},
    }


@task
def aggrega_risultati(
    cerca: Dict[str, int],
    cerca_1: Dict[str, int],
    conta: Dict[str, int],
    antana: Dict[str, int],
    fixed: Dict[str, int],
    feed_date: str,
) -> TaskData:
    """Aggrega in un unico dizionario."""
    output = {}
    for d in cerca, cerca_1, conta, antana, fixed:
        for k, v in d.items():
            if k not in output:
                output[k] = 0
            output[k] += int(v)
    return {
        "data": [
            output,
        ],
        "errors": [],
        "meta": {"filename": f"report_{feed_date}"},
    }


class ContaESottrai(Task):
    """Conta e sottrai."""

    def __init__(self, mapping: Dict[str, Tuple[str, int]], **kwargs: Any) -> None:
        """Prende un mapping fatto così.

        {"inizio nome del file": ("label da usare nel report", int da sottrarre)}
        """
        self.mapping = mapping
        super().__init__(**kwargs)

    def run(self, data: TaskData) -> TaskData:
        """Prende in input un TaskData."""
        output = {}
        for filedata in data["data"]:
            with open(filedata["path"], encoding="cp1252") as f:
                count = 0
                for count, _ in enumerate(f, 1):
                    pass
                for key in self.mapping:
                    if filedata["path"].name.startswith(key):
                        label, subtract = self.mapping[key]
                        if label not in output:
                            output[label] = 0
                        output[label] += count - subtract
        return {
            "data": [
                output,
            ],
            "errors": [],
            "meta": {},
        }


with Flow("report vontobel") as flow:
    on_date_ = Parameter("on_date", default="")
    past_days_ = Parameter("past_days", default="-2")
    on_date = shift_date(on_date_, past_days_, skip_weekends=True)

    detect_fixed_width = DetectDelivery(
        name="detect delivery fixed width",
        repo_label="sftp_vontobel",
        repo_path="flussi_antana/KPI/Elab/",
        source_label="sftp_vontobel",
        rule={
            r"VONT_ONLS_ORDIN(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})(\d{4})?\.txt",
        },
    )
    delivery_fixed_width = detect_fixed_width(feed_date=on_date)

    download_fixed_width = DownloadRemoteFiles(name="download files cerca csv", auth_label="sftp_vontobel")
    files_fixed_width = download_fixed_width(delivery_fixed_width)

    read_fixed_width = ReadCsv(
        name="read files fixed width",
        headless=True,
        fields=("singlecol",),
        encoding="cp1252",
    )
    data_fixed_width = read_fixed_width.map(files_fixed_width["data"])

    count_fixed_width = CountOccurrencies(
        name="count in cerca csv",
        mapping={
            "KP03": ("singlecol", r"^.{17}100.+"),
        },
        count_dups=False,
    )
    results_fixed_width = count_fixed_width.map(data_fixed_width)
    aggregati_fixed_width = aggregate(results_fixed_width)

    detect_cerca_csv = DetectDelivery(
        name="detect delivery cerca csv",
        repo_label="sftp_vontobel",
        repo_path="flussi_antana/KPI/Elab/",
        source_label="sftp_vontobel",
        rule={
            r"KPI(ron|gpm)(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Vontobel_ContrattiDossier_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            # kp30, kp32 ->
            r"Vontobel_RON_ControlloSaldiQuota_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            r"Vontobel_OLS_RON_ControlloSaldiQuota_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            r"Vontobel_GPM_ControlloSaldiQuota_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",
            # <-
            # r"Vontobel_RON_ControlloSaldiLiquid_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv", #kp31, kp33
            # r"Vontobel_GPM_ControlloSaldiLiquid_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv", #kp31, kp33
        },
    )
    delivery_cerca_csv = detect_cerca_csv(feed_date=on_date)

    download_cerca_csv = DownloadRemoteFiles(name="download files cerca csv", auth_label="sftp_vontobel")
    files_cerca_csv = download_cerca_csv(delivery_cerca_csv)

    read_cerca_csv = ReadCsv(
        name="read files cerca csv",
        fields=("KPI GROUP", "Mismatch", "CheckQuantitaAntanaDepositarie"),
        allow_missing_cols=True,
        options={"delimiter": ";"},
        encoding="cp1252",
    )
    data_cerca_csv = read_cerca_csv.map(files_cerca_csv["data"])

    count_cerca_csv = CountOccurrencies(
        name="count in cerca csv",
        mapping={
            "KP01": ("KPI GROUP", r"KP1"),
            "KP02": ("KPI GROUP", r"KP2"),
            "KP05": ("KPI GROUP", r"KP5"),
            "KP06": ("KPI GROUP", r"KP6"),
            "KP07": ("KPI GROUP", r"KP7"),
            "KP08": ("KPI GROUP", r"KP8"),
            "KP13": ("Mismatch", r"KO"),
            "KP14": ("Mismatch", r"DA INTEGRARE"),
            "KP30": ("CheckQuantitaAntanaDepositarie", r"OK"),
            # "KP31": ("CheckQuantitaAntanaDepositarie", r"OK"),
            "KP32": ("CheckQuantitaAntanaDepositarie", r"(KO)|(SFRIDO)"),
            # "KP33": ("CheckQuantitaAntanaDepositarie", r"KO"),
        },
        count_dups=False,
    )
    results_cerca_csv = count_cerca_csv.map(data_cerca_csv)

    aggregati_cerca_csv = aggregate(results_cerca_csv)

    # eliminare appena capiamo come sistemare sopra
    detect_cerca_csv_1 = DetectDelivery(
        name="detect delivery cerca csv 1",
        repo_label="sftp_vontobel",
        repo_path="flussi_antana/KPI/Elab/",
        source_label="sftp_vontobel",
        rule={
            r"Vontobel_RON_ControlloSaldiLiquid_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",  # kp31, kp33
            r"Vontobel_GPM_ControlloSaldiLiquid_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{8}\.csv",  # kp31, kp33
        },
    )
    delivery_cerca_csv_1 = detect_cerca_csv_1(feed_date=on_date)

    download_cerca_csv_1 = DownloadRemoteFiles(name="download files cerca csv 1", auth_label="sftp_vontobel")
    files_cerca_csv_1 = download_cerca_csv_1(delivery_cerca_csv_1)

    read_cerca_csv_1 = ReadCsv(
        name="read files cerca csv 1",
        fields=("CheckQuantitaAntanaDepositarie",),
        allow_missing_cols=True,
        options={"delimiter": ";"},
        encoding="cp1252",
    )
    data_cerca_csv_1 = read_cerca_csv_1.map(files_cerca_csv_1["data"])

    count_cerca_csv_1 = CountOccurrencies(
        name="count in cerca csv 1",
        mapping={
            "KP31": ("CheckQuantitaAntanaDepositarie", r"OK"),
            "KP33": ("CheckQuantitaAntanaDepositarie", r"(KO)|(SFRIDO)"),
        },
        count_dups=False,
    )
    results_cerca_csv_1 = count_cerca_csv_1.map(data_cerca_csv_1)

    aggregati_cerca_csv_1 = aggregate(results_cerca_csv_1)
    # eliminare appena capiamo come sistemare sopra
    detect_conta_e_sottrai = DetectDelivery(
        repo_label="sftp_vontobel",
        repo_path="flussi_antana/KPI/Elab/",
        source_label="sftp_vontobel",
        rule={
            r"VONT_ONLS_ESEG(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})(\d{4})?\.txt",
            r"ControlloDT(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Antana_Asset_Prices_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"antana_hist_prices_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Antana_Index_Prices_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Antana_Yield_Curves_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Antana_Mifid_Costs_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"Antana_Asset_Issuer_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"EstrazioneIbanAll(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
            r"EstrazioneIbanPrincipale(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
        },
    )
    delivery_conta_e_sottrai = detect_conta_e_sottrai(feed_date=on_date)

    download_conta_e_sottrai = DownloadRemoteFiles(auth_label="sftp_vontobel")
    files_conta_e_sottrai = download_conta_e_sottrai(delivery_conta_e_sottrai)

    conta_e_sottrai = ContaESottrai(
        mapping={
            "VONT_ONLS_ESEG": ("KP04", 2),
            "ControlloDT": ("KP12", 1),
            "Antana_Asset_Prices": ("KP15", 1),
            "antana_hist_prices": ("KP15", 1),
            "Antana_Index_Prices": ("KP17", 1),
            "Antana_Yield_Curves": ("KP18", 0),
            "Antana_Mifid_Costs": ("KP19", 1),
            "Antana_Asset_Issuer": ("KP20", 1),
            "EstrazioneIbanAll": ("KP28", 1),
            "EstrazioneIbanPrincipale": ("KP29", 1),
        }
    )
    results_conta_e_sottrai = conta_e_sottrai(files_conta_e_sottrai)

    detect_antana = DetectDelivery(
        name="detect delivery antana",
        repo_label="sftp_vontobel",
        repo_path="flussi_antana/KPI/Elab/",
        source_label="sftp_vontobel",
        rule={
            r"KPIantana(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})\.csv",
        },
    )
    delivery_antana = detect_antana(feed_date=on_date)

    download_antana = DownloadRemoteFiles(name="download files antana", auth_label="sftp_vontobel")
    files_antana = download_antana(delivery_antana)

    read_antana = ReadCsv(
        name="read antana",
        fields=(
            "KP21",
            "KP22",
            "KP23",
            "KP24",
            "KP25",
            "KP16",
            "KP26",
        ),
        headless=True,
        skip_lines=1,
        options={"delimiter": ";"},
        encoding="cp1252",
    )
    results_antana = read_antana.map(files_antana["data"])

    report_data = aggrega_risultati(
        aggregati_cerca_csv["data"][0],
        aggregati_cerca_csv_1["data"][0],
        results_conta_e_sottrai["data"][0],
        results_antana[0]["data"][0],
        aggregati_fixed_width["data"][0],
        on_date,
    )

    write = WriteExcelTemplate(
        filename_meta=[
            "filename",
        ],
        mapping={
            "KP01": "B5",
            "KP02": "B6",
            "KP03": "B7",
            "KP04": "B8",
            "KP05": "B9",
            "KP06": "B10",
            "KP07": "B11",
            "KP08": "B12",
            "KP09": "B16",
            "KP10": "B17",
            "KP11": "B18",
            "KP12": "B22",
            "KP13": "B23",
            "KP14": "B24",
            "KP15": "B28",
            "KP16": "B29",
            "KP17": "B30",
            "KP18": "B31",
            "KP19": "B32",
            "KP20": "B33",
            "KP21": "B34",
            "KP22": "B35",
            "KP23": "B36",
            "KP24": "B37",
            "KP25": "B38",
            "KP26": "B39",
            "KP27": "B100",
            "KP28": "B43",
            "KP29": "B44",
            "KP30": "B48",
            "KP31": "B49",
            "KP32": "C48",
            "KP33": "C49",
        },
    )
    report_file = write(report_data, Path("/app/.assets/vontobel/template.xlsx"))

    upload = UploadFiles(auth_label="sftp_vontobel", dest_prefix="flussi_antana/KPI/Elab/Todo")
    upload(report_file)

if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1]})
