import sys
from typing import List

from prefect import Parameter, case, task
from prefect.tasks.templates import StringFormatter
from pymol.jobs import DeleteFile, DownloadRemoteFiles, Flow, ReadCsv, ReadExcel, SendMail, UploadFiles, shift_date
from pymol.types.jobs import DataRow, TaskData

from mikono.vontobel.jobs import getmailparams


@task
def check_condition(errors: List[str]) -> int:
    return len(errors) if errors else False


@task
def detectfiles(date: str, date1: str) -> TaskData:
    datainput = date.replace("-", "")
    datainput1 = date1.replace("-", "")
    data = {
        "data": [
            {"path": f"flussi_antana/KPI/Elab/Todo/Import/report_{date}.xlsx"},
            {"path": f"flussi_antana/KPI/Vontobel_ContrattiDossier_{datainput}_{datainput1}.csv"},
        ],
    }
    return data  # type: ignore


@task
def search_ko_xls(data: TaskData) -> bool:
    skip_header_rows = (0, 1, 2, 12, 21, 34, 35, 38, 39)
    for count, row in enumerate(data["data"]):
        if row["D"] is not None and row["D"] not in ("", " ") and count not in skip_header_rows:
            return True
    return False


@task
def search_ko_csv(data: TaskData) -> bool:
    for row in data["data"]:
        if row["Mismatch"] != "OK":
            return True
    return False


@task
def textresult(res_xls: bool, res_csv: bool) -> tuple[str, str]:
    if res_xls is True:
        KPIText = "KO da verificare."
    else:
        KPIText = "tutto OK."

    if res_csv is True:
        RicDossierText = "differenze da verificare."
    else:
        RicDossierText = "nulla da segnalare."

    return (KPIText, RicDossierText)


@task
def foobar_xls(data: DataRow) -> TaskData:
    """Usata per convertire il dato del file xlsx scaricato in locale da RataRow a TaskData."""
    return {"data": [data], "errors": [], "meta": {}}


@task
def foobar_xls_remote(date: str, remotepath: str) -> TaskData:
    """Mappo file remoto da cancellare."""
    path = f"{remotepath}/report_{date}.xlsx"
    return {"data": [{"path": path}], "errors": [], "meta": {}}


MSG = """
<p><font color="black" size="2" face="Arial">
Buongiorno,</font></p>
<p><font color="black" size="2" face="Arial">
in allegato i report relativi a KPI quotidiani e riconciliazione dei dossier.</font></p>
<ol><font color="black" size="2" face="Arial">
<li>KPI: <b>{_obj1}</b></br></br></li>
<li>Riconciliazione contratti dossier: <b>{_obj2}</b></li>
</font></ol>
"""

with Flow("Invio Report KPI Vontobel al cliente") as flow:
    on_date_ = Parameter("on_date", default="")
    past_days_ = Parameter("past_days", default="-2")

    on_date = shift_date(on_date_, past_days_, skip_weekends=True)
    on_date1 = shift_date(on_date_, "-1", skip_weekends=True)

    data = detectfiles(date=on_date, date1=on_date1)

    download = DownloadRemoteFiles(
        auth_label="sftp_vontobel",
    )
    dled_files = download(data)

    read_xls = ReadExcel(
        fields=("A", "B", "C", "D", "E"),
        sheet_name="report",
        data_start_row=0,
        headless=True,
    )
    data_xls = read_xls(dled_files["data"][0])

    read_csv = ReadCsv(
        fields=(
            "DataImportNormalizzata",
            "IsPrimoGiornoMese",
            "Mismatch",
            "CONTRATTO",
            "Dossiertitoli",
            "ambiente",
            "Stato",
            "DescrizioneStato",
            "FileImport",
            "JobDescription",
            "DataFlusso",
            "DataImport",
            "FlagAttivo",
            "NomePartner",
            "depositariaDossierTitoli",
            "depositariaFileImport",
            "DataFlussoNormalizzata",
        ),
        encoding="iso-8859-1",
        options={"delimiter": ";"},
    )
    data_csv = read_csv(dled_files["data"][1])

    xls_ko = search_ko_xls(data_xls)
    csv_ko = search_ko_csv(data_csv)
    _textresult = textresult(xls_ko, csv_ko)

    with case(data_csv["meta"]["isEmpty"], False):
        template = StringFormatter(name="message body", template=MSG)
        msg = template(_obj1=_textresult[0], _obj2=_textresult[1])

        mailparams = getmailparams(db="db_clc_w")

        subject_, from_, to_, cc_ = mailparams.run(query="SELECT * FROM rs.v_Mikono_Vontobel_KPI_DatiInvioMail")

        send = SendMail(conf="mail_server", subject_prefix=False)
        send(
            {
                "subject": subject_,
                "from": from_,
                "to": to_,
                "cc": cc_,
                "msg": msg,
                "attatchemts": dled_files["data"],
                "attachments": dled_files["data"],
            }
        )

        # non c'è la classe che sposta il file, quindi imposto workaround
        # che prima carica su cartella destinazione file scaricato in locale
        # e poi se l'upload è andato a buon fine, cancello il file da share remota
        file_locale = foobar_xls(dled_files["data"][0])
        upload = UploadFiles(
            auth_label="sftp_vontobel", dest_prefix="flussi_antana/KPI/Elab/Todo/Import/InviatiControparte"
        )
        uploaded = upload(file_locale)
        with case(uploaded["meta"]["isEmpty"], False):
            delete = DeleteFile(auth_label="sftp_vontobel")
            path = "flussi_antana/KPI/Elab/Todo/Import"
            file_delete = foobar_xls_remote(date=on_date, remotepath=path)
            deleted = delete(file_delete)

if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1]})
