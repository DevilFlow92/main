from datetime import date, timedelta
from pathlib import PosixPath
from typing import Any, Optional, Tuple

import pyodbc
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData


class LastFile(Task):
    """Cerca l'ultimo documento nella cartella e lo scarica in locale."""

    def __init__(
        self,
        sftp_label: str,
        path: str,
        startswith: str,
        nomatch: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: Optional[timedelta] = RETRY_DELAY,
        **kwargs: Any,
    ):
        self.sftp_label = sftp_label
        self.path = path
        self.startswith = startswith
        self.nomatch = nomatch
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self) -> Tuple[Any, str, TaskData]:
        with self.log.start_action(self.name):
            try:
                conn = ftp_conn(from_vault(self.sftp_label))
                conn.open_connection()
                elenco = conn.describe(PosixPath(self.path))
                if self.nomatch == "":
                    ultimo_file = sorted(
                        [(k, v.modify, v.key) for k, v in elenco.items() if k.startswith(self.startswith)],
                        key=lambda x: x[1],
                        reverse=True,
                    )[0]
                else:
                    ultimo_file = sorted(
                        [
                            (k, v.modify, v.key)
                            for k, v in elenco.items()
                            if k.startswith(self.startswith) and not k.startswith(self.nomatch)
                        ],
                        key=lambda x: x[1],
                        reverse=True,
                    )[0]

                local_path = conn.retrieve(
                    PosixPath(ultimo_file[2]), PosixPath(self.dirspace)
                )  # il 2 per tirar fuori v.key
                FileName = ultimo_file[0]
                output = {"path": PosixPath(local_path)}
                return {"path": str(local_path)}, FileName, {"data": [output], "errors": [], "meta": {}}

            except Exception as ex:
                self.logger.error(f"Errore su sftp_vontobel: {str(ex)}")
                local_path = PosixPath("")
                FileName = ""
                return (
                    {"path": str(local_path)},
                    FileName,
                    {"data": [], "errors": [{"error": "No File Found.", "source": {}}], "meta": {}},
                )


class DeleteFileSFTP(Task):
    """Cancella uno o più file da SFTP che rispettano una nomenclatura.

    Etichetta sftp e path, da passare nella classe, nome file da passare nella run.
    """

    def __init__(
        self,
        auth_label: str,
        path: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ):
        self.auth_label = auth_label
        self.path = path
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def run(self, FileName: str) -> None:  # , data: str
        with self.log.start_action(self.name):
            with ftp_conn(from_vault(self.auth_label)) as conn:
                try:
                    path = PosixPath(self.path, FileName)
                    conn.delete(path)
                except Exception as ex:
                    self.logger.warning(
                        f"""Non è stato possibile eliminare il file{FileName}
                    da {self.auth_label} {self.path}
                    {str(ex)}"""
                    )


class getmailparams(Task):
    """Restituisce i parametri per invio mail, data una vista sql."""

    def __init__(
        self,
        db: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ):
        self.db = db
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, query: str) -> tuple[str, str, Any, Any]:
        with self.log.start_action(self.name):
            try:
                self.open()
                self.cursor.execute(query)
                dati_ = self.cursor.fetchall()
                dati = []
                for r in dati_:
                    dati.append({x[0]: getattr(r, x[0]) for x in r.cursor_description})

                to_ = []
                cc_ = []
                for row in dati:
                    subject_ = row["subject"]
                    from_ = row["from"]
                    if row["Destinatario"] == "to":
                        to_.append(row["Mail"])
                    if row["Destinatario"] == "cc":
                        cc_.append(row["Mail"])
            except Exception as ex:
                self.logger.error(f"Errore inatteso: {str(ex)}")
                raise ex
            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                if self.dbconn:
                    self.dbconn.close()
                return subject_, from_, to_, cc_


class RiconciliazioniSaldi(Task):
    """[ToDo] Previa query di select Mikono-based per i saldi giornalieri, restituisce i risultati in TaskData.

    Accoglie in input i seguenti parametri:
    - db -> per autenticazione a db MOL
    - queryric -> query riconciliazione
    - ambiente -> etichetta ambiente per gestire dinamicamente il nomefile output
    """

    def __init__(
        self,
        db: str,
        queryric: str,
        ambiente: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.queryric_ = queryric
        self.ambiente_ = ambiente
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, DataImport_: str) -> TaskData:  # noqa
        errors = []
        DataImport = DataImport_.replace("-", "")
        with self.log.start_action(self.name):
            try:
                self.open()
                # mi procuro DataFlussoNormalizzata e IsPrimoGiornoMese per la creazione nome file
                self.cursor.execute(
                    """SELECT top 1
                    CASE WHEN CAST(MIN(InizioMezzaGiornata)
                    OVER (ORDER BY InizioMezzaGiornata) as DATE) = CAST(? AS DATE)
                    THEN 1 ELSE 0 END IsPrimoGiornoMese
                    FROM S_Calendario
                    WHERE CodCliente = 302
                    AND FlagLavorativo = 1
                    AND YEAR(InizioMezzaGiornata) = YEAR(?)
                    AND MONTH(InizioMezzaGiornata) = MONTH(?)""",
                    DataImport,
                    DataImport,
                    DataImport,
                )
                query = self.cursor.fetchone()

                # Campi per preparazione nome file
                IsPrimoGiornoMese = query.IsPrimoGiornoMese
                today = date.today().strftime("%Y%m%d")
                today = str(today)

                basecsv = self.ambiente_
                DataImportstr = str(DataImport)
                basename = f"Vontobel_{basecsv}_ControlloSaldiLiquid_{DataImportstr}_{today}.csv"
                if IsPrimoGiornoMese:
                    NomeCsv = f"FM_{basename}"
                else:
                    NomeCsv = basename

                querytext = self.queryric_
                self.cursor.execute(
                    querytext,
                    DataImport,
                )
                Lettura = self.cursor.fetchall()  # carico i dati

                Dizionario = []  # creo dizionario
                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Errore inatteso: {str(ex)}")
                self.dbconn.rollback()
                errors.append(f"Errore inatteso: {str(ex)}")
                raise ex

            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                self.dbconn.close()
                return {"data": Dizionario, "errors": errors, "meta": {"FileName": NomeCsv}}  # type: ignore


class RiconciliazioniPatrimoni(Task):
    """[ToDo] Data una query Mikono-based per i patrimoni, restituisce i risultati in TaskData.

    Accoglie in input i seguenti parametri:
    - db -> per autenticazione a db MOL
    - queryric -> query riconciliazione
    - ambiente -> etichetta ambiente per gestire dinamicamente il nomefile output
    """

    def __init__(
        self,
        db: str,
        query: str,
        nomefile: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.query_ = query
        self.nomefile_ = nomefile
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)

        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: str) -> TaskData:  # noqa
        errors = []
        Dizionario = []
        with self.log.start_action(self.name):
            try:  # prova
                self.open()
                NomeCsv_ = self.nomefile_
                DataImportNormalizzata = data
                # DataImportNormalizzata = "2022-05-12"

                DataImportNomeCSV = DataImportNormalizzata.replace("-", "")

                # estrarre il primo giorno del mese [inizio]
                q1 = """
SELECT top 1
CASE WHEN CAST(MIN(InizioMezzaGiornata) OVER (ORDER BY InizioMezzaGiornata) as DATE) = CAST(? AS DATE)
THEN 1
ELSE 0
END IsPrimoGiornoMese
FROM S_Calendario
WHERE CodCliente = 302
AND FlagLavorativo = 1
AND YEAR(InizioMezzaGiornata) = YEAR(?)
AND MONTH(InizioMezzaGiornata) = MONTH(?)
                """
                self.cursor.execute(
                    q1,
                    DataImportNormalizzata,
                    DataImportNormalizzata,
                    DataImportNormalizzata,
                )
                Lettura_DB = self.cursor.fetchone()
                IsPrimoGiornoMese = Lettura_DB.IsPrimoGiornoMese
                # estrarre il primo giorno del mese [fine]

                # today = date.today().strftime("%Y%m%d")
                # controllo se è il primo giorno del mese per modificare dinamicamente
                # il nome del file
                if IsPrimoGiornoMese:
                    NomeCsv = f"FM_CheckSaldiTotali_{DataImportNomeCSV}_{NomeCsv_}.csv"
                else:
                    NomeCsv = f"CheckSaldiTotali_{DataImportNomeCSV}_{NomeCsv_}.csv"

                # estrarre i dati [inizio]
                q2 = self.query_

                self.cursor.execute(
                    q2,
                    DataImportNormalizzata,
                )
                Lettura = self.cursor.fetchall()
                # estrarre i dati [fine]

                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere il DB: {str(ex)}")
                self.dbconn.rollback()

                errors.append(f"Presenti errori nel caricamento su SFTP antana: {str(ex)}")
                raise ex
            finally:
                self.dbconn.close()
                return {
                    "data": Dizionario,
                    "errors": errors,  # type: ignore
                    "meta": {"FileName": NomeCsv},
                }
