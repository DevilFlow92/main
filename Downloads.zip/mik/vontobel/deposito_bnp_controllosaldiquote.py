"""Vontobel deposito file liquidita riconciliazione."""

import sys
from datetime import date, datetime
from typing import Any

import pyodbc
from prefect import Parameter
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, UploadFiles, WriteCsv, shift_date
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData


class CaricaDati(Task):
    """Accoglie in input i seguenti parametri.

        - db -> per autenticazione a db MOL
        - queryric -> query riconciliazione (varia in base all'ambiente GPM/RON)
        - ambiente -> etichetta ambiente per gestire dinamicamente il nomefile output
    Restituisce risultati query in dizionario.
    """

    def __init__(
        self,
        db: str,
        queryric: str,
        ambiente: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        self.queryric_ = queryric
        self.ambiente_ = ambiente
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, DataImport_: str) -> TaskData:  # noqa

        DataImport = DataImport_.replace("-", "")

        with self.log.start_action(self.name):
            try:
                self.open()
                # mi procuro DataFlussoNormalizzata e IsPrimoGiornoMese per la creazione nome file
                self.cursor.execute(
                    """SELECT top 1
                    CASE WHEN CAST(MIN(InizioMezzaGiornata)
                    OVER (ORDER BY InizioMezzaGiornata) as DATE) = CAST(? AS DATE)
                    THEN 1 ELSE 0 END IsPrimoGiornoMese
                    FROM S_Calendario
                    WHERE CodCliente = 302
                    AND FlagLavorativo = 1
                    AND YEAR(InizioMezzaGiornata) = YEAR(?)
                    AND MONTH(InizioMezzaGiornata) = MONTH(?)""",
                    DataImport,
                    DataImport,
                    DataImport,
                )
                query = self.cursor.fetchone()

                # Campi per preparazione nome file
                IsPrimoGiornoMese = query.IsPrimoGiornoMese
                today = date.today().strftime("%Y%m%d")
                today = str(today)

                basecsv = self.ambiente_
                DataImportstr = str(DataImport)
                basename = f"Vontobel_{basecsv}_ControlloSaldiQuota_{DataImportstr}_{today}.csv"
                if IsPrimoGiornoMese:
                    NomeCsv = f"FM_{basename}"
                else:
                    NomeCsv = basename

                querytext = self.queryric_
                self.cursor.execute(
                    querytext,
                    DataImport,
                )
                Lettura = self.cursor.fetchall()  # carico i dati

                Dizionario = []  # creo dizionario
                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

                return {"data": Dizionario, "errors": [], "meta": {"FileName": NomeCsv}}

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Errore inatteso: {str(ex)}")
                self.dbconn.rollback()
                raise ex

            finally:  # qualsiasi cosa succeda alla fine vogliamo chiudere la connessione
                if self.dbconn:
                    self.dbconn.close()


with Flow("Deposito_BNP_ControlloSaldiQuote") as flow:

    feed_date_ = Parameter("feed_date", default="")
    date_ = shift_date(feed_date_, 0, skip_weekends=True)

    # date_ = "2022-09-21"

    qGPM = """SELECT DataImportNormalizzata
                    ,DataFlussoNormalizzata
                    ,TipologiaMismatchFile
                    ,BancaMismatch
                    ,Banca
                    ,depositarieBanca
                    ,CheckQuantitaAntanaDepositarie
                    ,Account
                    ,Dossier_titoli
                    ,depositarieDossier_titoli
                    ,Isin
                    ,depositarieIsin
                    ,Descr_titolo
                ,CASE WHEN QuantitaAntanaDepositarie = 0
                    then '0'
                    else REPLACE(FORMAT(QuantitaAntanaDepositarie, '####.####'), '.', ',')
                end QuantitaAntanaDepositarie
                ,NoteOperatore
                ,case when Quantita = 0
                    then '0'
                    else replace(FORMAT(Quantita, '####.####'), '.', ',')
                end Quantita
                ,case when depositarieQuantita = 0
                    then '0'
                    else replace(FORMAT(depositarieQuantita, '####.####'), '.', ',')
                end depositarieQuantita
                ,case when Prezzo = 0
                    then '0'
                    else replace(FORMAT(Prezzo,'####.####'), '.', ',')
                end Prezzo
                ,case when depositariePrezzo = 0
                    then '0'
                    else replace(FORMAT(depositariePrezzo,'####.####'), '.', ',')
                end depositariePrezzo
                ,Divisa
                ,depositarieDivisa
                ,case when Cambio = 0
                    then '0'
                    else REPLACE(FORMAT(Cambio, '####.####'), '.', ',')
                END Cambio
                ,CASE WHEN depositarieCambio = 0
                    then '0'
                    else REPLACE(format(depositarieCambio, '####.####'), '.', ',')
                end depositarieCambio
                    ,dataFlusso
                    ,depositarieDataFlusso
                    ,FileImport
                    ,depositarieFileImport
                    ,IsPrimoGiornoMese
                    FROM rs.v_Mikono_Vontobel_GPM_BNP_SaldiQuote_pycc
                    WHERE DataImportNormalizzata = ?
                    ORDER BY ABS(QuantitaAntanaDepositarie) DESC"""

    qRON = """SELECT DataImportNormalizzata
                ,DataFlussoNormalizzata
                ,TipologiaMismatchFile
                ,BancaMismatch
                ,Banca
                ,depositarieBanca
                ,CheckQuantitaAntanaDepositarie
                ,Account
                ,Dossier_titoli
                ,depositarieDossier_titoli
                ,Isin
                ,depositarieIsin
                ,Descr_titolo
                ,CASE WHEN QuantitaAntanaDepositarie = 0
                    then '0'
                    else REPLACE(FORMAT(QuantitaAntanaDepositarie, '####.####'), '.', ',')
                end QuantitaAntanaDepositarie
                ,NoteOperatore
                ,case when Quantita = 0
                    then '0'
                    else replace(FORMAT(Quantita, '####.####'), '.', ',')
                end Quantita
                ,case when depositarieQuantita = 0
                    then '0'
                    else replace(FORMAT(depositarieQuantita, '####.####'), '.', ',')
                end depositarieQuantita
                ,case when Prezzo = 0
                    then '0'
                    else replace(FORMAT(Prezzo,'####.####'), '.', ',')
                end Prezzo
                ,case when depositariePrezzo = 0
                    then '0'
                    else replace(FORMAT(depositariePrezzo,'####.####'), '.', ',')
                end depositariePrezzo
                ,Divisa
                ,depositarieDivisa
                ,case when Cambio = 0
                    then '0'
                    else REPLACE(FORMAT(Cambio, '####.####'), '.', ',')
                END Cambio
                ,CASE WHEN depositarieCambio = 0
                    then '0'
                    else REPLACE(format(depositarieCambio, '####.####'), '.', ',')
                end depositarieCambio
                ,dataFlusso
                ,depositarieDataFlusso
                ,FileImport
                ,depositarieFileImport
                ,IsPrimoGiornoMese
                FROM  rs.v_Mikono_Vontobel_RON_BNP_SaldiQuote_pycc
                WHERE DataImportNormalizzata = ?
                ORDER BY ABS(QuantitaAntanaDepositarie) DESC"""

    FileLocaleGPM = CaricaDati(
        name="Carica dati riconciliazione GPM Quote BNP", db="db_clc_w", queryric=qGPM, ambiente="GPM_BNP"
    )

    FileLocaleRON = CaricaDati(
        name="Carica dati riconciliazione RON Quote BNP", db="db_clc_w", queryric=qRON, ambiente="RON_BNP"
    )

    DatiDaScrivereGPM = FileLocaleGPM(date_)
    DatiDaScrivereRON = FileLocaleRON(date_)

    write = WriteCsv(
        filename_meta=["FileName"],
        fields=[
            "DataImportNormalizzata",
            "DataFlussoNormalizzata",
            "TipologiaMismatchFile",
            "BancaMismatch",
            "Banca",
            "depositarieBanca",
            "CheckQuantitaAntanaDepositarie",
            "Account",
            "Dossier_titoli",
            "depositarieDossier_titoli",
            "Isin",
            "depositarieIsin",
            "Descr_titolo",
            "QuantitaAntanaDepositarie",
            "NoteOperatore",
            "Quantita",
            "depositarieQuantita",
            "Prezzo",
            "depositariePrezzo",
            "Divisa",
            "depositarieDivisa",
            "Cambio",
            "depositarieCambio",
            "dataFlusso",
            "depositarieDataFlusso",
            "FileImport",
            "depositarieFileImport",
            "IsPrimoGiornoMese",
        ],
        options={"delimiter": ";"},
    )
    written_filesGPM = write(DatiDaScrivereGPM)
    written_filesRON = write(DatiDaScrivereRON)

    upload = UploadFiles(
        auth_label="sftp_vontobel",
        dest_prefix="flussi_antana/Lavorazione_backoffice/Check_SaldiQuota",
    )
    upload(written_filesGPM)
    upload(written_filesRON)

if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        date_ = datetime.strptime(sys.argv[1], "%Y-%m-%d")  # type: ignore
        flow.run(parameters={"feed_date": date_.strftime("%Y-%m-%d")})  # type: ignore
