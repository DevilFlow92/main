"""Vontobel deposito file riconciliazione."""
import sys
from typing import Any

import pyodbc
from prefect import Parameter
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, UploadFiles, WriteCsv, shift_date
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import TaskData

"Classe Caricamento dati da db"


class CaricaDati(Task):
    """Richiama dati da db per scriverli in un csv da trasferire in sftp."""

    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)

        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, data: str) -> TaskData:  # noqa
        Dizionario = []
        with self.log.start_action(self.name):
            try:  # prova
                self.open()
                DataImportNormalizzata = data

                DataImportNomeCSV = DataImportNormalizzata.replace("-", "")

                # estrarre il primo giorno del mese [inizio]
                q1 = """
SELECT top 1
CASE WHEN CAST(MIN(InizioMezzaGiornata) OVER (ORDER BY InizioMezzaGiornata) as DATE) = CAST(? AS DATE)
THEN 1
ELSE 0
END IsPrimoGiornoMese
FROM S_Calendario
WHERE CodCliente = 302
AND FlagLavorativo = 1
AND YEAR(InizioMezzaGiornata) = YEAR(?)
AND MONTH(InizioMezzaGiornata) = MONTH(?)
                """
                self.cursor.execute(
                    q1,
                    DataImportNormalizzata,
                    DataImportNormalizzata,
                    DataImportNormalizzata,
                )
                Lettura_DB = self.cursor.fetchone()
                IsPrimoGiornoMese = Lettura_DB.IsPrimoGiornoMese
                # estrarre il primo giorno del mese [fine]

                # today = date.today().strftime("%Y%m%d")
                # controllo se è il primo giorno del mese per modificare dinamicamente
                # il nome del file
                if IsPrimoGiornoMese:
                    NomeCsv = f"FM_CheckSaldiTotali_{DataImportNomeCSV}_ValoriTotali.csv"
                else:
                    NomeCsv = f"CheckSaldiTotali_{DataImportNomeCSV}_ValoriTotali.csv"

                # estrarre i dati [inizio]
                q2 = """
SELECT FORMAT(DataImportNormalizzata, 'yyyyMMdd') DataImportNormalizzata
,Famiglia
,[DOSSIER BANCA]
,Banca
,CASE WHEN [VALORE ANTANA] = 0
    THEN '0'
    ELSE REPLACE(FORMAT([VALORE ANTANA], '####.####'),'.',',')
END [VALORE ANTANA]
,CASE WHEN [VALORE DEPOSITARIA] = 0
    THEN '0'
    ELSE replace(FORMAT([VALORE DEPOSITARIA], '####.####'),'.',',')
END [VALORE DEPOSITARIA]
,CASE WHEN [DIFF.] = 0
    THEN '0'
    ELSE REPLACE(FORMAT([DIFF.], '####.####'),'.',',')
END [DIFF.]
,REPLACE(SCOSTAMENTO,'.',',') SCOSTAMENTO
,RISULTATO
,NULL [Note]
,NULL [Soglia 5%]
FROM rs.v_Mikono_Vontobel_OLSRON_SaldiTotali_pycc
WHERE DataImportNormalizzata = ?
ORDER BY ABS_Scostamento DESC
                """
                self.cursor.execute(
                    q2,
                    DataImportNormalizzata,
                )
                Lettura = self.cursor.fetchall()
                # estrarre i dati [fine]

                for row in Lettura:
                    Dizionario.append({x[0]: getattr(row, x[0]) for x in row.cursor_description})

                return {"data": Dizionario, "errors": [], "meta": {"FileName": NomeCsv}}

            except Exception as ex:  # in caso di eccezione vogliamo sicuramente fare rollback
                self.logger.error(f"Impossibile leggere il DB: {str(ex)}")
                self.dbconn.rollback()
                raise ex
            finally:
                if self.dbconn:
                    self.dbconn.close()


with Flow("OLSRON_DepositoCsv_ValoriAggregati") as flow:
    on_date_ = Parameter("on_date", default="")
    shift_days_ = Parameter("shift_days", default="0")
    date_ = shift_date(on_date_, shift_days_, skip_weekends=True)

    FileLocale = CaricaDati(name="Carica Dati Valori Aggregati", db="db_clc_w")
    DatiDaScrivere = FileLocale(data=date_)

    write = WriteCsv(
        name="Scrivi csv con i dati valori aggregati",
        filename_meta=["FileName"],
        fields=[
            "DataImportNormalizzata",
            "Famiglia",
            "DOSSIER BANCA",
            "Banca",
            "VALORE ANTANA",
            "VALORE DEPOSITARIA",
            "DIFF.",
            "SCOSTAMENTO",
            "RISULTATO",
            "NOTE",
            "Soglia 5%",
        ],
        options={"delimiter": ";"},
    )
    written_files = write(DatiDaScrivere)
    upload = UploadFiles(
        name="Trasferisci file su sftp",
        auth_label="sftp_vontobel",
        dest_prefix="flussi_antana/Lavorazione_backoffice/Check_SaldiTotali",
    )
    upload(written_files)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1]})
