"""Pull file Azimut."""
from prefect import Parameter
from pymol.jobs import DiscardedAlertPolicy, Flow, PullStream

with Flow("pull files") as flow:
    source_label_ = Parameter("source_label", default=None)
    source_path_ = Parameter("source_path", default=None)
    whitelist_ = Parameter("whitelist", default=None)

    pull = PullStream(
        name="Pull ImportAnagrafiche Azimut",
        source_label="source_azimut",
        source_path={
            "",
        },
        whitelist={
            r"Anagr_Azimut_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_0915\.csv",
        },
        ignorelist={"log", "Elab"},
        dest_label="share_azimut",
        dest_path="CESAM/Azimut/ImportAnagraficaAzimut",
        timeout=60 * 15,
        discarded_alert_policy=DiscardedAlertPolicy.SIZE,
    )

    pull(
        source_label_override=source_label_,
        source_path_override=source_path_,
        whitelist_override=whitelist_,
    )

if __name__ == "__main__":
    flow.run()
