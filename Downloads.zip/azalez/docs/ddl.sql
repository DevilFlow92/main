-- CLC_Cesam.scratch.L_CESAM_AZ_ImportAnagrafica_Azimut definition

-- Drop table

-- DROP TABLE CLC_Cesam.scratch.L_CESAM_AZ_ImportAnagrafica_Azimut;

CREATE TABLE CLC_Cesam.scratch.L_CESAM_AZ_ImportAnagrafica_Azimut (
	id int IDENTITY(1,1) NOT NULL,
	msg_state char(4) COLLATE Latin1_General_CI_AS DEFAULT 'UNP' NULL,
	meta_id int NULL,
	msg_type varchar(4) COLLATE Latin1_General_CI_AS NULL,
	routing_state varchar(256) COLLATE Latin1_General_CI_AS NULL,
	cliente varchar(20) COLLATE Latin1_General_CI_AS NULL,
	desc_cliente varchar(200) COLLATE Latin1_General_CI_AS NULL,
	cod_natgiu smallint NULL,
	natura_giuridica varchar(200) COLLATE Latin1_General_CI_AS NULL,
	codice_fiscale varchar(20) COLLATE Latin1_General_CI_AS NULL,
	partita_iva varchar(100) COLLATE Latin1_General_CI_AS NULL,
	agenzia varchar(50) COLLATE Latin1_General_CI_AS NULL,
	desc_agenzia varchar(200) COLLATE Latin1_General_CI_AS NULL,
	agente varchar(10) COLLATE Latin1_General_CI_AS NULL,
	desc_agente varchar(200) COLLATE Latin1_General_CI_AS NULL,
	dt_inserimento varchar(50) COLLATE Latin1_General_CI_AS NULL,
	DataImport datetime NULL,
	CONSTRAINT PK_L_CESAM_AZ_ImportAnagrafica_Azimut_IdImport PRIMARY KEY (id)
);