# from pymol.jobs.core import FieldRule, RuleDict  # da modificare al prossimo deploy del jobs

from pymol.jobs.evtl.load.feeds.schema import FieldRule, RuleDict
from pymol.validation import Coerce, Schema, to_date, to_int, to_stripped_string

SCHEMA = Schema(
    {
        "IdPersona": Coerce(
            to_stripped_string(),
            nones=[""],
        ),
        "CodTipoPersona": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "CodiceFiscale": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "ChiaveClienteImport": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "CodiceFiscaleImport": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "PartitaIva": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "PartitaIVAImport": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "desc_cliente": Coerce(
            to_stripped_string(),
            nones=[
                "",
            ],
        ),
        "dt_inserimento": Coerce(
            to_date(["%d/%m/%Y", "%d-%m-%Y"]),
            nones=[
                "",
            ],
        ),
    }
)

RULES: RuleDict = {
    r"Anagr_Azimut_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_0915\.csv": {
        "-": {
            "cliente": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "desc_cliente": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "cod_natgiu": FieldRule(
                Coerce(
                    to_int(),
                    nones=[
                        "",
                    ],
                )
            ),
            "natura_giuridica": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "codice_fiscale": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "partita_iva": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "agenzia": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "desc_agenzia": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "agente": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "desc_agente": FieldRule(
                Coerce(
                    to_stripped_string(),
                    nones=[
                        "",
                    ],
                )
            ),
            "dt_inserimento": FieldRule(
                Coerce(
                    to_date(["%d/%m/%Y"]),
                    nones=[
                        "",
                    ],
                )
            ),
        }
    }
}
