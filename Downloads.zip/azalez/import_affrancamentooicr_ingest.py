"""."""
import sys
from datetime import datetime
from pathlib import PosixPath
from typing import Any, Optional, Set, cast

import pyodbc
from prefect import Parameter, case, context, task
from prefect.tasks.templates import JinjaTemplate
from pymol.ext.auth import from_vault
from pymol.ext.ftp import ftp_conn
from pymol.jobs import (
    DetectDelivery,
    DownloadRemoteFiles,
    Flow,
    IngestFeed,
    PullStream,
    ReadCsv,
    ReadDB,
    SendMail,
    ValidateData,
    shift_date,
    start_flow_run,
)
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import DataRow, ErrorRow, TaskData
from pymol.validation import Coerce, Schema, to_date, to_datetime, to_stripped_string
from pyodbc import OperationalError

MAIL_FROM = "noreply_pycc@gruppomol.it"
MAIL_TO = ["ReportDpeCesam@gruppomol.it"]
SUBJECT = "Errore Flusso Affrancamento_AZfund_ingest"

SCHEMA = {
    "CCLIE": Coerce(to_stripped_string()),
    "VAGNT": Coerce(to_stripped_string()),
    "CSOCPR": Coerce(to_stripped_string()),
    "CGPROD": Coerce(to_stripped_string()),
    "CSPROD": Coerce(to_stripped_string()),
    "VMESTN": Coerce(to_stripped_string()),
    "ISIN": Coerce(to_stripped_string()),
    "CVIN": Coerce(to_stripped_string()),
    "VQUOTE_FINEANNO": Coerce(to_stripped_string()),
    "CMP_FINEANNO": Coerce(to_stripped_string()),
    "IUNQT_E_FINEANNO": Coerce(to_stripped_string()),
    "FINEANNO": Coerce(
        to_date(["%Y%m%d"]),
        nones=[""],
    ),
    "VQUOTE_ATT": Coerce(to_stripped_string()),
    "CMP_ATT": Coerce(to_stripped_string()),
    "IUNQT_E_ATT": Coerce(to_stripped_string()),
    "VQUOTE_AFF": Coerce(to_stripped_string()),
    "IMP_E_AFF": Coerce(to_stripped_string()),
    "CMP_POST_AFF": Coerce(to_stripped_string()),
    "CDOSS": Coerce(to_stripped_string()),
    "CCLIE_1": Coerce(to_stripped_string()),
    "CPOS_1": Coerce(to_stripped_string()),
    "XCCLIE_1": Coerce(to_stripped_string()),
    "CCLIE_2": Coerce(to_stripped_string()),
    "CPOS_2": Coerce(to_stripped_string()),
    "XCCLIE_2": Coerce(to_stripped_string()),
    "CCLIE_3": Coerce(to_stripped_string()),
    "CPOS_3": Coerce(to_stripped_string()),
    "XCCLIE_3": Coerce(to_stripped_string()),
    "CCLIE_4": Coerce(to_stripped_string()),
    "CPOS_4": Coerce(to_stripped_string()),
    "XCCLIE_4": Coerce(to_stripped_string()),
    "CUSER": Coerce(to_stripped_string()),
    "DINS": Coerce(
        to_date(["%Y%m%d"]),
        nones=[""],
    ),
    "TMS": Coerce(
        to_datetime(["%Y%m%d %H:%M:%S.%f", "%Y%m%d %H:%M:%S"]),
        nones=[""],
    ),
    "DTCON": Coerce(
        to_date(["%Y%m%d"]),
        nones=[""],
    ),
}


SCHEMA_VISTA = Schema(
    {
        "IdIncarico": Coerce(int),
        "CodiceCliente": Coerce(to_stripped_string()),
        "NumeroMandato": Coerce(to_stripped_string()),
        "IdPromotore": Coerce(int),
        "TipologiaLavorazione": Coerce(to_stripped_string()),
        "Isin": Coerce(to_stripped_string()),
        "Imposta": Coerce(to_stripped_string()),
        "DirittoFisso": Coerce(to_stripped_string()),
        "CodiceFend": Coerce(to_stripped_string()),
    }
)

QUERY_VISTA = """
SELECT * FROM rs.v_CESAM_AZ_TransferAgent_ProvvistaAffrancamento
"""


class ReadDBWait(ReadDB):
    def run(self, params: tuple[Any, ...], wait: Any) -> TaskData:  # type: ignore
        output, errors = [], []
        with self.log.start_action(self.name), self.log.timed(self.name):
            self.open()
            self.cursor.execute(self.query, *params)
            for row in self.cursor.fetchall():
                outrow = {}
                for k in self.schema.schema.keys():
                    outrow[k] = getattr(row, k)
                is_valid, result = self._validate(outrow)
                if is_valid:
                    output.append(cast(DataRow, result))
                else:
                    errors.append(cast(ErrorRow, result))
            self.close()
            return {
                "data": output,
                "errors": errors,
                "meta": {
                    "query": self.query,
                    "scheduled_date": context.scheduled_start_time.date().isoformat(),
                    "isEmpty": len(output) == 0,
                    "hasErrors": len(errors) > 0,
                },
            }


def extract_filename(key: str) -> Any:
    return PosixPath(key).name.split("@")[0]


class DetectDeliveryWait(DetectDelivery):
    def run(self, feed_date: str, wait: Any, rule_override: Optional[Set[str]] = None) -> TaskData:  # type: ignore
        output = []
        with self.log.start_action(self.name), self.log.timed(self.name):
            _date = datetime.strptime(feed_date, "%Y-%m-%d")

            if rule_override:
                self.rule = rule_override

            repo_conf = from_vault(self.repo_label)
            with ftp_conn(repo_conf) as conn:
                files = conn.describe(PosixPath(self.repo_path, self.source_label, _date.strftime("%Y/%m/%d")))
                for _, m in files.items():
                    filename = extract_filename(m.key)
                    if self.follows_rule(filename=filename, rule=self.rule):
                        output.append({"path": m.key})

            if not output:
                return cast(TaskData, dict(data=[], errors=[], meta={"isEmpty": True}))
            elif self.follows_rule_strategy(output):
                return cast(TaskData, dict(data=output, errors=[], meta={"isEmpty": False}))
            else:
                meta = {
                    "isEmpty": True,
                    "hasErrors": True,
                }
                errors = [
                    {"error": f'File {d["path"]} does not match rule {self.rule_strategy}', "source": d} for d in output
                ]
                return cast(TaskData, dict(data=[], errors=errors, meta=meta))


@task
def filename_dinamico(data: TaskData) -> str:
    """Simula un nome file di ingest per la tabella E_Meta."""
    if data:
        source_path = str(data["meta"]["source_path"]).replace("Affrancamento", "Affrancamento_VISTA")
        return source_path
    else:
        return ""


class IngestFeedBack(IngestFeed):
    """Con questa versione viene dato un feedback in ["meta"]["ingested"] sull'effettivo ingest."""

    # Aggiungo il campo meta 'ingest' per dare feedback su ingest effettivo
    def run(  # type: ignore[override]
        self, data: TaskData, source_path: str | None = None, overwrite: bool | None = None
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            task_meta = data["meta"].copy()
            task_meta["overridden_source_path"] = source_path
            source_path_, pull_ts = self._source_path_and_ts(data, source_path)
            self.overwrite = overwrite if overwrite is not None else self.overwrite
            try:
                self.open()
                meta_id, is_ingested = self.log_meta(
                    source_path_,
                    pull_ts,
                    len(data["errors"]),
                    data["meta"]["sheet"] if "sheet" in data["meta"] else "-",
                )
                if not is_ingested or (is_ingested and self.overwrite):
                    ld = len(data["data"])
                    for count, msg_ in enumerate(data["data"]):
                        if count % 1000 == 0:
                            self.logger.info(f"CHECK - {ld-count} messaggi alla fine dell'ingest")
                        self.write_row(msg_, source_path_, task_meta, is_ingested, meta_id)
                    for invalid_msg in data["errors"]:
                        self.write_error(meta_id, str(invalid_msg["source"]), invalid_msg["error"], None)
                    self.set_ingested(meta_id, data["meta"]["sheet"] if "sheet" in data["meta"] else "-")
                    if data["data"]:
                        data["meta"]["ingested"] = True
                    else:
                        data["meta"]["ingested"] = False
                else:
                    self.logger.info(f"Skippo file già salvato: {source_path_}")
                    data["meta"]["ingested"] = False
                self.dbconn.commit()
                return data
            except OperationalError as exc:
                self.logger.warning(f"Impossibile connettersi al database '{self.db}': {exc}")
                raise exc
            except Exception as exc:
                self.dbconn.rollback()
                self.logger.error(f"Errore inatteso {exc.__class__} : {exc}. Processando il file (meta id): {meta_id}")
                raise exc
            finally:
                self.close()


class Ingest(IngestFeedBack):
    def get_msgvalues(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> tuple[str, DataRow]:
        return "scratch.L_CESAM_Import_Affrancamento_ProvvistaAzFund", msg


class Ingest_Vista(IngestFeedBack):
    def get_msgvalues(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> tuple[str, DataRow]:
        output = {
            "msg_state": "UNP",
            "msg_state_2": "UNP",
        }
        msg.update(output)
        return "scratch.VISTA_L_CESAM_Import_Affrancamento_ProvvistaAzFund", msg


@task
def Trued(wait: Any) -> bool:
    return True


class CheckForUNPState(Task):
    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def openDB(self, db: str | None = None) -> None:  # noqa
        if db is None:
            db = self.db
        auth_db = from_vault(db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def closeDB(self) -> None:  # noqa
        if self.dbconn:
            self.dbconn.close()

    def run(self) -> bool:
        with self.log.start_action(self.name):
            self.openDB()
            errors = []
            try:
                query = """
                SELECT * FROM  scratch.VISTA_L_CESAM_Import_Affrancamento_ProvvistaAzFund
                WHERE msg_state <> 'PRC' OR msg_state_2 <> 'PRC'
                """
                self.cursor.execute(query)
            except Exception as exc:
                self.cursor.rollback()
                errors.append(exc)
                self.logger.warning(exc)
                raise BusinessValueError(
                    f"""ATTENZIONE->
                Durante l'esecuzione del Task {self.name} si è verificata la seguente eccezione:
                Non è stato possibile leggere se ci siano righe con msg_state = 'UNP' in tabella.
                Eccezione-> {exc}"""
                )
            else:
                rr = self.cursor.fetchall()
                if rr:
                    template = f"""
                    <p>Buongiorno,</br></br>
                    Attenzione, ci sono {len(rr)} righe della tabella in stato diverso da 'PRC'.</br>
                    Si consiglia di verificare prima di lanciare nuove esecuzioni.</br></br>

                    Buon lavoro, </br>
                    Team DPE TECH
                    </p>"""
                    testo_mail_errors = JinjaTemplate(template=template).run()
                    SendMail(conf="mail_server").run(
                        {
                            "from": MAIL_FROM,
                            "to": MAIL_TO,
                            "cc": [],
                            "subject": SUBJECT,
                            "msg": testo_mail_errors,
                        }
                    )
                    return False
                else:
                    return True

            finally:
                if self.dbconn:
                    self.closeDB()


with Flow("Affrancamento_AZfund_ingest") as flow:
    feed_date_ = Parameter("feed_date", default="")
    date_ = shift_date(feed_date_, "", skip_weekends=True)

    cfu = CheckForUNPState(db="db_clc")
    cfued = cfu()

    with case(cfued, True):

        pull = PullStream(
            source_label="share",
            source_path={"CESAM/Azimut/Affrancamento"},
            whitelist={
                r"^(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{6}_Affrancamento\.csv$",
            },
            dest_label="share",
            dest_path="CESAM/Azimut/Affrancamento",
        )
        pulled = pull()

        detect = DetectDeliveryWait(
            repo_label="share",
            repo_path="CESAM/Azimut/Affrancamento",
            source_label="share",
            rule={
                r"^(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_\d{6}_Affrancamento\.csv$",
            },
        )
        detected = detect(feed_date=date_, wait=pulled)

        with case(detected["meta"]["isEmpty"], False):

            download = DownloadRemoteFiles(auth_label="share")
            downloaded = download(detected)

            read = ReadCsv(
                fields=SCHEMA.keys(),  # type: ignore
                options={"delimiter": ";"},
                encoding="cp1252",
            )
            readed = read(downloaded["data"][0])

            validate = ValidateData(schema=Schema(SCHEMA))
            validated = validate(readed)

            ingest = Ingest(
                db="db_clc",
                provider="",
                feed="",
            )
            ingested = ingest(validated)

            read_vista = ReadDBWait(
                name="ReadVISTA",
                db="db_clc",
                schema=SCHEMA_VISTA,
                query=QUERY_VISTA,
            )
            readed_vista = read_vista(params=(), wait=ingested)

            with case(bool(readed_vista["data"]), True):
                source_path = filename_dinamico(validated)

                ingest_vista = Ingest_Vista(
                    db="db_clc",
                    provider="",
                    feed="",
                )
                ingested_vista = ingest_vista(data=readed_vista, source_path=source_path)

                with case(Trued(wait=ingested_vista), True):
                    start_flow_run(flow_name="Affrancamento_AZfund_process", project_name="azimut")


if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        res = flow.run(parameters={"feed_date": sys.argv[1]})
