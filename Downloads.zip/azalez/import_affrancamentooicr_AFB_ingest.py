"""."""
from datetime import datetime
from typing import Any

import pyodbc
from prefect import case, task
from prefect.tasks.templates import JinjaTemplate
from pymol.ext.auth import from_vault
from pymol.jobs import Flow, IngestFeed, ReadDB, SendMail, start_flow_run
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.exceptions import BusinessValueError
from pymol.types.jobs import DataRow, TaskData
from pymol.validation import Coerce, Schema, to_stripped_string
from pyodbc import OperationalError

MAIL_FROM = "noreply_pycc@gruppomol.it"
MAIL_TO = ["ReportDpeCesam@gruppomol.it"]
SUBJECT = "Errore Flusso Affrancamento_AZfund_ingest"


SCHEMA_VISTA = Schema(
    {
        "IdIncarico": Coerce(int),
        "CodiceCliente": Coerce(to_stripped_string()),
        "NumeroMandato": Coerce(to_stripped_string()),
        # "IdPromotore": Coerce(int),
        "TipologiaLavorazione": Coerce(to_stripped_string()),
        "Isin": Coerce(to_stripped_string()),
        "Imposta": Coerce(to_stripped_string()),
        "DirittoFisso": Coerce(to_stripped_string()),
    }
)

QUERY_VISTA = """
SELECT * FROM rs.v_CESAM_AZ_AFB_ProvvistaAffrancamento
"""


# L'ingest non verrà così skippata se si rifà l'ingest
@task
def fake_filename_dinamico() -> str:
    """Simula un nome file di ingest per la tabella E_Meta."""
    # tt = prefect.context.scheduled_start_time.time().strftime("%H-%M")
    # tt = datetime.now().strftime("%Y-%m-%dT%H:%M:%S+00:00")
    timestamp_file = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamp_ = datetime.now().strftime("%Y-%m-%dT%H-%M-%S+00-00")
    timestamp_directory = datetime.now().strftime("%Y/%m/%d")
    output = f"/{timestamp_directory}/nofile_vista_affrancamento_AFB_{timestamp_file}@{timestamp_}"
    return output


class IngestFeedBack(IngestFeed):
    """Con questa versione viene dato un feedback in ["meta"]["ingested"] sull'effettivo ingest."""

    # Aggiungo il campo meta 'ingest' per dare feedback su ingest effettivo
    def run(  # type: ignore[override]
        self, data: TaskData, source_path: str | None = None, overwrite: bool | None = None
    ) -> TaskData:
        with self.log.start_action(self.name), self.log.timed(self.name):
            task_meta = data["meta"].copy()
            task_meta["overridden_source_path"] = source_path
            source_path_, pull_ts = self._source_path_and_ts(data, source_path)
            self.overwrite = overwrite if overwrite is not None else self.overwrite
            try:
                self.open()
                meta_id, is_ingested = self.log_meta(
                    source_path_,
                    pull_ts,
                    len(data["errors"]),
                    data["meta"]["sheet"] if "sheet" in data["meta"] else "-",
                )
                if not is_ingested or (is_ingested and self.overwrite):
                    ld = len(data["data"])
                    for count, msg_ in enumerate(data["data"]):
                        if count % 1000 == 0:
                            self.logger.info(f"CHECK - {ld-count} messaggi alla fine dell'ingest")
                        self.write_row(msg_, source_path_, task_meta, is_ingested, meta_id)
                    for invalid_msg in data["errors"]:
                        self.write_error(meta_id, str(invalid_msg["source"]), invalid_msg["error"], None)
                    self.set_ingested(meta_id, data["meta"]["sheet"] if "sheet" in data["meta"] else "-")
                    if data["data"]:
                        data["meta"]["ingested"] = True
                    else:
                        data["meta"]["ingested"] = False
                else:
                    self.logger.info(f"Skippo file già salvato: {source_path_}")
                    data["meta"]["ingested"] = False
                self.dbconn.commit()
                return data
            except OperationalError as exc:
                self.logger.warning(f"Impossibile connettersi al database '{self.db}': {exc}")
                raise exc
            except Exception as exc:
                self.dbconn.rollback()
                self.logger.error(f"Errore inatteso {exc.__class__} : {exc}. Processando il file (meta id): {meta_id}")
                raise exc
            finally:
                self.close()


class Ingest(IngestFeedBack):
    def get_msgvalues(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> tuple[str, DataRow]:
        return "scratch.L_CESAM_Import_Affrancamento_ProvvistaAzFund", msg


class Ingest_Vista(IngestFeedBack):
    def get_msgvalues(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> tuple[str, DataRow]:
        output = {
            "msg_state": "UNP",
            "msg_state_2": "UNP",
        }
        msg.update(output)
        return "scratch.VISTA_L_CESAM_Import_Affrancamento_ProvvistaAFB", msg


@task
def Trued(wait: Any) -> bool:
    return True


class CheckForUNPState(Task):
    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def openDB(self, db: str | None = None) -> None:  # noqa
        if db is None:
            db = self.db
        auth_db = from_vault(db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def closeDB(self) -> None:  # noqa
        if self.dbconn:
            self.dbconn.close()

    def run(self) -> bool:
        with self.log.start_action(self.name):
            self.openDB()
            errors = []
            try:
                query = """
                SELECT * FROM scratch.VISTA_L_CESAM_Import_Affrancamento_ProvvistaAFB
                WHERE msg_state <> 'PRC' OR msg_state_2 <> 'PRC'
                """
                self.cursor.execute(query)
            except Exception as exc:
                self.cursor.rollback()
                errors.append(exc)
                self.logger.warning(exc)
                raise BusinessValueError(
                    f"""ATTENZIONE->
                Durante l'esecuzione del Task {self.name} si è verificata la seguente eccezione:
                Non è stato possibile leggere se ci siano righe con msg_state = 'UNP' in tabella.
                Eccezione-> {exc}"""
                )
            else:
                rr = self.cursor.fetchall()
                if rr:
                    template = f"""
                    <p>Buongiorno,</br></br>
                    Attenzione, ci sono {len(rr)} righe della tabella in stato diverso da 'PRC'.</br>
                    Si consiglia di verificare prima di lanciare nuove esecuzioni.</br></br>

                    Buon lavoro, </br>
                    Team DPE TECH
                    </p>"""
                    testo_mail_errors = JinjaTemplate(template=template).run()
                    SendMail(conf="mail_server").run(
                        {
                            "from": MAIL_FROM,
                            "to": MAIL_TO,
                            "cc": [],
                            "subject": SUBJECT,
                            "msg": testo_mail_errors,
                        }
                    )
                    return False
                else:
                    return True

            finally:
                if self.dbconn:
                    self.closeDB()


with Flow("Affrancamento_AFB_ingest") as flow:

    cfu = CheckForUNPState(db="db_clc")
    cfued = cfu()

    with case(cfued, True):

        read_vista = ReadDB(
            name="ReadVISTA",
            db="db_clc",
            schema=SCHEMA_VISTA,
            query=QUERY_VISTA,
        )
        readed_vista = read_vista(params=())

        with case(bool(readed_vista["data"]), True):

            source_path = fake_filename_dinamico()

            ingest_vista = Ingest_Vista(
                db="db_clc",
                provider="",
                feed="",
            )
            ingested_vista = ingest_vista(data=readed_vista, source_path=source_path)

            with case(Trued(wait=ingested_vista), True):
                start_flow_run(flow_name="Affrancamento_AFB_process", project_name="azimut")


if __name__ == "__main__":

    flow.run()
