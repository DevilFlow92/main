"""Process."""
from typing import Any, Dict, List, Optional

import pyodbc
import requests
from prefect import case
from prefect.tasks.templates import JinjaTemplate
from pymol.ext.auth import from_vault
from pymol.jobs import BusinessStateError, Flow, SendMail, Transition, TransitionResult
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.exceptions import BusinessValueError
from pymol.validation import Coerce, Schema, to_stripped_string

# tabella di ingest in cui viene salvata la vista che ha
# tutte le informazioni utili alla Transition
INGEST_TABLE = "scratch.VISTA_L_CESAM_Import_Affrancamento_ProvvistaAFB"

QUERY = f"""
SELECT Id, msg_state FROM {INGEST_TABLE} iia WHERE iia.msg_state <> 'PRC'
"""

SCHEMA = Schema(
    {
        "Id": Coerce(int),
        "msg_state": Coerce(to_stripped_string()),
    }
)

template = """
<p>Buongiorno,</br></br>
Attenzione, alcune righe non sono state completamente processate dal flusso 'Affrancamento_AFB_process'.</br>
Verificare gli errori in tabella.</br></br>

Buon lavoro, </br>
Team DPE TECH
</p>
"""

MAIL_FROM = "noreply_pycc@gruppomol.it"
MAIL_TO = ["ReportDpeCesam@gruppomol.it"]
MAIL_CC = ["dpe_tech@gruppomol.it"]
SUBJECT = "Errore Flusso Affrancamento_AFB_process"


# Response status code handlers
def check_response(
    host: Any,
    endpoint: str,
    response: requests.Response,
    whitelist: List[int] = [200, 204, 404, 400],
    raising: bool = True,
) -> Optional[bool]:
    """Check response status code is in whitelist, raise Error as default."""
    if response.status_code not in whitelist:
        if raising:
            raise BusinessValueError(f"{host}{endpoint}, {response.status_code=}, {response.content=}")
        else:
            return False
    else:
        return True


class CleanTable(Task):
    def __init__(
        self,
        db: str,
        **kwargs: Any,
    ) -> None:  # noqa
        self.db_ = db
        super().__init__(max_retries=MAX_RETRIES, retry_delay=RETRY_DELAY, **kwargs)

    def open(self) -> None:  # noqa
        auth_db = from_vault(self.db_)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:  # noqa
        self.dbconn.close()

    def run(self, table: str) -> bool:  # noqa  # noqa
        with self.log.start_action(self.name):
            ok = False
            self.open()
            # output: List[Any] = []
            errors = []
            try:
                query = f"""
                TRUNCATE TABLE {table}"""
                self.cursor.execute(query)
            except Exception as exc:
                self.dbconn.rollback()
                errors.append(exc)
                self.logger.warning(exc)
                raise BusinessValueError(
                    f"""
                ATTENZIONE-> Durante l'esecuzione del Task {self.name} si
                è verificata la seguente eccezione:
                No è stato possibile svuotare la tabella {table}
                Eccezione-> {exc}
                """
                )
            else:
                self.cursor.commit()
                ok = True
            finally:
                if self.dbconn:
                    self.close()
                return ok


# Se recupero l'IdIncarico con questa funzione significa che l'incarico è stato creato da questa transition
def aggiungi_o_aggiorna_dato_aggiuntivo_incarico_per_tipo(
    id_incarico: int, tipo: int, payload: Any, host: Any, headers: Any, msg_state: str
) -> TransitionResult:
    """Aggiungi o aggiorna dato aggiuntivo incarico per tipo."""
    # Cerca il dato aggiuntivo associato all'Incarico
    endpoint = f"Incarico/{id_incarico}/datoAggiuntivo"
    response = requests.get(f"{host}{endpoint}/{tipo}", headers=headers)
    check_response(host, endpoint, response)

    # Dato aggiuntivo non presente -> Inserisce il dato aggiuntivo
    if response.status_code == 404:
        response = requests.post(f"{host}{endpoint}", headers=headers, data=str(payload))
        check_response(host, endpoint, response, [200, 204])

    # Dato aggiuntivo presente -> Modifica il dato aggiuntivo
    elif response.status_code == 200:
        response = requests.put(f"{host}{endpoint}", headers=headers, data=str(payload))
        check_response(host, endpoint, response, [200, 204])

    return msg_state, {}, []


def recupera_IdIncarico(msg: Any, services: dict[str, Any]) -> dict[str, Any]:
    return {"IdIncarico": msg.IdIncarico}


def clean_payload(data: Dict) -> Dict:  # type: ignore
    """Se valore in tabella is NULL, esclude quel valore dal payload dell'API."""
    return {k: v for k, v in data.items() if v}


def CheckCampiInput(msg: Any, data: dict[str, Any], services: dict[str, Any]) -> TransitionResult:  # noqa C901

    if (
        msg.IdIncarico
        and msg.CodiceCliente
        and msg.NumeroMandato
        and msg.TipologiaLavorazione
        and msg.Isin
        and msg.Imposta
        and msg.DirittoFisso
    ):
        return "S01", {}, []
    else:
        raise BusinessStateError(
            f"""
        ATTENZIONE-> Si è verificata la seguente eccezione:
        Alcuni campi della tabella {INGEST_TABLE},
        riga Id -> {msg.Id} non sono valorizzati.
        """
        )


def DatiAggiuntivi_1817(msg: Any, data: dict[str, Any], services: dict[str, Any]) -> TransitionResult:
    host, headers = services["api_qtask"]["host"], services["api_qtask"]["headers"]
    headers["Content-Type"] = "application/json; charset=utf-8"

    if msg.TipologiaLavorazione:
        raw_payload = {
            "CodTipoDatoAggiuntivo": 1817,
            "Testo": msg.TipologiaLavorazione,
        }
        payload = clean_payload(raw_payload)
        return aggiungi_o_aggiorna_dato_aggiuntivo_incarico_per_tipo(
            id_incarico=msg.IdIncarico,
            tipo=1817,
            payload=str(payload),
            host=host,
            headers=headers,
            msg_state="S02",
        )
    else:
        return "S02", {}, []


def PagamentoInvestimento(msg: Any, data: dict[str, Any], services: dict[str, Any]) -> TransitionResult:
    cursor = services["db_clc"]["cursor"]
    try:
        # pass

        cursor.execute(
            """
            INSERT INTO dbo.T_PagamentoInvestimento (IdIncarico, Importo, CodiceOperazione, FlagEffettuato, FlagAttivo)
            VALUES (?, ?, ?, 0, 1)""",
            msg.IdIncarico,
            msg.Imposta,
            msg.Isin,
        )

    except Exception as exc:
        services["db_clc"]["conn"].rollback()
        raise BusinessStateError(
            f"""
            ATTENZIONE-> Si è verificata la seguente eccezione:
            Fallito inserimento riga nella dbo.T_PagamentoInvestimento
            Eccezione-> {exc}"""
        )
    else:
        cursor.commit()
        return "S03", {}, []


def DatiAggiuntivi_2935(msg: Any, data: dict[str, Any], services: dict[str, Any]) -> TransitionResult:
    host, headers = services["api_qtask"]["host"], services["api_qtask"]["headers"]
    headers["Content-Type"] = "application/json; charset=utf-8"
    if msg.DirittoFisso:
        raw_payload = {
            "CodTipoDatoAggiuntivo": 2935,
            "Testo": msg.DirittoFisso,
        }
        payload = clean_payload(raw_payload)
        return aggiungi_o_aggiorna_dato_aggiuntivo_incarico_per_tipo(
            id_incarico=msg.IdIncarico,
            tipo=2935,
            payload=str(payload),
            host=host,
            headers=headers,
            msg_state="PRC",
        )
    else:
        return "PRC", {}, []


def Workflow_30146(msg: Any, data: dict[str, Any], services: dict[str, Any]) -> TransitionResult:
    host, headers = services["api_qtask"]["host"], services["api_qtask"]["headers"]
    headers["Content-Type"] = "application/json; charset=utf-8"
    endpoint = f"{host}Incarico/{msg.IdIncarico}/statoWorkflow/30146"
    res = requests.put(endpoint, headers=headers)
    if res.status_code not in (200, 204):
        raise BusinessStateError(
            f"Id {msg.Id} Chiamata API fallita - update codStatoWF -- {res.status_code} {res.text}"
        )
    else:
        return "PRC", {}, []


with Flow(name="Affrancamento_AFB_process") as flow:

    process = Transition(
        db_label="db_clc",
        services={"db_clc", "api_qtask"},
        states={
            "UNP": (CheckCampiInput, None),
            "ERR": (CheckCampiInput, None),
            "S01": (DatiAggiuntivi_1817, recupera_IdIncarico),
            "S02": (PagamentoInvestimento, recupera_IdIncarico),
            "S03": (DatiAggiuntivi_2935, recupera_IdIncarico),
        },
        state_table=INGEST_TABLE,
        state_column="msg_state",
        id_column="Id",
    )
    process_data = process(ext_params={})
    with case(process_data[0]["meta"]["hasErrors"], False):
        process2 = Transition(
            db_label="db_clc",
            services={"db_clc", "api_qtask"},
            states={
                "UNP": (Workflow_30146, None),
                "ERR": (Workflow_30146, None),
            },
            state_table=INGEST_TABLE,
            state_column="msg_state_2",
            id_column="Id",
        )
        process_data2 = process2(ext_params={})

        with case(process_data2[0]["meta"]["hasErrors"], True):
            jinja = JinjaTemplate(template=template)
            jinjaed = jinja()

            send_mail = SendMail(conf="mail_server")
            sended_mail = send_mail(
                {
                    "from": MAIL_FROM,
                    "to": MAIL_TO,
                    "cc": MAIL_CC,
                    "subject": SUBJECT,
                    "msg": jinjaed,
                }
            )

    with case(process_data[0]["meta"]["hasErrors"], True):
        jinja = JinjaTemplate(template=template)
        jinjaed = jinja()

        send_mail = SendMail(conf="mail_server")
        sended_mail = send_mail(
            {
                "from": MAIL_FROM,
                "to": MAIL_TO,
                "cc": MAIL_CC,
                "subject": SUBJECT,
                "msg": jinjaed,
            }
        )


if __name__ == "__main__":

    flow.run()
