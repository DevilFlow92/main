import json
import sys
from typing import Any

import requests
from prefect import Parameter, case, task
from prefect.tasks.templates import JinjaTemplate, StringFormatter
from pymol.auth import from_vault, qtask_token
from pymol.jobs import (
    DetectDelivery,
    DownloadRemoteFiles,
    Flow,
    IngestFeed,
    ReadCsvDelivery,
    ReadDB,
    SendMail,
    WriteCsv,
    shift_date,
)
from pymol.types.jobs import DataRow, TaskData

from cesam.azimut.rules import RULES, SCHEMA


class IngestAnagrafiche(IngestFeed):
    def get_msgtype(self, msg: DataRow, extra_values: DataRow, task_meta: dict[str, Any] = {}) -> str | None:
        """Torna il msg_type o uno SchemaError."""
        return "ANA"

    def get_routing_tags(self, values: DataRow, extra_values: DataRow, task_meta: dict[str, Any]) -> list[str]:
        return []

    def get_msgvalues(self, values: DataRow, extra_values: DataRow, task_meta: dict[str, Any]) -> tuple[str, DataRow]:
        return "scratch.L_CESAM_AZ_ImportAnagrafica_Azimut", values


def get_CodiceFiscale_Piva(row: dict[str, Any]) -> tuple[str, str]:
    cod_fiscale = row["CodiceFiscaleImport"] if int(row["CodTipoPersona"]) == 1 else row["PartitaIVAImport"]
    if "CodTipoPersona" not in row.keys():
        raise ValueError(f"CodTipoPersona non presente nel dataset {row}")

    key_codicefiscale = "CodiceFiscale" if row["CodTipoPersona"] == "1" else "PartitaIva"
    return cod_fiscale, key_codicefiscale


@task
def call_api(data: TaskData) -> TaskData:

    conf = from_vault("api_cesam")
    headers, _ = qtask_token(conf)
    headers["Content-Type"] = "application/json"
    base_url = conf["host"]
    output = []
    hasErrors = False
    if len(data["data"]) == 0:
        raise ValueError("Nessuna riga estrapolata dalla vista")

    if len(data["errors"]) > 0:
        hasErrors = True
        for row in data["errors"]:
            cod_fiscale, key_codicefiscale = get_CodiceFiscale_Piva(row)  # type:ignore
            output.append(
                {
                    "IdPersona": row["IdPersona"],  # type:ignore
                    "CodiceFiscale_Piva": cod_fiscale,
                    "errore": "Errore di validazione",
                }
            )

    for row in data["data"]:  # type:ignore
        cod_fiscale, key_codicefiscale = get_CodiceFiscale_Piva(row)  # type:ignore
        row_ = {
            "CodCliente": 23,
            key_codicefiscale: cod_fiscale,
            "CodTipoPersona": row["CodTipoPersona"],  # type:ignore
        }

        rsp = requests.put(
            f'{base_url}Persona/{row["IdPersona"]}',  # type:ignore
            data=json.dumps(row_),
            headers=headers,
        )
        if not str(rsp.status_code).startswith("2"):
            hasErrors = True
            output.append(
                {
                    "IdPersona": row["IdPersona"],  # type:ignore
                    "CodiceFiscale_Piva": cod_fiscale,
                    "errore": rsp.content.decode("utf-8"),
                }
            )
    return {"data": output, "errors": [], "meta": data["meta"] | {"hasErrors": hasErrors}}


@task
def get_file(data: TaskData) -> str:
    if data["meta"]["hasErrors"]:
        return str(data["data"][0]["path"])
    else:
        return ""


@task
def wait(local_file: TaskData) -> bool:
    return True


MAIL_TEMPLATE = """
    <!DOCTYPE html>
            <html>
            <head>
            <style>
            #pratiche {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
            }

            #pratiche td, #pratiche th {
            border: 1px solid #ddd;
            padding: 8px;
            }

            #pratiche tr:nth-child(even){background-color: #f2f2f2;}

            #pratiche tr:hover {background-color: #ddd;}

            #pratiche th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
            }
            </style>
            </head>
            <body>
    <p>Buongiorno,</p>
        <p>Si sono verificati degli errori nell'importazione delle anagrafiche azimut.<p/>
        <p>Di seguito, la lista degli errori:</p>
            <table id="pratiche">
            <tbody>
            <tr>
            <td><strong>IdPersona</strong></td>
            <td><strong>CodiceFiscale_Piva</strong></td>
            <td><strong>errore</strong></td>
            </tr>
            {% for row in data %}
                    <tr>
                    <td>{{row["IdPersona"]}}</td>
                    <td>{{row["CodiceFiscale_Piva"]}}</td>
                    <td>{{row["errore"]}}</td>
                    </tr>
            {% endfor %}
            </tbody>
            </table>
    <p>Saluti,<br>Team PyCC</p>
    </table>
    </body>
    </html>"""


with Flow("ingest anagrafiche") as flow:
    feed_date_ = Parameter("on_date", default="")
    shift_days_ = Parameter("shift_days", default="0")
    date_ = shift_date(feed_date_, shift_days_, skip_weekends=True)

    detect_delivery = DetectDelivery(
        repo_label="share_azimut",
        repo_path="CESAM/Azimut/ImportAnagraficaAzimut",
        source_label="source_azimut",
        rule={
            r"Anagr_Azimut_(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_0915\.csv",
        },
    )

    delivery_files = detect_delivery(feed_date=date_)

    with case(delivery_files["meta"]["isEmpty"], False):
        download = DownloadRemoteFiles(
            auth_label="share_azimut",
        )
        downloaded_files = download(delivery_files)

        read_dynamic_csv = ReadCsvDelivery(rule=RULES, options={"delimiter": ";"})
        input_data = read_dynamic_csv(data=downloaded_files["data"][0])

        ingest = IngestAnagrafiche(
            db="db_clc_cesam",
            provider="azimut",
            feed="",
            rules=RULES,
            scrap_tags=("alert",),
        )
        res = ingest(data=input_data)

        read_ = ReadDB(
            schema=SCHEMA, db="db_clc_w", query="SELECT * FROM rs.v_CESAM_AZ_AnagraficaClienti_Aggiornamento"
        )
        read_data = read_(params=(), upstream_tasks=[res])

        call_api_ = call_api(data=read_data)

        create_file = WriteCsv(
            fields=["IdPersona", "CodiceFiscale", "errore"],
            filename="report_azimut_import_anagrafiche.csv",
            date_in_filename="%Y%m%d",
            headless=False,
        )
        file_created = create_file(data=call_api_)
        local_file = get_file(data=file_created)

        with case(wait(local_file), True):
            subject = "Import Anagrafiche Azimut"

            with case(call_api_["meta"]["hasErrors"], True):
                render_template = JinjaTemplate(template=MAIL_TEMPLATE)
                body = render_template(data=call_api_["data"])

                send = SendMail(conf="mail_server")
                send(
                    {
                        "subject": subject,
                        "from": "info.cesam@gruppomol.it",
                        "to": ["lorenzo.fiori@gruppomol.it", "ReportDPECESAM@gruppomol.it"],
                        "cc": ["franco.atzori@gruppomol.it"],
                        "msg": body,
                        "attachments": [local_file],
                    }
                )

            with case(call_api_["meta"]["hasErrors"], False):
                message = (
                    "<p>Ciao,</p>"
                    "<p>importazione delle anagrafiche azimut avvenuta con successo.</p>"
                    "<p>Saluti, PyCC Team,</p>"
                )

                msg_task_get = StringFormatter(name="message body", template=message)
                body = msg_task_get()
                send = SendMail(conf="mail_server")
                send(
                    {
                        "subject": subject,
                        "from": "info.cesam@gruppomol.it",
                        "to": ["lorenzo.fiori@gruppomol.it", "ReportDPECESAM@gruppomol.it"],
                        "cc": ["franco.atzori@gruppomol.it"],
                        "msg": body,
                    }
                )

if __name__ == "__main__":
    if len(sys.argv) == 1:
        flow.run()
    else:
        flow.run(parameters={"on_date": sys.argv[1]})
