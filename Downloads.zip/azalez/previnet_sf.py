import tempfile
from datetime import datetime, timedelta
from os import path, walk
from pathlib import Path, PosixPath
from shutil import make_archive, rmtree
from tempfile import mkdtemp
from typing import Any, cast

import pyodbc
import requests
from prefect import case, task
from prefect.tasks.templates import JinjaTemplate
from pymol.auth import from_vault
from pymol.ext.services import service
from pymol.jobs import Flow, ReadDB, SendMail, UploadFiles
from pymol.jobs.core import MAX_RETRIES, RETRY_DELAY, Task
from pymol.types.jobs import DataRow, ErrorRow, TaskData
from pymol.validation import Coerce, Or, Schema, to_datetime
from PyPDF4 import PdfFileMerger, PdfFileReader, PdfFileWriter  # type: ignore

ERROR_MAIL_TEMPLATE = """
<p>Buongiorno,</br></br>
Si sono verificati errori nel trasferimento dei file Azimut verso l'sftp {{nomeftp}} di Previnet Fondo AZISF
</br></br>

<table>
  <tr>
    <th>Errore</th>
    <th>sulla riga</th>
  </tr>
    {% for line in errors %}
    <tr>
    <td>{{ line.error }}</td><td>{{ line.source }}</td>
    </tr>
    {% endfor %}
</table></br>

Buon lavoro, </br>
Team DPE TECH
</p>"""

SUCCESS_MAIL_TEMPLATE = """
<p>Buongiorno,</br></br>
I file relatvi all'export verso Previnet Fondo AZISF sono stati traferiti con successo sull'sftp {{nomeftp}}.
</br></br>

Buon lavoro, </br>
Team DPE TECH
</p>"""

SCHEMA = {
    "documento_id": int,
    "idincarico": int,
    "chiavecliente": str,
    "codtipoincarico": int,
    "descrizioneincarico": str,
    "tipo_documento": int,
    "nomefile_input": str,
    "idrepository": int,
    "percorsocompleto": str,
    "NamingCartellaZip": str,
    "ProgressivoZip": int,
    "nomedocumentopdf": str,
    "StringaCSV": str,
    "FlagUpload": bool,
    "DataUpload": Coerce(to_datetime(templates=["%Y-%m-%d %H:%M:%S.%f"])),
    "DescrizioneKO": Or(str, None),
    "NumeroMandato": Or(str, None),
}


@task
def nome_ftp() -> str:
    return from_vault("source_previnet")["host"]  # type: ignore


@task
def merge_errors(merge_data: TaskData, download_data: TaskData) -> TaskData:
    """Unisce gli errori di più task in un unico task."""
    errors: list[ErrorRow] = []
    for row in merge_data["errors"]:
        row_error = row.copy()
        row_error["source"].pop("file_pdf", None)
        errors.append(row_error)
    for row in download_data["errors"]:
        row_error = row.copy()
        row_error["source"].pop("file_pdf", None)
        errors.append(row_error)
    return {"data": cast(list[DataRow], errors), "errors": [], "meta": {"isEmpty": len(errors) == 0}}


@task
def merge_pdf(data: TaskData, output_merged_folder: str) -> TaskData:
    """Apre, mergia pdf e li ordina nelle cartelle corrette."""
    output, errors, meta = [], [], data["meta"].copy()
    for folder in data["data"]:
        try:
            merged_folder = f'{output_merged_folder}/{folder["naming_cartella_zip"][0]}_{folder["progressivo_zip"][0]}'
            Path(merged_folder).mkdir(parents=True, exist_ok=True)
            merger = PdfFileMerger()
            for file_path in folder["paths"]:
                try:
                    merger.append(str(file_path), pages=None, import_bookmarks=False)
                except Exception:  # nosec
                    maybe_seems_encrypted = PdfFileReader(str(file_path))
                    if maybe_seems_encrypted.isEncrypted:
                        maybe_seems_encrypted.decrypt("")
                        writer = PdfFileWriter()
                        writer.appendPagesFromReader(maybe_seems_encrypted)
                        with tempfile.NamedTemporaryFile(delete=False) as fp:  # todo, da testare con delete = True
                            writer.write(fp)
                            fp.flush()
                            fp.close()
                            merger.append(fp.name, pages=None, import_bookmarks=False)

            with open(path.join(merged_folder, f'{folder["nomedocumentopdf"]}.pdf'), "wb+") as fo:
                merger.write(fo)
                fo.flush()
                fo.close()
            merger.close()
            output.append(
                {
                    "nomedocumentopdf": folder["nomedocumentopdf"],
                    "path": path.join(merged_folder, f'{folder["nomedocumentopdf"]}.pdf'),
                    "stringhe_CSV": folder["stringhe_CSV"],
                    "merged_folder": merged_folder,
                    "id_documenti": folder["id_documenti"],
                }
            )
        except Exception as ex:
            errors.append({"error": str(ex), "source": folder})
    return {"data": output, "errors": cast(list[ErrorRow], errors), "meta": meta}


@task
def download_files(data: TaskData, output_download_dir: str) -> TaskData:
    output: list[DataRow] = []
    errors: list[ErrorRow] = []
    meta = data["meta"].copy()
    s = service("api_cesam")
    for row in data["data"]:
        res = requests.get(
            f"{s['host']}Incarico/{row['idincarico']}/documento/{row['documento_id']}/contenuto",  # type: ignore
            headers=s["headers"],  # type: ignore
        )
        if res.status_code == 200:
            folder = f'{output_download_dir}/{row["nomedocumentopdf"]}'
            Path(folder).mkdir(parents=True, exist_ok=True)
            all_nomedocumentopdf = [d["nomedocumentopdf"] for d in output]
            # lo etichettano "nome documento" ma è la cartella dentro cui salvare i pdf
            # che possono essere più di uno a parità di "nomedocumentopdf"
            if row["nomedocumentopdf"] not in all_nomedocumentopdf:
                # Write PDF to disk
                with open(f'{folder}/{row["nomefile_input"]}', "wb+") as f:
                    f.write(res.content)
                # Populate dictionary
                output.append(
                    {
                        "nomedocumentopdf": row["nomedocumentopdf"],
                        "file_pdf": [res.content],
                        "stringhe_CSV": set([row["StringaCSV"]]),
                        "id_documenti": [row["documento_id"]],
                        "amount_doc_to_merge": 1,
                        "nomefile_input": [row["nomefile_input"]],
                        "naming_cartella_zip": [row["NamingCartellaZip"]],
                        "progressivo_zip": [row["ProgressivoZip"]],
                        "paths": [Path(folder, row["nomefile_input"])],
                    }
                )
            else:
                for element in output:
                    if row["nomedocumentopdf"] == element["nomedocumentopdf"]:
                        # Update dictionary
                        element["file_pdf"].append(res.content)
                        element["stringhe_CSV"].add(row["StringaCSV"])
                        element["id_documenti"].append(row["documento_id"])
                        element["amount_doc_to_merge"] += 1
                        element["nomefile_input"].append(row["nomefile_input"])
                        element["naming_cartella_zip"].append(row["NamingCartellaZip"])
                        element["progressivo_zip"].append(row["ProgressivoZip"])
                        element["paths"].append(Path(folder, row["nomefile_input"]))
                        # Write PDF to disk
                        with open(f'{folder}/{row["nomefile_input"]}', "wb+") as f:
                            f.write(res.content)

        else:
            errors.append({"error": f"da api dl documento: {res.status_code}, {res.text} ", "source": row})

    return {"data": output, "errors": errors, "meta": meta}


@task
def exec_sp() -> bool:
    res = service("db_clc_cesam")
    try:
        cursor = res["cursor"]  # type: ignore
        cursor.execute("EXEC export.CESAM_AZ_Documenti_PREVINET_AZISF")  # type: ignore
        cursor.commit()  # type: ignore
    except Exception as ex:
        raise ValueError(f"Error executing SP: {ex}")
    finally:
        if "conn" in res:  # type: ignore
            res["conn"].close()  # type: ignore
    return True


@task
def write_txt(data: TaskData, output_root_folder: str) -> None:
    """Crea file txt contenente stringhe CSV."""
    for folder in data["data"]:
        merged_folder = f'{output_root_folder}/{folder["naming_cartella_zip"][0]}_{folder["progressivo_zip"][0]}'
        with open(path.join(merged_folder, "indice.txt"), "a") as fo:
            fo.write(str(folder["stringhe_CSV"].pop()))
            fo.write("\n")
            fo.flush()
            fo.close()


@task
def zip_file(output_root_folder: str, output_zip_dir: str) -> TaskData:
    """Zippa ogni sottocartella in output_root_folder e tiene traccia dei path."""
    output = []
    for _, dir_names, _ in walk(output_root_folder):
        for dir_name in dir_names:
            archive_name = f"{output_zip_dir}/{dir_name}"
            make_archive(archive_name, "zip", path.join(output_root_folder, dir_name))
            output.append(
                {
                    "path": PosixPath(f"{archive_name}.zip"),
                    "naming_cartella_zip": dir_name.rsplit(sep="_", maxsplit=1)[0],
                }
            )
    return {"data": output, "errors": [], "meta": {"isEmpty": len(output) == 0}}


@task
def mktempdirs() -> tuple[str, str, str]:
    output_download_dir = mkdtemp()
    output_merged_dir = mkdtemp()
    output_zip_dir = mkdtemp()
    return output_download_dir, output_merged_dir, output_zip_dir


@task
def rmtempdirs(output_download_dir: str, output_merged_dir: str, output_zip_dir: str) -> None:
    rmtree(output_download_dir)
    rmtree(output_merged_dir)
    rmtree(output_zip_dir)


class UpdateDB(Task):
    def __init__(
        self,
        db: str,
        max_retries: int = MAX_RETRIES,
        retry_delay: timedelta = RETRY_DELAY,
        **kwargs: Any,
    ) -> None:
        self.db = db
        super().__init__(max_retries=max_retries, retry_delay=retry_delay, **kwargs)

    def open(self) -> None:
        auth_db = from_vault(self.db)
        self.db_params = (
            f"DRIVER={auth_db['driver']};SERVER={auth_db['server']};"
            f"DATABASE={auth_db['database']};{auth_db['options']};Pooling=False"
        )
        self.dbconn = pyodbc.connect(self.db_params, autocommit=False)
        self.cursor = self.dbconn.cursor()

    def close(self) -> None:
        self.dbconn.close()

    def run(self, data: TaskData) -> None:  # type: ignore
        timestamp = datetime.now()
        with self.log.start_action(self.name), self.log.timed(self.name):
            seen = set()
            try:
                self.open()
                for row in data["data"]:
                    if row["naming_cartella_zip"] in seen:
                        continue
                    seen.add(row["naming_cartella_zip"])
                    self.cursor.execute(
                        """UPDATE [export].[CESAM_AZ_Previdenza_FlussoGiornaliero_Documenti_AZSustainableFuture]
                        SET FlagUpload = 1, DataUpload = ?
                        WHERE NamingCartellaZip=?""",
                        timestamp,
                        row["naming_cartella_zip"],
                    )
                self.cursor.commit()
            except Exception as ex:
                raise ValueError(f"Error opening connection: {ex}")
            finally:
                if self.dbconn:
                    self.close()


with Flow("Previnet Sustainable Future") as flow:
    output_download_dir, output_merged_dir, output_zip_dir = mktempdirs()

    sp_execution = exec_sp()

    readdb = ReadDB(
        schema=Schema(SCHEMA),
        db="db_clc_cesam",
        query="""SELECT *
        FROM [export].[CESAM_AZ_Previdenza_FlussoGiornaliero_Documenti_AZSustainableFuture] t
        WHERE t.FlagUpload = 0 AND t.NamingCartellaZip LIKE 'AZISF_%'""",
    )
    data = readdb(upstream_tasks=[sp_execution], params={})

    dir_paths = download_files(data, output_download_dir)

    merged_pdfs = merge_pdf(dir_paths, output_merged_dir, upstream_tasks=[dir_paths])

    file_txt = write_txt(dir_paths, output_merged_dir, upstream_tasks=[merged_pdfs])

    zipped_files = zip_file(output_merged_dir, output_zip_dir, upstream_tasks=[file_txt])

    errors = merge_errors(merged_pdfs, dir_paths)

    nomeftp = nome_ftp()
    with case(errors["meta"]["isEmpty"], False):
        template_mail = JinjaTemplate(template=ERROR_MAIL_TEMPLATE)
        body = template_mail(errors=errors["data"], nomeftp=nomeftp)

        sendmail = SendMail(name="KO Mail", conf="mail_server")
        sendmail(
            {
                "from": "noreply_dpeflows@gruppomol.it",
                "to": "lorenzo.fiori@gruppomol.it",
                "cc": "filippo.roggi@gruppomol.it",
                "subject": "[Error] - Export Azimut Previnet Fondo AZISF",
                "msg": body,
            }
        )

    with case(errors["meta"]["isEmpty"], True):
        upload = UploadFiles(name="upload file", auth_label="source_previnet")
        resup = upload(rows=zipped_files, dest_prefix="toPrevinet/")

        updatedb = UpdateDB(db="db_clc_cesam")
        resdb = updatedb(data=zipped_files, upstream_tasks=[resup])

        template_mail = JinjaTemplate(template=SUCCESS_MAIL_TEMPLATE)
        body = template_mail(nomeftp=nomeftp)

        sendmail = SendMail(name="OK Mail", conf="mail_server")
        sendmail(
            {
                "from": "info.cesam@gruppomol.it",
                "to": "reportdpecesam@gruppomol.it",
                "cc": "lorenzo.fiori@gruppomol.it,filippo.roggi@gruppomol.it",
                "subject": "[Success] - Export Azimut Previnet Fondo AZISF",
                "msg": body,
            },
            upstream_tasks=[resup, resdb],
        )

        rmtempdirs(output_download_dir, output_merged_dir, output_zip_dir, upstream_tasks=[resup])


if __name__ == "__main__":
    flow.run()
